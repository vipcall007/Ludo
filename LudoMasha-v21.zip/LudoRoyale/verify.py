#!/usr/bin/env python3
"""
Pre-build verification for LUDO MASHA.

This sandbox has no Android SDK or Gradle, so the real compiler cannot run
here. This script checks, statically, every class of mistake that has actually
broken a build on this project so far. Run it before packaging.

Exit code 0 = all checks pass, 1 = at least one problem found.
"""
import glob
import os
import re
import sys
import xml.dom.minidom

ROOT = os.path.dirname(os.path.abspath(__file__))
MAIN = os.path.join(ROOT, "app/src/main")
problems = []


def report(check, detail):
    problems.append(f"{check}: {detail}")


# ---------------------------------------------------------------- resources
def values_files():
    return glob.glob(os.path.join(MAIN, "res/values*/*.xml"))


def check_duplicate_resources():
    """Two <string name="x"> in one file fails mergeDebugResources."""
    for f in values_files():
        names = re.findall(r'name="([A-Za-z0-9_.]+)"', open(f, encoding="utf-8").read())
        seen, dupes = set(), set()
        for n in names:
            if n in seen:
                dupes.add(n)
            seen.add(n)
        for d in sorted(dupes):
            report("DUPLICATE RESOURCE", f"{os.path.basename(f)} defines '{d}' more than once")


def defined(kind):
    out = set()
    for f in values_files():
        src = open(f, encoding="utf-8").read()
        out |= set(re.findall(r'<' + kind + r'\s+name="([A-Za-z0-9_.]+)"', src))
    return out


def referenced(kind, rprefix):
    out = set()
    for f in glob.glob(os.path.join(ROOT, "app/src/**/*.kt"), recursive=True):
        out |= set(re.findall(r"R\." + rprefix + r"\.([A-Za-z0-9_]+)", open(f).read()))
    for f in glob.glob(os.path.join(MAIN, "res/**/*.xml"), recursive=True):
        out |= set(re.findall(r"@" + kind + r"/([A-Za-z0-9_.]+)", open(f, encoding="utf-8").read()))
    manifest = os.path.join(MAIN, "AndroidManifest.xml")
    out |= set(re.findall(r"@" + kind + r"/([A-Za-z0-9_.]+)", open(manifest, encoding="utf-8").read()))
    return out


def check_missing_resources():
    for kind, rprefix in [("string", "string"), ("color", "color")]:
        missing = referenced(kind, rprefix) - defined(kind)
        for m in sorted(missing):
            report("MISSING RESOURCE", f"@{kind}/{m} referenced but never defined")

    # drawables live as files, not <item> entries
    have = set()
    for d in glob.glob(os.path.join(MAIN, "res/drawable*")) + glob.glob(os.path.join(MAIN, "res/mipmap*")):
        for f in os.listdir(d):
            have.add(os.path.splitext(f)[0])
    used = referenced("drawable", "drawable") | referenced("mipmap", "mipmap")
    for m in sorted(used - have):
        report("MISSING RESOURCE", f"drawable/mipmap '{m}' referenced but no such file")


def check_ids():
    declared = set()
    for f in glob.glob(os.path.join(MAIN, "res/layout/*.xml")):
        declared |= set(re.findall(r'android:id="@\+id/([A-Za-z0-9_]+)"', open(f, encoding="utf-8").read()))
    used = set()
    for f in glob.glob(os.path.join(ROOT, "app/src/main/**/*.kt"), recursive=True):
        used |= set(re.findall(r"R\.id\.([A-Za-z0-9_]+)", open(f).read()))
    for m in sorted(used - declared):
        report("MISSING ID", f"R.id.{m} used in code but not in any layout")


# ------------------------------------------------------------------- kotlin
def kt_files():
    return glob.glob(os.path.join(ROOT, "app/src/**/*.kt"), recursive=True)


def check_duplicate_declarations():
    """Two 'private val x' in one class is a conflicting declaration."""
    for f in kt_files():
        decls = re.findall(r"^    (?:private |internal )?(?:lateinit )?va[lr] ([A-Za-z_][A-Za-z0-9_]*)",
                           open(f).read(), re.M)
        seen, dupes = set(), set()
        for d in decls:
            if d in seen:
                dupes.add(d)
            seen.add(d)
        for d in sorted(dupes):
            report("DUPLICATE DECLARATION", f"{os.path.basename(f)} declares '{d}' more than once")


def check_braces():
    for f in kt_files():
        src = open(f).read()
        if src.count("{") != src.count("}"):
            report("UNBALANCED BRACES", os.path.basename(f))


ANDROID_TYPES = {
    "android.widget": ["RadioGroup", "RadioButton", "CheckBox", "EditText", "TextView",
                       "Button", "FrameLayout", "LinearLayout", "ImageView", "Toast"],
    "android.view": ["View", "MotionEvent", "Gravity"],
    "android.graphics": ["Canvas", "Color", "Paint", "Path", "RectF", "Rect",
                         "LinearGradient", "RadialGradient", "Shader"],
    "android.content": ["Context", "Intent"],
    "android.content.res": ["ColorStateList"],
    "android.os": ["Bundle", "Handler", "Looper"],
    "android.util": ["AttributeSet"],
    "android.media": ["AudioAttributes", "AudioFormat", "AudioTrack"],
    "androidx.appcompat.app": ["AlertDialog", "AppCompatActivity"],
}


def check_imports():
    cls_to_pkg = {c: p for p, cs in ANDROID_TYPES.items() for c in cs}
    for f in kt_files():
        src = open(f).read()
        body = re.sub(r"^import .*$", "", src, flags=re.M)
        imported = {i.rsplit(".", 1)[1] for i in re.findall(r"^import ([\w.]+)", src, flags=re.M)}
        for cls, pkg in cls_to_pkg.items():
            if not re.search(r"\b" + cls + r"\b", body):
                continue
            if cls in imported or f"{pkg}.{cls}" in body:
                continue
            if re.search(r"\b(class|object|interface) " + cls + r"\b", src):
                continue
            report("MISSING IMPORT", f"{os.path.basename(f)} uses {cls} (needs {pkg}.{cls})")


def check_custom_views():
    """A view named in XML must exist as a class."""
    classes = set()
    for f in kt_files():
        for m in re.findall(r"^(?:class|object) ([A-Za-z0-9_]+)", open(f).read(), re.M):
            classes.add(m)
    for f in glob.glob(os.path.join(MAIN, "res/layout/*.xml")):
        for fq in re.findall(r"<(com\.example\.ludoroyale\.[A-Za-z0-9_.]+)", open(f, encoding="utf-8").read()):
            if fq.rsplit(".", 1)[1] not in classes:
                report("MISSING CLASS", f"{os.path.basename(f)} uses <{fq}> but no such class")


def check_manifest_activities():
    manifest = open(os.path.join(MAIN, "AndroidManifest.xml"), encoding="utf-8").read()
    classes = set()
    for f in kt_files():
        for m in re.findall(r"^class ([A-Za-z0-9_]+)", open(f).read(), re.M):
            classes.add(m)
    for name in re.findall(r'android:name="(\.[A-Za-z0-9_.]+)"', manifest):
        if name.rsplit(".", 1)[1] not in classes:
            report("MISSING ACTIVITY", f"manifest declares {name} but no such class")


def check_xml_wellformed():
    targets = glob.glob(os.path.join(MAIN, "res/**/*.xml"), recursive=True)
    targets.append(os.path.join(MAIN, "AndroidManifest.xml"))
    for f in targets:
        try:
            xml.dom.minidom.parse(f)
        except Exception as e:
            report("BAD XML", f"{os.path.relpath(f, ROOT)}: {e}")


def main():
    check_xml_wellformed()
    check_duplicate_resources()
    check_missing_resources()
    check_ids()
    check_duplicate_declarations()
    check_braces()
    check_imports()
    check_custom_views()
    check_manifest_activities()

    if problems:
        print(f"FAILED — {len(problems)} problem(s):\n")
        for p in problems:
            print("  " + p)
        return 1
    print("All pre-build checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
