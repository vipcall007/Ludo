package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/**
 * The backdrop behind every screen: deep blue water, a shaft of light from
 * above, faint caustic ribbons and a drift of bubbles. Drawn in code, so it
 * always renders and costs nothing to ship.
 */
class GameBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** x, y, radius — all as a fraction of the view, so it scales anywhere. */
    private val bubbles = mutableListOf<Triple<Float, Float, Float>>()
    private val ribbons = mutableListOf<FloatArray>()

    init {
        val rnd = Random(20260919)
        repeat(40) {
            bubbles += Triple(rnd.nextFloat(), rnd.nextFloat(), 0.003f + rnd.nextFloat() * 0.011f)
        }
        repeat(18) {
            ribbons += floatArrayOf(
                rnd.nextFloat(), rnd.nextFloat(),
                0.10f + rnd.nextFloat() * 0.28f,
                0.003f + rnd.nextFloat() * 0.007f,
                (14 + rnd.nextInt(20)).toFloat()
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        paint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                Color.rgb(0x15, 0x3C, 0x74),   // lit water near the surface
                Color.rgb(0x0E, 0x28, 0x55),
                Color.rgb(0x06, 0x12, 0x2E)    // deep shade at the bottom
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        // shaft of daylight coming down from the top
        paint.shader = RadialGradient(
            w * 0.5f, -h * 0.18f, h * 0.9f,
            intArrayOf(Color.argb(70, 0x7E, 0xD8, 0xF2), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // caustic ribbons
        for (r in ribbons) {
            val x = r[0] * w
            val y = r[1] * h
            val len = r[2] * w
            val amp = h * 0.010f
            stroke.color = Color.argb(r[4].toInt(), 0xCF, 0xF2, 0xFF)
            stroke.strokeWidth = r[3] * w
            val p = Path()
            p.moveTo(x, y)
            p.quadTo(x + len * 0.35f, y - amp, x + len * 0.7f, y)
            p.quadTo(x + len * 0.85f, y + amp, x + len, y - amp * 0.4f)
            canvas.drawPath(p, stroke)
        }

        // bubbles
        for ((fx, fy, fr) in bubbles) {
            val cx = fx * w
            val cy = fy * h
            val rr = fr * w
            paint.color = Color.argb(22, 255, 255, 255)
            canvas.drawCircle(cx, cy, rr, paint)
            paint.color = Color.argb(55, 255, 255, 255)
            canvas.drawCircle(cx - rr * 0.3f, cy - rr * 0.3f, rr * 0.28f, paint)
        }

        // corner vignette
        paint.shader = RadialGradient(
            w * 0.5f, h * 0.5f, maxOf(w, h) * 0.8f,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(120, 0, 0, 0)),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }
}
