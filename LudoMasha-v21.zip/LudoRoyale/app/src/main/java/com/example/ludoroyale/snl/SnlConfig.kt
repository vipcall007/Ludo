package com.example.ludoroyale.snl

import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialSize
import com.example.ludoroyale.engine.SpecialType

/**
 * One snake or ladder on the classic 1..100 board.
 *
 * [entryCell] is the square that fires it — a snake's head, a ladder's foot.
 * [exitCell] is where the piece ends up. A snake always carries a piece
 * backwards and a ladder always forwards, and both ends stay inside 2..99 so
 * a piece can never be pushed off the board or handed square 100 for free.
 */
data class SnlSpecial(
    val id: String,
    val type: SpecialType,
    val size: SpecialSize,
    val entryCell: Int,
    val exitCell: Int,
    /** Picks one of the drawn snake skins / ladder woods, so no two look alike. */
    val skin: Int = 0
) {
    val delta: Int get() = exitCell - entryCell
}

/**
 * Every snake and ladder of the standalone SNAKE & LADDER board lives here.
 * Nothing about their behaviour is baked into drawing code, so the board can
 * be retuned by editing this one table.
 *
 * Counts follow the specification exactly:
 *  EASY   — 3 snakes (2 small, 1 very large) and 6 ladders (1 very large, 2 medium, 3 small)
 *  MEDIUM — 6 small snakes and 6 small ladders
 *  HARD   — 8 mixed snakes and 5 ladders (1 very large, 2 medium, 2 small)
 */
object SnlConfig {

    const val LAST_CELL = 100
    const val COLUMNS = 10
    const val ROWS = 10

    /** Only one snake or ladder may fire per dice move — this is what stops loops. */
    const val MAX_SPECIAL_MOVEMENTS_PER_DICE_MOVE = 1

    private fun snake(id: String, size: SpecialSize, head: Int, tail: Int, skin: Int) =
        SnlSpecial(id, SpecialType.SNAKE, size, head, tail, skin)

    private fun ladder(id: String, size: SpecialSize, foot: Int, top: Int, skin: Int) =
        SnlSpecial(id, SpecialType.LADDER, size, foot, top, skin)

    private val EASY: List<SnlSpecial> = listOf(
        snake("e_s1", SpecialSize.SMALL, 41, 20, 0),
        snake("e_s2", SpecialSize.SMALL, 64, 42, 1),
        // the showpiece: a very large snake coiling down the upper board
        snake("e_s3", SpecialSize.VERY_LARGE, 71, 11, 2),

        ladder("e_l1", SpecialSize.VERY_LARGE, 16, 74, 0),
        ladder("e_l2", SpecialSize.MEDIUM, 66, 97, 1),
        ladder("e_l3", SpecialSize.MEDIUM, 5, 38, 2),
        ladder("e_l4", SpecialSize.SMALL, 8, 28, 0),
        ladder("e_l5", SpecialSize.SMALL, 68, 89, 1),
        ladder("e_l6", SpecialSize.SMALL, 80, 99, 2)
    )

    private val MEDIUM: List<SnlSpecial> = listOf(
        snake("m_s1", SpecialSize.SMALL, 72, 49, 0),
        snake("m_s2", SpecialSize.SMALL, 85, 63, 1),
        snake("m_s3", SpecialSize.SMALL, 26, 4, 2),
        snake("m_s4", SpecialSize.SMALL, 61, 41, 3),
        snake("m_s5", SpecialSize.SMALL, 22, 2, 4),
        snake("m_s6", SpecialSize.SMALL, 57, 38, 5),

        ladder("m_l1", SpecialSize.SMALL, 74, 94, 0),
        ladder("m_l2", SpecialSize.SMALL, 9, 27, 1),
        ladder("m_l3", SpecialSize.SMALL, 80, 99, 2),
        ladder("m_l4", SpecialSize.SMALL, 46, 66, 0),
        ladder("m_l5", SpecialSize.SMALL, 71, 91, 1),
        ladder("m_l6", SpecialSize.SMALL, 30, 50, 2)
    )

    private val HARD: List<SnlSpecial> = listOf(
        snake("h_s1", SpecialSize.SMALL, 46, 25, 0),
        snake("h_s2", SpecialSize.SMALL, 88, 66, 1),
        snake("h_s3", SpecialSize.MEDIUM, 97, 63, 2),
        snake("h_s4", SpecialSize.MEDIUM, 67, 33, 3),
        snake("h_s5", SpecialSize.MEDIUM, 34, 8, 4),
        snake("h_s6", SpecialSize.LARGE, 51, 10, 5),
        snake("h_s7", SpecialSize.LARGE, 60, 20, 0),
        snake("h_s8", SpecialSize.VERY_LARGE, 83, 22, 1),

        ladder("h_l1", SpecialSize.VERY_LARGE, 30, 91, 0),
        ladder("h_l2", SpecialSize.MEDIUM, 4, 38, 1),
        ladder("h_l3", SpecialSize.MEDIUM, 45, 76, 2),
        ladder("h_l4", SpecialSize.SMALL, 61, 81, 0),
        ladder("h_l5", SpecialSize.SMALL, 71, 92, 1)
    )

    fun specialsFor(difficulty: SnakeDifficulty): List<SnlSpecial> = when (difficulty) {
        SnakeDifficulty.EASY -> EASY
        SnakeDifficulty.MEDIUM -> MEDIUM
        SnakeDifficulty.HARD -> HARD
    }

    /**
     * The special a piece has LANDED on, or null. Landing is exact, so passing
     * over a snake head or a ladder foot can never fire it.
     */
    fun specialAt(difficulty: SnakeDifficulty, cell: Int): SnlSpecial? =
        specialsFor(difficulty).firstOrNull { it.entryCell == cell }

    /**
     * Fairness check, also asserted by the unit tests:
     *  - no two specials share an entry square
     *  - no exit sits on another entry (that would chain two shortcuts)
     *  - every end stays inside 2..99, so square 100 still needs an exact roll
     *  - snakes always go down, ladders always go up
     */
    fun isSane(difficulty: SnakeDifficulty): Boolean {
        val list = specialsFor(difficulty)
        val entries = list.map { it.entryCell }.toSet()
        if (entries.size != list.size) return false
        if (list.any { it.exitCell in entries }) return false
        if (list.any { it.entryCell !in 2..99 || it.exitCell !in 2..99 }) return false
        if (list.any { it.type == SpecialType.SNAKE && it.delta >= 0 }) return false
        if (list.any { it.type == SpecialType.LADDER && it.delta <= 0 }) return false
        return true
    }

    // ---------------------------------------------------------------- layout

    /**
     * Board coordinates for a square, boustrophedon exactly like the printed
     * game: 1 is the bottom-left corner, the first row runs left to right, the
     * next row runs right to left, and 100 ends up top-left.
     *
     * Returns (row, col) with row 0 at the TOP of the screen and col 0 on the
     * left, both 0..9 — ready to multiply by the on-screen cell size.
     */
    fun cellToGrid(cell: Int): Pair<Int, Int> {
        val c = cell.coerceIn(1, LAST_CELL)
        val indexFromBottom = c - 1
        val rowFromBottom = indexFromBottom / COLUMNS
        val within = indexFromBottom % COLUMNS
        val col = if (rowFromBottom % 2 == 0) within else COLUMNS - 1 - within
        val row = ROWS - 1 - rowFromBottom
        return row to col
    }
}
