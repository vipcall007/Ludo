package com.example.ludoroyale.engine

data class RuleConfig(
    val extraTurnOnSix: Boolean = true,
    val threeSixCancelsTurn: Boolean = true,
    val captureGrantsExtraTurn: Boolean = true,
    /** Sending one of your pieces home also earns another roll. */
    val finishGrantsExtraTurn: Boolean = true,
    val exactRollToFinish: Boolean = true,
    val safeCellsBlockCapture: Boolean = true,
    val sixRequiredToLeaveBase: Boolean = true,

    /**
     * QUICK MODE: a much faster game.
     *  - each player starts with TWO tokens already on the board
     *  - HOME stays LOCKED until that player captures an opponent
     *  - the first player with 1 kill AND 1 token home wins outright
     */
    val quickMode: Boolean = false,

    /** LUDO SNAKE MODE: snakes and ladders act as shortcuts on the Ludo route. */
    val snakeMode: Boolean = false,
    val snakeDifficulty: SnakeDifficulty = SnakeDifficulty.EASY,

    /** Consecutive sixes allowed before the turn is forfeited. */
    val maxConsecutiveSixes: Int = 3,

    /** TEAM MODE (2v2): partners sit opposite each other and cannot capture
     *  their own team's pieces. */
    val teamMode: Boolean = false,

    /** Openly-labelled "lucky dice": rolls the die twice and keeps the higher
     *  face, so sixes and captures happen more often. Applied identically to
     *  EVERY player — it speeds the game up, it does not favour anyone. */
    val luckyDice: Boolean = false
)
