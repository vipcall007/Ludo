package com.example.ludoroyale

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Original sound effects synthesised on the fly (sine tones rendered into an
 * AudioTrack) — no audio files bundled, nothing copied, and far more reliable
 * than ToneGenerator, which was silent on some phones.
 */
object SoundFx {

    private const val RATE = 22050
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    /** [freq] start pitch; [endFreq] slides to it when set (comic slides, whoops). */
    private data class Note(val freq: Double, val ms: Int, val vol: Double = 0.55, val endFreq: Double = -1.0)

    var enabled: Boolean = true
        set(value) {
            field = value
            if (!value) stopMusic() else if (musicWanted) startMusic()
        }

    // ---------- background music ----------

    private var musicTrack: AudioTrack? = null
    private var musicWanted = false

    /**
     * A calm looping background bed, synthesised rather than shipped as a file:
     * a slow pentatonic arpeggio over a soft pad, rendered once into a seamless
     * ~8 second buffer and then hardware-looped, so it costs no APK size and
     * almost no CPU.
     */
    fun startMusic() {
        musicWanted = true
        if (!enabled || musicTrack != null) return
        exec.execute {
            try {
                val seconds = 8
                val n = RATE * seconds
                val buf = DoubleArray(n)

                // gentle pad: two detuned low notes held throughout
                for (i in 0 until n) {
                    val t = i.toDouble() / RATE
                    buf[i] += sin(2.0 * PI * 110.0 * t) * 0.05
                    buf[i] += sin(2.0 * PI * 110.6 * t) * 0.05
                    buf[i] += sin(2.0 * PI * 164.8 * t) * 0.035
                }

                // slow arpeggio, C pentatonic, one note every half second
                val notes = doubleArrayOf(523.3, 587.3, 659.3, 784.0, 880.0, 784.0, 659.3, 587.3)
                val noteLen = RATE / 2
                var idx = 0
                var k = 0
                while (idx < n) {
                    val f = notes[k % notes.size]
                    val count = minOf(noteLen, n - idx)
                    for (i in 0 until count) {
                        val t = i.toDouble() / RATE
                        // soft pluck: quick attack, long decay
                        val env = Math.exp(-t * 3.2) * (1.0 - Math.exp(-t * 90.0))
                        buf[idx + i] += sin(2.0 * PI * f * t) * env * 0.09
                    }
                    idx += noteLen
                    k++
                }

                // fade the seam so the loop joins cleanly
                val seam = RATE / 8
                for (i in 0 until seam) {
                    val g = i.toDouble() / seam
                    buf[i] *= g
                    buf[n - 1 - i] *= g
                }

                val pcm = ShortArray(n)
                for (i in 0 until n) pcm[i] =
                    (buf[i].coerceIn(-1.0, 1.0) * 0.55 * Short.MAX_VALUE).toInt().toShort()

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.setLoopPoints(0, pcm.size, -1)     // -1 = loop forever
                track.setVolume(0.35f)
                track.play()
                musicTrack = track
            } catch (_: Exception) { }
        }
    }

    fun stopMusic() {
        musicWanted = false
        try { musicTrack?.stop(); musicTrack?.release() } catch (_: Exception) { }
        musicTrack = null
    }

    /** Pause the music without forgetting that the player wants it on. */
    fun pauseMusic() {
        try { musicTrack?.pause() } catch (_: Exception) { }
    }

    fun resumeMusic() {
        if (!enabled || !musicWanted) return
        try { musicTrack?.play() } catch (_: Exception) { }
    }

    // ---- public effects ----

    fun gameStart() = play(
        listOf(
            Note(523.0, 120), Note(659.0, 120), Note(784.0, 120), Note(1047.0, 300, 0.6)
        )
    )

    /**
     * A plain, realistic dice roll: a handful of wooden taps as the cube
     * tumbles, slowing down, then one last settle. Short, dry, no ringing —
     * each tap is a quick noise burst shaped like a knock rather than a tone.
     */
    fun diceRoll() {
        if (!enabled) return
        exec.execute {
            try {
                val totalMs = 620
                val n = RATE * totalMs / 1000
                val buf = DoubleArray(n)
                val rnd = java.util.Random()

                // taps get further apart as the cube loses speed
                val taps = mutableListOf<Int>()
                var at = 15
                var gap = 55
                while (at < totalMs - 120) {
                    taps += at
                    at += gap
                    gap = (gap * 1.28).toInt().coerceAtMost(170)
                }
                taps += totalMs - 110      // final settle

                for ((i, tap) in taps.withIndex()) {
                    val isLast = i == taps.lastIndex
                    val lenMs = if (isLast) 90 else 38
                    val amp = if (isLast) 0.60 else 0.30 * (1.0 - i.toDouble() / taps.size * 0.5)
                    val start = RATE * tap / 1000
                    val count = RATE * lenMs / 1000
                    var lp = 0.0
                    for (k in 0 until count) {
                        val idx = start + k
                        if (idx >= n) break
                        // low-passed noise = wood knock, not a beep
                        lp = lp * 0.72 + rnd.nextGaussian() * 0.28
                        val decay = Math.exp(-k.toDouble() / RATE * (if (isLast) 38.0 else 95.0))
                        buf[idx] += lp * decay * amp
                    }
                }

                val out = ShortArray(n)
                for (i in 0 until n) out[i] =
                    (buf[i].coerceIn(-1.0, 1.0) * 0.95 * Short.MAX_VALUE).toInt().toShort()
                writeAndPlay(out, totalMs)
            } catch (_: Exception) { }
        }
    }

    fun step() = play(listOf(Note(880.0, 28, 0.25)))

    fun tokenMove() = play(listOf(Note(700.0, 70, 0.4)))

    /** Comic "wah-wah-wahhh" slide when a piece gets cut. */
    fun capture() = play(
        listOf(
            Note(700.0, 150, 0.55, endFreq = 520.0),
            Note(560.0, 150, 0.55, endFreq = 410.0),
            Note(430.0, 420, 0.60, endFreq = 190.0)
        )
    )

    /** Ladder climb: a quick rising run of notes. */
    fun ladderClimb() = play(
        listOf(
            Note(392.0, 70, 0.40), Note(523.0, 70, 0.42),
            Note(659.0, 70, 0.44), Note(784.0, 150, 0.46)
        )
    )

    /** Snake slide: a falling swoop, like sliding back down. */
    fun snakeSlide() = play(
        listOf(
            Note(740.0, 120, 0.45, endFreq = 500.0),
            Note(500.0, 130, 0.45, endFreq = 330.0),
            Note(330.0, 220, 0.50, endFreq = 180.0)
        )
    )

    /** Sparkle for the arrow-mode magic jump. */
    fun magic() = play(
        listOf(
            Note(900.0, 45, 0.4), Note(1200.0, 45, 0.4), Note(1500.0, 45, 0.45),
            Note(1800.0, 60, 0.5), Note(2200.0, 120, 0.45)
        )
    )

    /** Full celebration fanfare on a win. */
    fun win() = play(
        listOf(
            Note(523.0, 130), Note(659.0, 130), Note(784.0, 130), Note(1047.0, 240, 0.62),
            Note(0.0, 70),
            Note(784.0, 110), Note(1047.0, 110), Note(1319.0, 520, 0.65, endFreq = 1568.0)
        )
    )

    /** Buzzer when three sixes burn the turn. */
    fun turnLost() = play(
        listOf(Note(200.0, 200, 0.55), Note(0.0, 50), Note(165.0, 280, 0.55))
    )

    fun arrow() = magic()

    // ---- synthesis ----

    private fun play(notes: List<Note>) {
        if (!enabled) return
        exec.execute {
            try {
                val totalMs = notes.sumOf { it.ms }
                val totalSamples = RATE * totalMs / 1000
                if (totalSamples <= 0) return@execute
                val buffer = ShortArray(totalSamples)

                var idx = 0
                for (note in notes) {
                    val count = min(RATE * note.ms / 1000, totalSamples - idx)
                    for (i in 0 until count) {
                        val t = i.toDouble() / RATE
                        val f = if (note.endFreq > 0.0)
                                    note.freq + (note.endFreq - note.freq) * (i.toDouble() / count)
                                else note.freq
                        val sample = if (f <= 0.0) 0.0
                                     else sin(2.0 * PI * f * t) * envelope(i, count) * note.vol
                        buffer[idx++] = (sample * Short.MAX_VALUE).toInt().toShort()
                    }
                    if (idx >= totalSamples) break
                }

                writeAndPlay(buffer, totalMs)
            } catch (_: Exception) {
                // never let a sound problem break the game
            }
        }
    }

    private fun writeAndPlay(buffer: ShortArray, totalMs: Int) {
        try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                handler.postDelayed({
                    try { track.stop(); track.release() } catch (_: Exception) { }
                }, (totalMs + 250).toLong())
        } catch (_: Exception) {
            // never let a sound problem break the game
        }
    }

    /** Short fade in/out so notes don't click. */
    private fun envelope(i: Int, count: Int): Double {
        if (count <= 1) return 0.0
        val fade = max(1, count / 12)
        val rise = min(1.0, i.toDouble() / fade)
        val fall = min(1.0, (count - 1 - i).toDouble() / fade)
        return min(rise, fall)
    }
}
