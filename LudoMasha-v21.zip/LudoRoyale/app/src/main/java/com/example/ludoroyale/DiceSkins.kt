package com.example.ludoroyale

import android.graphics.Color

/**
 * One dice design. Every value here is a colour, so the face is drawn in code
 * and stays sharp on any screen — there are no image files to ship.
 */
data class DiceSkin(
    val id: String,
    val label: String,
    /** Body gradient, top-left to bottom-right. */
    val top: Int,
    val bottom: Int,
    /** Bright inner bevel and the deeper outer border. */
    val bevel: Int,
    val border: Int,
    val pip: Int,
    /** Coins to unlock. 0 = free from the start. */
    val price: Int,
    /** 0 round pips, 1 rounded-square pips, 2 tiny star pips. */
    val pipStyle: Int = 0
)

/**
 * The dice collection. All of it is original artwork, unlocked with coins the
 * player earns by winning — there is nothing to buy with real money.
 */
object DiceSkins {

    const val DEFAULT_ID = "gold"

    val ALL: List<DiceSkin> = listOf(
        DiceSkin(
            "gold", "Royal Gold",
            Color.rgb(0xFF, 0xE3, 0x8A), Color.rgb(0xC8, 0x8B, 0x12),
            Color.rgb(0xFF, 0xF2, 0xBE), Color.rgb(0x8A, 0x5B, 0x00),
            Color.rgb(0x14, 0x11, 0x08), price = 0
        ),
        DiceSkin(
            "ivory", "Ivory",
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0xD3, 0xDB, 0xE6),
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0x8E, 0x9C, 0xB2),
            Color.rgb(0x1E, 0x28, 0x3C), price = 0
        ),
        DiceSkin(
            "ocean", "Ocean",
            Color.rgb(0x6B, 0xE0, 0xF2), Color.rgb(0x10, 0x7A, 0xA8),
            Color.rgb(0xC6, 0xF6, 0xFF), Color.rgb(0x08, 0x46, 0x66),
            Color.WHITE, price = 300
        ),
        DiceSkin(
            "coral", "Coral",
            Color.rgb(0xFF, 0x9E, 0xA8), Color.rgb(0xD1, 0x3A, 0x52),
            Color.rgb(0xFF, 0xD8, 0xDC), Color.rgb(0x7E, 0x16, 0x28),
            Color.rgb(0xFF, 0xF2, 0xE6), price = 500, pipStyle = 1
        ),
        DiceSkin(
            "emerald", "Emerald",
            Color.rgb(0x86, 0xE8, 0x9A), Color.rgb(0x18, 0x87, 0x45),
            Color.rgb(0xD2, 0xFA, 0xDA), Color.rgb(0x0B, 0x4A, 0x25),
            Color.rgb(0xF2, 0xFF, 0xF4), price = 700
        ),
        DiceSkin(
            "amber", "Amber",
            Color.rgb(0xFF, 0xC9, 0x70), Color.rgb(0xE0, 0x6E, 0x10),
            Color.rgb(0xFF, 0xEA, 0xC2), Color.rgb(0x8C, 0x3C, 0x04),
            Color.rgb(0x35, 0x1A, 0x02), price = 900, pipStyle = 1
        ),
        DiceSkin(
            "violet", "Violet",
            Color.rgb(0xC9, 0xAA, 0xFF), Color.rgb(0x63, 0x3B, 0xC8),
            Color.rgb(0xE8, 0xDA, 0xFF), Color.rgb(0x33, 0x1A, 0x78),
            Color.WHITE, price = 1200, pipStyle = 2
        ),
        DiceSkin(
            "midnight", "Midnight",
            Color.rgb(0x4A, 0x5C, 0x86), Color.rgb(0x13, 0x1D, 0x3A),
            Color.rgb(0x7E, 0x94, 0xC4), Color.rgb(0x07, 0x0C, 0x1E),
            Color.rgb(0xF2, 0xC1, 0x4E), price = 1500, pipStyle = 2
        ),
        DiceSkin(
            "reef", "Reef",
            Color.rgb(0x7E, 0xF0, 0xD2), Color.rgb(0x0E, 0x8E, 0x86),
            Color.rgb(0xCC, 0xFF, 0xF2), Color.rgb(0x06, 0x50, 0x4C),
            Color.rgb(0x05, 0x33, 0x30), price = 1800
        ),
        DiceSkin(
            "ruby", "Ruby",
            Color.rgb(0xFF, 0x7A, 0x7A), Color.rgb(0x9E, 0x0B, 0x22),
            Color.rgb(0xFF, 0xC8, 0xC8), Color.rgb(0x5A, 0x04, 0x12),
            Color.WHITE, price = 2200, pipStyle = 2
        ),
        DiceSkin(
            "sand", "Driftwood",
            Color.rgb(0xF0, 0xD8, 0xA8), Color.rgb(0xB0, 0x82, 0x44),
            Color.rgb(0xFF, 0xF0, 0xD4), Color.rgb(0x6B, 0x46, 0x18),
            Color.rgb(0x4A, 0x2E, 0x0C), price = 2600
        ),
        DiceSkin(
            "storm", "Storm",
            Color.rgb(0xB8, 0xC6, 0xD8), Color.rgb(0x46, 0x56, 0x6E),
            Color.rgb(0xE4, 0xEE, 0xFA), Color.rgb(0x22, 0x2E, 0x42),
            Color.rgb(0x10, 0x18, 0x28), price = 3000, pipStyle = 1
        )
    )

    fun byId(id: String): DiceSkin? = ALL.firstOrNull { it.id == id }

    fun free(): List<String> = ALL.filter { it.price == 0 }.map { it.id }

    fun resolve(id: String): DiceSkin = byId(id) ?: ALL.first()
}
