package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Covers the rules in the Quick Mode specification. */
class QuickModeTest {

    private fun twoPlayers(): GameState = GameState(
        gameId = "quick-test",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        )
    )

    private fun engine(state: GameState) = LudoEngine(state, RuleConfig(quickMode = true))

    private fun bank(state: GameState, vararg values: Int) {
        state.pendingRolls.clear()
        state.pendingRolls.addAll(values.toList())
        state.phase = TurnPhase.AWAITING_MOVE
        state.lastDiceRoll = values.lastOrNull()
    }

    /** Puts a yellow piece exactly where red will land after [roll] from [redSteps]. */
    private fun parkVictim(state: GameState, redSteps: Int, roll: Int): com.example.ludoroyale.model.Token {
        val target = LudoBoard.toGlobalIndex(PlayerColor.RED, redSteps + roll - 1)
        val victim = state.players[1].tokens[0]
        victim.state = TokenState.ACTIVE
        victim.steps = ((target - PlayerColor.YELLOW.startOffset + LudoBoard.TRACK_LENGTH)
            % LudoBoard.TRACK_LENGTH) + 1
        return victim
    }

    // ---- section 4/5: HOME is locked until a kill ----

    @Test
    fun `home is locked at the start of a quick match`() {
        val state = twoPlayers()
        assertFalse(state.players[0].hasCapturedOpponent)
        assertFalse(state.players[1].hasCapturedOpponent)
    }

    @Test
    fun `a finishing move is not offered while home is locked`() {
        val state = twoPlayers()
        val e = engine(state)
        val token = state.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 2         // a 2 would finish it

        bank(state, 2)
        assertTrue(
            "no finishing move may be offered before a kill",
            e.legalMovesFor(2).none { it.token.id == token.id && it.finishesToken }
        )
    }

    @Test
    fun `the same finishing move becomes legal once home is unlocked`() {
        val state = twoPlayers()
        val e = engine(state)
        state.players[0].hasCapturedOpponent = true       // a kill already happened
        val token = state.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 2

        bank(state, 2)
        assertTrue(
            e.legalMovesFor(2).any { it.token.id == token.id && it.finishesToken }
        )
    }

    // ---- section 6: a capture unlocks HOME ----

    @Test
    fun `capturing an opponent unlocks home permanently`() {
        val state = twoPlayers()
        val e = engine(state)
        val red = state.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = 5
        val victim = parkVictim(state, 5, 3)

        bank(state, 3)
        val move = e.legalMovesFor(3).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertTrue(result.capturedTokens.any { it.id == victim.id })
        assertTrue("the capture must unlock home", result.unlockedHome)
        assertTrue(state.players[0].hasCapturedOpponent)

        // section 20: being captured later must NOT re-lock it
        red.resetToBase()
        assertTrue(state.players[0].hasCapturedOpponent)
    }

    @Test
    fun `landing on a safe cell captures nothing and leaves home locked`() {
        val state = twoPlayers()
        val e = engine(state)
        // find a roll that lands red on a safe square occupied by yellow
        val redStart = 4
        val red = state.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = redStart

        var usedRoll = -1
        for (roll in 1..6) {
            val global = LudoBoard.toGlobalIndex(PlayerColor.RED, redStart + roll - 1)
            if (LudoBoard.isSafeCell(global)) { usedRoll = roll; break }
        }
        if (usedRoll == -1) return        // no safe square in reach here; nothing to assert

        parkVictim(state, redStart, usedRoll)
        bank(state, usedRoll)
        val move = e.legalMovesFor(usedRoll).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertTrue("a safe square protects the piece", result.capturedTokens.isEmpty())
        assertFalse("home must stay locked", result.unlockedHome)
        assertFalse(state.players[0].hasCapturedOpponent)
    }

    // ---- section 12: one kill plus one token home wins ----

    @Test
    fun `one kill and one token home wins immediately`() {
        val state = twoPlayers()
        val e = engine(state)
        state.players[0].hasCapturedOpponent = true       // requirement A already met

        val token = state.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3

        bank(state, 3)
        val move = e.legalMovesFor(3).first { it.token.id == token.id && it.finishesToken }
        val result = e.applyMove(move)

        assertTrue("one token home must end a quick match", result.gameWon)
        assertEquals("p1", result.winnerPlayerId)
        assertEquals(TurnPhase.GAME_OVER, state.phase)
        assertEquals(1, state.players[0].finishedCount)   // only ONE token needed
    }

    @Test
    fun `classic mode still needs all four tokens home`() {
        val state = twoPlayers()
        val e = LudoEngine(state, RuleConfig(quickMode = false))
        val token = state.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3

        bank(state, 3)
        val move = e.legalMovesFor(3).first { it.token.id == token.id && it.finishesToken }
        val result = e.applyMove(move)

        assertFalse("one token home must not win a classic match", result.gameWon)
        assertEquals(1, state.players[0].finishedCount)
    }

    // ---- section 2/10: starting layout ----

    @Test
    fun `two pieces start active and two stay in base`() {
        val state = twoPlayers()
        // this is the setup the game applies for quick mode
        for (p in state.players) {
            p.tokens[0].state = TokenState.ACTIVE; p.tokens[0].steps = 1
            p.tokens[1].state = TokenState.ACTIVE; p.tokens[1].steps = 1
        }
        for (p in state.players) {
            assertEquals(2, p.tokens.count { it.state == TokenState.ACTIVE })
            assertEquals(2, p.tokens.count { it.state == TokenState.BASE })
        }
    }

    @Test
    fun `the two base pieces still need a six to come out`() {
        val state = twoPlayers()
        val e = engine(state)
        state.players[0].tokens[0].state = TokenState.ACTIVE
        state.players[0].tokens[0].steps = 1
        state.players[0].tokens[1].state = TokenState.ACTIVE
        state.players[0].tokens[1].steps = 1

        bank(state, 4)
        assertTrue(
            "a non-six must not release a base piece",
            e.legalMovesFor(4).none { it.leavesBase }
        )
        bank(state, 6)
        assertTrue(e.legalMovesFor(6).any { it.leavesBase })
    }
}
