package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Ludo Snake Mode: the normal Ludo board, route and tokens, with snakes and
 * ladders acting as shortcuts. These tests cover the counts required by the
 * specification and the exact-landing trigger rule.
 */
class LudoSnakeModeTest {

    private fun state(): GameState = GameState(
        gameId = "snake-test",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        )
    )

    private fun engine(s: GameState, diff: SnakeDifficulty) =
        LudoEngine(s, RuleConfig(snakeMode = true, snakeDifficulty = diff))

    private fun bank(s: GameState, vararg values: Int) {
        s.pendingRolls.clear()
        s.pendingRolls.addAll(values.toList())
        s.phase = TurnPhase.AWAITING_MOVE
        s.lastDiceRoll = values.lastOrNull()
    }

    /** The red-relative step that sits on ring cell [cell]. */
    private fun redStepsFor(cell: Int): Int =
        ((cell - PlayerColor.RED.startOffset + LudoBoard.TRACK_LENGTH) % LudoBoard.TRACK_LENGTH) + 1

    // ---------- counts required by the specification ----------

    @Test
    fun `easy has exactly three snakes`() {
        val list = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
        assertEquals(3, list.count { it.type == SpecialType.SNAKE })
    }

    @Test
    fun `easy has exactly six ladders`() {
        val list = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
        assertEquals(6, list.count { it.type == SpecialType.LADDER })
    }

    @Test
    fun `easy snake and ladder sizes match the spec`() {
        val list = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
        val snakes = list.filter { it.type == SpecialType.SNAKE }
        val ladders = list.filter { it.type == SpecialType.LADDER }
        assertEquals(2, snakes.count { it.size == SpecialSize.SMALL })
        assertEquals(1, snakes.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(1, ladders.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(2, ladders.count { it.size == SpecialSize.MEDIUM })
        assertEquals(3, ladders.count { it.size == SpecialSize.SMALL })
    }

    @Test
    fun `medium has exactly six snakes`() {
        assertEquals(6, SnakeLadderConfig.specialsFor(SnakeDifficulty.MEDIUM)
            .count { it.type == SpecialType.SNAKE })
    }

    @Test
    fun `medium has exactly six ladders`() {
        assertEquals(6, SnakeLadderConfig.specialsFor(SnakeDifficulty.MEDIUM)
            .count { it.type == SpecialType.LADDER })
    }

    @Test
    fun `medium snakes and ladders are all small`() {
        val list = SnakeLadderConfig.specialsFor(SnakeDifficulty.MEDIUM)
        assertTrue(list.all { it.size == SpecialSize.SMALL })
    }

    @Test
    fun `hard has exactly eight snakes`() {
        assertEquals(8, SnakeLadderConfig.specialsFor(SnakeDifficulty.HARD)
            .count { it.type == SpecialType.SNAKE })
    }

    @Test
    fun `hard has exactly five ladders`() {
        val ladders = SnakeLadderConfig.specialsFor(SnakeDifficulty.HARD)
            .filter { it.type == SpecialType.LADDER }
        assertEquals(5, ladders.size)
        assertEquals(1, ladders.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(2, ladders.count { it.size == SpecialSize.MEDIUM })
        assertEquals(2, ladders.count { it.size == SpecialSize.SMALL })
    }

    // ---------- board safety ----------

    @Test
    fun `every difficulty board is safe`() {
        for (d in SnakeDifficulty.entries) {
            assertTrue("$d board must be safe", SnakeLadderConfig.isSane(d))
        }
        assertEquals(1, SnakeLadderConfig.MAX_SPECIAL_MOVEMENTS_PER_DICE_MOVE)
    }

    @Test
    fun `snakes always go backwards and ladders always go forwards`() {
        for (d in SnakeDifficulty.entries) {
            for (sp in SnakeLadderConfig.specialsFor(d)) {
                if (sp.type == SpecialType.SNAKE) assertTrue(sp.delta < 0)
                else assertTrue(sp.delta > 0)
            }
        }
    }

    // ---------- trigger rules ----------

    @Test
    fun `ladder triggers on an exact landing`() {
        val ladder = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
            .first { it.type == SpecialType.LADDER }
        val entrySteps = redStepsFor(ladder.entryCell)
        if (entrySteps < 3) return                 // too close to the start to set up

        val s = state()
        val e = engine(s, SnakeDifficulty.EASY)
        val token = s.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = entrySteps - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == token.id }
        val result = e.applyMove(move)

        assertNotNull("landing exactly on a ladder must fire it", result.special)
        assertEquals(SpecialType.LADDER, result.special!!.type)
        assertEquals(entrySteps, result.specialFromSteps)
        assertEquals(entrySteps + ladder.delta, result.specialToSteps)
        assertEquals(entrySteps + ladder.delta, token.steps)
    }

    @Test
    fun `passing over a ladder does not trigger it`() {
        val ladder = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
            .first { it.type == SpecialType.LADDER }
        val entrySteps = redStepsFor(ladder.entryCell)
        if (entrySteps < 3) return

        val s = state()
        val e = engine(s, SnakeDifficulty.EASY)
        val token = s.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = entrySteps - 2

        bank(s, 4)                                  // sails straight past the entry
        val move = e.legalMovesFor(4).first { it.token.id == token.id }
        val result = e.applyMove(move)

        assertNull("passing over must not fire a ladder", result.special)
        assertEquals(entrySteps + 2, token.steps)
    }

    @Test
    fun `snake triggers on an exact landing`() {
        val snake = SnakeLadderConfig.specialsFor(SnakeDifficulty.MEDIUM)
            .first { it.type == SpecialType.SNAKE }
        val entrySteps = redStepsFor(snake.entryCell)
        if (entrySteps < 3) return

        val s = state()
        val e = engine(s, SnakeDifficulty.MEDIUM)
        val token = s.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = entrySteps - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == token.id }
        val result = e.applyMove(move)

        assertNotNull("landing exactly on a snake head must fire it", result.special)
        assertEquals(SpecialType.SNAKE, result.special!!.type)
        assertTrue("a snake must send the piece backwards", token.steps < entrySteps)
        assertEquals(entrySteps + snake.delta, token.steps)
    }

    @Test
    fun `passing over a snake head does not trigger it`() {
        val snake = SnakeLadderConfig.specialsFor(SnakeDifficulty.MEDIUM)
            .first { it.type == SpecialType.SNAKE }
        val entrySteps = redStepsFor(snake.entryCell)
        if (entrySteps < 3) return

        val s = state()
        val e = engine(s, SnakeDifficulty.MEDIUM)
        val token = s.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = entrySteps - 2

        bank(s, 5)
        val move = e.legalMovesFor(5).first { it.token.id == token.id }
        val result = e.applyMove(move)

        assertNull("passing over must not fire a snake", result.special)
        assertEquals(entrySteps + 3, token.steps)
    }

    @Test
    fun `no shortcut fires in classic mode`() {
        val ladder = SnakeLadderConfig.specialsFor(SnakeDifficulty.EASY)
            .first { it.type == SpecialType.LADDER }
        val entrySteps = redStepsFor(ladder.entryCell)
        if (entrySteps < 3) return

        val s = state()
        val e = LudoEngine(s, RuleConfig())          // classic: snakeMode off
        val token = s.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = entrySteps - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == token.id }
        val result = e.applyMove(move)

        assertNull("classic mode must have no shortcuts", result.special)
        assertEquals(entrySteps, token.steps)
    }

    // ---------- the rest of Ludo still behaves ----------

    @Test
    fun `snake mode still needs a six to leave base`() {
        val s = state()
        val e = engine(s, SnakeDifficulty.HARD)
        bank(s, 4)
        assertTrue(e.legalMovesFor(4).none { it.leavesBase })
        bank(s, 6)
        assertTrue(e.legalMovesFor(6).any { it.leavesBase })
    }

    @Test
    fun `snake mode still needs all four tokens home to win`() {
        val s = state()
        val e = engine(s, SnakeDifficulty.EASY)
        val token = s.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == token.id && it.finishesToken }
        val result = e.applyMove(move)

        assertTrue(!result.gameWon)
        assertEquals(1, s.players[0].finishedCount)
    }
}
