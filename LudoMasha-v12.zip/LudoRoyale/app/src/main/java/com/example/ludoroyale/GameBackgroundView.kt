package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/**
 * Game-table backdrop drawn in code so it always renders: deep blue-violet
 * gradient, a warm pool of light behind the board, scattered faint dice pips,
 * and a darker vignette at the corners.
 */
class GameBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dots = mutableListOf<Triple<Float, Float, Float>>()   // x%, y%, radius%

    init {
        val rnd = Random(20260918)
        repeat(46) {
            dots += Triple(rnd.nextFloat(), rnd.nextFloat(), 0.004f + rnd.nextFloat() * 0.012f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // base gradient
        paint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                Color.rgb(0x8E, 0x14, 0x1B),   // deep red at the top
                Color.rgb(0x2A, 0x14, 0x42),   // blending through
                Color.rgb(0x0B, 0x14, 0x3A)    // dark blue at the bottom
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        // warm pool of light where the board sits
        paint.shader = RadialGradient(
            w * 0.5f, h * 0.47f, w * 0.95f,
            intArrayOf(Color.argb(95, 0xE0, 0x9A, 0x3A), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        // faint scattered pips, like a felt pattern
        paint.shader = null
        paint.color = Color.argb(26, 255, 255, 255)
        for ((fx, fy, fr) in dots) {
            canvas.drawCircle(fx * w, fy * h, fr * w, paint)
        }

        // corner vignette
        paint.shader = RadialGradient(
            w * 0.5f, h * 0.5f, maxOf(w, h) * 0.78f,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(130, 0, 0, 0)),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }
}
