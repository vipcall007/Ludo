package com.example.ludoroyale.ai

import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import kotlin.random.Random

/**
 * Computer player. It only ever picks from the same legal-move list a human
 * is shown — it never sees hidden information and never gets illegal moves.
 *
 * EASY   — plays like a child: mostly grabs whatever looks shiny, often
 *          blunders into danger, sometimes picks at random.
 * MEDIUM — sensible everyday player: takes obvious cuts and home runs,
 *          avoids the worst hangs, but doesn't think far ahead.
 * HARD   — plays properly: values cuts and finishing, actively runs pieces
 *          OUT of danger, refuses to park in front of an enemy, prefers safe
 *          squares, and pushes its leading piece home.
 */
object LudoAI {

    fun chooseMove(
        kind: PlayerKind,
        legalMoves: List<Move>,
        state: GameState? = null,
        random: Random = Random.Default
    ): Move {
        require(legalMoves.isNotEmpty())
        return when (kind) {
            PlayerKind.AI_EASY -> {
                // a child: 55% of the time just plays something at random
                if (random.nextInt(100) < 55) legalMoves[random.nextInt(legalMoves.size)]
                else legalMoves.maxByOrNull { score(it, state, depth = 0) } ?: legalMoves.first()
            }
            PlayerKind.AI_MEDIUM -> {
                // sensible, but slips now and then
                if (random.nextInt(100) < 15) legalMoves[random.nextInt(legalMoves.size)]
                else legalMoves.maxByOrNull { score(it, state, depth = 1) } ?: legalMoves.first()
            }
            PlayerKind.AI_HARD ->
                legalMoves.maxByOrNull { score(it, state, depth = 2) } ?: legalMoves.first()
            else -> legalMoves.first()
        }
    }

    /** Higher = better. [depth] 0 = shallow/naive, 1 = sensible, 2 = full judgement. */
    private fun score(move: Move, state: GameState?, depth: Int): Int {
        var s = 0

        if (move.capturesTokenIds.isNotEmpty()) s += 120 * move.capturesTokenIds.size
        if (move.finishesToken) s += 110
        if (move.entersHomeStretch) s += 55
        if (move.leavesBase) s += 30

        if (depth == 0) return s + move.toSteps / 6      // naive: just push forward

        val landsSafe = move.toSteps <= LudoBoard.TRACK_LENGTH - 1 &&
            LudoBoard.isSafeCell(LudoBoard.toGlobalIndex(move.token.color, move.toSteps - 1))
        if (landsSafe) s += 35
        if (move.toSteps > LudoBoard.TRACK_LENGTH - 1) s += 45   // inside the home run, untouchable
        s += move.toSteps / 4                                     // progress

        if (depth < 2 || state == null) return s

        // --- full judgement: danger in and danger out ---
        val danger = dangerAt(state, move, move.toSteps)
        val dangerNow = dangerAt(state, move, move.fromSteps)

        if (!landsSafe) s -= danger * 45            // don't park in front of an enemy
        if (dangerNow > 0) s += 40                  // running a threatened piece away is good
        if (danger == 0 && dangerNow > 0) s += 35   // ...especially right out of reach

        return s
    }

    /**
     * How many enemy pieces could reach [steps] with a single normal roll (1..6).
     * Team-mates are ignored — they can't cut you.
     */
    private fun dangerAt(state: GameState, move: Move, steps: Int): Int {
        if (steps <= 0 || steps > LudoBoard.TRACK_LENGTH - 1) return 0
        val target = LudoBoard.toGlobalIndex(move.token.color, steps - 1)
        val me = state.players.firstOrNull { p -> p.tokens.any { it.id == move.token.id } } ?: return 0

        var threats = 0
        for (enemy in state.players) {
            if (enemy.id == me.id) continue
            if (enemy.team != 0 && enemy.team == me.team) continue
            for (tok in enemy.tokens) {
                if (tok.state != TokenState.ACTIVE) continue
                for (roll in 1..6) {
                    val landing = tok.steps + roll
                    if (landing > LudoBoard.TRACK_LENGTH - 1) continue
                    if (LudoBoard.toGlobalIndex(tok.color, landing - 1) == target) { threats++; break }
                }
            }
        }
        return threats
    }
}
