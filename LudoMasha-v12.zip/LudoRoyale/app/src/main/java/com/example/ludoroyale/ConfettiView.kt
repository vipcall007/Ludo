package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/** Falling confetti for the win screen — drawn in code, no assets. */
class ConfettiView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Piece(
        var x: Float, var y: Float, var vy: Float, var vx: Float,
        var spin: Float, var angle: Float, val w: Float, val h: Float, val color: Int
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pieces = mutableListOf<Piece>()
    private var running = false
    private val rnd = Random.Default

    private val palette = intArrayOf(
        Color.rgb(0xE5, 0x30, 0x35), Color.rgb(0x22, 0xA6, 0x4B),
        Color.rgb(0xFA, 0xBF, 0x16), Color.rgb(0x16, 0x8D, 0xE8),
        Color.rgb(0xF2, 0xC1, 0x4E), Color.WHITE
    )

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            val h = height.toFloat()
            for (p in pieces) {
                p.y += p.vy
                p.x += p.vx
                p.angle += p.spin
                if (p.y > h + 40f) reset(p, fromTop = true)
            }
            invalidate()
            postDelayed(this, 16)
        }
    }

    fun start() {
        if (running) return
        running = true
        pieces.clear()
        repeat(90) { pieces += newPiece() }
        post(ticker)
    }

    fun stop() {
        running = false
        removeCallbacks(ticker)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }

    private fun newPiece(): Piece {
        val w = if (width > 0) width.toFloat() else 1080f
        val h = if (height > 0) height.toFloat() else 1920f
        return Piece(
            x = rnd.nextFloat() * w,
            y = -rnd.nextFloat() * h,
            vy = 3f + rnd.nextFloat() * 6f,
            vx = -1.2f + rnd.nextFloat() * 2.4f,
            spin = -6f + rnd.nextFloat() * 12f,
            angle = rnd.nextFloat() * 360f,
            w = 8f + rnd.nextFloat() * 10f,
            h = 12f + rnd.nextFloat() * 14f,
            color = palette[rnd.nextInt(palette.size)]
        )
    }

    private fun reset(p: Piece, fromTop: Boolean) {
        p.x = rnd.nextFloat() * (if (width > 0) width.toFloat() else 1080f)
        p.y = if (fromTop) -30f else p.y
        p.vy = 3f + rnd.nextFloat() * 6f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (p in pieces) {
            paint.color = p.color
            canvas.save()
            canvas.rotate(p.angle, p.x, p.y)
            canvas.drawRect(RectF(p.x - p.w / 2, p.y - p.h / 2, p.x + p.w / 2, p.y + p.h / 2), paint)
            canvas.restore()
        }
    }
}
