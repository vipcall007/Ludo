package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode
import kotlin.random.Random

/** The kinds of thing a daily mission can ask for. */
enum class MissionType(val verb: String) {
    PLAY_MATCHES("Play %d matches"),
    WIN_MATCHES("Win %d matches"),
    CAPTURE_TOKENS("Capture %d tokens"),
    SEND_TOKENS_HOME("Send %d tokens home"),
    PLAY_SNAKE_MATCH("Play %d Snakes & Ladders matches"),
    PLAY_QUICK_MATCH("Play %d Quick matches"),
    PLAY_ARROW_MATCH("Play %d Arrow Mode matches"),
    CLIMB_LADDERS("Climb %d ladders"),
    ROLL_SIXES("Roll %d sixes");

    /** "Play 3 matches" — singular reads properly too. */
    fun describe(target: Int): String {
        val text = verb.replace("%d", target.toString())
        return if (target == 1) text.replace("matches", "match").replace("tokens", "token")
            .replace("ladders", "ladder").replace("sixes", "six") else text
    }
}

/** A mission the catalog can hand out, before it belongs to a particular day. */
data class MissionDef(
    val type: MissionType,
    val target: Int,
    val xp: Int,
    val coins: Int
)

/**
 * One mission on one day.
 *
 * [claimed] is separate from [completed] on purpose: finishing a mission and
 * collecting it are two different moments, and only the collecting may pay.
 */
data class Mission(
    val id: String,
    val type: MissionType,
    val target: Int,
    var progress: Int = 0,
    var claimed: Boolean = false,
    val xp: Int = 0,
    val coins: Int = 0,
    /** The day this mission belongs to; a different day means a fresh set. */
    val day: Int = 0
) {
    val completed: Boolean get() = progress >= target
    val claimable: Boolean get() = completed && !claimed
    fun describe(): String = type.describe(target)
    fun progressText(): String = "${progress.coerceAtMost(target)}/$target"

    /** Adds to the tally and stops at the target, so nothing over-counts. */
    fun advance(by: Int) {
        if (claimed) return
        progress = (progress + by).coerceAtMost(target)
    }
}

/**
 * The pool daily missions are drawn from, and the drawing itself.
 *
 * The draw is seeded by the day, so the same day always produces the same
 * missions: closing the game and opening it again cannot reroll a hard set
 * into an easy one, and there is no way to farm a fresh list.
 */
object MissionCatalog {

    const val PER_DAY = 4

    val POOL: List<MissionDef> = listOf(
        MissionDef(MissionType.PLAY_MATCHES, 2, xp = 30, coins = 40),
        MissionDef(MissionType.PLAY_MATCHES, 3, xp = 45, coins = 60),
        MissionDef(MissionType.WIN_MATCHES, 1, xp = 40, coins = 50),
        MissionDef(MissionType.WIN_MATCHES, 2, xp = 70, coins = 90),
        MissionDef(MissionType.CAPTURE_TOKENS, 3, xp = 35, coins = 45),
        MissionDef(MissionType.CAPTURE_TOKENS, 5, xp = 55, coins = 70),
        MissionDef(MissionType.SEND_TOKENS_HOME, 3, xp = 35, coins = 45),
        MissionDef(MissionType.SEND_TOKENS_HOME, 5, xp = 55, coins = 70),
        MissionDef(MissionType.PLAY_SNAKE_MATCH, 1, xp = 30, coins = 40),
        MissionDef(MissionType.PLAY_QUICK_MATCH, 1, xp = 30, coins = 40),
        MissionDef(MissionType.PLAY_ARROW_MATCH, 1, xp = 30, coins = 40),
        MissionDef(MissionType.CLIMB_LADDERS, 2, xp = 30, coins = 40),
        MissionDef(MissionType.ROLL_SIXES, 6, xp = 30, coins = 40),
        MissionDef(MissionType.ROLL_SIXES, 10, xp = 50, coins = 65)
    )

    /**
     * The missions for [day]. Always the same list for the same day, never two
     * missions of the same type, and always at least one that any mode can
     * finish so no day is impossible for someone who only plays Classic.
     */
    fun generate(day: Int, count: Int = PER_DAY): List<Mission> {
        val rnd = Random(day * 7919L + 13L)
        val wanted = count.coerceIn(3, 5)
        val chosen = mutableListOf<MissionDef>()

        // one that any mode satisfies, so the day is never a dead end
        val universal = POOL.filter {
            it.type == MissionType.PLAY_MATCHES || it.type == MissionType.WIN_MATCHES
        }
        chosen += universal[rnd.nextInt(universal.size)]

        val rest = POOL.shuffled(rnd)
        for (def in rest) {
            if (chosen.size >= wanted) break
            if (chosen.any { it.type == def.type }) continue
            chosen += def
        }

        return chosen.mapIndexed { i, def ->
            Mission(
                id = "d$day-m$i",
                type = def.type,
                target = def.target,
                xp = def.xp,
                coins = def.coins,
                day = day
            )
        }
    }
}

/**
 * The player's missions for today, and the rules for moving them along.
 *
 * Screens never touch [Mission.progress] directly — they hand this book the
 * events the match posted, and the book decides what counts. That is what
 * keeps mission logic from being re-implemented in every Activity.
 */
class MissionBook(missions: List<Mission> = emptyList()) : GameEventListener {

    private val items = missions.toMutableList()

    val missions: List<Mission> get() = items.toList()

    val day: Int get() = items.firstOrNull()?.day ?: 0

    /** Missions finished this session that were not finished when it began. */
    private val newlyCompleted = mutableListOf<Mission>()

    fun takeNewlyCompleted(): List<Mission> {
        val list = newlyCompleted.toList()
        newlyCompleted.clear()
        return list
    }

    /** Swaps in a new day's missions, dropping yesterday's entirely. */
    fun replaceWith(fresh: List<Mission>) {
        items.clear()
        items.addAll(fresh)
        newlyCompleted.clear()
    }

    override fun onGameEvent(event: GameEvent) {
        if (!event.byLocalPlayer && event.type != GameEventType.MATCH_COMPLETED) return
        for (mission in items) {
            if (mission.completed) continue
            val step = stepFor(mission.type, event)
            if (step <= 0) continue
            mission.advance(step)
            if (mission.completed) newlyCompleted += mission
        }
    }

    private fun stepFor(type: MissionType, event: GameEvent): Int = when (type) {
        MissionType.PLAY_MATCHES ->
            if (event.type == GameEventType.MATCH_COMPLETED) 1 else 0

        MissionType.WIN_MATCHES ->
            if (event.type == GameEventType.MATCH_WON && event.byLocalPlayer) 1 else 0

        MissionType.CAPTURE_TOKENS ->
            if (event.type == GameEventType.TOKEN_CAPTURED) event.count else 0

        MissionType.SEND_TOKENS_HOME ->
            if (event.type == GameEventType.TOKEN_HOME) event.count else 0

        MissionType.PLAY_SNAKE_MATCH ->
            if (event.type == GameEventType.MATCH_COMPLETED && event.mode == GameMode.SNAKES) 1 else 0

        MissionType.PLAY_QUICK_MATCH ->
            if (event.type == GameEventType.MATCH_COMPLETED && event.mode == GameMode.QUICK) 1 else 0

        MissionType.PLAY_ARROW_MATCH ->
            if (event.type == GameEventType.MATCH_COMPLETED && event.mode == GameMode.ARROW) 1 else 0

        MissionType.CLIMB_LADDERS ->
            if (event.type == GameEventType.LADDER_TRIGGERED) event.count else 0

        MissionType.ROLL_SIXES ->
            if (event.type == GameEventType.DICE_ROLLED && event.value == 6) 1 else 0
    }

    /**
     * Collects a finished mission. Returns what it paid, or null if it was not
     * ready or had already been collected — the one place a double claim is
     * stopped, so no screen can pay twice by asking twice.
     */
    fun claim(missionId: String): Pair<Int, Int>? {
        val mission = items.firstOrNull { it.id == missionId } ?: return null
        if (!mission.claimable) return null
        mission.claimed = true
        return mission.xp to mission.coins
    }

    fun claimableCount(): Int = items.count { it.claimable }
}

/**
 * Missions written to one line of text and back, so they can live in the
 * ordinary preferences file without pulling in a JSON library.
 *
 * Format, one mission per '|' field:  id,type,target,progress,claimed,xp,coins,day
 * Anything unreadable is treated as "no missions saved", which simply means a
 * fresh set is generated — a corrupt line can never crash the game.
 */
object MissionCodec {

    fun encode(missions: List<Mission>): String = missions.joinToString("|") { m ->
        listOf(
            m.id, m.type.name, m.target, m.progress,
            if (m.claimed) 1 else 0, m.xp, m.coins, m.day
        ).joinToString(",")
    }

    fun decode(raw: String): List<Mission> {
        if (raw.isBlank()) return emptyList()
        val out = mutableListOf<Mission>()
        for (part in raw.split("|")) {
            val f = part.split(",")
            if (f.size < 8) continue
            val type = MissionType.entries.firstOrNull { it.name == f[1] } ?: continue
            val target = f[2].toIntOrNull() ?: continue
            val progress = f[3].toIntOrNull() ?: continue
            val day = f[7].toIntOrNull() ?: continue
            out += Mission(
                id = f[0],
                type = type,
                target = target,
                progress = progress.coerceIn(0, target),
                claimed = f[4] == "1",
                xp = f[5].toIntOrNull() ?: 0,
                coins = f[6].toIntOrNull() ?: 0,
                day = day
            )
        }
        return out
    }
}
