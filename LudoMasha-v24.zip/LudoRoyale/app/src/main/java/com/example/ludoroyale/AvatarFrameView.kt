package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * A player's face and the frame around it, drawn together.
 *
 * The two belong in one view because the frame has to hug the portrait exactly,
 * and because the ten-second turn clock is drawn as a ring OUTSIDE this view —
 * so this one is kept perfectly circular and sized so that a ring can sit
 * around it without ever overlapping the face.
 *
 * All of it is drawn in code: original shapes, no image files.
 */
class AvatarFrameView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var avatarId: String = Cosmetics.AVATAR_P1
        set(value) { field = value; invalidate() }

    var frameId: String = Cosmetics.FRAME_BRONZE
        set(value) { field = value; invalidate() }

    /** Drawn as a computer opponent instead of a person. */
    var isBot: Boolean = false
        set(value) { field = value; invalidate() }

    /** The seat colour, used for the backing disc so seats stay tellable apart. */
    var accent: Int = Color.rgb(0x2B, 0x3A, 0x63)
        set(value) { field = value; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        // the frame takes the outer eighth; the portrait fills the rest
        val frameW = s * 0.10f
        val portrait = s * 0.5f - frameW

        drawPortrait(canvas, cx, cy, portrait)
        drawFrame(canvas, cx, cy, s * 0.5f - frameW * 0.5f, frameW)
    }

    // ------------------------------------------------------------- portrait

    private fun drawPortrait(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        // backing disc in the seat colour
        shade.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.4f, r * 1.6f,
            intArrayOf(lighten(accent, 0.35f), accent, darken(accent, 0.35f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null

        canvas.save()
        val clip = Path()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        canvas.clipPath(clip)

        if (isBot) drawBot(canvas, cx, cy, r) else when (avatarId) {
            Cosmetics.AVATAR_KNIGHT -> drawKnight(canvas, cx, cy, r)
            Cosmetics.AVATAR_CROWN -> drawPerson(canvas, cx, cy, r, skin = SKINS[0], hair = HAIRS[3], crown = true)
            Cosmetics.AVATAR_P2 -> drawPerson(canvas, cx, cy, r, skin = SKINS[1], hair = HAIRS[1])
            Cosmetics.AVATAR_P3 -> drawPerson(canvas, cx, cy, r, skin = SKINS[2], hair = HAIRS[2])
            Cosmetics.AVATAR_P4 -> drawPerson(canvas, cx, cy, r, skin = SKINS[3], hair = HAIRS[3])
            else -> drawPerson(canvas, cx, cy, r, skin = SKINS[0], hair = HAIRS[0])
        }

        canvas.restore()

        // a soft light from the top left, over everything
        shade.shader = RadialGradient(
            cx - r * 0.4f, cy - r * 0.5f, r * 1.1f,
            intArrayOf(Color.argb(60, 255, 255, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null
    }

    private fun drawPerson(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        skin: Int, hair: Int, crown: Boolean = false
    ) {
        // shoulders
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.82f, fill)

        // head
        fill.color = skin
        canvas.drawCircle(cx, cy - r * 0.10f, r * 0.46f, fill)

        // hair as a cap over the top of the head
        fill.color = hair
        canvas.drawArc(
            RectF(cx - r * 0.48f, cy - r * 0.60f, cx + r * 0.48f, cy + r * 0.36f),
            185f, 170f, true, fill
        )

        // eyes
        fill.color = Color.rgb(0x22, 0x1A, 0x14)
        canvas.drawCircle(cx - r * 0.16f, cy - r * 0.10f, r * 0.055f, fill)
        canvas.drawCircle(cx + r * 0.16f, cy - r * 0.10f, r * 0.055f, fill)

        // a small smile
        stroke.color = Color.rgb(0x6B, 0x3A, 0x28)
        stroke.strokeWidth = r * 0.055f
        canvas.drawArc(
            RectF(cx - r * 0.18f, cy - r * 0.10f, cx + r * 0.18f, cy + r * 0.22f),
            20f, 140f, false, stroke
        )

        if (crown) {
            fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
            val p = Path()
            val top = cy - r * 0.52f
            p.moveTo(cx - r * 0.44f, top + r * 0.20f)
            p.lineTo(cx - r * 0.44f, top - r * 0.16f)
            p.lineTo(cx - r * 0.18f, top + r * 0.06f)
            p.lineTo(cx, top - r * 0.30f)
            p.lineTo(cx + r * 0.18f, top + r * 0.06f)
            p.lineTo(cx + r * 0.44f, top - r * 0.16f)
            p.lineTo(cx + r * 0.44f, top + r * 0.20f)
            p.close()
            canvas.drawPath(p, fill)
        }
    }

    private fun drawKnight(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.82f, fill)

        // helmet
        fill.shader = LinearGradient(
            cx, cy - r * 0.6f, cx, cy + r * 0.5f,
            intArrayOf(Color.rgb(0xE2, 0xEA, 0xF4), Color.rgb(0x8A, 0x9A, 0xB0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            RectF(cx - r * 0.46f, cy - r * 0.56f, cx + r * 0.46f, cy + r * 0.44f),
            r * 0.30f, r * 0.30f, fill
        )
        fill.shader = null

        // visor slot
        fill.color = Color.rgb(0x1A, 0x22, 0x33)
        canvas.drawRoundRect(
            RectF(cx - r * 0.34f, cy - r * 0.18f, cx + r * 0.34f, cy + r * 0.02f),
            r * 0.06f, r * 0.06f, fill
        )
        // breathing slits
        for (i in -1..1) {
            canvas.drawRoundRect(
                RectF(cx + i * r * 0.16f - r * 0.03f, cy + r * 0.12f,
                      cx + i * r * 0.16f + r * 0.03f, cy + r * 0.34f),
                r * 0.03f, r * 0.03f, fill
            )
        }

        // plume
        fill.color = Color.rgb(0xE5, 0x30, 0x35)
        canvas.drawRoundRect(
            RectF(cx - r * 0.07f, cy - r * 0.86f, cx + r * 0.07f, cy - r * 0.46f),
            r * 0.07f, r * 0.07f, fill
        )
    }

    private fun drawBot(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.82f, fill)

        fill.shader = LinearGradient(
            cx, cy - r * 0.6f, cx, cy + r * 0.5f,
            intArrayOf(Color.rgb(0xCF, 0xDC, 0xEE), Color.rgb(0x7E, 0x90, 0xAA)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            RectF(cx - r * 0.48f, cy - r * 0.46f, cx + r * 0.48f, cy + r * 0.40f),
            r * 0.22f, r * 0.22f, fill
        )
        fill.shader = null

        fill.color = Color.rgb(0x16, 0x8D, 0xE8)
        canvas.drawCircle(cx - r * 0.18f, cy - r * 0.06f, r * 0.10f, fill)
        canvas.drawCircle(cx + r * 0.18f, cy - r * 0.06f, r * 0.10f, fill)

        stroke.color = Color.rgb(0x33, 0x42, 0x58)
        stroke.strokeWidth = r * 0.06f
        canvas.drawLine(cx - r * 0.18f, cy + r * 0.22f, cx + r * 0.18f, cy + r * 0.22f, stroke)

        // antenna
        stroke.strokeWidth = r * 0.07f
        canvas.drawLine(cx, cy - r * 0.46f, cx, cy - r * 0.74f, stroke)
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawCircle(cx, cy - r * 0.80f, r * 0.10f, fill)
    }

    // ---------------------------------------------------------------- frame

    /**
     * The frame ring.
     *
     * Each tier is the same width and sits in the same place, so a Legendary
     * frame is showier but never bigger — nobody's face gets squeezed for
     * having a better frame, and the turn ring outside always fits.
     */
    private fun drawFrame(canvas: Canvas, cx: Float, cy: Float, r: Float, w: Float) {
        val id = frameId
        if (id == Cosmetics.FRAME_NONE) return

        val colors: IntArray = when (id) {
            Cosmetics.FRAME_BRONZE -> intArrayOf(
                Color.rgb(0xE0, 0xA4, 0x6E), Color.rgb(0xA8, 0x63, 0x2E), Color.rgb(0x6B, 0x38, 0x14)
            )
            Cosmetics.FRAME_SILVER -> intArrayOf(
                Color.rgb(0xF2, 0xF6, 0xFC), Color.rgb(0xB4, 0xC2, 0xD4), Color.rgb(0x6E, 0x7E, 0x94)
            )
            Cosmetics.FRAME_GOLD -> intArrayOf(
                Color.rgb(0xFF, 0xEE, 0xB4), Color.rgb(0xF2, 0xC1, 0x4E), Color.rgb(0x9A, 0x69, 0x06)
            )
            Cosmetics.FRAME_DIAMOND -> intArrayOf(
                Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0xAE, 0xE4, 0xFF), Color.rgb(0x4C, 0x8F, 0xC4)
            )
            Cosmetics.FRAME_ROYAL -> intArrayOf(
                Color.rgb(0xDC, 0xC6, 0xFF), Color.rgb(0x8E, 0x63, 0xE0), Color.rgb(0x40, 0x22, 0x8E)
            )
            Cosmetics.FRAME_LEGENDARY -> intArrayOf(
                Color.rgb(0xFF, 0xF0, 0xC0), Color.rgb(0xFF, 0x9A, 0x2E), Color.rgb(0xA8, 0x2A, 0x06)
            )
            else -> intArrayOf(
                Color.rgb(0xE0, 0xA4, 0x6E), Color.rgb(0xA8, 0x63, 0x2E), Color.rgb(0x6B, 0x38, 0x14)
            )
        }

        stroke.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r, colors, floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        stroke.strokeWidth = w
        canvas.drawCircle(cx, cy, r, stroke)
        stroke.shader = null

        // an inner hairline so the frame reads as metal rather than a flat band
        stroke.color = Color.argb(110, 255, 255, 255)
        stroke.strokeWidth = w * 0.18f
        canvas.drawCircle(cx, cy, r - w * 0.32f, stroke)

        // the better tiers get studs; the very best gets a crown on top
        val studs = when (id) {
            Cosmetics.FRAME_GOLD, Cosmetics.FRAME_DIAMOND -> 6
            Cosmetics.FRAME_ROYAL, Cosmetics.FRAME_LEGENDARY -> 8
            else -> 0
        }
        if (studs > 0) {
            fill.color = colors[0]
            for (i in 0 until studs) {
                val angle = (2.0 * Math.PI * i / studs) - Math.PI / 2.0
                canvas.drawCircle(
                    cx + cos(angle).toFloat() * r,
                    cy + sin(angle).toFloat() * r,
                    w * 0.30f, fill
                )
            }
        }
        if (id == Cosmetics.FRAME_LEGENDARY) {
            fill.color = Color.rgb(0xFF, 0xE9, 0xA8)
            val p = Path()
            val top = cy - r - w * 0.35f
            p.moveTo(cx - r * 0.30f, top + w * 0.55f)
            p.lineTo(cx - r * 0.30f, top - w * 0.25f)
            p.lineTo(cx - r * 0.12f, top + w * 0.20f)
            p.lineTo(cx, top - w * 0.60f)
            p.lineTo(cx + r * 0.12f, top + w * 0.20f)
            p.lineTo(cx + r * 0.30f, top - w * 0.25f)
            p.lineTo(cx + r * 0.30f, top + w * 0.55f)
            p.close()
            canvas.drawPath(p, fill)
        }
    }

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    private companion object {
        val SKINS = intArrayOf(
            Color.rgb(0xF2, 0xC6, 0xA0), Color.rgb(0xD9, 0xA3, 0x74),
            Color.rgb(0xA8, 0x71, 0x4A), Color.rgb(0x74, 0x4A, 0x2E)
        )
        val HAIRS = intArrayOf(
            Color.rgb(0x2A, 0x1C, 0x12), Color.rgb(0x5A, 0x3A, 0x1E),
            Color.rgb(0x1A, 0x14, 0x10), Color.rgb(0x3C, 0x2A, 0x18)
        )
    }
}
