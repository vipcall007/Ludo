package com.example.ludoroyale.snl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.TokenArts
import com.example.ludoroyale.cosmetics.TokenOrnament
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.model.PlayerColor
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/**
 * The standalone SNAKE & LADDER board: a driftwood 10x10 grid numbered 1..100
 * the way the printed game is, floating in shallow tropical water with coral
 * around the edges, real snakes and rope-lashed wooden ladders.
 *
 * Everything that never changes — sea, frame, planks, snakes, ladders — is
 * painted once into [staticLayer] and blitted each frame, so the drawing can
 * carry a lot of detail without costing anything per frame.
 *
 * The view only DRAWS and ANIMATES. Every rule lives in [SnlEngine].
 */
class SnlBoardView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** One piece as the board needs to see it. */
    class Piece(val id: String, val color: PlayerColor, var cell: Int)

    /**
     * The world the board is played in. Each difficulty gets its own; see
     * [SnlTheme]. It decides paint only — never a square, a snake or an odd.
     */
    val theme: SnlTheme get() = SnlTheme.of(difficulty)

    var difficulty: SnakeDifficulty = SnakeDifficulty.EASY
        set(value) {
            field = value
            rebuildSpecials()
            redrawStaticLayer()
            invalidate()
        }

    /** Called once per square as a piece hops along, so the UI can tick. */
    var onStep: (() -> Unit)? = null

    /**
     * Which token skin the counters wear. It changes the collar, the inset and
     * the little mark in the middle — never the seat colour, which is how a
     * player finds their own counter on a crowded square.
     */
    var tokenArtId: String = Cosmetics.TOKEN_CLASSIC
        set(value) { field = value; invalidate() }

    private var pieces: List<Piece> = emptyList()

    /** Live drawing position of every piece, in (row, col) board units. */
    private val displayed = HashMap<String, Pair<Float, Float>>()

    private var glowCell: Int? = null
    private var glowPhase = 0f

    // ------------------------------------------------------------- lifecycle

    private val glowTicker = object : Runnable {
        override fun run() {
            if (glowCell == null) return
            glowPhase += 0.22f
            invalidate()
            postDelayed(this, 40)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(glowTicker)
        for (t in tickers.values) removeCallbacks(t)
        tickers.clear()
        staticLayer?.recycle()
        staticLayer = null
    }

    // ------------------------------------------------------------------ API

    fun setPieces(list: List<Piece>) {
        pieces = list
        for (p in list) displayed[p.id] = centerOf(p.cell)
        invalidate()
    }

    fun snapTo(list: List<Piece>) {
        pieces = list
        for (p in list) displayed[p.id] = centerOf(p.cell)
        invalidate()
    }

    fun setGlow(cell: Int?) {
        glowCell = cell
        removeCallbacks(glowTicker)
        if (cell != null) { glowPhase = 0f; post(glowTicker) }
        invalidate()
    }

    /** Walks a piece square by square, the way a hand moves a counter. */
    fun hopAlong(pieceId: String, cells: List<Int>, onComplete: () -> Unit) {
        if (cells.isEmpty()) { onComplete(); return }
        glide(pieceId, cells.map { centerOf(it) }, perLegMs = 115L, arc = 0.22f, onComplete = onComplete)
    }

    /** Slides down a snake, or climbs a ladder, in one smooth run. */
    fun rideSpecial(pieceId: String, special: SnlSpecial, onComplete: () -> Unit) {
        val drawn = drawnSpecials.firstOrNull { it.spec.id == special.id }
        val path = if (drawn != null && drawn.spec.type == SpecialType.SNAKE && cellW > 0f) {
            // follow the snake's own curve, so the piece really slides along it
            drawn.spine.map { (x, y) -> ((y - top) / cellH) to ((x - left) / cellW) }
        } else {
            listOf(centerOf(special.entryCell), centerOf(special.exitCell))
        }
        val legMs = if (special.type == SpecialType.LADDER) 70L else 26L
        glide(pieceId, path, perLegMs = legMs, arc = 0f, onComplete = onComplete)
    }

    /** Knocked back to the start pad. */
    fun sendToStart(pieceId: String, fromCell: Int, onComplete: () -> Unit) {
        glide(pieceId, listOf(centerOf(fromCell), centerOf(0)), perLegMs = 320L, arc = 0.9f, onComplete = onComplete)
    }

    // -------------------------------------------------------------- animation

    /** One ticker per piece, so two pieces can move at the same time. */
    private val tickers = HashMap<String, Runnable>()

    private fun glide(
        pieceId: String,
        path: List<Pair<Float, Float>>,
        perLegMs: Long,
        arc: Float,
        onComplete: () -> Unit
    ) {
        if (path.size < 2) {
            val only = path.lastOrNull()
            if (only != null) displayed[pieceId] = only
            invalidate(); onComplete(); return
        }
        val start = System.currentTimeMillis()
        val total = perLegMs * (path.size - 1)
        val ticks = path.size > 2 && perLegMs >= 100L      // only the square-by-square walk ticks
        tickers.remove(pieceId)?.let { removeCallbacks(it) }
        var lastLeg = -1
        val run = object : Runnable {
            override fun run() {
                val t = ((System.currentTimeMillis() - start).toFloat() / total).coerceIn(0f, 1f)
                val pos = t * (path.size - 1)
                val leg = pos.toInt().coerceAtMost(path.size - 2)
                val f = pos - leg
                if (ticks && leg != lastLeg) {
                    lastLeg = leg
                    onStep?.invoke()
                }
                val a = path[leg]
                val b = path[leg + 1]
                val lift = if (arc > 0f) -arc * sin(f * Math.PI).toFloat() else 0f
                displayed[pieceId] =
                    (a.first + (b.first - a.first) * f + lift) to (a.second + (b.second - a.second) * f)
                invalidate()
                if (t >= 1f) {
                    displayed[pieceId] = path.last()
                    tickers.remove(pieceId)
                    invalidate()
                    onComplete()
                } else postDelayed(this, 16)
            }
        }
        tickers[pieceId] = run
        post(run)
    }

    // -------------------------------------------------------------- geometry

    /**
     * The board fills whatever space it is given, so on a phone the squares
     * come out taller than they are wide — exactly like the printed board.
     */
    private var cellW = 0f
    private var cellH = 0f
    private var left = 0f
    private var top = 0f
    private var seaW = 0f
    private var seaH = 0f

    /** The smaller of the two cell sides — what all line weights scale from. */
    private val unit: Float get() = min(cellW, cellH)

    private fun px(col: Float) = left + col * cellW
    private fun py(row: Float) = top + row * cellH

    /** (row, col) centre in board units. Cell 0 is the start pad under square 1. */
    private fun centerOf(cellNo: Int): Pair<Float, Float> {
        if (cellNo <= 0) return (SnlConfig.ROWS - 0.46f) to 0.5f
        val (r, c) = SnlConfig.cellToGrid(cellNo)
        return (r + 0.5f) to (c + 0.5f)
    }

    private fun screenOf(cellNo: Int): Pair<Float, Float> {
        val (r, c) = centerOf(cellNo)
        return px(c) to py(r)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        if (fw <= 0f || fh <= 0f) return

        // the sea border around the timber frame
        seaW = fw * 0.055f
        seaH = min(fh * 0.045f, seaW * 1.4f)

        cellW = (fw - 2 * seaW) / SnlConfig.COLUMNS
        cellH = (fh - 2 * seaH) / SnlConfig.ROWS
        left = seaW
        top = seaH

        numberPaint.textSize = unit * 0.34f
        rebuildSpecials()
        redrawStaticLayer()
        for (p in pieces) displayed[p.id] = centerOf(p.cell)
    }

    // ---------------------------------------------------------------- paints

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val blit = Paint(Paint.FILTER_BITMAP_FLAG)

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt().coerceIn(0, 255)
    )

    private fun lighten(c: Int, f: Float) = mix(c, Color.WHITE, f)
    private fun darken(c: Int, f: Float) = mix(c, Color.BLACK, f)
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    // ------------------------------------------------------------------ draw

    private var staticLayer: Bitmap? = null

    private fun redrawStaticLayer() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0 || cellW <= 0f) return
        staticLayer?.recycle()
        val bmp = try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            staticLayer = null
            return
        }
        val c = Canvas(bmp)
        drawWater(c)
        drawBorderLife(c)
        drawFrame(c)
        drawPlanks(c)
        drawLadders(c)
        drawSnakes(c)
        staticLayer = bmp
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cellW <= 0f) return
        val layer = staticLayer
        if (layer != null && !layer.isRecycled) {
            canvas.drawBitmap(layer, 0f, 0f, blit)
        } else {
            drawWater(canvas); drawBorderLife(canvas); drawFrame(canvas)
            drawPlanks(canvas); drawLadders(canvas); drawSnakes(canvas)
        }
        drawGlow(canvas)
        drawPieces(canvas)
    }

    /** Sunlit shallow water, with caustic ribbons drifting across it. */
    private fun drawWater(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        val th = theme
        shade.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(th.skyTop, th.skyMid, th.skyDeep),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, shade)
        shade.shader = null

        shade.shader = RadialGradient(
            w * 0.5f, -h * 0.15f, h * 0.95f,
            intArrayOf(th.lightTint, Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, shade)
        shade.shader = null

        val rnd = Random(4211)
        repeat(30) {
            val y = rnd.nextFloat() * h
            val x = rnd.nextFloat() * w
            val len = w * (0.10f + rnd.nextFloat() * 0.26f)
            val amp = h * 0.010f
            stroke.color = withAlpha(th.driftTint, 20 + rnd.nextInt(26))
            stroke.strokeWidth = w * (0.004f + rnd.nextFloat() * 0.010f)
            val p = Path()
            p.moveTo(x, y)
            p.quadTo(x + len * 0.35f, y - amp, x + len * 0.7f, y)
            p.quadTo(x + len * 0.85f, y + amp, x + len, y - amp * 0.4f)
            canvas.drawPath(p, stroke)
        }
    }

    /** Coral and shells crowding the sea border, plus a couple of fish. */
    /**
     * Whatever crowds the border of this world.
     *
     * One layout of spots serves all four, so every theme is balanced the same
     * way round the board and none of them ends up busier than the others.
     */
    private fun drawBorderLife(canvas: Canvas) {
        when (theme.ambience) {
            Ambience.REEF -> drawReef(canvas)
            Ambience.GARDEN -> drawGarden(canvas)
            Ambience.JUNGLE -> drawJungle(canvas)
            Ambience.TEMPLE -> drawTemple(canvas)
        }
    }

    /** Where border decoration is allowed to stand, in every world. */
    private fun borderSpots(): List<Triple<Float, Float, Float>> {
        val w = width.toFloat()
        val h = height.toFloat()
        return listOf(
            Triple(seaW * 0.52f, seaH * 0.95f, 1.0f),
            Triple(w - seaW * 0.52f, seaH * 0.85f, 0.9f),
            Triple(seaW * 0.48f, h - seaH * 0.85f, 1.05f),
            Triple(w - seaW * 0.48f, h - seaH * 0.95f, 0.95f),
            Triple(w * 0.32f, seaH * 0.62f, 0.7f),
            Triple(w * 0.68f, h - seaH * 0.58f, 0.72f),
            Triple(seaW * 0.46f, h * 0.30f, 0.72f),
            Triple(w - seaW * 0.46f, h * 0.44f, 0.70f),
            Triple(seaW * 0.46f, h * 0.62f, 0.66f),
            Triple(w - seaW * 0.46f, h * 0.76f, 0.68f),
            Triple(w * 0.68f, seaH * 0.58f, 0.6f),
            Triple(w * 0.32f, h - seaH * 0.55f, 0.62f)
        )
    }

    private fun drawReef(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r0 = seaW * 0.62f

        val corals = intArrayOf(
            Color.rgb(0xF0, 0x7B, 0x88), Color.rgb(0xF2, 0xA6, 0x4B),
            Color.rgb(0x6F, 0xD8, 0xC4), Color.rgb(0xB0, 0x8A, 0xE6),
            Color.rgb(0xF6, 0xD0, 0x6B)
        )
        val rnd = Random(90210)

        fun coral(cx: Float, cy: Float, r: Float, color: Int) {
            stroke.color = color
            stroke.strokeWidth = r * 0.26f
            val foot = cy + r * 0.85f

            val stem = Path()
            stem.moveTo(cx, foot)
            stem.quadTo(cx + r * 0.10f, foot - r * 0.8f, cx, cy - r * 0.75f)
            canvas.drawPath(stem, stroke)

            for (side in intArrayOf(-1, 1)) {
                val a = Path()
                a.moveTo(cx, foot - r * 0.35f)
                a.quadTo(cx + side * r * 0.62f, foot - r * 0.55f, cx + side * r * 0.66f, cy - r * 0.35f)
                canvas.drawPath(a, stroke)

                val b = Path()
                b.moveTo(cx, foot - r * 0.95f)
                b.quadTo(cx + side * r * 0.42f, cy - r * 0.55f, cx + side * r * 0.36f, cy - r * 0.95f)
                canvas.drawPath(b, stroke)
            }

            fill.color = Color.argb(120, 255, 255, 255)
            canvas.drawCircle(cx, cy - r * 0.78f, r * 0.15f, fill)
            canvas.drawCircle(cx - r * 0.66f, cy - r * 0.36f, r * 0.13f, fill)
            canvas.drawCircle(cx + r * 0.66f, cy - r * 0.36f, r * 0.13f, fill)
        }

        fun shell(cx: Float, cy: Float, r: Float) {
            fill.color = Color.rgb(0xFA, 0xE6, 0xD2)
            canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 180f, 180f, true, fill)
            stroke.color = Color.argb(150, 0xC8, 0x9A, 0x78)
            stroke.strokeWidth = r * 0.12f
            for (i in 0..3) {
                val a = Math.PI + Math.PI * i / 3.0
                canvas.drawLine(cx, cy, cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(), stroke)
            }
        }

        val spots = borderSpots()
        for ((cx, cy, scale) in spots) {
            coral(cx, cy, r0 * scale, corals[rnd.nextInt(corals.size)])
            if (rnd.nextFloat() < 0.6f) {
                shell(cx + r0 * 0.5f * scale, cy + r0 * 0.34f * scale, r0 * 0.24f * scale)
            }
        }

        fun fish(cx: Float, cy: Float, r: Float, color: Int, facingRight: Boolean) {
            val dir = if (facingRight) 1f else -1f
            fill.color = color
            canvas.drawOval(RectF(cx - r, cy - r * 0.55f, cx + r, cy + r * 0.55f), fill)
            val tail = Path()
            tail.moveTo(cx - r * dir, cy)
            tail.lineTo(cx - r * 1.6f * dir, cy - r * 0.5f)
            tail.lineTo(cx - r * 1.6f * dir, cy + r * 0.5f)
            tail.close()
            canvas.drawPath(tail, fill)
            fill.color = Color.WHITE
            canvas.drawCircle(cx + r * 0.5f * dir, cy - r * 0.12f, r * 0.15f, fill)
            fill.color = Color.BLACK
            canvas.drawCircle(cx + r * 0.52f * dir, cy - r * 0.12f, r * 0.07f, fill)
        }
        fish(w * 0.50f, seaH * 0.42f, seaH * 0.26f, Color.rgb(0x2E, 0x8B, 0xE8), true)
        fish(w * 0.44f, h - seaH * 0.38f, seaH * 0.24f, Color.rgb(0xF5, 0x8A, 0x2E), false)
    }

    /**
     * ROYAL GARDEN — clipped hedges, flowers and a stone urn or two, bright
     * enough to feel like an afternoon on a palace lawn.
     */
    private fun drawGarden(canvas: Canvas) {
        val r0 = seaW * 0.62f
        val rnd = Random(90210)
        val blooms = intArrayOf(
            Color.rgb(0xFF, 0x8A, 0xA8), Color.rgb(0xFF, 0xD1, 0x62),
            Color.rgb(0xE6, 0x8A, 0xF0), Color.rgb(0xFF, 0xF0, 0xB8),
            Color.rgb(0xFF, 0xA8, 0x6B)
        )

        fun hedge(cx: Float, cy: Float, r: Float) {
            fill.color = Color.rgb(0x1E, 0x6E, 0x40)
            canvas.drawCircle(cx, cy + r * 0.30f, r * 0.62f, fill)
            fill.color = Color.rgb(0x2C, 0x8C, 0x52)
            canvas.drawCircle(cx - r * 0.30f, cy, r * 0.48f, fill)
            canvas.drawCircle(cx + r * 0.30f, cy + r * 0.10f, r * 0.44f, fill)
            fill.color = Color.rgb(0x46, 0xAE, 0x68)
            canvas.drawCircle(cx - r * 0.12f, cy - r * 0.28f, r * 0.38f, fill)
        }

        fun flower(cx: Float, cy: Float, r: Float, color: Int) {
            stroke.color = Color.rgb(0x2C, 0x8C, 0x52)
            stroke.strokeWidth = r * 0.20f
            canvas.drawLine(cx, cy + r * 1.30f, cx, cy, stroke)
            fill.color = color
            for (i in 0 until 5) {
                val a = (2.0 * Math.PI * i / 5.0) - Math.PI / 2.0
                canvas.drawCircle(
                    cx + (r * 0.52f * cos(a)).toFloat(),
                    cy + (r * 0.52f * sin(a)).toFloat(),
                    r * 0.36f, fill
                )
            }
            fill.color = Color.rgb(0xFF, 0xE9, 0xA8)
            canvas.drawCircle(cx, cy, r * 0.30f, fill)
        }

        for ((cx, cy, scale) in borderSpots()) {
            val r = r0 * scale
            if (rnd.nextFloat() < 0.55f) {
                hedge(cx, cy, r)
                flower(cx + r * 0.52f, cy + r * 0.22f, r * 0.30f, blooms[rnd.nextInt(blooms.size)])
            } else {
                flower(cx, cy, r * 0.46f, blooms[rnd.nextInt(blooms.size)])
                flower(cx - r * 0.50f, cy + r * 0.34f, r * 0.32f, blooms[rnd.nextInt(blooms.size)])
                flower(cx + r * 0.48f, cy + r * 0.40f, r * 0.28f, blooms[rnd.nextInt(blooms.size)])
            }
        }

        // a pair of butterflies, the garden's answer to the reef's fish
        fun butterfly(cx: Float, cy: Float, r: Float, color: Int) {
            fill.color = color
            canvas.drawOval(RectF(cx - r * 1.1f, cy - r * 0.8f, cx - r * 0.1f, cy + r * 0.3f), fill)
            canvas.drawOval(RectF(cx + r * 0.1f, cy - r * 0.8f, cx + r * 1.1f, cy + r * 0.3f), fill)
            fill.color = Color.rgb(0x3A, 0x2A, 0x14)
            canvas.drawRoundRect(RectF(cx - r * 0.10f, cy - r * 0.7f, cx + r * 0.10f, cy + r * 0.5f), r * 0.1f, r * 0.1f, fill)
        }
        butterfly(width * 0.50f, seaH * 0.44f, seaH * 0.24f, Color.rgb(0xFF, 0xC8, 0x5E))
        butterfly(width * 0.44f, height - seaH * 0.40f, seaH * 0.22f, Color.rgb(0xF0, 0x92, 0xC8))
    }

    /**
     * DARK JUNGLE — broad leaves and hanging vines pressing in on the board,
     * with a few fireflies so the gloom still has something alive in it.
     */
    private fun drawJungle(canvas: Canvas) {
        val r0 = seaW * 0.62f
        val rnd = Random(5150)
        val greens = intArrayOf(
            Color.rgb(0x1C, 0x5E, 0x38), Color.rgb(0x25, 0x7A, 0x46),
            Color.rgb(0x12, 0x46, 0x2C), Color.rgb(0x33, 0x8E, 0x50)
        )

        fun leaf(cx: Float, cy: Float, r: Float, angle: Float, color: Int) {
            canvas.save()
            canvas.rotate(angle, cx, cy)
            fill.color = color
            val p = Path()
            p.moveTo(cx, cy - r)
            p.cubicTo(cx + r * 0.78f, cy - r * 0.42f, cx + r * 0.60f, cy + r * 0.72f, cx, cy + r)
            p.cubicTo(cx - r * 0.60f, cy + r * 0.72f, cx - r * 0.78f, cy - r * 0.42f, cx, cy - r)
            p.close()
            canvas.drawPath(p, fill)
            stroke.color = withAlpha(lighten(color, 0.40f), 170)
            stroke.strokeWidth = r * 0.10f
            canvas.drawLine(cx, cy - r * 0.9f, cx, cy + r * 0.9f, stroke)
            for (i in 1..3) {
                val y = cy - r * 0.5f + i * r * 0.40f
                canvas.drawLine(cx, y, cx + r * 0.42f, y + r * 0.20f, stroke)
                canvas.drawLine(cx, y, cx - r * 0.42f, y + r * 0.20f, stroke)
            }
            canvas.restore()
        }

        fun vine(cx: Float, cy: Float, r: Float) {
            stroke.color = Color.rgb(0x1A, 0x4A, 0x2E)
            stroke.strokeWidth = r * 0.16f
            val p = Path()
            p.moveTo(cx, cy - r * 1.4f)
            p.quadTo(cx + r * 0.5f, cy - r * 0.2f, cx - r * 0.2f, cy + r * 1.2f)
            canvas.drawPath(p, stroke)
            fill.color = Color.rgb(0x2C, 0x8C, 0x52)
            canvas.drawCircle(cx + r * 0.26f, cy - r * 0.35f, r * 0.16f, fill)
            canvas.drawCircle(cx - r * 0.02f, cy + r * 0.45f, r * 0.14f, fill)
        }

        for ((cx, cy, scale) in borderSpots()) {
            val r = r0 * scale
            leaf(cx, cy, r * 0.92f, -40f + rnd.nextFloat() * 80f, greens[rnd.nextInt(greens.size)])
            if (rnd.nextFloat() < 0.6f) {
                leaf(cx + r * 0.52f, cy + r * 0.30f, r * 0.62f, -70f + rnd.nextFloat() * 140f,
                     greens[rnd.nextInt(greens.size)])
            }
            if (rnd.nextFloat() < 0.5f) vine(cx - r * 0.45f, cy, r * 0.8f)
        }

        // fireflies
        repeat(14) {
            val fx = rnd.nextFloat() * width
            val fy = rnd.nextFloat() * height
            // keep them off the playfield so nothing competes with the numbers
            if (fx > px(0f) && fx < px(SnlConfig.COLUMNS.toFloat()) &&
                fy > py(0f) && fy < py(SnlConfig.ROWS.toFloat())) return@repeat
            shade.shader = RadialGradient(
                fx, fy, seaH * 0.22f,
                intArrayOf(Color.argb(170, 0xE8, 0xFF, 0x9A), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(fx, fy, seaH * 0.22f, shade)
            shade.shader = null
        }
    }

    /**
     * DANGEROUS ROYAL TEMPLE — carved stone blocks, braziers and gold
     * medallions. The torches glow, which is where the warm light overhead is
     * coming from.
     */
    private fun drawTemple(canvas: Canvas) {
        val r0 = seaW * 0.62f
        val rnd = Random(31415)

        fun block(cx: Float, cy: Float, r: Float) {
            fill.color = Color.rgb(0x5A, 0x46, 0x36)
            canvas.drawRoundRect(RectF(cx - r * 0.86f, cy - r * 0.62f, cx + r * 0.86f, cy + r * 0.62f),
                r * 0.10f, r * 0.10f, fill)
            stroke.color = Color.argb(120, 0x24, 0x18, 0x10)
            stroke.strokeWidth = r * 0.08f
            canvas.drawLine(cx - r * 0.86f, cy, cx + r * 0.86f, cy, stroke)
            canvas.drawLine(cx - r * 0.20f, cy - r * 0.62f, cx - r * 0.20f, cy, stroke)
            canvas.drawLine(cx + r * 0.36f, cy, cx + r * 0.36f, cy + r * 0.62f, stroke)
            stroke.color = Color.argb(70, 0xFF, 0xE0, 0xB0)
            stroke.strokeWidth = r * 0.05f
            canvas.drawLine(cx - r * 0.80f, cy - r * 0.56f, cx + r * 0.80f, cy - r * 0.56f, stroke)
        }

        fun medallion(cx: Float, cy: Float, r: Float) {
            shade.shader = LinearGradient(
                cx, cy - r, cx, cy + r,
                Color.rgb(0xFF, 0xE6, 0xA8), Color.rgb(0xA8, 0x77, 0x14), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 0.56f, shade)
            shade.shader = null
            stroke.color = Color.rgb(0x6B, 0x49, 0x06)
            stroke.strokeWidth = r * 0.09f
            canvas.drawCircle(cx, cy, r * 0.56f, stroke)
            fill.color = Color.rgb(0x6B, 0x49, 0x06)
            canvas.drawPath(starPath(cx, cy, r * 0.32f), fill)
        }

        fun torch(cx: Float, cy: Float, r: Float) {
            // bowl
            fill.color = Color.rgb(0x3E, 0x30, 0x26)
            val bowl = Path()
            bowl.moveTo(cx - r * 0.56f, cy)
            bowl.lineTo(cx + r * 0.56f, cy)
            bowl.lineTo(cx + r * 0.30f, cy + r * 0.62f)
            bowl.lineTo(cx - r * 0.30f, cy + r * 0.62f)
            bowl.close()
            canvas.drawPath(bowl, fill)
            // the glow it casts
            shade.shader = RadialGradient(
                cx, cy - r * 0.35f, r * 1.5f,
                intArrayOf(Color.argb(140, 0xFF, 0xB4, 0x4E), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy - r * 0.35f, r * 1.5f, shade)
            shade.shader = null
            // flame
            fill.color = Color.rgb(0xFF, 0x8A, 0x1E)
            val f = Path()
            f.moveTo(cx, cy - r * 1.10f)
            f.cubicTo(cx + r * 0.58f, cy - r * 0.42f, cx + r * 0.34f, cy, cx, cy)
            f.cubicTo(cx - r * 0.34f, cy, cx - r * 0.58f, cy - r * 0.42f, cx, cy - r * 1.10f)
            f.close()
            canvas.drawPath(f, fill)
            fill.color = Color.rgb(0xFF, 0xE3, 0x8A)
            val g = Path()
            g.moveTo(cx, cy - r * 0.72f)
            g.cubicTo(cx + r * 0.30f, cy - r * 0.28f, cx + r * 0.16f, cy - r * 0.05f, cx, cy - r * 0.05f)
            g.cubicTo(cx - r * 0.16f, cy - r * 0.05f, cx - r * 0.30f, cy - r * 0.28f, cx, cy - r * 0.72f)
            g.close()
            canvas.drawPath(g, fill)
        }

        for ((cx, cy, scale) in borderSpots()) {
            val r = r0 * scale
            block(cx, cy + r * 0.30f, r)
            when {
                rnd.nextFloat() < 0.42f -> torch(cx, cy - r * 0.55f, r * 0.78f)
                else -> medallion(cx, cy - r * 0.30f, r * 0.86f)
            }
        }
    }

    /** The driftwood frame the board is built on, lashed with rope. */
    private fun drawFrame(canvas: Canvas) {
        val th = theme
        val w = width.toFloat()
        val h = height.toFloat()
        val r = unit * 0.55f
        val outer = RectF(seaW * 0.42f, seaH * 0.42f, w - seaW * 0.42f, h - seaH * 0.42f)

        shadow.alpha = 80
        canvas.drawRoundRect(
            RectF(outer.left + seaW * 0.14f, outer.top + seaH * 0.22f,
                  outer.right + seaW * 0.14f, outer.bottom + seaH * 0.24f), r, r, shadow
        )

        shade.shader = LinearGradient(
            0f, outer.top, 0f, outer.bottom,
            intArrayOf(th.frameLight, th.frameDark, th.frameMid, th.frameDark),
            floatArrayOf(0f, 0.38f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(outer, r, r, shade)
        shade.shader = null

        stroke.color = withAlpha(th.frameEdge, 55)
        stroke.strokeWidth = unit * 0.035f
        val rnd = Random(777)
        repeat(20) {
            val y = outer.top + rnd.nextFloat() * outer.height()
            val x0 = outer.left + rnd.nextFloat() * outer.width() * 0.5f
            canvas.drawLine(x0, y, x0 + outer.width() * (0.10f + rnd.nextFloat() * 0.22f), y, stroke)
        }

        stroke.color = th.frameEdge
        stroke.strokeWidth = unit * 0.075f
        canvas.drawRoundRect(outer, r, r, stroke)

        // rope binding just inside the frame
        val rope = RectF(
            px(0f) - seaW * 0.26f, py(0f) - seaH * 0.26f,
            px(SnlConfig.COLUMNS.toFloat()) + seaW * 0.26f,
            py(SnlConfig.ROWS.toFloat()) + seaH * 0.26f
        )
        stroke.color = th.lashing
        stroke.strokeWidth = min(seaW, seaH) * 0.26f
        canvas.drawRoundRect(rope, r * 0.5f, r * 0.5f, stroke)
        stroke.color = withAlpha(th.frameDark, 140)
        stroke.strokeWidth = min(seaW, seaH) * 0.08f
        val tick = min(seaW, seaH) * 0.62f
        val bump = min(seaW, seaH) * 0.10f
        var x = rope.left
        while (x < rope.right) {
            canvas.drawLine(x, rope.top - bump, x + tick * 0.4f, rope.top + bump, stroke)
            canvas.drawLine(x, rope.bottom - bump, x + tick * 0.4f, rope.bottom + bump, stroke)
            x += tick
        }
        var y = rope.top
        while (y < rope.bottom) {
            canvas.drawLine(rope.left - bump, y, rope.left + bump, y + tick * 0.4f, stroke)
            canvas.drawLine(rope.right - bump, y, rope.right + bump, y + tick * 0.4f, stroke)
            y += tick
        }

        fill.color = th.innerEdge
        canvas.drawRect(
            RectF(px(0f), py(0f), px(SnlConfig.COLUMNS.toFloat()), py(SnlConfig.ROWS.toFloat())), fill
        )
    }

    /**
     * The 100 squares, each a little plank: pale driftwood and weathered
     * blue-grey in turn, with grain, a lifted edge and its number burned in.
     */
    private fun drawPlanks(canvas: Canvas) {
        val th = theme
        val rnd = Random(31337)
        val insetX = cellW * 0.030f
        val insetY = cellH * 0.045f
        for (n in 1..SnlConfig.LAST_CELL) {
            val (row, col) = SnlConfig.cellToGrid(n)
            val l = px(col.toFloat())
            val t = py(row.toFloat())
            val rect = RectF(l + insetX, t + insetY, l + cellW - insetX, t + cellH - insetY)
            val radius = unit * 0.14f

            val pale = (row + col) % 2 == 0
            val base = if (pale) th.tilePale else th.tileDark

            shadow.alpha = 55
            canvas.drawRoundRect(
                RectF(rect.left + insetX * 0.8f, rect.top + insetY * 0.9f,
                      rect.right + insetX * 0.8f, rect.bottom + insetY * 0.9f), radius, radius, shadow
            )

            shade.shader = LinearGradient(
                rect.left, rect.top, rect.left, rect.bottom,
                lighten(base, 0.18f), darken(base, 0.14f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rect, radius, radius, shade)
            shade.shader = null

            stroke.color = withAlpha(darken(base, 0.34f), 60)
            stroke.strokeWidth = unit * 0.020f
            for (g in 0 until 2) {
                val gy = rect.top + rect.height() * (0.34f + 0.30f * g) + rnd.nextFloat() * cellH * 0.05f
                canvas.drawLine(rect.left + cellW * 0.10f, gy, rect.right - cellW * 0.10f, gy, stroke)
            }

            stroke.color = Color.argb(90, 255, 255, 255)
            stroke.strokeWidth = unit * 0.024f
            canvas.drawLine(
                rect.left + radius, rect.top + cellH * 0.030f,
                rect.right - radius, rect.top + cellH * 0.030f, stroke
            )

            numberPaint.color = if (pale) th.numberOnPale else th.numberOnDark
            canvas.drawText(n.toString(), l + cellW * 0.30f, t + cellH * 0.34f, numberPaint)

            if (n == SnlConfig.LAST_CELL) {
                drawGoldStar(canvas, l + cellW * 0.68f, t + cellH * 0.66f, unit * 0.28f)
            }
            if (n == 1) drawStartArrow(canvas, l + cellW * 0.70f, t + cellH * 0.68f, unit * 0.22f)
        }
    }

    private fun drawGoldStar(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        shade.shader = LinearGradient(
            cx, cy - r, cx, cy + r,
            lighten(theme.starColor, 0.45f), darken(theme.starColor, 0.30f), Shader.TileMode.CLAMP
        )
        val path = starPath(cx, cy, r)
        canvas.drawPath(path, shade)
        shade.shader = null
        stroke.color = Color.rgb(0x8A, 0x5A, 0x0C)
        stroke.strokeWidth = r * 0.16f
        canvas.drawPath(path, stroke)
    }

    private fun drawStartArrow(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Path()
        p.moveTo(cx - r, cy - r * 0.45f)
        p.lineTo(cx + r * 0.25f, cy - r * 0.45f)
        p.lineTo(cx + r * 0.25f, cy - r)
        p.lineTo(cx + r, cy)
        p.lineTo(cx + r * 0.25f, cy + r)
        p.lineTo(cx + r * 0.25f, cy + r * 0.45f)
        p.lineTo(cx - r, cy + r * 0.45f)
        p.close()
        fill.color = Color.rgb(0x8A, 0x5A, 0x22)
        canvas.drawPath(p, fill)
    }

    // ---------------------------------------------------- snakes and ladders

    private class Drawn(
        val spec: SnlSpecial,
        val spine: List<Pair<Float, Float>>
    )

    private var drawnSpecials: List<Drawn> = emptyList()

    private fun rebuildSpecials() {
        if (cellW <= 0f) { drawnSpecials = emptyList(); return }
        drawnSpecials = SnlConfig.specialsFor(difficulty).map { spec ->
            if (spec.type == SpecialType.SNAKE) Drawn(spec, buildSpine(spec))
            else Drawn(spec, listOf(screenOf(spec.entryCell), screenOf(spec.exitCell)))
        }
    }

    /** A serpentine curve from head square to tail square. */
    private fun buildSpine(spec: SnlSpecial): List<Pair<Float, Float>> {
        val (hx, hy) = screenOf(spec.entryCell)
        val (tx, ty) = screenOf(spec.exitCell)
        val dx = tx - hx
        val dy = ty - hy
        val len = hypot(dx, dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len

        val span = abs(spec.entryCell - spec.exitCell)
        val waves = when {
            span >= 40 -> 2.6f
            span >= 26 -> 2.0f
            else -> 1.5f
        }
        val amp = unit * when {
            span >= 40 -> 1.05f
            span >= 26 -> 0.85f
            else -> 0.62f
        }

        val steps = 150
        val out = ArrayList<Pair<Float, Float>>(steps + 1)
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            // the swing fades at both ends so head and tail sit on their squares
            val envelope = sin(t * Math.PI).toFloat().pow(0.65f)
            val off = amp * envelope * sin(t * waves * 2f * Math.PI.toFloat())
            val sx = (hx + dx * t + nx * off).coerceIn(px(0.20f), px(SnlConfig.COLUMNS - 0.20f))
            val sy = (hy + dy * t + ny * off).coerceIn(py(0.20f), py(SnlConfig.ROWS - 0.20f))
            out += sx to sy
        }
        return out
    }

    /** Thick behind the head, long gentle taper, needle-fine tail. */
    private fun widthAt(t: Float, maxW: Float): Float {
        val neck = if (t < 0.10f) 0.80f + 0.20f * (t / 0.10f) else 1f
        val taper = (1f - t.pow(1.35f)).coerceAtLeast(0f).pow(0.62f)
        return maxW * neck * taper
    }

    /** Unit tangent and normal of the spine at [i]. */
    private fun frameAt(sp: List<Pair<Float, Float>>, i: Int): FloatArray {
        val p = sp[max(0, i - 1)]
        val q = sp[min(sp.lastIndex, i + 1)]
        val tx = q.first - p.first
        val ty = q.second - p.second
        val tl = hypot(tx, ty).coerceAtLeast(0.0001f)
        return floatArrayOf(tx / tl, ty / tl, -ty / tl, tx / tl, atan2(ty, tx))
    }

    private fun bodyPath(sp: List<Pair<Float, Float>>, maxW: Float): Path {
        val n = sp.lastIndex
        val leftSide = ArrayList<Pair<Float, Float>>(sp.size)
        val rightSide = ArrayList<Pair<Float, Float>>(sp.size)
        for (i in sp.indices) {
            val f = frameAt(sp, i)
            val w = widthAt(i.toFloat() / n, maxW) / 2f
            leftSide += (sp[i].first + f[2] * w) to (sp[i].second + f[3] * w)
            rightSide += (sp[i].first - f[2] * w) to (sp[i].second - f[3] * w)
        }
        val p = Path()
        p.moveTo(leftSide[0].first, leftSide[0].second)
        for (i in 1 until leftSide.size) p.lineTo(leftSide[i].first, leftSide[i].second)
        for (i in rightSide.indices.reversed()) p.lineTo(rightSide[i].first, rightSide[i].second)
        p.close()
        return p
    }

    /** A real snake head: wedge-shaped, with a snout, jaw, brow and eye. */
    private fun headPath(hx: Float, hy: Float, ang: Float, l: Float, wd: Float): Path {
        val c = cos(ang)
        val s = sin(ang)
        fun tx(x: Float, y: Float) = hx + x * c - y * s
        fun ty(x: Float, y: Float) = hy + x * s + y * c
        val p = Path()
        p.moveTo(tx(l, 0f), ty(l, 0f))
        p.cubicTo(
            tx(l * 0.88f, -wd * 0.52f), ty(l * 0.88f, -wd * 0.52f),
            tx(l * 0.50f, -wd * 0.98f), ty(l * 0.50f, -wd * 0.98f),
            tx(l * 0.02f, -wd), ty(l * 0.02f, -wd)
        )
        p.cubicTo(
            tx(-l * 0.34f, -wd * 1.02f), ty(-l * 0.34f, -wd * 1.02f),
            tx(-l * 0.62f, -wd * 0.78f), ty(-l * 0.62f, -wd * 0.78f),
            tx(-l * 0.72f, -wd * 0.56f), ty(-l * 0.72f, -wd * 0.56f)
        )
        p.lineTo(tx(-l * 0.72f, wd * 0.56f), ty(-l * 0.72f, wd * 0.56f))
        p.cubicTo(
            tx(-l * 0.62f, wd * 0.78f), ty(-l * 0.62f, wd * 0.78f),
            tx(-l * 0.34f, wd * 1.02f), ty(-l * 0.34f, wd * 1.02f),
            tx(l * 0.02f, wd), ty(l * 0.02f, wd)
        )
        p.cubicTo(
            tx(l * 0.50f, wd * 0.98f), ty(l * 0.50f, wd * 0.98f),
            tx(l * 0.88f, wd * 0.52f), ty(l * 0.88f, wd * 0.52f),
            tx(l, 0f), ty(l, 0f)
        )
        p.close()
        return p
    }

    /**
     * base, belly, dark, pattern colour, pattern kind (0 saddle, 1 band, 2 diamond).
     * Taken from the world the board is in, so a garden snake and a temple
     * snake are the same animal in different paint.
     */
    private fun skinOf(skin: Int): IntArray = theme.snakeSkin(skin)

    @Suppress("unused")
    private fun legacySkinOf(skin: Int): IntArray = when (skin % 6) {
        0 -> intArrayOf(Color.rgb(38, 120, 54), Color.rgb(214, 228, 150), Color.rgb(14, 58, 26), Color.rgb(16, 74, 32), 0)
        1 -> intArrayOf(Color.rgb(176, 44, 40), Color.rgb(242, 206, 176), Color.rgb(92, 16, 16), Color.rgb(60, 12, 14), 1)
        2 -> intArrayOf(Color.rgb(96, 62, 150), Color.rgb(224, 208, 246), Color.rgb(42, 22, 74), Color.rgb(38, 18, 70), 2)
        3 -> intArrayOf(Color.rgb(198, 150, 40), Color.rgb(248, 232, 182), Color.rgb(104, 72, 12), Color.rgb(70, 46, 8), 1)
        4 -> intArrayOf(Color.rgb(26, 108, 140), Color.rgb(196, 232, 244), Color.rgb(10, 52, 74), Color.rgb(8, 44, 62), 0)
        else -> intArrayOf(Color.rgb(72, 78, 92), Color.rgb(206, 212, 224), Color.rgb(26, 30, 40), Color.rgb(22, 26, 34), 2)
    }

    private fun drawSnakes(canvas: Canvas) {
        for (d in drawnSpecials) {
            if (d.spec.type != SpecialType.SNAKE) continue
            drawSnake(canvas, d)
        }
    }

    private fun drawSnake(canvas: Canvas, d: Drawn) {
        val sp = d.spine
        val n = sp.lastIndex
        val skin = skinOf(d.spec.skin)
        val base = skin[0]
        val belly = skin[1]
        val dark = skin[2]
        val patC = skin[3]
        val pattern = skin[4]

        val maxW = unit * 0.30f
        val body = bodyPath(sp, maxW)

        // shadow on the planks
        canvas.save()
        canvas.translate(maxW * 0.30f, maxW * 0.42f)
        fill.color = Color.argb(76, 0, 0, 40)
        canvas.drawPath(body, fill)
        canvas.restore()

        fill.color = base
        canvas.drawPath(body, fill)

        canvas.save()
        canvas.clipPath(body)

        // one side catches the light, the other falls away — that is what
        // makes a flat shape read as a round body
        for (side in intArrayOf(1, -1)) {
            val line = Path()
            for (i in 0..n) {
                val f = frameAt(sp, i)
                val w = widthAt(i.toFloat() / n, maxW) / 2f
                val x = sp[i].first + f[2] * w * side
                val y = sp[i].second + f[3] * w * side
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
            }
            stroke.color = if (side == 1) withAlpha(belly, 217) else withAlpha(dark, 178)
            stroke.strokeWidth = maxW * 0.34f
            canvas.drawPath(line, stroke)
        }

        // markings
        fill.color = withAlpha(patC, 230)
        var i = 6
        val stepPat = if (pattern == 1) 7 else 11
        while (i < n - 6) {
            val f = frameAt(sp, i)
            val w = widthAt(i.toFloat() / n, maxW) / 2f
            canvas.save()
            canvas.translate(sp[i].first, sp[i].second)
            canvas.rotate(Math.toDegrees(f[4].toDouble()).toFloat())
            when (pattern) {
                1 -> canvas.drawRect(RectF(-w * 0.30f, -w * 1.2f, w * 0.32f, w * 1.2f), fill)
                2 -> {
                    val dia = Path()
                    dia.moveTo(0f, -w * 1.05f)
                    dia.lineTo(w * 0.85f, 0f)
                    dia.lineTo(0f, w * 1.05f)
                    dia.lineTo(-w * 0.85f, 0f)
                    dia.close()
                    canvas.drawPath(dia, fill)
                }
                else -> {
                    canvas.drawOval(RectF(-w * 0.55f, -w * 0.84f, w * 0.55f, w * 0.0f), fill)
                    canvas.drawOval(RectF(-w * 0.55f, w * 0.0f, w * 0.55f, w * 0.84f), fill)
                }
            }
            canvas.restore()
            i += stepPat
        }

        // scale rows
        val scaleDark = withAlpha(darken(base, 0.45f), 115)
        i = 2
        while (i < n - 2) {
            val f = frameAt(sp, i)
            val w = widthAt(i.toFloat() / n, maxW) / 2f
            if (w >= 1.2f) {
                val rows = max(3, Math.round(w / (unit * 0.05f)))
                canvas.save()
                canvas.translate(sp[i].first, sp[i].second)
                canvas.rotate(Math.toDegrees(f[4].toDouble()).toFloat())
                for (k in -rows..rows) {
                    val y = (k.toFloat() / rows) * w * 0.94f
                    val r = w / rows * 0.95f
                    stroke.color = scaleDark
                    stroke.strokeWidth = max(0.6f, r * 0.30f)
                    canvas.drawArc(RectF(-r * 0.95f, y - r * 0.95f, r * 0.95f, y + r * 0.95f), -112f, 224f, false, stroke)
                    stroke.color = Color.argb(34, 255, 255, 255)
                    stroke.strokeWidth = max(0.5f, r * 0.18f)
                    canvas.drawArc(
                        RectF(-r * 0.80f, y - r * 0.12f - r * 0.80f, r * 0.80f, y - r * 0.12f + r * 0.80f),
                        -99f, 198f, false, stroke
                    )
                }
                canvas.restore()
            }
            i += 3
        }

        // faint sheen down the length
        shade.shader = LinearGradient(
            sp[0].first, sp[0].second, sp[n].first, sp[n].second,
            intArrayOf(Color.argb(46, 255, 255, 255), Color.argb(10, 255, 255, 255), Color.argb(36, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(body, shade)
        shade.shader = null
        canvas.restore()

        stroke.color = dark
        stroke.strokeWidth = max(1.2f, maxW * 0.075f)
        canvas.drawPath(body, stroke)

        drawSnakeHead(canvas, sp, maxW, base, belly, dark)
    }

    private fun drawSnakeHead(
        canvas: Canvas,
        sp: List<Pair<Float, Float>>,
        maxW: Float,
        base: Int,
        belly: Int,
        dark: Int
    ) {
        val f = frameAt(sp, 0)
        val ang = atan2(-f[1], -f[0])          // the head faces away from the body
        val hx = sp[0].first
        val hy = sp[0].second
        val l = maxW * 1.15f
        val wd = maxW * 0.62f
        val c = cos(ang)
        val s = sin(ang)
        fun tx(x: Float, y: Float) = hx + x * c - y * s
        fun ty(x: Float, y: Float) = hy + x * s + y * c

        // forked tongue, drawn first so the head covers its root
        stroke.color = Color.rgb(206, 32, 48)
        stroke.strokeWidth = maxW * 0.11f
        canvas.drawLine(tx(l * 0.98f, 0f), ty(l * 0.98f, 0f), tx(l * 1.55f, 0f), ty(l * 1.55f, 0f), stroke)
        canvas.drawLine(
            tx(l * 1.55f, 0f), ty(l * 1.55f, 0f),
            tx(l * 1.95f, -wd * 0.42f), ty(l * 1.95f, -wd * 0.42f), stroke
        )
        canvas.drawLine(
            tx(l * 1.55f, 0f), ty(l * 1.55f, 0f),
            tx(l * 1.95f, wd * 0.42f), ty(l * 1.95f, wd * 0.42f), stroke
        )

        val head = headPath(hx, hy, ang, l, wd)

        canvas.save()
        canvas.translate(maxW * 0.26f, maxW * 0.36f)
        fill.color = Color.argb(71, 0, 0, 40)
        canvas.drawPath(head, fill)
        canvas.restore()

        shade.shader = LinearGradient(
            tx(0f, -wd), ty(0f, -wd), tx(0f, wd), ty(0f, wd),
            intArrayOf(lighten(base, 0.28f), base, darken(base, 0.30f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(head, shade)
        shade.shader = null

        canvas.save()
        canvas.clipPath(head)
        // head scales
        stroke.color = withAlpha(darken(base, 0.45f), 102)
        stroke.strokeWidth = maxW * 0.05f
        for (i in 0 until 7) {
            for (sg in intArrayOf(-1, 1)) {
                val x = -l * 0.55f + (i / 6f) * l * 1.35f
                val y = sg * wd * (0.30f + 0.22f * sin(i * 0.9f))
                val cx = tx(x, y)
                val cy = ty(x, y)
                val rr = wd * 0.22f
                canvas.drawArc(
                    RectF(cx - rr, cy - rr, cx + rr, cy + rr),
                    Math.toDegrees(ang.toDouble()).toFloat() - 108f, 216f, false, stroke
                )
            }
        }
        // jaw line
        stroke.color = withAlpha(dark, 191)
        stroke.strokeWidth = maxW * 0.09f
        val jaw = Path()
        jaw.moveTo(tx(l * 0.92f, wd * 0.10f), ty(l * 0.92f, wd * 0.10f))
        jaw.quadTo(
            tx(l * 0.15f, wd * 0.72f), ty(l * 0.15f, wd * 0.72f),
            tx(-l * 0.62f, wd * 0.50f), ty(-l * 0.62f, wd * 0.50f)
        )
        canvas.drawPath(jaw, stroke)
        // pale chin
        stroke.color = withAlpha(belly, 120)
        stroke.strokeWidth = maxW * 0.14f
        canvas.drawLine(
            tx(l * 0.70f, wd * 0.62f), ty(l * 0.70f, wd * 0.62f),
            tx(-l * 0.40f, wd * 0.80f), ty(-l * 0.40f, wd * 0.80f), stroke
        )
        canvas.restore()

        stroke.color = dark
        stroke.strokeWidth = max(1.2f, maxW * 0.075f)
        canvas.drawPath(head, stroke)

        // brow, eye, slit pupil, catchlight
        for (sg in intArrayOf(-1, 1)) {
            val ex = tx(l * 0.24f, sg * wd * 0.52f)
            val ey = ty(l * 0.24f, sg * wd * 0.52f)
            canvas.save()
            canvas.translate(ex, ey)
            canvas.rotate(Math.toDegrees(ang.toDouble()).toFloat())
            fill.color = darken(base, 0.35f)
            canvas.drawOval(RectF(-wd * 0.34f, -wd * 0.27f, wd * 0.34f, wd * 0.27f), fill)
            fill.color = Color.rgb(244, 206, 74)
            canvas.drawOval(RectF(-wd * 0.25f, -wd * 0.20f, wd * 0.25f, wd * 0.20f), fill)
            fill.color = Color.BLACK
            canvas.drawOval(RectF(-wd * 0.055f, -wd * 0.17f, wd * 0.055f, wd * 0.17f), fill)
            fill.color = Color.argb(217, 255, 255, 255)
            canvas.drawCircle(-wd * 0.09f, -wd * 0.09f, wd * 0.07f, fill)
            canvas.restore()
        }

        // nostrils
        fill.color = Color.argb(140, 0, 0, 0)
        for (sg in intArrayOf(-1, 1)) {
            canvas.drawCircle(tx(l * 0.80f, sg * wd * 0.28f), ty(l * 0.80f, sg * wd * 0.28f), wd * 0.055f, fill)
        }
    }

    // ------------------------------------------------------------- ladders

    private fun drawLadders(canvas: Canvas) {
        for (d in drawnSpecials) {
            if (d.spec.type != SpecialType.LADDER) continue
            val (x0, y0) = d.spine[0]
            val (x1, y1) = d.spine[1]
            drawLadder(canvas, x0, y0, x1, y1, d.spec.skin)
        }
    }

    /**
     * A driftwood ladder: round poles with a light and a dark edge so they read
     * as timber, and rungs lashed on with rope at both ends.
     */
    private fun drawLadder(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, skin: Int) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = hypot(dx, dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len
        val half = unit * 0.34f

        val wood = theme.ladderWood(skin)
        val ropeColor = theme.ropeColor

        canvas.save()
        canvas.translate(unit * 0.09f, unit * 0.12f)
        stroke.color = Color.argb(60, 0, 0, 0)
        stroke.strokeWidth = unit * 0.14f
        canvas.drawLine(x0 + nx * half, y0 + ny * half, x1 + nx * half, y1 + ny * half, stroke)
        canvas.drawLine(x0 - nx * half, y0 - ny * half, x1 - nx * half, y1 - ny * half, stroke)
        canvas.restore()

        val rungs = (len / (unit * 0.66f)).toInt().coerceAtLeast(3)
        for (i in 1 until rungs) {
            val t = i.toFloat() / rungs
            val rx = x0 + dx * t
            val ry = y0 + dy * t
            stroke.color = wood[2]
            stroke.strokeWidth = unit * 0.115f
            canvas.drawLine(rx + nx * half, ry + ny * half, rx - nx * half, ry - ny * half, stroke)
            stroke.color = wood[0]
            stroke.strokeWidth = unit * 0.080f
            canvas.drawLine(rx + nx * half, ry + ny * half, rx - nx * half, ry - ny * half, stroke)
            stroke.color = withAlpha(wood[1], 150)
            stroke.strokeWidth = unit * 0.028f
            canvas.drawLine(
                rx + nx * half * 0.86f, ry + ny * half * 0.86f - unit * 0.022f,
                rx - nx * half * 0.86f, ry - ny * half * 0.86f - unit * 0.022f, stroke
            )
            stroke.color = ropeColor
            stroke.strokeWidth = unit * 0.032f
            for (sg in intArrayOf(-1, 1)) {
                val lx = rx + nx * half * sg
                val ly = ry + ny * half * sg
                canvas.drawLine(
                    lx - nx * unit * 0.055f - dx / len * unit * 0.055f,
                    ly - ny * unit * 0.055f - dy / len * unit * 0.055f,
                    lx + nx * unit * 0.055f + dx / len * unit * 0.055f,
                    ly + ny * unit * 0.055f + dy / len * unit * 0.055f, stroke
                )
            }
        }

        for (sg in intArrayOf(-1, 1)) {
            val ax = x0 + nx * half * sg
            val ay = y0 + ny * half * sg
            val bx = x1 + nx * half * sg
            val by = y1 + ny * half * sg
            stroke.color = wood[2]
            stroke.strokeWidth = unit * 0.155f
            canvas.drawLine(ax, ay, bx, by, stroke)
            stroke.color = wood[0]
            stroke.strokeWidth = unit * 0.112f
            canvas.drawLine(ax, ay, bx, by, stroke)
            stroke.color = wood[1]
            stroke.strokeWidth = unit * 0.038f
            canvas.drawLine(
                ax - nx * unit * 0.024f, ay - ny * unit * 0.024f,
                bx - nx * unit * 0.024f, by - ny * unit * 0.024f, stroke
            )
        }
    }

    // ---------------------------------------------------------------- pieces

    private fun drawGlow(canvas: Canvas) {
        val c = glowCell ?: return
        val (cx, cy) = screenOf(c)
        val p = 0.5f + 0.5f * sin(glowPhase)
        val r = unit * (0.50f + 0.24f * p)
        fill.color = Color.argb((95 + 90 * p).toInt().coerceIn(0, 255), 0xFF, 0xE0, 0x7A)
        canvas.drawCircle(cx, cy, r, fill)
        fill.color = Color.argb((140 + 80 * p).toInt().coerceIn(0, 255), 0xFF, 0xF6, 0xD2)
        canvas.drawCircle(cx, cy, r * 0.52f, fill)
    }

    private fun drawPieces(canvas: Canvas) {
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Piece>>()
        for (p in pieces) {
            val pos = displayed[p.id] ?: continue
            val key = Math.round(pos.first * 3) to Math.round(pos.second * 3)
            byCell.getOrPut(key) { mutableListOf() }.add(p)
        }
        for ((key, group) in byCell) {
            val row = key.first / 3f
            val col = key.second / 3f
            val offsets = fanOffsets(group.size)
            val shrink = when (group.size) {
                0, 1 -> 1f
                2 -> 0.82f
                3 -> 0.72f
                else -> 0.64f
            }
            group.forEachIndexed { i, piece ->
                val (ox, oy) = offsets[i]
                drawPiece(canvas, px(col) + ox * cellW, py(row) + oy * cellH, piece.color, shrink)
            }
        }
    }

    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.17f to 0f, 0.17f to 0f)
        3 -> listOf(0f to -0.18f, -0.18f to 0.14f, 0.18f to 0.14f)
        else -> listOf(-0.17f to -0.17f, 0.17f to -0.17f, -0.17f to 0.17f, 0.17f to 0.17f)
    }

    /** The same lit dome used on the Ludo board, so both boards feel like one game. */
    private fun drawPiece(canvas: Canvas, cx: Float, cy: Float, color: PlayerColor, scale: Float) {
        val radius = unit * 0.38f * scale
        val base = colorOf(color)
        val art = TokenArts.byId(tokenArtId)

        if (art.halo != 0) {
            shade.shader = RadialGradient(
                cx, cy, radius * 1.8f,
                intArrayOf(art.halo, Color.TRANSPARENT),
                floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, radius * 1.8f, shade)
            shade.shader = null
        }

        shadow.alpha = 80
        canvas.drawOval(
            RectF(cx - radius * 0.95f, cy + radius * 0.34f, cx + radius * 0.95f, cy + radius * 1.0f),
            shadow
        )

        fill.color = Color.rgb(0xF6, 0xEC, 0xD6)
        canvas.drawCircle(cx, cy + radius * 0.05f, radius * 1.14f, fill)
        fill.color = darken(base, 0.55f)
        canvas.drawCircle(cx, cy + radius * 0.04f, radius * 1.04f, fill)
        if (art.id != Cosmetics.TOKEN_CLASSIC) {
            fill.color = art.trim
            canvas.drawCircle(cx, cy + radius * 0.02f, radius * 0.98f, fill)
        }

        shade.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.40f, radius * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, shade)
        shade.shader = null

        fill.color = art.inset
        canvas.drawCircle(cx, cy, radius * 0.60f, fill)
        fill.color = base
        canvas.drawPath(ornamentPath(cx, cy, radius * 0.50f, art.ornament), fill)

        gloss.shader = RadialGradient(
            cx - radius * 0.34f, cy - radius * 0.46f, radius * 0.75f,
            Color.argb((140 + 115 * art.sheen).toInt().coerceIn(0, 255), 255, 255, 255),
            Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, gloss)
        gloss.shader = null
    }

    /**
     * The mark a token skin wears in the middle. Same size for every skin, so
     * no counter is harder to pick out than any other.
     */
    private fun ornamentPath(cx: Float, cy: Float, r: Float, ornament: TokenOrnament): Path {
        val p = Path()
        when (ornament) {
            TokenOrnament.STAR -> return starPath(cx, cy, r)
            TokenOrnament.GEM -> {
                p.moveTo(cx, cy - r); p.lineTo(cx + r * 0.86f, cy - r * 0.18f)
                p.lineTo(cx, cy + r); p.lineTo(cx - r * 0.86f, cy - r * 0.18f); p.close()
            }
            TokenOrnament.FLAME -> {
                p.moveTo(cx, cy - r * 1.05f)
                p.cubicTo(cx + r * 0.90f, cy - r * 0.25f, cx + r * 0.55f, cy + r, cx, cy + r)
                p.cubicTo(cx - r * 0.55f, cy + r, cx - r * 0.90f, cy - r * 0.25f, cx, cy - r * 1.05f)
                p.close()
            }
            TokenOrnament.CRYSTAL -> {
                p.moveTo(cx, cy - r); p.lineTo(cx + r * 0.52f, cy - r * 0.30f)
                p.lineTo(cx + r * 0.34f, cy + r * 0.92f); p.lineTo(cx - r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.52f, cy - r * 0.30f); p.close()
            }
            TokenOrnament.CROWN -> {
                p.moveTo(cx - r * 0.88f, cy + r * 0.62f); p.lineTo(cx - r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx - r * 0.40f, cy + r * 0.06f); p.lineTo(cx, cy - r * 0.86f)
                p.lineTo(cx + r * 0.40f, cy + r * 0.06f); p.lineTo(cx + r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx + r * 0.88f, cy + r * 0.62f); p.close()
            }
            TokenOrnament.BOLT -> {
                p.moveTo(cx + r * 0.30f, cy - r); p.lineTo(cx - r * 0.55f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.02f, cy + r * 0.12f); p.lineTo(cx - r * 0.28f, cy + r)
                p.lineTo(cx + r * 0.58f, cy - r * 0.18f); p.lineTo(cx + r * 0.04f, cy - r * 0.18f)
                p.close()
            }
            TokenOrnament.PRISM -> {
                for (i in 0 until 3) {
                    val a = (-Math.PI / 2 + i * 2 * Math.PI / 3)
                    p.moveTo(cx, cy)
                    p.lineTo(cx + (r * cos(a - 0.42)).toFloat(), cy + (r * sin(a - 0.42)).toFloat())
                    p.lineTo(cx + (r * cos(a + 0.42)).toFloat(), cy + (r * sin(a + 0.42)).toFloat())
                    p.close()
                }
            }
            TokenOrnament.SCALE -> {
                for (i in 0 until 3) {
                    val oy = cy - r * 0.45f + i * r * 0.46f
                    val rr = r * (0.92f - i * 0.16f)
                    p.addArc(RectF(cx - rr, oy - rr * 0.8f, cx + rr, oy + rr * 0.8f), 180f, 180f)
                    p.close()
                }
            }
            TokenOrnament.RING -> {
                p.addCircle(cx, cy, r * 0.86f, Path.Direction.CW)
                p.addCircle(cx, cy, r * 0.46f, Path.Direction.CCW)
            }
        }
        return p
    }

    private fun starPath(cx: Float, cy: Float, outerR: Float): Path {
        val path = Path()
        val innerR = outerR * 0.45f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outerR else innerR
            val a = Math.PI / 2 * -1 + i * Math.PI / 5
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }
}
