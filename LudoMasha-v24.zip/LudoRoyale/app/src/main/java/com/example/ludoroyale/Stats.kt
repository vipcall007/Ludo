package com.example.ludoroyale

import android.content.Context
import android.content.SharedPreferences
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.CosmeticItem
import com.example.ludoroyale.cosmetics.CosmeticType
import com.example.ludoroyale.cosmetics.UnlockMethod
import com.example.ludoroyale.model.GameMode
import com.example.ludoroyale.progression.DailyRewards
import com.example.ludoroyale.progression.League
import com.example.ludoroyale.progression.LeagueRules
import com.example.ludoroyale.progression.Mission
import com.example.ludoroyale.progression.MissionCatalog
import com.example.ludoroyale.progression.MissionCodec
import com.example.ludoroyale.progression.MysteryChest
import com.example.ludoroyale.progression.Progression
import com.example.ludoroyale.progression.RewardGrant
import com.example.ludoroyale.progression.RewardKind
import com.example.ludoroyale.progression.Season

/**
 * Everything the game remembers about this player between sessions.
 *
 * It is all kept on the phone, in one preferences file, and none of it is sent
 * anywhere. Coins are a number in this file: they cannot be bought, cashed out
 * or wagered, and nothing here is ever read by the rules engine, so no amount
 * of any of it changes how the dice falls or where a piece may go.
 *
 * The file carries a [STORE_VERSION] so an older install can be brought
 * forward without losing anything. A player who already owned dice keeps them.
 */
class Stats(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ludo_masha", Context.MODE_PRIVATE)

    init {
        migrate()
    }

    private fun int(key: String, def: Int = 0) = prefs.getInt(key, def)
    private fun put(key: String, value: Int) = prefs.edit().putInt(key, value).apply()
    private fun long(key: String, def: Long = 0L) = prefs.getLong(key, def)
    private fun put(key: String, value: Long) = prefs.edit().putLong(key, value).apply()
    private fun str(key: String, def: String = "") = prefs.getString(key, def) ?: def
    private fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()

    // ------------------------------------------------------------ migration

    /**
     * Brings an older saved file forward.
     *
     * Version 1 was the build before progression existed: it had coins, wins
     * and dice. Those are kept exactly as they were; XP is seeded from the
     * wins already recorded so a returning player does not restart at zero,
     * and the dice they owned are folded into the one cosmetic list.
     */
    private fun migrate() {
        val found = int(KEY_VERSION, 0)
        if (found >= STORE_VERSION) return
        val editor = prefs.edit()

        if (found < 2) {
            // fold the old dice-only ownership list into the cosmetic list
            val oldDice = str(KEY_OWNED_DICE_V1)
            if (oldDice.isNotBlank()) {
                val merged = (str(KEY_OWNED).split(",") + oldDice.split(","))
                    .map { it.trim() }.filter { it.isNotBlank() }.distinct()
                editor.putString(KEY_OWNED, merged.joinToString(","))
            }
            // carry the chosen dice over into the new per-type selection
            val oldActive = str(KEY_DICE_V1)
            if (oldActive.isNotBlank()) {
                editor.putString(selectedKey(CosmeticType.DICE_SKIN), oldActive)
            }
            // seed XP from matches already won, so progress is not lost
            if (long(KEY_XP, -1L) < 0L) {
                val played = int(KEY_PLAYED)
                val won = int(KEY_WON)
                val seeded = played.toLong() * 20L + won.toLong() * 50L
                editor.putLong(KEY_XP, seeded)
            }
            // the first day the game was opened anchors the season calendar
            if (int(KEY_EPOCH_DAY, -1) < 0) editor.putInt(KEY_EPOCH_DAY, today())
        }

        editor.putInt(KEY_VERSION, STORE_VERSION)
        editor.apply()
    }

    // ------------------------------------------------------------- identity

    var playerName: String
        get() = str(KEY_NAME)
        set(v) = put(KEY_NAME, v.trim().take(14))

    // -------------------------------------------------------------- economy

    var coins: Int
        get() = int(KEY_COINS, 0)
        set(v) = put(KEY_COINS, v.coerceAtLeast(0))

    /** Lifetime XP. Never goes down, not even at the end of a season. */
    var xp: Long
        get() = long(KEY_XP, 0L).coerceAtLeast(0L)
        set(v) = put(KEY_XP, v.coerceAtLeast(0L))

    fun level(): Int = Progression.levelForXp(xp)
    fun rankName(): String = Progression.titleFor(level())
    fun levelProgress(): Float = Progression.progress(xp)
    fun xpIntoLevel(): Int = Progression.xpIntoLevel(xp)
    fun xpSpan(): Int = Progression.xpSpanForLevel(level())

    /** Adds XP and reports the level before and after. */
    fun addXp(amount: Int): Pair<Int, Int> {
        if (amount <= 0) return level() to level()
        val before = level()
        xp += amount.toLong()
        return before to level()
    }

    fun addCoins(amount: Int) {
        if (amount > 0) coins += amount
    }

    // ----------------------------------------------------------- statistics

    var gamesPlayed: Int
        get() = int(KEY_PLAYED); set(v) = put(KEY_PLAYED, v)

    var gamesWon: Int
        get() = int(KEY_WON); set(v) = put(KEY_WON, v)

    var wins2p: Int
        get() = int(KEY_W2); set(v) = put(KEY_W2, v)

    var wins4p: Int
        get() = int(KEY_W4); set(v) = put(KEY_W4, v)

    var winsTeam: Int
        get() = int(KEY_WT); set(v) = put(KEY_WT, v)

    var winsQuick: Int
        get() = int(KEY_WQ); set(v) = put(KEY_WQ, v)

    var winsSnake: Int
        get() = int(KEY_WS); set(v) = put(KEY_WS, v)

    var winsArrow: Int
        get() = int(KEY_WA); set(v) = put(KEY_WA, v)

    var kills: Int
        get() = int(KEY_KILLS); set(v) = put(KEY_KILLS, v)

    var tokensHome: Int
        get() = int(KEY_HOME); set(v) = put(KEY_HOME, v)

    var streak: Int
        get() = int(KEY_STREAK); set(v) = put(KEY_STREAK, v)

    var bestStreak: Int
        get() = int(KEY_BEST); set(v) = put(KEY_BEST, v)

    fun winRate(): Float =
        if (gamesPlayed == 0) 0f else gamesWon * 100f / gamesPlayed

    fun addKill() {
        kills += 1
    }

    // --------------------------------------------------------- competitive

    /** LOCAL league points, from matches on this phone only. Not a world rank. */
    var leaguePoints: Int
        get() = int(KEY_LEAGUE_POINTS, 0); set(v) = put(KEY_LEAGUE_POINTS, v.coerceAtLeast(0))

    fun league(): League = LeagueRules.leagueFor(leaguePoints)
    fun leagueProgress(): Float = LeagueRules.progress(leaguePoints)

    /** The day the game was first opened — the season calendar counts from it. */
    val epochDay: Int
        get() {
            val stored = int(KEY_EPOCH_DAY, -1)
            if (stored >= 0) return stored
            val now = today()
            put(KEY_EPOCH_DAY, now)
            return now
        }

    fun season(): Season = Season.forDay(today(), epochDay)

    /**
     * Rolls the competitive standing into a new season when one has ended.
     *
     * It touches league points and nothing else: level, XP, coins and every
     * owned cosmetic are permanent and are not seasonal data.
     */
    fun rolloverSeasonIfNeeded(): Boolean {
        val current = season()
        val recorded = int(KEY_SEASON_ID, current.id)
        if (recorded == current.id) {
            if (int(KEY_SEASON_ID, -1) != current.id) put(KEY_SEASON_ID, current.id)
            return false
        }
        leaguePoints = Season.softReset(leaguePoints)
        put(KEY_SEASON_ID, current.id)
        return true
    }

    // ---------------------------------------------------------- preferences

    var vibration: Boolean
        get() = prefs.getBoolean(KEY_VIBRATE, true)
        set(v) = prefs.edit().putBoolean(KEY_VIBRATE, v).apply()

    var soundOn: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(v) = prefs.edit().putBoolean(KEY_SOUND, v).apply()

    // ------------------------------------------------------------ cosmetics

    private var ownedRaw: String
        get() = str(KEY_OWNED)
        set(v) = put(KEY_OWNED, v)

    /**
     * Everything the player owns: what was earned, plus the free items, plus
     * whatever their level has already earned them. Level unlocks are worked
     * out here rather than stored, so a player can never miss one.
     */
    fun owned(): Set<String> {
        val bought = ownedRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val byLevel = Cosmetics.unlockedAtLevel(level()).map { it.id }
        return (Cosmetics.free() + bought + byLevel).toSet()
    }

    fun owns(id: String): Boolean = id in owned()

    /** Records an item as owned. Returns false when it was already there. */
    fun grant(id: String): Boolean {
        if (Cosmetics.byId(id) == null) return false
        if (owns(id)) return false
        ownedRaw = (ownedRaw.split(",").filter { it.isNotBlank() } + id)
            .distinct().joinToString(",")
        return true
    }

    /** Spends the coins and unlocks the item. False when it is too dear. */
    fun buy(id: String): Boolean {
        val item = Cosmetics.byId(id) ?: return false
        if (owns(id)) return true
        if (item.unlock != UnlockMethod.COINS) return false
        if (coins < item.price) return false
        coins -= item.price
        return grant(id)
    }

    private fun selectedKey(type: CosmeticType) = "selected_${type.name.lowercase()}"

    /** The item in use for [type], falling back to the default if need be. */
    fun selected(type: CosmeticType): String {
        val stored = str(selectedKey(type), Cosmetics.defaultFor(type))
        val item = Cosmetics.byId(stored)
        if (item == null || item.type != type || !owns(stored)) return Cosmetics.defaultFor(type)
        return stored
    }

    /** Puts an owned item of the right type into use. False otherwise. */
    fun select(id: String): Boolean {
        val item = Cosmetics.byId(id) ?: return false
        if (!owns(id)) return false
        put(selectedKey(item.type), id)
        return true
    }

    /** Kept for the dice screen, which only ever deals in dice. */
    var activeDice: String
        get() = selected(CosmeticType.DICE_SKIN)
        set(v) { select(v) }

    fun buyDice(id: String): Boolean = buy(id)

    // -------------------------------------------------------- the calendar

    /**
     * Which day it is here, from the phone's own clock and time zone.
     *
     * Offline this is the only clock there is. The daily systems all take a
     * day number rather than reading the clock themselves, so the day a server
     * hands down can replace this one without any of them changing.
     */
    fun today(): Int {
        val now = System.currentTimeMillis()
        val offset = java.util.TimeZone.getDefault().getOffset(now)
        return ((now + offset) / 86_400_000L).toInt()
    }

    // ------------------------------------------------------- daily rewards

    private var lastClaimDay: Int
        get() = int(KEY_CHEST_DAY, -1); set(v) = put(KEY_CHEST_DAY, v)

    /** Which rung of the seven-day cycle was last collected. */
    var claimedCycleDay: Int
        get() = int(KEY_CHEST_STREAK, 0).coerceIn(0, DailyRewards.CYCLE_LENGTH)
        private set(v) = put(KEY_CHEST_STREAK, v)

    fun chestReady(): Boolean = DailyRewards.canClaim(lastClaimDay, today())

    fun chestDayOnOffer(): Int =
        DailyRewards.dayOnOffer(lastClaimDay, today(), claimedCycleDay)

    /**
     * Collects today's reward exactly once.
     *
     * The claim is written before anything is paid, so reopening the screen
     * cannot pay a second time even if the app is killed mid-animation.
     * Returns null when today's has already been taken.
     */
    fun claimDaily(): RewardGrant? {
        if (!chestReady()) return null
        val day = chestDayOnOffer()
        val reward = DailyRewards.rewardFor(day)

        // mark it taken FIRST — an interrupted claim must not become a free one
        claimedCycleDay = day
        lastClaimDay = today()

        if (reward.kind == RewardKind.CHEST) {
            val pull = MysteryChest.open(kotlin.random.Random(System.nanoTime()), owned())
            val coinsPaid = reward.coins + pull.coins
            addCoins(coinsPaid)
            if (pull.gaveCosmetic) pull.cosmeticId?.let { grant(it) }
            return RewardGrant(coinsPaid, pull.cosmeticId, pull.wasDuplicate)
        }

        val id = reward.cosmeticId
        if (id == null) {
            addCoins(reward.coins)
            return RewardGrant(reward.coins, null, false)
        }
        if (owns(id)) {
            addCoins(DailyRewards.DUPLICATE_COINS)
            return RewardGrant(DailyRewards.DUPLICATE_COINS, id, wasDuplicate = true)
        }
        grant(id)
        addCoins(reward.coins)
        return RewardGrant(reward.coins, id, wasDuplicate = false)
    }

    /** Opens a chest earned by playing, paying coins for anything already owned. */
    fun openMysteryChest(): RewardGrant {
        val pull = MysteryChest.open(kotlin.random.Random(System.nanoTime()), owned())
        addCoins(pull.coins)
        if (pull.gaveCosmetic) pull.cosmeticId?.let { grant(it) }
        return pull
    }

    // ------------------------------------------------------------ missions

    /**
     * Today's missions, generated the first time they are asked for each day.
     *
     * The generator is seeded by the day, so this returns the same four
     * missions all day however many times the app is restarted.
     */
    fun missionsForToday(): List<Mission> {
        val day = today()
        val saved = MissionCodec.decode(str(KEY_MISSIONS))
        if (saved.isNotEmpty() && saved.first().day == day) return saved
        val fresh = MissionCatalog.generate(day)
        saveMissions(fresh)
        return fresh
    }

    fun saveMissions(missions: List<Mission>) {
        put(KEY_MISSIONS, MissionCodec.encode(missions))
    }

    // --------------------------------------------- one payout per match

    /**
     * True the first time a given match is banked, false every time after.
     *
     * A finished match can reach the result screen more than once — a rotation,
     * a re-render, a stray callback — and each of those must not be worth
     * another hundred coins. The match's own id is written down here and
     * checked before anything is paid.
     */
    fun claimMatchPayout(matchId: String): Boolean {
        if (matchId.isBlank()) return false
        if (str(KEY_LAST_MATCH) == matchId) return false
        put(KEY_LAST_MATCH, matchId)
        return true
    }

    /**
     * Records a finished match: counters, streak, league points.
     *
     * XP and coins are NOT added here — the caller works those out from the
     * match summary and adds them once, so there is exactly one place where
     * a match can pay.
     */
    fun recordMatch(mode: GameMode, players: Int, team: Boolean, won: Boolean) {
        gamesPlayed += 1
        if (won) {
            gamesWon += 1
            when {
                mode == GameMode.SNAKES -> winsSnake += 1
                mode == GameMode.QUICK -> winsQuick += 1
                mode == GameMode.ARROW -> winsArrow += 1
                team -> winsTeam += 1
                players >= 4 -> wins4p += 1
                else -> wins2p += 1
            }
            streak += 1
            if (streak > bestStreak) bestStreak = streak
        } else {
            streak = 0
        }
        leaguePoints = LeagueRules.pointsAfter(leaguePoints, won, players)
    }

    /** Everything newly unlocked by crossing from [before] into [after]. */
    fun unlocksBetween(before: Int, after: Int): List<CosmeticItem> {
        if (after <= before) return emptyList()
        val list = mutableListOf<CosmeticItem>()
        for (level in (before + 1)..after) list += Cosmetics.unlockedOnReaching(level)
        return list
    }

    private companion object {
        const val STORE_VERSION = 2

        const val KEY_VERSION = "store_version"
        const val KEY_NAME = "player_name"
        const val KEY_COINS = "coins"
        const val KEY_XP = "xp"
        const val KEY_PLAYED = "games_played"
        const val KEY_WON = "games_won"
        const val KEY_W2 = "wins_2p"
        const val KEY_W4 = "wins_4p"
        const val KEY_WT = "wins_team"
        const val KEY_WQ = "wins_quick"
        const val KEY_WS = "wins_snake"
        const val KEY_WA = "wins_arrow"
        const val KEY_KILLS = "kills"
        const val KEY_HOME = "tokens_home"
        const val KEY_STREAK = "streak"
        const val KEY_BEST = "best_streak"
        const val KEY_VIBRATE = "vibration"
        const val KEY_SOUND = "sound_on"
        const val KEY_OWNED = "owned_cosmetics"
        const val KEY_LEAGUE_POINTS = "league_points"
        const val KEY_SEASON_ID = "season_id"
        const val KEY_EPOCH_DAY = "epoch_day"
        const val KEY_CHEST_DAY = "chest_last_day"
        const val KEY_CHEST_STREAK = "chest_streak"
        const val KEY_MISSIONS = "missions"
        const val KEY_LAST_MATCH = "last_match_id"

        // version 1 keys, read once during migration and then left alone
        const val KEY_OWNED_DICE_V1 = "owned_dice"
        const val KEY_DICE_V1 = "active_dice"
    }
}
