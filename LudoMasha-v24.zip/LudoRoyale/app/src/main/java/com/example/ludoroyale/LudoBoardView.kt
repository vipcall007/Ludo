package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.TokenArt
import com.example.ludoroyale.cosmetics.TokenArts
import com.example.ludoroyale.cosmetics.TokenOrnament
import com.example.ludoroyale.engine.ArrowConfig
import com.example.ludoroyale.engine.ArrowKind
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SnakeLadderConfig
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import kotlin.math.min

/**
 * Draws the classic Ludo cross board (wooden frame, circular home yards,
 * arrow-shaped home stretches, star safe cells, direction arrows) plus
 * styled tokens with stack counts, and moves tokens box-by-box.
 * Everything is drawn in code — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    /** Draw the ARROW MODE markings (straight arrows, home arrows, turns). */
    var arrowMode: Boolean = false
        set(value) { field = value; invalidate() }

    /**
     * The token skin in use. It changes the rim, the inset and the ornament —
     * never the body colour, which is how everyone tells whose piece is whose.
     */
    var tokenArt: TokenArt = TokenArts.byId(Cosmetics.TOKEN_CLASSIC)
        set(value) { field = value; invalidate() }

    /** Called once per square as a piece hops along, so the UI can tick. */
    var onStep: (() -> Unit)? = null

    var tappableTokenIds: Set<String> = emptySet()
        set(value) {
            field = value
            if (value.isEmpty()) stopPulse() else startPulse()
            invalidate()
        }

    // Movable pieces breathe in and out so the player can spot them instantly.
    private var pulse = 1f
    private var pulseUp = true
    private var pulsing = false

    private val pulseTick = object : Runnable {
        override fun run() {
            if (!pulsing) return
            pulse += if (pulseUp) 0.022f else -0.022f
            if (pulse >= 1.18f) { pulse = 1.18f; pulseUp = false }
            if (pulse <= 1.0f) { pulse = 1.0f; pulseUp = true }
            invalidate()
            postDelayed(this, 32)
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        pulse = 1f
        pulseUp = true
        post(pulseTick)
    }

    private fun stopPulse() {
        pulsing = false
        pulse = 1f
        removeCallbacks(pulseTick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopPulse()   // don't keep ticking after the view is gone
    }

    var onTokenTapped: ((Token) -> Unit)? = null

    /** Picked one of the little number chips floating over a piece. */
    var onChoicePicked: ((Int) -> Unit)? = null

    // Small number chips shown right above a piece, so the player never
    // leaves the board to say how many points to give it.
    /** LUDO SNAKE MODE: which board to draw, or null for none. */
    var snakeDifficulty: SnakeDifficulty? = null
        set(value) { field = value; invalidate() }

    /** Ring cell of the snake head / ladder foot that is currently firing. */
    private var glowingSpecialCell: Int? = null
    private var specialGlow = 0f
    private var glowRunning = false

    private val glowTick = object : Runnable {
        override fun run() {
            if (!glowRunning) return
            specialGlow += 0.16f
            if (specialGlow > 2f * Math.PI.toFloat()) specialGlow -= 2f * Math.PI.toFloat()
            invalidate()
            postDelayed(this, 40)
        }
    }

    /** Lights up a snake head or ladder foot while its shortcut plays. */
    fun setSpecialGlow(cell: Int?) {
        glowingSpecialCell = cell
        if (cell != null) {
            if (!glowRunning) { glowRunning = true; post(glowTick) }
        } else {
            glowRunning = false
            removeCallbacks(glowTick)
            specialGlow = 0f
        }
        invalidate()
    }

    /**
     * Rides a snake or ladder: the piece follows the drawn shape rather than
     * cutting straight across, so a slide really looks like a slide and a
     * climb really looks like a climb.
     */
    fun rideSpecial(
        tokenId: String,
        color: PlayerColor,
        fromSteps: Int,
        toSteps: Int,
        isLadder: Boolean,
        onComplete: () -> Unit
    ) {
        val a = BoardGeometry.centerForSteps(color, fromSteps)
        val b = BoardGeometry.centerForSteps(color, toSteps)
        val path = mutableListOf<Pair<Float, Float>>()

        val steps = 22
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val r = a.first + (b.first - a.first) * t
            val c = a.second + (b.second - a.second) * t
            if (isLadder) {
                // climb straight, with a small rise so it reads as going up
                path += (r - kotlin.math.sin(t * Math.PI).toFloat() * 0.18f) to c
            } else {
                // follow the snake's wave, matching how it is drawn
                val dr = b.first - a.first
                val dc = b.second - a.second
                val len = kotlin.math.sqrt(dr * dr + dc * dc).coerceAtLeast(0.001f)
                val nr = -dc / len
                val nc = dr / len
                val amp = 0.42f * kotlin.math.sin(t * Math.PI * 3).toFloat()
                path += (r + nr * amp) to (c + nc * amp)
            }
        }
        glide(tokenId, path, onComplete, perLegMs = if (isLadder) 26L else 22L)
    }

    private var choiceTokenId: String? = null
    private var choiceValues: List<Int> = emptyList()
    private val chipRects = mutableListOf<Pair<Int, RectF>>()

    fun showChoices(tokenId: String, values: List<Int>) {
        choiceTokenId = tokenId
        choiceValues = values
        invalidate()
    }

    fun clearChoices() {
        choiceTokenId = null
        choiceValues = emptyList()
        chipRects.clear()
        invalidate()
    }

    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Token currently vanishing/reappearing for an ARROW-MODE magic jump. */
    private var fadingTokenId: String? = null
    private var fadeAlpha: Float = 1f

    /**
     * ARROW MODE magic move: the piece puffs out at the arrow's start and
     * reappears where the arrow ends, instead of walking the gap.
     */
    fun magicTeleport(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit) {
        fadingTokenId = tokenId
        fadeOut(tokenId, color, toSteps, onComplete, 1f)
    }

    private fun fadeOut(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit, a: Float) {
        if (a <= 0.05f) {
            // reappear at the arrow's end
            displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, toSteps)
            fadeIn(tokenId, onComplete, 0f)
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeOut(tokenId, color, toSteps, onComplete, a - 0.16f) }, 34)
    }

    private fun fadeIn(tokenId: String, onComplete: () -> Unit, a: Float) {
        if (a >= 1f) {
            fadeAlpha = 1f
            fadingTokenId = null
            invalidate()
            onComplete()
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeIn(tokenId, onComplete, a + 0.16f) }, 34)
    }

    /** Instantly syncs the board to [newState] (game start, or after a hop lands). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /** Moves one token cell-by-cell from [fromSteps] to [toSteps], then calls [onComplete]. */
    /**
     * Slides one piece smoothly along the squares from [fromSteps] to
     * [toSteps] — it walks the real path (so it turns the corners correctly)
     * but glides continuously instead of jumping square to square.
     */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        if (fromSteps <= 0) {
            path += BoardGeometry.centerForSteps(color, toSteps)
        } else {
            for (step in (fromSteps + 1)..toSteps) path += BoardGeometry.centerForSteps(color, step)
        }
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete)
    }

    /**
     * A cut piece races back the way it came — its path reversed, faster than a
     * normal move — instead of blinking straight to its base.
     */
    fun flyHome(tokenId: String, color: PlayerColor, fromSteps: Int, baseSlot: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        var step = fromSteps
        while (step > 1) {                       // retrace the lap backwards
            step -= maxOf(1, fromSteps / 8)      // skip a little so it stays quick
            path += BoardGeometry.centerForSteps(color, maxOf(step, 1))
        }
        path += BoardGeometry.BASE_SLOTS.getValue(color)[baseSlot.coerceIn(0, 3)]
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete, perLegMs = 34L)
    }

    private fun glide(tokenId: String, path: List<Pair<Float, Float>>, onComplete: () -> Unit, perLegMs: Long = 110L) {
        val legs = path.size - 1
        val perLeg = perLegMs                   // ms per square
        val total = (legs * perLeg).coerceAtLeast(160L)
        val startAt = System.currentTimeMillis()
        var lastLeg = -1

        val ticker = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - startAt
                val t = (elapsed.toFloat() / total).coerceIn(0f, 1f)
                val pos = t * legs
                val leg = pos.toInt().coerceAtMost(legs - 1)
                val f = pos - leg

                val a = path[leg]
                val b = path[leg + 1]
                displayedCenters[tokenId] =
                    (a.first + (b.first - a.first) * f) to (a.second + (b.second - a.second) * f)

                if (leg != lastLeg) {
                    lastLeg = leg
                    if (legs > 1) onStep?.invoke()
                }
                invalidate()

                if (t >= 1f) {
                    displayedCenters[tokenId] = path.last()
                    invalidate()
                    onComplete()
                } else {
                    postDelayed(this, 16)
                }
            }
        }
        post(ticker)
    }

    // ---- geometry ----
    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell
    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(px(c0), py(r0), px(c1), py(r1))

    // ---- paints ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xBD, 0xBD, 0xBD)
        strokeWidth = 1.5f
    }
    private val specialLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bodyShade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xFF, 0xEB, 0x3B)
        strokeWidth = 6f
    }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0x21, 0x21, 0x21)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.028f
        cell = (size - 2 * frame) / BoardGeometry.GRID_SIZE
        badgeText.textSize = cell * 0.46f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawFrame(canvas)
        drawHomeYards(canvas)
        drawTrack(canvas)
        drawHomeStretches(canvas)
        drawCenterArrows(canvas)
        drawSpecials(canvas)
        if (arrowMode) drawArrows(canvas)
        drawSpecialGlow(canvas)
        drawTokens(canvas)
        drawChoiceChips(canvas)
    }

    /** Wooden outer frame, gold inner edge, soft off-white playfield. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.055f

        // outer shadow
        fill.color = Color.argb(90, 0, 0, 0)
        canvas.drawRoundRect(RectF(2f, 5f, size, size + 3f), r, r, fill)

        // dark wood edge
        fill.color = Color.rgb(0xA8, 0x63, 0x24)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, fill)

        // warm wood face
        fill.color = Color.rgb(0xD9, 0x93, 0x4A)
        canvas.drawRoundRect(RectF(frame * 0.28f, frame * 0.28f, size - frame * 0.28f, size - frame * 0.28f), r, r, fill)

        // thin gold inner edge framing the play area
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawRect(
            RectF(px(0f) - frame * 0.22f, py(0f) - frame * 0.22f,
                  px(15f) + frame * 0.22f, py(15f) + frame * 0.22f), fill
        )

        // playfield
        fill.color = Color.rgb(0xFA, 0xFA, 0xF5)
        canvas.drawRect(RectF(px(0f), py(0f), px(15f), py(15f)), fill)
    }

    /** The four colored corner yards, each with a white circle holding the 4 base slots. */
    private fun drawHomeYards(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0].toFloat(); val c0 = box[1].toFloat()
            val r1 = (box[2] + 1).toFloat(); val c1 = (box[3] + 1).toFloat()

            fill.color = colorOf(color)
            canvas.drawRect(rect(r0, c0, r1, c1), fill)

            // white circle in the middle of the yard
            val cx = px((c0 + c1) / 2f)
            val cy = py((r0 + r1) / 2f)
            val radius = cell * 2.1f
            canvas.drawCircle(cx + cell * 0.06f, cy + cell * 0.09f, radius, shadow)
            fill.color = Color.WHITE
            canvas.drawCircle(cx, cy, radius, fill)
        }
    }

    /** The 52-cell outer ring: white cells, colored start cells, star safe cells, direction arrows. */
    private fun drawTrack(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val r = rc.first.toFloat(); val c = rc.second.toFloat()
            var startColor: PlayerColor? = null
            for (color in PlayerColor.entries) if (color.startOffset == idx) startColor = color

            fill.color = if (startColor != null) colorOf(startColor) else Color.WHITE
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), fill)
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), gridLine)

            if (LudoBoard.isSafeCell(idx)) {
                val starColor = if (startColor != null) Color.WHITE else Color.rgb(0x9E, 0x9E, 0x9E)
                drawStar(canvas, px(c + 0.5f), py(r + 0.5f), cell * 0.3f, starColor)
            }
        }
    }

    /** A chevron on a start cell showing which way tokens travel from there. */

    /** Star path using whatever colour/alpha is already set on [fill]. */
    private fun drawStarPath(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            path.let { p ->
                val x = cx + (rr * Math.cos(angle)).toFloat()
                val y = cy + (rr * Math.sin(angle)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            val x = cx + (rr * Math.cos(angle)).toFloat()
            val y = cy + (rr * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    /** Each color's private path to home, drawn as one solid colored lane. */
    private fun drawHomeStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            fill.color = colorOf(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), fill)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), gridLine)
            }
        }
    }

    /** The four big arrowheads meeting at the center — the "win" zone. */
    private fun drawCenterArrows(canvas: Canvas) {
        val cx = px(7.5f); val cy = py(7.5f)
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(px(p1c), py(p1r))
            path.lineTo(px(p2c), py(p2r))
            path.lineTo(cx, cy)
            path.close()
            fill.color = colorOf(color)
            canvas.drawPath(path, fill)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    /**
     * Tokens, grouped so stacked pieces are obvious: one styled piece per
     * (cell, color) with a numbered badge when more than one sits there,
     * and a slight offset when two different colors share a safe cell.
     */
    /**
     * Every piece is drawn as its own piece — a pile of three shows three
     * discs fanned out, not one disc with a number on it. Movable pieces
     * gently grow and shrink so the player can see what they can play.
     */
    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return

        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            val shrink = when {
                tokens.size >= 4 -> 0.62f
                tokens.size == 3 -> 0.70f
                tokens.size == 2 -> 0.80f
                else -> 1f
            }
            tokens.forEachIndexed { i, token ->
                val (ox, oy) = offsets[i]
                val faded = token.id == fadingTokenId
                val alpha = if (faded) fadeAlpha else 1f
                val tappable = token.id in tappableTokenIds
                val scale = shrink * if (tappable) pulse else 1f
                drawToken(
                    canvas,
                    px(col) + ox * cell,
                    py(row) + oy * cell,
                    token.color, alpha, tappable, scale
                )
            }
        }
    }

    /** Where each piece sits when several share one square. */
    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.16f to 0f, 0.16f to 0f)
        3 -> listOf(0f to -0.17f, -0.17f to 0.13f, 0.17f to 0.13f)
        4 -> listOf(-0.16f to -0.16f, 0.16f to -0.16f, -0.16f to 0.16f, 0.16f to 0.16f)
        else -> {
            // 5+ : ring them around the cell centre
            val list = mutableListOf<Pair<Float, Float>>()
            for (i in 0 until count) {
                val angle = 2.0 * Math.PI * i / count
                list += (0.19f * Math.cos(angle).toFloat()) to (0.19f * Math.sin(angle).toFloat())
            }
            list
        }
    }

    /** A piece drawn as a lit dome: contact shadow, dark rim, shaded body, highlight. */
    private fun drawToken(
        canvas: Canvas, cx: Float, cy: Float,
        color: PlayerColor, alpha: Float, tappable: Boolean, scale: Float
    ) {
        if (alpha <= 0.02f) return
        val radius = cell * 0.36f * scale
        val a = (alpha * 255).toInt().coerceIn(0, 255)
        val base = colorOf(color)
        val art = tokenArt
        // a rainbow skin walks its trim round the wheel; everything else is fixed
        val trim = if (art.shifting) shiftingTrim() else art.trim

        // the skin's halo, behind everything, so it never hides the piece
        if (art.halo != 0) {
            bodyShade.shader = RadialGradient(
                cx, cy, radius * 1.85f,
                intArrayOf(withAlphaScaled(art.halo, alpha), Color.TRANSPARENT),
                floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, radius * 1.85f, bodyShade)
            bodyShade.shader = null
        }

        // contact shadow flattened on the board
        shadow.alpha = (75 * alpha).toInt().coerceIn(0, 255)
        canvas.drawOval(
            RectF(cx - radius * 0.95f, cy + radius * 0.34f, cx + radius * 0.95f, cy + radius * 0.98f),
            shadow
        )
        shadow.alpha = 60

        // dark rim keeps overlapping pieces readable
        fill.color = darken(base, 0.55f)
        fill.alpha = a
        canvas.drawCircle(cx, cy + radius * 0.05f, radius * 1.06f, fill)

        // the skin's metal collar, drawn just inside that rim
        if (art.id != Cosmetics.TOKEN_CLASSIC) {
            fill.color = trim
            fill.alpha = (a * 0.92f).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy + radius * 0.02f, radius * 1.00f, fill)
            fill.alpha = 255
        }

        // body shaded from a top-left light source
        bodyShade.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.40f, radius * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        bodyShade.alpha = a
        canvas.drawCircle(cx, cy, radius, bodyShade)
        bodyShade.shader = null
        bodyShade.alpha = 255

        // the inset disc the ornament sits on
        fill.color = art.inset
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 0.62f, fill)

        // the ornament, in the player's own colour so the piece stays readable
        fill.color = base
        fill.alpha = a
        drawOrnament(canvas, cx, cy, radius * 0.52f, art.ornament, base, trim, a)
        fill.alpha = 255

        // specular highlight, stronger on the polished skins
        val sheen = (140f + 115f * art.sheen) * alpha
        gloss.shader = RadialGradient(
            cx - radius * 0.34f, cy - radius * 0.46f, radius * 0.75f,
            Color.argb(sheen.toInt().coerceIn(0, 255), 255, 255, 255),
            Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, gloss)
        gloss.shader = null

        if (tappable) canvas.drawCircle(cx, cy, radius + 5f, highlight)
    }

    /**
     * The little mark in the middle of a piece.
     *
     * Each one is drawn at the same size and weight, so no skin is easier or
     * harder to pick out on a crowded square than any other.
     */
    private fun drawOrnament(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        ornament: TokenOrnament, base: Int, trim: Int, a: Int
    ) {
        fill.color = base
        fill.alpha = a
        when (ornament) {
            TokenOrnament.STAR -> drawStarPath(canvas, cx, cy, r)

            TokenOrnament.GEM -> {
                val p = Path()
                p.moveTo(cx, cy - r)
                p.lineTo(cx + r * 0.86f, cy - r * 0.18f)
                p.lineTo(cx, cy + r)
                p.lineTo(cx - r * 0.86f, cy - r * 0.18f)
                p.close()
                canvas.drawPath(p, fill)
                specialLine.color = Color.argb((a * 0.55f).toInt(), 255, 255, 255)
                specialLine.strokeWidth = r * 0.16f
                canvas.drawLine(cx - r * 0.86f, cy - r * 0.18f, cx + r * 0.86f, cy - r * 0.18f, specialLine)
            }

            TokenOrnament.FLAME -> {
                val p = Path()
                p.moveTo(cx, cy - r * 1.05f)
                p.cubicTo(cx + r * 0.90f, cy - r * 0.25f, cx + r * 0.55f, cy + r, cx, cy + r)
                p.cubicTo(cx - r * 0.55f, cy + r, cx - r * 0.90f, cy - r * 0.25f, cx, cy - r * 1.05f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.CRYSTAL -> {
                val p = Path()
                p.moveTo(cx, cy - r)
                p.lineTo(cx + r * 0.52f, cy - r * 0.30f)
                p.lineTo(cx + r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.52f, cy - r * 0.30f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.CROWN -> {
                val p = Path()
                p.moveTo(cx - r * 0.88f, cy + r * 0.62f)
                p.lineTo(cx - r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx - r * 0.40f, cy + r * 0.06f)
                p.lineTo(cx, cy - r * 0.86f)
                p.lineTo(cx + r * 0.40f, cy + r * 0.06f)
                p.lineTo(cx + r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx + r * 0.88f, cy + r * 0.62f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.BOLT -> {
                val p = Path()
                p.moveTo(cx + r * 0.30f, cy - r)
                p.lineTo(cx - r * 0.55f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.02f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.28f, cy + r)
                p.lineTo(cx + r * 0.58f, cy - r * 0.18f)
                p.lineTo(cx + r * 0.04f, cy - r * 0.18f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.PRISM -> {
                // three facets in the player's colour, so it still reads as theirs
                for (i in 0 until 3) {
                    val angle = (-Math.PI / 2 + i * 2 * Math.PI / 3).toFloat()
                    val p = Path()
                    p.moveTo(cx, cy)
                    p.lineTo(
                        cx + r * Math.cos((angle - 0.42f).toDouble()).toFloat(),
                        cy + r * Math.sin((angle - 0.42f).toDouble()).toFloat()
                    )
                    p.lineTo(
                        cx + r * Math.cos((angle + 0.42f).toDouble()).toFloat(),
                        cy + r * Math.sin((angle + 0.42f).toDouble()).toFloat()
                    )
                    p.close()
                    fill.color = if (i == 1) lighten(base, 0.30f) else base
                    fill.alpha = a
                    canvas.drawPath(p, fill)
                }
            }

            TokenOrnament.SCALE -> {
                // three overlapping scales
                for (i in 0 until 3) {
                    val oy = cy - r * 0.45f + i * r * 0.46f
                    val rr = r * (0.92f - i * 0.16f)
                    fill.color = if (i % 2 == 0) base else darken(base, 0.18f)
                    fill.alpha = a
                    canvas.drawArc(
                        RectF(cx - rr, oy - rr * 0.8f, cx + rr, oy + rr * 0.8f),
                        180f, 180f, true, fill
                    )
                }
            }

            TokenOrnament.RING -> {
                specialLine.color = base
                specialLine.strokeWidth = r * 0.42f
                canvas.drawCircle(cx, cy, r * 0.66f, specialLine)
            }
        }
        fill.color = base
        fill.alpha = 255
    }

    /** The rainbow skin's trim, cycling slowly so it never strobes. */
    private fun shiftingTrim(): Int {
        val t = (System.currentTimeMillis() % 6000L) / 6000f
        val hue = t * 360f
        return Color.HSVToColor(floatArrayOf(hue, 0.55f, 1f))
    }

    private fun withAlphaScaled(color: Int, alpha: Float): Int = Color.argb(
        (Color.alpha(color) * alpha).toInt().coerceIn(0, 255),
        Color.red(color), Color.green(color), Color.blue(color)
    )

    private fun lighten(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    /**
     * Snakes and ladders on the Ludo route. A ladder is two rails with rungs,
     * a snake is a wavy green body with a head — both drawn between the exact
     * squares they connect, so it is obvious where a piece will be carried.
     */
    /** Pulsing halo on the snake head / ladder foot that is firing. */
    private fun drawSpecialGlow(canvas: Canvas) {
        val cell0 = glowingSpecialCell ?: return
        val ring = BoardGeometry.RING
        val (r, c) = ring[cell0 % ring.size]
        val cx = px(c + 0.5f)
        val cy = py(r + 0.5f)
        val pulse = 0.5f + 0.5f * kotlin.math.sin(specialGlow)
        val radius = cell * (0.42f + 0.22f * pulse)

        fill.color = Color.argb((90 + 90 * pulse).toInt().coerceIn(0, 255), 0xFF, 0xE0, 0x7A)
        canvas.drawCircle(cx, cy, radius, fill)
        fill.color = Color.argb((140 + 80 * pulse).toInt().coerceIn(0, 255), 0xFF, 0xF3, 0xC4)
        canvas.drawCircle(cx, cy, radius * 0.55f, fill)
    }

    private fun drawSpecials(canvas: Canvas) {
        val diff = snakeDifficulty ?: return
        val ring = BoardGeometry.RING

        for (sp in SnakeLadderConfig.specialsFor(diff)) {
            val a = ring[sp.entryCell % ring.size]
            val b = ring[sp.exitCell % ring.size]
            val x0 = px(a.second + 0.5f); val y0 = py(a.first + 0.5f)
            val x1 = px(b.second + 0.5f); val y1 = py(b.first + 0.5f)

            if (sp.type == SpecialType.LADDER) drawLadder(canvas, x0, y0, x1, y1)
            else drawSnake(canvas, x0, y0, x1, y1)
        }
    }

    private fun drawLadder(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val nx = -dy / len * cell * 0.15f
        val ny = dx / len * cell * 0.15f

        specialLine.strokeWidth = cell * 0.065f
        specialLine.color = Color.rgb(0x8D, 0x5A, 0x2B)
        canvas.drawLine(x0 + nx, y0 + ny, x1 + nx, y1 + ny, specialLine)
        canvas.drawLine(x0 - nx, y0 - ny, x1 - nx, y1 - ny, specialLine)

        specialLine.strokeWidth = cell * 0.045f
        specialLine.color = Color.rgb(0xC9, 0x8A, 0x45)
        val rungs = (len / (cell * 0.5f)).toInt().coerceAtLeast(2)
        for (i in 1 until rungs) {
            val t = i.toFloat() / rungs
            val rx = x0 + dx * t
            val ry = y0 + dy * t
            canvas.drawLine(rx + nx, ry + ny, rx - nx, ry - ny, specialLine)
        }
    }

    private fun drawSnake(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len

        val path = Path()
        path.moveTo(x0, y0)
        val waves = 3
        for (i in 1..waves * 2) {
            val t = i.toFloat() / (waves * 2)
            val amp = cell * 0.42f * kotlin.math.sin(i * Math.PI / 2).toFloat()
            path.lineTo(x0 + dx * t + nx * amp, y0 + dy * t + ny * amp)
        }
        path.lineTo(x1, y1)

        specialLine.strokeCap = Paint.Cap.ROUND
        specialLine.strokeJoin = Paint.Join.ROUND
        specialLine.strokeWidth = cell * 0.24f
        specialLine.color = Color.rgb(0x1B, 0x5E, 0x20)
        canvas.drawPath(path, specialLine)
        specialLine.strokeWidth = cell * 0.13f
        specialLine.color = Color.rgb(0x66, 0xBB, 0x6A)
        canvas.drawPath(path, specialLine)

        // head sits on the entry square
        fill.color = Color.rgb(0x1B, 0x5E, 0x20)
        canvas.drawCircle(x0, y0, cell * 0.21f, fill)
        fill.color = Color.WHITE
        canvas.drawCircle(x0 - cell * 0.07f, y0 - cell * 0.04f, cell * 0.055f, fill)
        canvas.drawCircle(x0 + cell * 0.07f, y0 - cell * 0.04f, cell * 0.055f, fill)
        fill.color = Color.BLACK
        canvas.drawCircle(x0 - cell * 0.07f, y0 - cell * 0.04f, cell * 0.025f, fill)
        canvas.drawCircle(x0 + cell * 0.07f, y0 - cell * 0.04f, cell * 0.025f, fill)
    }

    /** Number chips floating just above the chosen piece. */
    private fun drawChoiceChips(canvas: Canvas) {
        chipRects.clear()
        val tokenId = choiceTokenId ?: return
        if (choiceValues.isEmpty()) return
        val pos = displayedCenters[tokenId] ?: return

        val r = cell * 0.34f
        val gap = cell * 0.12f
        val totalW = choiceValues.size * (r * 2) + (choiceValues.size - 1) * gap
        var x = px(pos.second) - totalW / 2f + r
        // sit above the piece, but flip below if it would fall off the top
        var y = py(pos.first) - cell * 0.95f
        if (y - r < 0f) y = py(pos.first) + cell * 0.95f

        for (value in choiceValues) {
            // shadow + gold chip
            canvas.drawCircle(x + r * 0.10f, y + r * 0.16f, r, shadow)
            fill.color = Color.rgb(0x1E, 0x28, 0x32)
            canvas.drawCircle(x, y, r, fill)
            fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
            canvas.drawCircle(x, y, r * 0.86f, fill)

            badgeText.color = Color.rgb(0x1E, 0x14, 0x00)
            badgeText.textSize = r * 1.15f
            canvas.drawText(value.toString(), x, y + r * 0.42f, badgeText)

            chipRects += value to RectF(x - r, y - r, x + r, y + r)
            x += r * 2 + gap
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell <= 0f) return true

        // a visible number chip wins the tap
        for ((value, rect) in chipRects) {
            if (rect.contains(event.x, event.y)) {
                onChoicePicked?.invoke(value)
                return true
            }
        }

        // rebuild the same layout used for drawing, so taps hit what you see
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            tokens.forEachIndexed { i, token ->
                if (token.id !in tappableTokenIds) return@forEachIndexed
                val (ox, oy) = offsets[i]
                val dx = event.x - (px(col) + ox * cell)
                val dy = event.y - (py(row) + oy * cell)
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }

        // copy to a local val: Kotlin cannot smart-cast a var written inside a lambda
        val chosen = best
        val touchRadius = cell * 0.8f
        if (chosen != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(chosen)
        }
        return true
    }

    // ---------------------------------------------------------- ARROW MODE

    /** Unit direction of travel along the ring at [index], in cell units. */
    private fun ringDirection(index: Int): Pair<Float, Float> {
        val ring = BoardGeometry.RING
        val a = ring[index % ring.size]
        val b = ring[(index + 1) % ring.size]
        val dx = (b.second - a.second).toFloat()
        val dy = (b.first - a.first).toFloat()
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.0001f)
        return (dx / len) to (dy / len)
    }

    private fun ringCentre(index: Int): Pair<Float, Float> {
        val ring = BoardGeometry.RING
        val (r, c) = ring[index % ring.size]
        return px(c + 0.5f) to py(r + 0.5f)
    }

    /**
     * The markings that make ARROW MODE readable at a glance: a feathered dart
     * on every straight arrow, a solid arrow in the owner's colour on every
     * home arrow, a U-turn hook where each colour leaves the ring, and a small
     * globe on each starting square.
     */
    private fun drawArrows(canvas: Canvas) {
        specialLine.strokeCap = Paint.Cap.ROUND
        specialLine.strokeJoin = Paint.Join.ROUND

        for ((color, startCell) in ArrowConfig.START_CELLS) {
            drawGlobe(canvas, startCell, colorOf(color))
        }
        for ((color, turnCell) in ArrowConfig.HOME_TURNS) {
            drawHomeTurn(canvas, turnCell, colorOf(color))
        }
        for (arrow in ArrowConfig.ARROWS) {
            val (cx, cy) = ringCentre(arrow.cell)
            val (dx, dy) = ringDirection(arrow.cell)
            val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
            canvas.save()
            canvas.rotate(angle, cx, cy)
            if (arrow.kind == ArrowKind.STRAIGHT) {
                drawDart(canvas, cx, cy)
            } else {
                drawSolidArrow(canvas, cx, cy, arrow.color?.let { colorOf(it) } ?: Color.DKGRAY)
            }
            canvas.restore()
        }
    }

    /** A feathered dart: the straight arrow, drawn pointing along the route. */
    private fun drawDart(canvas: Canvas, cx: Float, cy: Float) {
        val len = cell * 0.36f
        specialLine.color = Color.argb(215, 0x37, 0x44, 0x5E)
        specialLine.strokeWidth = cell * 0.075f
        canvas.drawLine(cx - len, cy, cx + len * 0.55f, cy, specialLine)
        // head
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.10f, cy - cell * 0.20f, specialLine)
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.10f, cy + cell * 0.20f, specialLine)
        // three feathers at the tail
        specialLine.strokeWidth = cell * 0.055f
        for (i in 0 until 3) {
            val x = cx - len + i * cell * 0.13f
            canvas.drawLine(x, cy - cell * 0.17f, x + cell * 0.11f, cy, specialLine)
            canvas.drawLine(x, cy + cell * 0.17f, x + cell * 0.11f, cy, specialLine)
        }
    }

    /** A solid arrow in the owner's colour: the home arrow. */
    private fun drawSolidArrow(canvas: Canvas, cx: Float, cy: Float, color: Int) {
        val len = cell * 0.34f
        val head = cell * 0.19f
        val body = Path()
        body.moveTo(cx + len, cy)
        body.lineTo(cx + len - head, cy - head)
        body.lineTo(cx + len - head, cy - head * 0.42f)
        body.lineTo(cx - len, cy - head * 0.42f)
        body.lineTo(cx - len, cy + head * 0.42f)
        body.lineTo(cx + len - head, cy + head * 0.42f)
        body.lineTo(cx + len - head, cy + head)
        body.close()

        fill.color = Color.argb(70, 0, 0, 0)
        canvas.save()
        canvas.translate(cell * 0.03f, cell * 0.04f)
        canvas.drawPath(body, fill)
        canvas.restore()

        fill.color = color
        canvas.drawPath(body, fill)
        specialLine.color = darken(color, 0.45f)
        specialLine.strokeWidth = cell * 0.035f
        canvas.drawPath(body, specialLine)
    }

    /** The hook that shows where a colour turns off the ring into its lane. */
    private fun drawHomeTurn(canvas: Canvas, ringCell: Int, color: Int) {
        val (cx, cy) = ringCentre(ringCell)
        val (dx, dy) = ringDirection(ringCell)
        val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
        canvas.save()
        canvas.rotate(angle, cx, cy)
        specialLine.color = Color.argb(150, Color.red(color), Color.green(color), Color.blue(color))
        specialLine.strokeWidth = cell * 0.060f
        val r = cell * 0.30f
        val hook = Path()
        hook.moveTo(cx - cell * 0.42f, cy + r)
        hook.lineTo(cx + cell * 0.10f, cy + r)
        hook.quadTo(cx + cell * 0.10f + r, cy + r, cx + cell * 0.10f + r, cy)
        hook.quadTo(cx + cell * 0.10f + r, cy - r, cx + cell * 0.10f, cy - r)
        hook.lineTo(cx - cell * 0.18f, cy - r)
        canvas.drawPath(hook, specialLine)
        // little head on the returning end
        canvas.drawLine(cx - cell * 0.18f, cy - r, cx - cell * 0.06f, cy - r - cell * 0.11f, specialLine)
        canvas.drawLine(cx - cell * 0.18f, cy - r, cx - cell * 0.06f, cy - r + cell * 0.11f, specialLine)
        canvas.restore()
    }

    /** A small globe on a colour's starting square. */
    private fun drawGlobe(canvas: Canvas, ringCell: Int, color: Int) {
        val (cx, cy) = ringCentre(ringCell)
        val r = cell * 0.26f
        fill.color = Color.argb(235, 255, 255, 255)
        canvas.drawCircle(cx, cy, r, fill)
        specialLine.color = darken(color, 0.25f)
        specialLine.strokeWidth = cell * 0.045f
        canvas.drawCircle(cx, cy, r, specialLine)
        specialLine.strokeWidth = cell * 0.032f
        canvas.drawLine(cx - r, cy, cx + r, cy, specialLine)
        canvas.drawOval(RectF(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r), specialLine)
    }
}
