package com.example.ludoroyale.cosmetics

import android.graphics.Color

/** What sits in the middle of a piece. */
enum class TokenOrnament { STAR, GEM, FLAME, CRYSTAL, CROWN, BOLT, PRISM, SCALE, RING }

/**
 * How a token skin looks.
 *
 * READABILITY IS THE RULE HERE. A piece must say whose it is from across the
 * table at a glance, so the player's colour always stays the body of the piece.
 * A skin only changes the rim, the inset, the ornament and the sheen — the
 * jewellery, never the flag. That is why every field below is a trim and none
 * of them replaces [com.example.ludoroyale.model.PlayerColor].
 */
data class TokenArt(
    val id: String,
    /** The metal of the rim and the ornament. */
    val trim: Int,
    /** The disc the ornament sits on. */
    val inset: Int,
    val ornament: TokenOrnament,
    /** How strongly the body is polished, 0f..1f. */
    val sheen: Float = 0.35f,
    /** A halo drawn behind the piece, or 0 for none. */
    val halo: Int = 0,
    /** Cycles the trim through the rainbow when true. */
    val shifting: Boolean = false
)

/**
 * The look of every token skin in the catalog.
 *
 * FAIRNESS: none of these values reaches the engine. A Dragon token and a
 * Classic token occupy the same square, move the same distance and are cut on
 * the same rules. The only difference is what the player sees.
 */
object TokenArts {

    private val GOLD = Color.rgb(0xF2, 0xC1, 0x4E)
    private val PALE_GOLD = Color.rgb(0xFF, 0xE9, 0xA8)
    private val ICE = Color.rgb(0xBF, 0xEC, 0xFF)
    private val EMBER = Color.rgb(0xFF, 0x8A, 0x2E)
    private val PLATINUM = Color.rgb(0xE6, 0xEE, 0xF8)
    private val ROYAL_PURPLE = Color.rgb(0x8E, 0x63, 0xE0)
    private val VOLT = Color.rgb(0xFF, 0xF1, 0x6B)
    private val JADE = Color.rgb(0x5C, 0xE0, 0xAE)

    val ALL: List<TokenArt> = listOf(
        TokenArt(Cosmetics.TOKEN_CLASSIC, Color.WHITE, Color.WHITE, TokenOrnament.STAR, sheen = 0.35f),
        TokenArt(Cosmetics.TOKEN_GOLDEN, GOLD, PALE_GOLD, TokenOrnament.CROWN, sheen = 0.60f, halo = Color.argb(70, 0xFF, 0xD1, 0x62)),
        TokenArt(Cosmetics.TOKEN_DIAMOND, PLATINUM, Color.WHITE, TokenOrnament.GEM, sheen = 0.80f, halo = Color.argb(70, 0xCF, 0xEA, 0xFF)),
        TokenArt(Cosmetics.TOKEN_FIRE, EMBER, Color.rgb(0xFF, 0xE0, 0xB8), TokenOrnament.FLAME, sheen = 0.45f, halo = Color.argb(80, 0xFF, 0x6A, 0x1E)),
        TokenArt(Cosmetics.TOKEN_ICE, ICE, Color.rgb(0xEC, 0xFA, 0xFF), TokenOrnament.CRYSTAL, sheen = 0.70f, halo = Color.argb(70, 0x8F, 0xD8, 0xFF)),
        TokenArt(Cosmetics.TOKEN_ROYAL, ROYAL_PURPLE, PALE_GOLD, TokenOrnament.CROWN, sheen = 0.50f, halo = Color.argb(70, 0x9A, 0x6A, 0xF0)),
        TokenArt(Cosmetics.TOKEN_LIGHTNING, VOLT, Color.rgb(0xFF, 0xFB, 0xD8), TokenOrnament.BOLT, sheen = 0.55f, halo = Color.argb(80, 0xFF, 0xF2, 0x6B)),
        TokenArt(Cosmetics.TOKEN_RAINBOW, GOLD, Color.WHITE, TokenOrnament.PRISM, sheen = 0.60f, halo = Color.argb(60, 0xFF, 0xFF, 0xFF), shifting = true),
        TokenArt(Cosmetics.TOKEN_DRAGON, JADE, Color.rgb(0xDF, 0xFA, 0xEE), TokenOrnament.SCALE, sheen = 0.50f, halo = Color.argb(75, 0x3C, 0xD9, 0x9A))
    )

    fun byId(id: String): TokenArt = ALL.firstOrNull { it.id == id } ?: ALL.first()
}
