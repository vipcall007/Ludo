package com.example.ludoroyale.cosmetics

/**
 * What kind of thing a cosmetic is.
 *
 * Every one of these changes how something LOOKS and nothing else. There is no
 * cosmetic type for dice odds, movement or board rules, because no such thing
 * is allowed to exist in this game.
 */
enum class CosmeticType(val display: String) {
    TOKEN_SKIN("TOKEN"),
    DICE_SKIN("DICE"),
    AVATAR("AVATAR"),
    AVATAR_FRAME("FRAME"),
    VICTORY_EFFECT("VICTORY")
}

enum class Rarity(val display: String) {
    COMMON("COMMON"),
    RARE("RARE"),
    EPIC("EPIC"),
    LEGENDARY("LEGENDARY")
}

/** How an item is come by. */
enum class UnlockMethod {
    /** Owned from the first launch. */
    FREE,
    /** Bought with coins earned by playing. */
    COINS,
    /** Given on reaching a player level. */
    LEVEL,
    /** Given by the daily login cycle. */
    DAILY,
    /** Given for finishing missions. */
    MISSION,
    /** Found in a chest earned by playing. */
    CHEST
}

/**
 * One collectable.
 *
 * This is the single source of truth for what exists, what it costs and how it
 * is come by. The drawing code keys off [id] for its colours, so a cosmetic can
 * be re-priced or re-classified without touching a line of rendering, and no
 * Activity has to carry its own copy of the list.
 */
data class CosmeticItem(
    val id: String,
    val name: String,
    val type: CosmeticType,
    val rarity: Rarity,
    val unlock: UnlockMethod,
    /** Coins, when [unlock] is COINS. Otherwise 0. */
    val price: Int = 0,
    /** Player level required, when [unlock] is LEVEL. Otherwise 0. */
    val requiredLevel: Int = 0
) {
    /** What a duplicate is worth when a chest turns one up again. */
    val dustValue: Int
        get() = when (rarity) {
            Rarity.COMMON -> 40
            Rarity.RARE -> 90
            Rarity.EPIC -> 180
            Rarity.LEGENDARY -> 350
        }
}

/**
 * The whole collection.
 *
 * FAIRNESS: nothing in this catalog is consulted by the rules engine, the dice
 * or the computer players. A Legendary dragon token moves exactly as far as the
 * free one, and a Legendary dice rolls exactly the same numbers.
 */
object Cosmetics {

    // ---------------------------------------------------------- token skins

    const val TOKEN_CLASSIC = "tok_classic"
    const val TOKEN_GOLDEN = "tok_golden"
    const val TOKEN_DIAMOND = "tok_diamond"
    const val TOKEN_FIRE = "tok_fire"
    const val TOKEN_ICE = "tok_ice"
    const val TOKEN_ROYAL = "tok_royal"
    const val TOKEN_LIGHTNING = "tok_lightning"
    const val TOKEN_RAINBOW = "tok_rainbow"
    const val TOKEN_DRAGON = "tok_dragon"

    // ----------------------------------------------------------- dice skins
    // the ids the older builds already saved stay exactly as they were, so a
    // player who had bought a dice still owns it after updating

    const val DICE_GOLD = "gold"
    const val DICE_IVORY = "ivory"
    const val DICE_OCEAN = "ocean"
    const val DICE_CORAL = "coral"
    const val DICE_EMERALD = "emerald"
    const val DICE_AMBER = "amber"
    const val DICE_VIOLET = "violet"
    const val DICE_MIDNIGHT = "midnight"
    const val DICE_REEF = "reef"
    const val DICE_RUBY = "ruby"
    const val DICE_SAND = "sand"
    const val DICE_STORM = "storm"
    const val DICE_GOLDEN = "dice_golden"
    const val DICE_DIAMOND = "dice_diamond"
    const val DICE_FIRE = "dice_fire"
    const val DICE_ICE = "dice_ice"
    const val DICE_ROYAL = "dice_royal"
    const val DICE_NEON = "dice_neon"
    const val DICE_DRAGON = "dice_dragon"

    // ------------------------------------------------------------- avatars

    const val AVATAR_P1 = "av_p1"
    const val AVATAR_P2 = "av_p2"
    const val AVATAR_P3 = "av_p3"
    const val AVATAR_P4 = "av_p4"
    const val AVATAR_CROWN = "av_crown"
    const val AVATAR_KNIGHT = "av_knight"

    // -------------------------------------------------------------- frames

    const val FRAME_NONE = "fr_none"
    const val FRAME_BRONZE = "fr_bronze"
    const val FRAME_SILVER = "fr_silver"
    const val FRAME_GOLD = "fr_gold"
    const val FRAME_DIAMOND = "fr_diamond"
    const val FRAME_ROYAL = "fr_royal"
    const val FRAME_LEGENDARY = "fr_legendary"

    // ----------------------------------------------------- victory effects

    const val FX_CONFETTI = "fx_confetti"
    const val FX_GOLD_RAIN = "fx_gold_rain"
    const val FX_FIREWORKS = "fx_fireworks"
    const val FX_ROYAL_CROWN = "fx_royal_crown"

    val ALL: List<CosmeticItem> = listOf(
        // ---- token skins
        item(TOKEN_CLASSIC, "Classic", CosmeticType.TOKEN_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(TOKEN_GOLDEN, "Golden Token", CosmeticType.TOKEN_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 600),
        item(TOKEN_ICE, "Ice Token", CosmeticType.TOKEN_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 800),
        item(TOKEN_FIRE, "Fire Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.COINS, price = 1200),
        item(TOKEN_ROYAL, "Royal Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 10),
        item(TOKEN_LIGHTNING, "Lightning Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.COINS, price = 1600),
        item(TOKEN_DIAMOND, "Diamond Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 20),
        item(TOKEN_RAINBOW, "Rainbow Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.CHEST),
        item(TOKEN_DRAGON, "Dragon Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 30),

        // ---- dice skins already in the game
        item(DICE_GOLD, "Royal Gold", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(DICE_IVORY, "Ivory", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(DICE_OCEAN, "Ocean", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.COINS, price = 300),
        item(DICE_CORAL, "Coral", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.COINS, price = 500),
        item(DICE_EMERALD, "Emerald", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 700),
        item(DICE_AMBER, "Amber", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 900),
        item(DICE_VIOLET, "Violet", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 1200),
        item(DICE_MIDNIGHT, "Midnight", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 1500),
        item(DICE_REEF, "Reef", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 1800),
        item(DICE_RUBY, "Ruby", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.COINS, price = 2200),
        item(DICE_SAND, "Driftwood", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.COINS, price = 2600),
        item(DICE_STORM, "Storm", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 3000),

        // ---- the named dice the brief asks for
        item(DICE_GOLDEN, "Golden Dice", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.DAILY),
        item(DICE_ICE, "Ice Dice", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.COINS, price = 1000),
        item(DICE_FIRE, "Fire Dice", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.COINS, price = 1400),
        item(DICE_ROYAL, "Royal Dice", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 5),
        item(DICE_NEON, "Neon Dice", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.CHEST),
        item(DICE_DIAMOND, "Diamond Dice", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 20),
        item(DICE_DRAGON, "Dragon Dice", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.CHEST),

        // ---- avatars
        item(AVATAR_P1, "Player One", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P2, "Player Two", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P3, "Player Three", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P4, "Player Four", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_KNIGHT, "Knight", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.COINS, price = 700),
        item(AVATAR_CROWN, "Crowned", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 10),

        // ---- avatar frames
        item(FRAME_NONE, "No Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FRAME_BRONZE, "Bronze Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FRAME_SILVER, "Silver Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.LEVEL, requiredLevel = 5),
        item(FRAME_GOLD, "Gold Frame", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.DAILY),
        item(FRAME_DIAMOND, "Diamond Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 20),
        item(FRAME_ROYAL, "Royal Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.COINS, price = 2000),
        item(FRAME_LEGENDARY, "Legendary Frame", CosmeticType.AVATAR_FRAME, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 30),

        // ---- victory effects
        item(FX_CONFETTI, "Confetti", CosmeticType.VICTORY_EFFECT, Rarity.COMMON, UnlockMethod.FREE),
        item(FX_GOLD_RAIN, "Gold Rain", CosmeticType.VICTORY_EFFECT, Rarity.RARE, UnlockMethod.DAILY),
        item(FX_FIREWORKS, "Fireworks", CosmeticType.VICTORY_EFFECT, Rarity.EPIC, UnlockMethod.COINS, price = 1500),
        item(FX_ROYAL_CROWN, "Royal Crown", CosmeticType.VICTORY_EFFECT, Rarity.LEGENDARY, UnlockMethod.CHEST)
    )

    private fun item(
        id: String, name: String, type: CosmeticType, rarity: Rarity,
        unlock: UnlockMethod, price: Int = 0, requiredLevel: Int = 0
    ) = CosmeticItem(id, name, type, rarity, unlock, price, requiredLevel)

    fun byId(id: String): CosmeticItem? = ALL.firstOrNull { it.id == id }

    fun byType(type: CosmeticType): List<CosmeticItem> = ALL.filter { it.type == type }

    /** Owned from the first launch, whatever else happens. */
    fun free(): List<String> = ALL.filter { it.unlock == UnlockMethod.FREE }.map { it.id }

    /** What a brand-new player has selected. */
    fun defaultFor(type: CosmeticType): String = when (type) {
        CosmeticType.TOKEN_SKIN -> TOKEN_CLASSIC
        CosmeticType.DICE_SKIN -> DICE_GOLD
        CosmeticType.AVATAR -> AVATAR_P1
        CosmeticType.AVATAR_FRAME -> FRAME_BRONZE
        CosmeticType.VICTORY_EFFECT -> FX_CONFETTI
    }

    /** Everything a player is owed for standing at [level]. */
    fun unlockedAtLevel(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel in 1..level }

    /** Everything handed out exactly on reaching [level]. */
    fun unlockedOnReaching(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel == level }

    /** Every id must be unique, or ownership would be ambiguous. */
    fun isSane(): Boolean {
        val ids = ALL.map { it.id }
        if (ids.size != ids.toSet().size) return false
        if (ALL.any { it.unlock == UnlockMethod.COINS && it.price <= 0 }) return false
        if (ALL.any { it.unlock == UnlockMethod.LEVEL && it.requiredLevel <= 0 }) return false
        if (ALL.any { it.unlock != UnlockMethod.COINS && it.price != 0 }) return false
        // every type must have something a new player already owns
        return CosmeticType.entries.all { type ->
            byType(type).any { it.unlock == UnlockMethod.FREE }
        }
    }
}
