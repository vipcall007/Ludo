package com.example.ludoroyale.progression

import com.example.ludoroyale.cosmetics.Cosmetics
import kotlin.random.Random

/** What a reward hands over. */
enum class RewardKind {
    COINS,
    DICE_SKIN,
    TOKEN_SKIN,
    AVATAR_FRAME,
    VICTORY_EFFECT,
    /** A chest: coins plus one cosmetic from the pool. */
    CHEST
}

/** One rung of the login cycle. */
data class DailyReward(
    val day: Int,
    val kind: RewardKind,
    val coins: Int = 0,
    val cosmeticId: String? = null
) {
    fun label(): String = when (kind) {
        RewardKind.COINS -> "+$coins"
        RewardKind.CHEST -> "CHEST"
        else -> Cosmetics.byId(cosmeticId ?: "")?.name ?: "REWARD"
    }
}

/**
 * The seven-day login cycle.
 *
 * Day seven is the one people come back for, so it is the only chest and it is
 * worth noticeably more than the rest. The rules below are the whole of it:
 * there is nothing to spend, nothing to wager and no way to pay for a better
 * day.
 */
object DailyRewards {

    val CYCLE: List<DailyReward> = listOf(
        DailyReward(1, RewardKind.COINS, coins = 50),
        DailyReward(2, RewardKind.DICE_SKIN, coins = 0, cosmeticId = Cosmetics.DICE_GOLDEN),
        DailyReward(3, RewardKind.TOKEN_SKIN, coins = 0, cosmeticId = Cosmetics.TOKEN_GOLDEN),
        DailyReward(4, RewardKind.AVATAR_FRAME, coins = 0, cosmeticId = Cosmetics.FRAME_GOLD),
        DailyReward(5, RewardKind.COINS, coins = 150),
        DailyReward(6, RewardKind.VICTORY_EFFECT, coins = 0, cosmeticId = Cosmetics.FX_GOLD_RAIN),
        DailyReward(7, RewardKind.CHEST, coins = 300)
    )

    const val CYCLE_LENGTH = 7

    /**
     * Coins paid instead of a cosmetic the player already has. A cycle must
     * never feel like a wasted day, so a repeat always pays something.
     */
    const val DUPLICATE_COINS = 120

    fun rewardFor(day: Int): DailyReward =
        CYCLE[(day - 1).coerceIn(0, CYCLE.size - 1)]

    /** Today's chest is still waiting when it has not been claimed today. */
    fun canClaim(lastClaimDay: Int, today: Int): Boolean = lastClaimDay != today

    /**
     * Which rung the cycle is offering.
     *
     * Claiming yesterday carries the run forward; missing a day sends it back
     * to day one; finishing day seven starts a fresh cycle at day one. Once
     * today has been claimed, the day already taken is what is shown.
     *
     * AFTER-DAY-SEVEN POLICY, stated plainly: the cycle repeats from day one.
     * Nothing is lost, and cosmetics already owned pay [DUPLICATE_COINS]
     * instead of being handed over twice.
     */
    fun dayOnOffer(lastClaimDay: Int, today: Int, claimedDay: Int): Int {
        if (!canClaim(lastClaimDay, today)) return claimedDay.coerceIn(1, CYCLE_LENGTH)
        val continues = lastClaimDay == today - 1 && claimedDay in 1 until CYCLE_LENGTH
        return if (continues) claimedDay + 1 else 1
    }
}

/** What opening something actually handed over. */
data class RewardGrant(
    val coins: Int,
    val cosmeticId: String?,
    /** True when the cosmetic was already owned and paid out as coins instead. */
    val wasDuplicate: Boolean
) {
    val gaveCosmetic: Boolean get() = cosmeticId != null && !wasDuplicate
}

/**
 * The chest earned by playing.
 *
 * FAIRNESS, and these are commitments the code keeps, not decoration:
 *  - the pool below is the whole pool; there is no hidden second table
 *  - [odds] returns the real chances, and the game shows them on the screen
 *  - nothing here can be bought with real money, and nothing is wagered
 *  - no entry affects gameplay in any way; every one is a colour
 *  - a duplicate pays [CosmeticItem.dustValue] coins, decided before the draw,
 *    so there is no near-miss and nothing is "almost" won
 */
object MysteryChest {

    /** id to weight. Weights are plain integers so the odds can be read off. */
    val POOL: List<Pair<String, Int>> = listOf(
        "COINS_SMALL" to 34,
        "COINS_BIG" to 16,
        Cosmetics.DICE_ICE to 8,
        Cosmetics.DICE_FIRE to 7,
        Cosmetics.DICE_NEON to 6,
        Cosmetics.TOKEN_GOLDEN to 8,
        Cosmetics.TOKEN_ICE to 7,
        Cosmetics.TOKEN_FIRE to 6,
        Cosmetics.FRAME_GOLD to 4,
        Cosmetics.FRAME_ROYAL to 2,
        Cosmetics.TOKEN_RAINBOW to 1,
        Cosmetics.DICE_DRAGON to 1,
        Cosmetics.FX_ROYAL_CROWN to 1
    )

    const val COINS_SMALL = 80
    const val COINS_BIG = 200

    private val totalWeight: Int get() = POOL.sumOf { it.second }

    /** The real chance of each entry, as a percentage. Shown to the player. */
    fun odds(): List<Pair<String, Float>> {
        val total = totalWeight.toFloat()
        return POOL.map { (id, weight) -> id to weight * 100f / total }
    }

    fun isSane(): Boolean {
        if (POOL.isEmpty()) return false
        if (POOL.any { it.second <= 0 }) return false
        val ids = POOL.map { it.first }
        if (ids.size != ids.toSet().size) return false
        return POOL.all { (id, _) ->
            id == "COINS_SMALL" || id == "COINS_BIG" || Cosmetics.byId(id) != null
        }
    }

    /**
     * Draws one entry. [owned] decides duplicates before anything is shown, so
     * the animation never builds up to a prize that was never going to be one.
     */
    fun open(rnd: Random, owned: Set<String>): RewardGrant {
        var roll = rnd.nextInt(totalWeight)
        var picked = POOL.last().first
        for ((id, weight) in POOL) {
            if (roll < weight) { picked = id; break }
            roll -= weight
        }
        return when (picked) {
            "COINS_SMALL" -> RewardGrant(COINS_SMALL, null, false)
            "COINS_BIG" -> RewardGrant(COINS_BIG, null, false)
            else -> {
                val item = Cosmetics.byId(picked)
                when {
                    item == null -> RewardGrant(COINS_SMALL, null, false)
                    picked in owned -> RewardGrant(item.dustValue, picked, wasDuplicate = true)
                    else -> RewardGrant(0, picked, wasDuplicate = false)
                }
            }
        }
    }
}
