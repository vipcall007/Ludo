package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * UNDO: a photograph of the board, and putting it back.
 *
 * The promises these tests hold [GameSnapshot] to: it copies everything a move
 * can change, it shares no memory with the live state, and restoring it leaves
 * the board exactly as it stood — including a capture that has to be undone on
 * both sides at once.
 */
class UndoTest {

    private fun state(): GameState = GameState(
        gameId = "undo-test",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        )
    )

    private fun bank(s: GameState, vararg values: Int) {
        s.pendingRolls.clear()
        s.pendingRolls.addAll(values.toList())
        s.phase = TurnPhase.AWAITING_MOVE
        s.lastDiceRoll = values.lastOrNull()
    }

    private fun stepsFor(color: PlayerColor, cell: Int): Int =
        ((cell - color.startOffset + LudoBoard.TRACK_LENGTH) % LudoBoard.TRACK_LENGTH) + 1

    /** A short fingerprint of everything a move is allowed to change. */
    private fun fingerprint(s: GameState): String = buildString {
        append(s.currentPlayerIndex).append('|')
        append(s.lastDiceRoll).append('|')
        append(s.consecutiveSixes).append('|')
        append(s.pendingRolls.joinToString(",")).append('|')
        append(s.phase).append('|')
        append(s.rankings.joinToString(",")).append('|')
        for (p in s.players) {
            append(p.id).append(':')
            append(p.finishedCount).append(',')
            append(p.hasCapturedOpponent).append(',')
            append(p.hasWon).append('[')
            for (t in p.tokens) append(t.id).append('=').append(t.state).append('@').append(t.steps).append(' ')
            append(']')
        }
    }

    @Test
    fun `a snapshot is a copy, not a view`() {
        val s = state()
        val shot = GameSnapshot.of(s)
        s.pendingRolls.add(6)
        s.players[0].tokens[0].steps = 9
        s.rankings.add("p1")

        assertEquals(0, shot.pendingRolls.size)
        assertEquals(0, shot.players[0].tokens[0].steps)
        assertEquals(0, shot.rankings.size)
    }

    @Test
    fun `restoring puts an ordinary move back exactly`() {
        val s = state()
        val e = LudoEngine(s, RuleConfig())
        s.players[0].tokens[0].state = TokenState.ACTIVE
        s.players[0].tokens[0].steps = 5
        bank(s, 4)

        val before = fingerprint(s)
        val shot = GameSnapshot.of(s)

        e.applyMove(e.legalMovesFor(4).first())
        assertNotEquals(before, fingerprint(s))

        shot.restoreInto(s)
        assertEquals(before, fingerprint(s))
    }

    @Test
    fun `restoring puts a capture back on both sides`() {
        val s = state()
        val e = LudoEngine(s, RuleConfig())

        // yellow parks on a square red can reach with a three
        val victimCell = 6
        val yellow = s.players[1].tokens[0]
        yellow.state = TokenState.ACTIVE
        yellow.steps = stepsFor(PlayerColor.YELLOW, victimCell)

        val red = s.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = stepsFor(PlayerColor.RED, victimCell) - 3
        bank(s, 3)

        val before = fingerprint(s)
        val shot = GameSnapshot.of(s)

        val result = e.applyMove(e.legalMovesFor(3).first { it.token.id == red.id })
        assertEquals(1, result.capturedTokens.size)
        assertEquals(TokenState.BASE, yellow.state)

        shot.restoreInto(s)
        assertEquals(before, fingerprint(s))
        assertEquals(TokenState.ACTIVE, yellow.state)
        assertEquals(stepsFor(PlayerColor.YELLOW, victimCell), yellow.steps)
    }

    @Test
    fun `restoring puts the quick-mode home unlock back`() {
        val s = state()
        val e = LudoEngine(s, RuleConfig(quickMode = true))

        val victimCell = 6
        val yellow = s.players[1].tokens[0]
        yellow.state = TokenState.ACTIVE
        yellow.steps = stepsFor(PlayerColor.YELLOW, victimCell)

        val red = s.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = stepsFor(PlayerColor.RED, victimCell) - 3
        bank(s, 3)

        val shot = GameSnapshot.of(s)
        e.applyMove(e.legalMovesFor(3).first { it.token.id == red.id })
        assertTrue("the cut should unlock home", s.players[0].hasCapturedOpponent)

        shot.restoreInto(s)
        assertTrue("undo should lock home again", !s.players[0].hasCapturedOpponent)
    }

    @Test
    fun `a stack of snapshots rewinds a whole run of moves`() {
        val s = state()
        val e = LudoEngine(s, RuleConfig())
        val stack = mutableListOf<Pair<String, GameSnapshot>>()

        var guard = 0
        while (stack.size < 25 && guard < 4000) {
            guard++
            when (s.phase) {
                TurnPhase.AWAITING_ROLL -> e.rollDice()
                TurnPhase.AWAITING_MOVE -> {
                    val moves = e.legalMoves()
                    if (moves.isEmpty()) e.passTurn()
                    else {
                        stack.add(fingerprint(s) to GameSnapshot.of(s))
                        e.applyMove(moves.random())
                    }
                }
                TurnPhase.GAME_OVER -> break
            }
        }

        assertTrue("the run produced no moves to undo", stack.isNotEmpty())
        while (stack.isNotEmpty()) {
            val (expected, shot) = stack.removeAt(stack.size - 1)
            shot.restoreInto(s)
            assertEquals(expected, fingerprint(s))
        }
    }

    @Test
    fun `restoring never leaves a piece off its route`() {
        val s = state()
        val e = LudoEngine(s, RuleConfig())
        repeat(400) {
            when (s.phase) {
                TurnPhase.AWAITING_ROLL -> e.rollDice()
                TurnPhase.AWAITING_MOVE -> {
                    val moves = e.legalMoves()
                    if (moves.isEmpty()) e.passTurn()
                    else {
                        val shot = GameSnapshot.of(s)
                        e.applyMove(moves.random())
                        shot.restoreInto(s)
                        e.applyMove(e.legalMoves().random())
                    }
                }
                TurnPhase.GAME_OVER -> Unit
            }
            for (p in s.players) {
                for (t in p.tokens) {
                    assertTrue("a piece left its route", t.steps in 0..LudoEngine.FINISH_STEPS)
                }
            }
        }
    }
}
