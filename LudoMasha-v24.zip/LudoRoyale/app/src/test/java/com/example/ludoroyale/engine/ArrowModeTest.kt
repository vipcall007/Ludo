package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * ARROW MODE: the normal Ludo board with eight arrows painted on the ring.
 *
 * The promises these tests hold the engine to: an arrow fires only on an exact
 * landing, at most one fires per dice move, a straight arrow serves everybody,
 * and a home arrow serves only its own colour.
 */
class ArrowModeTest {

    private fun state(): GameState = GameState(
        gameId = "arrow-test",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        )
    )

    private fun engine(s: GameState) = LudoEngine(s, RuleConfig(arrowMode = true))

    private fun bank(s: GameState, vararg values: Int) {
        s.pendingRolls.clear()
        s.pendingRolls.addAll(values.toList())
        s.phase = TurnPhase.AWAITING_MOVE
        s.lastDiceRoll = values.lastOrNull()
    }

    /** The step count, for [color], that stands on ring cell [cell]. */
    private fun stepsFor(color: PlayerColor, cell: Int): Int =
        ((cell - color.startOffset + LudoBoard.TRACK_LENGTH) % LudoBoard.TRACK_LENGTH) + 1

    // ------------------------------------------------------------ the table

    @Test
    fun `the arrow table is sane`() {
        assertTrue(ArrowConfig.isSane())
    }

    @Test
    fun `there are four straight arrows and four home arrows`() {
        assertEquals(4, ArrowConfig.ARROWS.count { it.kind == ArrowKind.STRAIGHT })
        assertEquals(4, ArrowConfig.ARROWS.count { it.kind == ArrowKind.HOME })
    }

    @Test
    fun `every colour owns exactly one home arrow`() {
        val owners = ArrowConfig.ARROWS
            .filter { it.kind == ArrowKind.HOME }
            .mapNotNull { it.color }
        assertEquals(4, owners.toSet().size)
        assertEquals(PlayerColor.entries.toSet(), owners.toSet())
    }

    @Test
    fun `no two arrows share a square`() {
        val cells = ArrowConfig.ARROWS.map { it.cell }
        assertEquals(cells.size, cells.toSet().size)
    }

    // ------------------------------------------------------- straight arrow

    @Test
    fun `a straight arrow carries any colour six squares on`() {
        val s = state()
        val e = engine(s)
        val arrow = ArrowConfig.ARROWS.first { it.kind == ArrowKind.STRAIGHT }
        val red = s.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = stepsFor(PlayerColor.RED, arrow.cell) - 3

        bank(s, 3)
        val move = e.legalMovesFor(3).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertNotNull(result.arrow)
        assertEquals(ArrowKind.STRAIGHT, result.arrow!!.kind)
        assertEquals(stepsFor(PlayerColor.RED, arrow.cell) + ArrowConfig.STRAIGHT_JUMP, red.steps)
    }

    @Test
    fun `passing over an arrow does nothing`() {
        val s = state()
        val e = engine(s)
        val arrow = ArrowConfig.ARROWS.first { it.kind == ArrowKind.STRAIGHT }
        val red = s.players[0].tokens[0]
        val landing = stepsFor(PlayerColor.RED, arrow.cell)
        red.state = TokenState.ACTIVE
        red.steps = landing - 2

        bank(s, 4)                       // 2 short of the arrow, rolls straight past it
        val move = e.legalMovesFor(4).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertNull(result.arrow)
        assertEquals(landing + 2, red.steps)
    }

    @Test
    fun `only one arrow fires per dice move`() {
        // a straight arrow must never drop a piece onto another arrow
        for (arrow in ArrowConfig.ARROWS.filter { it.kind == ArrowKind.STRAIGHT }) {
            for (color in PlayerColor.entries) {
                val landing = stepsFor(color, arrow.cell)
                val after = landing + ArrowConfig.STRAIGHT_JUMP
                if (after > LudoBoard.TRACK_LENGTH - 1) continue
                val cell = LudoBoard.toGlobalIndex(color, after - 1)
                assertNull(
                    "${arrow.id} drops $color onto another arrow",
                    ArrowConfig.arrowAt(cell)
                )
            }
        }
    }

    // ----------------------------------------------------------- home arrow

    @Test
    fun `a home arrow takes its own colour to the home lane`() {
        val s = state()
        val e = engine(s)
        val arrow = ArrowConfig.ARROWS.first { it.kind == ArrowKind.HOME && it.color == PlayerColor.RED }
        val red = s.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = stepsFor(PlayerColor.RED, arrow.cell) - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertNotNull(result.arrow)
        assertEquals(ArrowKind.HOME, result.arrow!!.kind)
        assertEquals(ArrowConfig.HOME_LANE_STEPS, red.steps)
        assertEquals(TokenState.HOME_STRETCH, red.state)
    }

    @Test
    fun `a home arrow ignores every other colour`() {
        val s = state()
        val e = engine(s)
        val arrow = ArrowConfig.ARROWS.first { it.kind == ArrowKind.HOME && it.color == PlayerColor.RED }
        // yellow moves onto red's home arrow
        s.currentPlayerIndex = 1
        val yellow = s.players[1].tokens[0]
        val landing = stepsFor(PlayerColor.YELLOW, arrow.cell)
        yellow.state = TokenState.ACTIVE
        yellow.steps = landing - 2

        bank(s, 2)
        val move = e.legalMovesFor(2).first { it.token.id == yellow.id }
        val result = e.applyMove(move)

        assertNull(result.arrow)
        assertEquals(landing, yellow.steps)
    }

    @Test
    fun `every home arrow sits the same distance from its own home lane`() {
        for (arrow in ArrowConfig.ARROWS.filter { it.kind == ArrowKind.HOME }) {
            val color = arrow.color!!
            val landing = stepsFor(color, arrow.cell)
            assertTrue(
                "${arrow.id} is not in front of its own home lane",
                landing < ArrowConfig.HOME_LANE_STEPS
            )
        }
    }

    // ---------------------------------------------------------- whole games

    @Test
    fun `arrow games still finish and never push a piece off its route`() {
        for (game in 0 until 60) {
            val s = GameState(
                gameId = "arrow-$game",
                players = mutableListOf(
                    Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
                    Player.create("p2", "Green", PlayerColor.GREEN, PlayerKind.HUMAN),
                    Player.create("p3", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN),
                    Player.create("p4", "Blue", PlayerColor.BLUE, PlayerKind.HUMAN)
                )
            )
            val e = engine(s)
            var turns = 0
            while (s.phase != TurnPhase.GAME_OVER && turns < 8000) {
                turns++
                when (s.phase) {
                    TurnPhase.AWAITING_ROLL -> e.rollDice()
                    TurnPhase.AWAITING_MOVE -> {
                        val moves = e.legalMoves()
                        if (moves.isEmpty()) e.passTurn()
                        else {
                            val result = e.applyMove(moves.random())
                            if (result.arrow != null) {
                                assertNotNull(result.arrowFromSteps)
                                assertNotNull(result.arrowToSteps)
                            }
                        }
                    }
                    TurnPhase.GAME_OVER -> Unit
                }
                for (p in s.players) {
                    for (t in p.tokens) {
                        assertTrue("a piece left its route", t.steps in 0..LudoEngine.FINISH_STEPS)
                    }
                }
            }
            assertEquals("an arrow game never ended", TurnPhase.GAME_OVER, s.phase)
        }
    }
}
