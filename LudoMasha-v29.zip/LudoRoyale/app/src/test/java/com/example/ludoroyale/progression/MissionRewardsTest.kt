package com.example.ludoroyale.progression

import com.example.ludoroyale.cosmetics.CosmeticType
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.UnlockMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * THE MISSION TRACK
 *
 * Every dice, token, avatar and frame worth having is earned here and nowhere
 * else — there is no price on any of them any more. That makes this the single
 * route to the whole collection, so the things that matter are: the track and
 * the catalog agree with each other, a rung can never be reached twice or
 * skipped, and nothing a player has earned can be taken back.
 */
class MissionRewardsTest {

    // ------------------------------------------------- it agrees with itself

    @Test
    fun `the track and the catalog name the same items`() {
        assertTrue("the mission track and the catalog have drifted apart",
                   MissionRewards.isSane())
    }

    @Test
    fun `every rung names a real cosmetic`() {
        for (step in MissionRewards.TRACK) {
            assertNotNull("${step.cosmeticId} is promised but does not exist", step.item)
        }
    }

    @Test
    fun `the rungs climb, and no two share a number`() {
        var last = 0
        for (step in MissionRewards.TRACK) {
            assertTrue("rung ${step.missionsDone} is out of order", step.missionsDone > last)
            last = step.missionsDone
        }
    }

    @Test
    fun `nothing is promised twice`() {
        val ids = MissionRewards.TRACK.map { it.cosmeticId }
        assertEquals("an item appears on the track more than once", ids.size, ids.toSet().size)
    }

    @Test
    fun `the first reward is within reach of a first day`() {
        val first = MissionRewards.TRACK.first()
        assertTrue("a new player sees nothing for too long", first.missionsDone <= 2)
    }

    // ------------------------------------------ what a given player is owed

    @Test
    fun `a player who has done nothing is owed nothing`() {
        assertTrue(MissionRewards.unlockedAt(0).isEmpty())
    }

    @Test
    fun `finishing the whole track owes the whole track`() {
        val last = MissionRewards.TRACK.last().missionsDone
        assertEquals(MissionRewards.TRACK.size, MissionRewards.unlockedAt(last).size)
        assertEquals(MissionRewards.TRACK.size, MissionRewards.unlockedAt(last + 500).size)
    }

    @Test
    fun `what is owed only ever grows`() {
        var previous = 0
        for (total in 0..120) {
            val owed = MissionRewards.unlockedAt(total).size
            assertTrue("a reward was taken away between $total and the step before",
                       owed >= previous)
            previous = owed
        }
    }

    // ---------------------------------------------- what crossing over gives

    @Test
    fun `crossing a rung hands over exactly that rung`() {
        val rung = MissionRewards.TRACK.first()
        val earned = MissionRewards.earnedBetween(rung.missionsDone - 1, rung.missionsDone)
        assertEquals(1, earned.size)
        assertEquals(rung.cosmeticId, earned.first().cosmeticId)
    }

    @Test
    fun `standing still hands over nothing`() {
        assertTrue(MissionRewards.earnedBetween(10, 10).isEmpty())
        assertTrue(MissionRewards.earnedBetween(10, 4).isEmpty())
    }

    @Test
    fun `a big jump hands over everything it passed`() {
        val last = MissionRewards.TRACK.last().missionsDone
        val earned = MissionRewards.earnedBetween(0, last)
        assertEquals("a player who jumped the whole way was short-changed",
                     MissionRewards.TRACK.size, earned.size)
    }

    @Test
    fun `walking the track one mission at a time gives each item exactly once`() {
        val seen = mutableListOf<String>()
        val last = MissionRewards.TRACK.last().missionsDone
        for (n in 1..last) {
            seen += MissionRewards.earnedBetween(n - 1, n).map { it.cosmeticId }
        }
        assertEquals("an item was handed out twice, or not at all",
                     MissionRewards.TRACK.size, seen.size)
        assertEquals(seen.size, seen.toSet().size)
        assertEquals(MissionRewards.TRACK.map { it.cosmeticId }, seen)
    }

    // ------------------------------------------------------ what comes next

    @Test
    fun `the next rung is always ahead, never behind`() {
        for (total in 0..90) {
            val next = MissionRewards.next(total) ?: continue
            assertTrue("the next reward was one already earned", next.missionsDone > total)
        }
    }

    @Test
    fun `there is nothing next once the track is done`() {
        assertNull(MissionRewards.next(MissionRewards.TRACK.last().missionsDone))
    }

    @Test
    fun `progress runs from nothing to everything and stays in range`() {
        assertEquals(0f, MissionRewards.progress(0), 0.0001f)
        assertEquals(1f, MissionRewards.progress(MissionRewards.TRACK.last().missionsDone), 0.0001f)
        assertEquals(1f, MissionRewards.progress(9999), 0.0001f)
        for (n in 0..200) {
            val p = MissionRewards.progress(n)
            assertTrue(p in 0f..1f)
        }
    }

    // ----------------------------------------- the collection is reachable

    @Test
    fun `every mission item says which rung earns it`() {
        for (item in Cosmetics.ALL.filter { it.unlock == UnlockMethod.MISSION }) {
            assertNotNull("${item.id} is earned by missions but is on no rung",
                          MissionRewards.requiredFor(item.id))
        }
    }

    @Test
    fun `everything in the catalog can actually be got`() {
        for (item in Cosmetics.ALL) {
            val reachable = when (item.unlock) {
                UnlockMethod.FREE -> true
                UnlockMethod.LEVEL -> item.requiredLevel in 1..Progression.MAX_LEVEL
                UnlockMethod.MISSION -> MissionRewards.requiredFor(item.id) != null
                UnlockMethod.COINS -> item.price > 0
                UnlockMethod.DAILY -> DailyRewards.CYCLE.any { it.cosmeticId == item.id } ||
                    MysteryChest.POOL.any { it.first == item.id }
                UnlockMethod.CHEST -> MysteryChest.POOL.any { it.first == item.id }
            }
            assertTrue("${item.id} cannot be obtained by any route", reachable)
        }
    }

    @Test
    fun `nothing in the catalog is sold for coins any more`() {
        // The owner asked for the collection to be earned, not bought. If a
        // price ever creeps back in, this is where it gets caught.
        val priced = Cosmetics.ALL.filter { it.unlock == UnlockMethod.COINS }
        assertTrue("these are back on sale: ${priced.map { it.id }}", priced.isEmpty())
    }

    @Test
    fun `every kind of cosmetic has something on the track`() {
        val onTrack = MissionRewards.TRACK.mapNotNull { it.item?.type }.toSet()
        for (type in listOf(
            CosmeticType.DICE_SKIN, CosmeticType.TOKEN_SKIN,
            CosmeticType.AVATAR, CosmeticType.AVATAR_FRAME
        )) {
            assertTrue("$type has nothing to earn on the mission track", type in onTrack)
        }
    }

    @Test
    fun `the dice collection is the twelve picture dice and nothing else`() {
        val dice = Cosmetics.byType(CosmeticType.DICE_SKIN)
        assertEquals("the dice collection is not twelve", 12, dice.size)
        assertTrue("a dice that is not one of the pictures is still in the game",
                   dice.all { it.id.startsWith("dx_") })
        assertEquals("exactly one dice should be free to start with",
                     1, dice.count { it.unlock == UnlockMethod.FREE })
        assertFalse("the free dice is not the one a new player is given",
                    Cosmetics.byId(Cosmetics.defaultFor(CosmeticType.DICE_SKIN))?.unlock
                        != UnlockMethod.FREE)
    }
}
