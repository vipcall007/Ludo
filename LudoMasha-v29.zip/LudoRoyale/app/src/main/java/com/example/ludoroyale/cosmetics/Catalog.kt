package com.example.ludoroyale.cosmetics

/**
 * What kind of thing a cosmetic is.
 *
 * Every one of these changes how something LOOKS and nothing else. There is no
 * cosmetic type for dice odds, movement or board rules, because no such thing
 * is allowed to exist in this game.
 */
enum class CosmeticType(val display: String) {
    TOKEN_SKIN("TOKEN"),
    DICE_SKIN("DICE"),
    AVATAR("AVATAR"),
    AVATAR_FRAME("FRAME"),
    VICTORY_EFFECT("VICTORY")
}

enum class Rarity(val display: String) {
    COMMON("COMMON"),
    RARE("RARE"),
    EPIC("EPIC"),
    LEGENDARY("LEGENDARY")
}

/** How an item is come by. */
enum class UnlockMethod {
    /** Owned from the first launch. */
    FREE,
    /** Bought with coins earned by playing. */
    COINS,
    /** Given on reaching a player level. */
    LEVEL,
    /** Given by the daily login cycle. */
    DAILY,
    /** Given for finishing missions. */
    MISSION,
    /** Found in a chest earned by playing. */
    CHEST
}

/**
 * One collectable.
 *
 * This is the single source of truth for what exists, what it costs and how it
 * is come by. The drawing code keys off [id] for its colours, so a cosmetic can
 * be re-priced or re-classified without touching a line of rendering, and no
 * Activity has to carry its own copy of the list.
 */
data class CosmeticItem(
    val id: String,
    val name: String,
    val type: CosmeticType,
    val rarity: Rarity,
    val unlock: UnlockMethod,
    /** Coins, when [unlock] is COINS. Otherwise 0. */
    val price: Int = 0,
    /** Player level required, when [unlock] is LEVEL. Otherwise 0. */
    val requiredLevel: Int = 0
) {
    /** What a duplicate is worth when a chest turns one up again. */
    val dustValue: Int
        get() = when (rarity) {
            Rarity.COMMON -> 40
            Rarity.RARE -> 90
            Rarity.EPIC -> 180
            Rarity.LEGENDARY -> 350
        }
}

/**
 * The whole collection.
 *
 * FAIRNESS: nothing in this catalog is consulted by the rules engine, the dice
 * or the computer players. A Legendary dragon token moves exactly as far as the
 * free one, and a Legendary dice rolls exactly the same numbers.
 */
object Cosmetics {

    // ---------------------------------------------------------- token skins

    const val TOKEN_CLASSIC = "tok_classic"
    const val TOKEN_GOLDEN = "tok_golden"
    const val TOKEN_DIAMOND = "tok_diamond"
    const val TOKEN_FIRE = "tok_fire"
    const val TOKEN_ICE = "tok_ice"
    const val TOKEN_ROYAL = "tok_royal"
    const val TOKEN_LIGHTNING = "tok_lightning"
    const val TOKEN_RAINBOW = "tok_rainbow"
    const val TOKEN_DRAGON = "tok_dragon"

    // ----------------------------------------------------------- dice skins
    //
    // THE ONLY DICE IN THE GAME ARE THE TWELVE PICTURE DICE.
    //
    // The nineteen drawn dice that earlier builds had — flat coloured cubes
    // with painted pips — were removed on the owner's instruction. Their
    // drawing code still lives in DiceSkins, so bringing one back is a matter
    // of adding a line here again, but nothing in the game offers them.
    //
    // Their artwork lives in DiceFaceArt as six real pictures per dice, and
    // their ids keep the "dx_" prefix so a picture dice can never be mistaken
    // for anything else.

    const val DX_HEART = "dx_heart"
    const val DX_GHOST = "dx_ghost"
    const val DX_GIFT = "dx_gift"
    const val DX_ROBOT = "dx_robot"
    const val DX_ALIEN = "dx_alien"
    const val DX_WYRM = "dx_wyrm"
    const val DX_STAR = "dx_star"
    const val DX_COSMOS = "dx_cosmos"
    const val DX_EIGHT = "dx_eight"
    const val DX_RUBY = "dx_ruby"
    const val DX_KING = "dx_king"
    const val DX_ROYALS = "dx_royals"

    // ------------------------------------------------------------- avatars

    const val AVATAR_P1 = "av_p1"
    const val AVATAR_P2 = "av_p2"
    const val AVATAR_P3 = "av_p3"
    const val AVATAR_P4 = "av_p4"
    const val AVATAR_CROWN = "av_crown"
    const val AVATAR_KNIGHT = "av_knight"
    const val AVATAR_SULTAN = "av_sultan"
    const val AVATAR_WIZARD = "av_wizard"
    const val AVATAR_PHARAOH = "av_pharaoh"
    const val AVATAR_JOKER = "av_joker"

    /**
     * The player's own photograph.
     *
     * This one is not a drawing: choosing it opens the phone's picture
     * chooser, and what the player crops is kept on this phone and shown
     * here. It is free and always owned, because it is their own face.
     */
    const val AVATAR_PHOTO = "av_photo"

    // -------------------------------------------------------------- frames

    const val FRAME_NONE = "fr_none"
    const val FRAME_BRONZE = "fr_bronze"
    const val FRAME_SILVER = "fr_silver"
    const val FRAME_GOLD = "fr_gold"
    const val FRAME_DIAMOND = "fr_diamond"
    const val FRAME_ROYAL = "fr_royal"
    const val FRAME_LEGENDARY = "fr_legendary"
    const val FRAME_EMERALD = "fr_emerald"
    const val FRAME_MAGIC = "fr_magic"
    const val FRAME_FLAME = "fr_flame"
    const val FRAME_PEACOCK = "fr_peacock"
    const val FRAME_OBSIDIAN = "fr_obsidian"

    // ----------------------------------------------------- victory effects

    const val FX_CONFETTI = "fx_confetti"
    const val FX_GOLD_RAIN = "fx_gold_rain"
    const val FX_FIREWORKS = "fx_fireworks"
    const val FX_ROYAL_CROWN = "fx_royal_crown"

    val ALL: List<CosmeticItem> = listOf(
        // ---- token skins
        item(TOKEN_CLASSIC, "Classic", CosmeticType.TOKEN_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(TOKEN_GOLDEN, "Golden Token", CosmeticType.TOKEN_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(TOKEN_ICE, "Ice Token", CosmeticType.TOKEN_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(TOKEN_FIRE, "Fire Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(TOKEN_ROYAL, "Royal Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 10),
        item(TOKEN_LIGHTNING, "Lightning Token", CosmeticType.TOKEN_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(TOKEN_DIAMOND, "Diamond Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 20),
        item(TOKEN_RAINBOW, "Rainbow Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.CHEST),
        item(TOKEN_DRAGON, "Dragon Token", CosmeticType.TOKEN_SKIN, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 30),

        // ---- the twelve picture dice: the whole dice collection.
        // One is free so a new player is never without a dice; the rest are
        // earned on the mission track and cannot be bought at any price.
        item(DX_GIFT, "Gift Box", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(DX_HEART, "Burning Heart", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(DX_GHOST, "Ghost Charm", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(DX_STAR, "Starburst", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(DX_ROBOT, "Robo", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DX_ALIEN, "Alien", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DX_EIGHT, "Eight Ball", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DX_COSMOS, "Cosmos", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DX_RUBY, "Ruby Crown", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(DX_WYRM, "Wyrm", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(DX_KING, "The King", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(DX_ROYALS, "King & Queen", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),

        // ---- avatars
        item(AVATAR_PHOTO, "My Photo", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P1, "Player One", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P2, "Player Two", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P3, "Player Three", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_P4, "Player Four", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AVATAR_KNIGHT, "Knight", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.MISSION),
        item(AVATAR_SULTAN, "Sultan", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.MISSION),
        item(AVATAR_WIZARD, "Wizard", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.MISSION),
        item(AVATAR_CROWN, "Crowned", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 10),
        item(AVATAR_PHARAOH, "Pharaoh", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(AVATAR_JOKER, "Court Jester", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.MISSION),

        // ---- avatar frames
        item(FRAME_NONE, "No Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FRAME_BRONZE, "Bronze Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FRAME_SILVER, "Silver Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.LEVEL, requiredLevel = 5),
        item(FRAME_EMERALD, "Emerald Frame", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.MISSION),
        item(FRAME_GOLD, "Gold Frame", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.DAILY),
        item(FRAME_MAGIC, "Magic Frame", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.MISSION),
        item(FRAME_FLAME, "Flame Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.MISSION),
        item(FRAME_DIAMOND, "Diamond Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 20),
        item(FRAME_PEACOCK, "Peacock Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.MISSION),
        item(FRAME_ROYAL, "Royal Frame", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.MISSION),
        item(FRAME_OBSIDIAN, "Obsidian Frame", CosmeticType.AVATAR_FRAME, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(FRAME_LEGENDARY, "Legendary Frame", CosmeticType.AVATAR_FRAME, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 30),

        // ---- victory effects
        item(FX_CONFETTI, "Confetti", CosmeticType.VICTORY_EFFECT, Rarity.COMMON, UnlockMethod.FREE),
        item(FX_GOLD_RAIN, "Gold Rain", CosmeticType.VICTORY_EFFECT, Rarity.RARE, UnlockMethod.DAILY),
        item(FX_FIREWORKS, "Fireworks", CosmeticType.VICTORY_EFFECT, Rarity.EPIC, UnlockMethod.MISSION),
        item(FX_ROYAL_CROWN, "Royal Crown", CosmeticType.VICTORY_EFFECT, Rarity.LEGENDARY, UnlockMethod.CHEST)
    )

    private fun item(
        id: String, name: String, type: CosmeticType, rarity: Rarity,
        unlock: UnlockMethod, price: Int = 0, requiredLevel: Int = 0
    ) = CosmeticItem(id, name, type, rarity, unlock, price, requiredLevel)

    fun byId(id: String): CosmeticItem? = ALL.firstOrNull { it.id == id }

    fun byType(type: CosmeticType): List<CosmeticItem> = ALL.filter { it.type == type }

    /** Owned from the first launch, whatever else happens. */
    fun free(): List<String> = ALL.filter { it.unlock == UnlockMethod.FREE }.map { it.id }

    /** What a brand-new player has selected. */
    fun defaultFor(type: CosmeticType): String = when (type) {
        CosmeticType.TOKEN_SKIN -> TOKEN_CLASSIC
        CosmeticType.DICE_SKIN -> DX_GIFT
        CosmeticType.AVATAR -> AVATAR_P1
        CosmeticType.AVATAR_FRAME -> FRAME_BRONZE
        CosmeticType.VICTORY_EFFECT -> FX_CONFETTI
    }

    /** Everything a player is owed for standing at [level]. */
    fun unlockedAtLevel(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel in 1..level }

    /** Everything handed out exactly on reaching [level]. */
    fun unlockedOnReaching(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel == level }

    /** Every id must be unique, or ownership would be ambiguous. */
    fun isSane(): Boolean {
        val ids = ALL.map { it.id }
        if (ids.size != ids.toSet().size) return false
        if (ALL.any { it.unlock == UnlockMethod.COINS && it.price <= 0 }) return false
        if (ALL.any { it.unlock == UnlockMethod.LEVEL && it.requiredLevel <= 0 }) return false
        if (ALL.any { it.unlock != UnlockMethod.COINS && it.price != 0 }) return false
        // every type must have something a new player already owns
        return CosmeticType.entries.all { type ->
            byType(type).any { it.unlock == UnlockMethod.FREE }
        }
    }
}
