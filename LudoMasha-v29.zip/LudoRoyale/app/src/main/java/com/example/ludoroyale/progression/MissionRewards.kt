package com.example.ludoroyale.progression

import com.example.ludoroyale.cosmetics.CosmeticItem
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.UnlockMethod

/** One rung of the mission track: finish [missionsDone] missions, get [cosmeticId]. */
data class MissionMilestone(val missionsDone: Int, val cosmeticId: String) {
    val item: CosmeticItem? get() = Cosmetics.byId(cosmeticId)
}

/**
 * THE MISSION TRACK — how dice, tokens, avatars and frames are come by.
 *
 * Everything showy in this game is earned by playing, not bought. The player
 * finishes daily missions; the count of missions they have ever finished only
 * ever goes up; and each rung of this track hands over one item when that
 * count passes it.
 *
 * WHY A RUNNING TOTAL RATHER THAN A PRICE
 *
 * A price means the same item can be had twice as fast by playing twice as
 * long in one day, and it means a player who has nothing has no route at all.
 * A running total cannot be rushed and cannot be missed: every mission the
 * player has ever finished still counts, whatever else has happened since, so
 * the track never resets and an item once earned is never taken back.
 *
 * FAIRNESS: every item on this track is a picture. Nothing here touches the
 * dice odds, the rules or the computer players — a Legendary dice rolls the
 * same numbers as the free one.
 */
object MissionRewards {

    /**
     * The rungs, in order.
     *
     * The first few come quickly so a new player sees the track working within
     * a day or two; the later ones stretch out so the Legendary pieces stay
     * worth having. Nothing is ever removed from this list — removing a rung
     * would take an item away from a player who had already earned it.
     */
    val TRACK: List<MissionMilestone> = listOf(
        // ---- the first week or so: something new almost every day
        MissionMilestone(1, Cosmetics.DX_HEART),
        MissionMilestone(2, Cosmetics.FRAME_EMERALD),
        MissionMilestone(3, Cosmetics.TOKEN_GOLDEN),
        MissionMilestone(4, Cosmetics.DX_GHOST),
        MissionMilestone(5, Cosmetics.AVATAR_KNIGHT),
        MissionMilestone(6, Cosmetics.DX_STAR),
        MissionMilestone(8, Cosmetics.TOKEN_ICE),
        MissionMilestone(10, Cosmetics.FRAME_MAGIC),

        // ---- settling into a habit
        MissionMilestone(12, Cosmetics.DX_ROBOT),
        MissionMilestone(14, Cosmetics.AVATAR_SULTAN),
        MissionMilestone(16, Cosmetics.TOKEN_FIRE),
        MissionMilestone(18, Cosmetics.DX_ALIEN),
        MissionMilestone(20, Cosmetics.FRAME_FLAME),
        MissionMilestone(23, Cosmetics.AVATAR_WIZARD),
        MissionMilestone(26, Cosmetics.DX_EIGHT),
        MissionMilestone(29, Cosmetics.FX_FIREWORKS),

        // ---- the long haul
        MissionMilestone(32, Cosmetics.TOKEN_LIGHTNING),
        MissionMilestone(36, Cosmetics.DX_COSMOS),
        MissionMilestone(40, Cosmetics.FRAME_PEACOCK),
        MissionMilestone(44, Cosmetics.AVATAR_PHARAOH),
        MissionMilestone(48, Cosmetics.DX_RUBY),
        MissionMilestone(52, Cosmetics.FRAME_ROYAL),
        MissionMilestone(57, Cosmetics.AVATAR_JOKER),
        MissionMilestone(62, Cosmetics.DX_WYRM),
        MissionMilestone(68, Cosmetics.FRAME_OBSIDIAN),
        MissionMilestone(74, Cosmetics.DX_KING),
        MissionMilestone(80, Cosmetics.DX_ROYALS)
    )

    /** Every item owed to somebody who has finished [total] missions in all. */
    fun unlockedAt(total: Int): List<String> =
        TRACK.filter { it.missionsDone <= total }.map { it.cosmeticId }

    /**
     * What crossing from [before] to [after] hands over, so the game can show
     * it once, at the moment it happens.
     */
    fun earnedBetween(before: Int, after: Int): List<MissionMilestone> {
        if (after <= before) return emptyList()
        return TRACK.filter { it.missionsDone in (before + 1)..after }
    }

    /** The next rung, or null once the whole track is done. */
    fun next(total: Int): MissionMilestone? =
        TRACK.firstOrNull { it.missionsDone > total }

    /** How many missions still to go for [cosmeticId], or null if it is not on the track. */
    fun requiredFor(cosmeticId: String): Int? =
        TRACK.firstOrNull { it.cosmeticId == cosmeticId }?.missionsDone

    /** How far along the whole track somebody is, 0f..1f. */
    fun progress(total: Int): Float {
        val last = TRACK.lastOrNull()?.missionsDone ?: return 1f
        return (total.toFloat() / last).coerceIn(0f, 1f)
    }

    /**
     * The track has to line up with the catalog or somebody is promised an item
     * that does not exist, or owns one there is no way to earn.
     */
    fun isSane(): Boolean {
        // ascending, no rung shared by two items
        val steps = TRACK.map { it.missionsDone }
        if (steps != steps.sorted() || steps.size != steps.toSet().size) return false
        if (steps.any { it < 1 }) return false

        // every rung names a real cosmetic, and never the same one twice
        val ids = TRACK.map { it.cosmeticId }
        if (ids.size != ids.toSet().size) return false
        if (ids.any { Cosmetics.byId(it) == null }) return false

        // and the two lists agree about which items are earned this way
        val claimed = ids.toSet()
        val declared = Cosmetics.ALL
            .filter { it.unlock == UnlockMethod.MISSION }
            .map { it.id }
            .toSet()
        return claimed == declared
    }
}
