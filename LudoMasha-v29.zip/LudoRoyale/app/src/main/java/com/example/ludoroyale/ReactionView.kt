package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** The faces that can appear when somebody's piece gets sent home. */
enum class TauntFace { LAUGHING, DIZZY, TONGUE, SMUG, SHOCKED }

/**
 * The face that pops up when a piece is cut.
 *
 * DRAWN, NOT TYPED
 *
 * The obvious way to do this is a TextView with an emoji in it. The trouble is
 * that the emoji a phone draws is the phone's, not the game's: the same laugh
 * is yellow and round on one handset, flat and grey on another, and missing
 * altogether on an old one, where it comes out as an empty box. So the faces
 * are drawn here, the same way everything else in this game is drawn, and they
 * look the same on every phone it runs on.
 *
 * It is meant to be funny, not cruel, so it is big, quick and gone: it springs
 * in, wobbles once, and fades within a second. The board is never blocked —
 * this view does not take touches.
 */
class ReactionView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var face: TauntFace? = null
    private var startedAt = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        // it is a decoration; it must never eat a tap meant for the board
        isClickable = false
        isFocusable = false
        visibility = GONE
    }

    /** Shows a face, chosen at random so the same joke is not told twice running. */
    fun pop(which: TauntFace = TauntFace.entries.random()) {
        face = which
        startedAt = System.currentTimeMillis()
        visibility = VISIBLE
        alpha = 1f
        removeCallbacks(ticker)
        post(ticker)
    }

    fun clear() {
        removeCallbacks(ticker)
        face = null
        visibility = GONE
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (face == null) return
            val age = System.currentTimeMillis() - startedAt
            if (age >= LIFE_MS) {
                clear()
                return
            }
            invalidate()
            postDelayed(this, 16)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(ticker)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val which = face ?: return
        val age = (System.currentTimeMillis() - startedAt).toFloat()
        val life = age / LIFE_MS

        val side = min(width, height).toFloat()
        if (side <= 0f) return
        val cx = width / 2f
        val cy = height / 2f

        // springs in over the first fifth, holds, then fades out at the end
        val grow = (age / 160f).coerceAtMost(1f)
        val overshoot = 1f + 0.22f * sin(grow * Math.PI).toFloat()
        val fade = if (life > 0.75f) 1f - (life - 0.75f) / 0.25f else 1f
        val tilt = 9f * sin(age / 90f).toFloat() * (1f - life)

        val r = side * 0.30f * grow * overshoot
        if (r <= 1f) return

        canvas.save()
        canvas.rotate(tilt, cx, cy)
        val a = (255 * fade).toInt().coerceIn(0, 255)

        // a soft halo so the face reads over a busy board
        glow.shader = RadialGradient(
            cx, cy, r * 1.9f,
            intArrayOf(Color.argb((a * 0.45f).toInt(), 0, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.9f, glow)
        glow.shader = null

        // the head
        fill.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.35f, r * 1.5f,
            intArrayOf(Color.rgb(0xFF, 0xE9, 0x8A), Color.rgb(0xF2, 0xB5, 0x14)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        fill.alpha = a
        canvas.drawCircle(cx, cy, r, fill)
        fill.shader = null
        fill.alpha = 255

        stroke.color = Color.argb(a, 0x8A, 0x5B, 0x00)
        stroke.strokeWidth = r * 0.07f
        canvas.drawCircle(cx, cy, r, stroke)

        val ink = Color.argb(a, 0x2A, 0x1C, 0x06)
        when (which) {
            TauntFace.LAUGHING -> drawLaughing(canvas, cx, cy, r, ink, a)
            TauntFace.DIZZY -> drawDizzy(canvas, cx, cy, r, ink)
            TauntFace.TONGUE -> drawTongue(canvas, cx, cy, r, ink, a)
            TauntFace.SMUG -> drawSmug(canvas, cx, cy, r, ink)
            TauntFace.SHOCKED -> drawShocked(canvas, cx, cy, r, ink, a)
        }
        canvas.restore()
    }

    // ------------------------------------------------------------- the faces

    private fun drawLaughing(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        // eyes squeezed shut into two arcs
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        for (s in intArrayOf(-1, 1)) {
            canvas.drawArc(
                RectF(cx + s * r * 0.36f - r * 0.20f, cy - r * 0.34f,
                      cx + s * r * 0.36f + r * 0.20f, cy - r * 0.02f),
                200f, 140f, false, stroke
            )
        }
        // a wide open laugh
        fill.color = ink
        val mouth = Path()
        mouth.addArc(RectF(cx - r * 0.44f, cy - r * 0.02f, cx + r * 0.44f, cy + r * 0.66f), 0f, 180f)
        mouth.close()
        canvas.drawPath(mouth, fill)
        fill.color = Color.argb(a, 0xFF, 0x7A, 0x8A)
        canvas.drawArc(
            RectF(cx - r * 0.20f, cy + r * 0.16f, cx + r * 0.20f, cy + r * 0.58f),
            0f, 180f, true, fill
        )
        // two tears of laughter
        fill.color = Color.argb(a, 0x5E, 0xC8, 0xFF)
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.66f, cy - r * 0.02f, r * 0.10f, fill)
        }
    }

    private fun drawDizzy(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int) {
        stroke.color = ink
        stroke.strokeWidth = r * 0.10f
        // crossed-out eyes
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * r * 0.34f
            val ey = cy - r * 0.16f
            val d = r * 0.15f
            canvas.drawLine(ex - d, ey - d, ex + d, ey + d, stroke)
            canvas.drawLine(ex - d, ey + d, ex + d, ey - d, stroke)
        }
        // a wavy mouth
        stroke.strokeWidth = r * 0.09f
        val m = Path()
        m.moveTo(cx - r * 0.36f, cy + r * 0.38f)
        m.quadTo(cx - r * 0.18f, cy + r * 0.20f, cx, cy + r * 0.38f)
        m.quadTo(cx + r * 0.18f, cy + r * 0.56f, cx + r * 0.36f, cy + r * 0.38f)
        canvas.drawPath(m, stroke)
    }

    private fun drawTongue(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        // one eye winking
        fill.color = ink
        canvas.drawCircle(cx - r * 0.34f, cy - r * 0.16f, r * 0.10f, fill)
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        canvas.drawArc(
            RectF(cx + r * 0.16f, cy - r * 0.32f, cx + r * 0.54f, cy),
            200f, 140f, false, stroke
        )
        // and a tongue out
        stroke.strokeWidth = r * 0.08f
        canvas.drawArc(
            RectF(cx - r * 0.34f, cy + r * 0.06f, cx + r * 0.34f, cy + r * 0.48f),
            10f, 160f, false, stroke
        )
        fill.color = Color.argb(a, 0xFF, 0x6E, 0x86)
        canvas.drawRoundRect(
            RectF(cx - r * 0.14f, cy + r * 0.28f, cx + r * 0.14f, cy + r * 0.66f),
            r * 0.14f, r * 0.14f, fill
        )
    }

    private fun drawSmug(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int) {
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        // half-closed, pleased-with-itself eyes
        for (s in intArrayOf(-1, 1)) {
            canvas.drawLine(
                cx + s * r * 0.50f, cy - r * 0.20f,
                cx + s * r * 0.18f, cy - r * 0.16f, stroke
            )
        }
        fill.color = ink
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.02f, r * 0.08f, fill)
        }
        // a one-sided smirk
        val m = Path()
        m.moveTo(cx - r * 0.30f, cy + r * 0.32f)
        m.quadTo(cx + r * 0.10f, cy + r * 0.52f, cx + r * 0.42f, cy + r * 0.18f)
        canvas.drawPath(m, stroke)
    }

    private fun drawShocked(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        fill.color = Color.argb(a, 0xFF, 0xFF, 0xFF)
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.16f, r * 0.17f, fill)
        }
        fill.color = ink
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.16f, r * 0.08f, fill)
        }
        // a round, open mouth
        fill.color = ink
        canvas.drawOval(RectF(cx - r * 0.20f, cy + r * 0.14f, cx + r * 0.20f, cy + r * 0.62f), fill)
        // and a sweat drop
        fill.color = Color.argb(a, 0x5E, 0xC8, 0xFF)
        val drop = Path()
        drop.moveTo(cx + r * 0.72f, cy - r * 0.46f)
        drop.quadTo(cx + r * 0.90f, cy - r * 0.10f, cx + r * 0.72f, cy - r * 0.04f)
        drop.quadTo(cx + r * 0.54f, cy - r * 0.10f, cx + r * 0.72f, cy - r * 0.46f)
        drop.close()
        canvas.drawPath(drop, fill)
    }

    private companion object {
        const val LIFE_MS = 1150f
    }
}

/**
 * The padlock that holds HOME shut in Quick mode, and the moment it opens.
 *
 * WHAT THIS IS INSTEAD OF
 *
 * The brief asked for a 3D picture of a lock opening. There is no way to draw
 * a rendered picture here, so the lock is built out of shapes and lit as a
 * solid object instead: the body has a highlight down one side and a shadow
 * down the other, the shackle is a thick ring with its own light on top, and
 * the whole thing turns slightly as it opens so it reads as an object in space
 * rather than a flat badge. It is not a render, and it is not pretending to be
 * one; it is honest metal drawn in code, and it is sharp at any size.
 *
 * EVERY PLAYER HAS THEIR OWN
 *
 * The lock belongs to one player. In Quick mode each player's HOME is locked
 * until THAT player cuts somebody, so this opens for whoever made the cut and
 * for nobody else — the engine already keeps the flag per player, and this
 * only ever shows what it is told to show.
 */
class LockBurstView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var startedAt = 0L
    private var running = false

    /** The colour of the player whose lock this is. */
    var accent: Int = Color.rgb(0xF2, 0xC1, 0x4E)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = false
        isFocusable = false
        visibility = GONE
    }

    fun play(color: Int) {
        accent = color
        startedAt = System.currentTimeMillis()
        running = true
        visibility = VISIBLE
        removeCallbacks(ticker)
        post(ticker)
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            if (System.currentTimeMillis() - startedAt >= LIFE_MS) {
                running = false
                visibility = GONE
                return
            }
            invalidate()
            postDelayed(this, 16)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(ticker)
        running = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running) return
        val age = (System.currentTimeMillis() - startedAt).toFloat()
        val life = (age / LIFE_MS).coerceIn(0f, 1f)

        val side = min(width, height).toFloat()
        if (side <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        val s = side * 0.26f

        // the three beats: it arrives, the shackle springs, it fades away
        val arrive = (age / 180f).coerceAtMost(1f)
        val open = ((age - 240f) / 340f).coerceIn(0f, 1f)
        val fade = if (life > 0.78f) 1f - (life - 0.78f) / 0.22f else 1f
        val a = (255 * fade).toInt().coerceIn(0, 255)

        // eased so the shackle flicks up rather than sliding
        val sprung = 1f - (1f - open) * (1f - open)

        canvas.save()
        canvas.translate(cx, cy)
        // a slight turn: enough to read as an object, not enough to be dizzying
        canvas.rotate(-10f * sprung)
        canvas.scale(arrive * (1f + 0.10f * sprung), arrive * (1f + 0.10f * sprung))

        // the light that comes out of it
        if (open > 0f) {
            glow.shader = RadialGradient(
                0f, 0f, s * (2.2f + 1.6f * sprung),
                intArrayOf(
                    Color.argb((a * 0.55f * (1f - open * 0.5f)).toInt(), 255, 236, 170),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, s * (2.2f + 1.6f * sprung), glow)
            glow.shader = null

            // and the rays
            stroke.color = Color.argb((a * 0.7f * (1f - open)).toInt(), 255, 240, 190)
            stroke.strokeWidth = s * 0.10f
            for (i in 0 until 8) {
                val ang = Math.PI * 2 * i / 8
                val from = s * (1.5f + 1.1f * sprung)
                val to = from + s * 0.5f
                canvas.drawLine(
                    (cos(ang) * from).toFloat(), (sin(ang) * from).toFloat(),
                    (cos(ang) * to).toFloat(), (sin(ang) * to).toFloat(), stroke
                )
            }
        }

        drawShackle(canvas, s, sprung, a)
        drawBody(canvas, s, a, open)

        canvas.restore()
    }

    /** The loop. It swings up and tips over to one side as it lets go. */
    private fun drawShackle(canvas: Canvas, s: Float, sprung: Float, a: Int) {
        canvas.save()
        canvas.translate(0f, -s * 0.62f - s * 0.50f * sprung)
        canvas.rotate(26f * sprung, -s * 0.52f, 0f)

        stroke.strokeWidth = s * 0.30f
        // the shaded back of the loop
        stroke.color = Color.argb(a, 0x6E, 0x7C, 0x92)
        canvas.drawArc(
            RectF(-s * 0.52f, -s * 0.52f, s * 0.52f, s * 0.52f), 180f, 180f, false, stroke
        )
        // and the lit front of it
        stroke.strokeWidth = s * 0.13f
        stroke.color = Color.argb(a, 0xDE, 0xE8, 0xF6)
        canvas.drawArc(
            RectF(-s * 0.52f, -s * 0.56f, s * 0.52f, s * 0.48f), 195f, 100f, false, stroke
        )
        canvas.restore()
    }

    /** The body, lit from the left so it sits as a solid block. */
    private fun drawBody(canvas: Canvas, s: Float, a: Int, open: Float) {
        val body = RectF(-s, -s * 0.30f, s, s * 1.05f)
        val corner = s * 0.26f

        fill.shader = android.graphics.LinearGradient(
            body.left, body.top, body.right, body.bottom,
            intArrayOf(
                Color.rgb(0xFF, 0xEE, 0xB4),
                lighten(accent, 0.15f),
                darken(accent, 0.45f)
            ),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        fill.alpha = a
        canvas.drawRoundRect(body, corner, corner, fill)
        fill.shader = null
        fill.alpha = 255

        stroke.color = Color.argb(a, 0x6B, 0x45, 0x04)
        stroke.strokeWidth = s * 0.08f
        canvas.drawRoundRect(body, corner, corner, stroke)

        // the keyhole: round on top, a wedge below, and it widens as it opens
        fill.color = Color.argb(a, 0x2A, 0x1C, 0x06)
        val kr = s * (0.20f + 0.05f * open)
        canvas.drawCircle(0f, s * 0.24f, kr, fill)
        val slot = Path()
        slot.moveTo(-kr * 0.55f, s * 0.30f)
        slot.lineTo(kr * 0.55f, s * 0.30f)
        slot.lineTo(kr * 0.85f, s * 0.80f)
        slot.lineTo(-kr * 0.85f, s * 0.80f)
        slot.close()
        canvas.drawPath(slot, fill)
    }

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    private companion object {
        const val LIFE_MS = 1450f
    }
}
