package com.example.ludoroyale

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import kotlin.math.min

/**
 * A player's picture, the frame round it, and their turn clock — all one view.
 *
 * SQUARE, NOT ROUND
 *
 * The portrait is a rounded square. A square shows a photograph the way the
 * player framed it instead of cutting the corners off it, and it sits square
 * against the dice beside it.
 *
 * THE CLOCK IS PART OF THE FRAME
 *
 * The fifteen seconds are drawn as a bright line travelling round the inside
 * edge of the frame itself, not as a separate ring hovering outside it. That
 * means every seat shows its own clock in its own frame, the clock can never
 * drift out of line with the picture, and it costs no extra room on screen.
 *
 * Everything here is drawn in code — original shapes, no image files — except
 * a photograph the player chose themselves.
 */
class AvatarFrameView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var avatarId: String = Cosmetics.AVATAR_P1
        set(value) { field = value; invalidate() }

    var frameId: String = Cosmetics.FRAME_BRONZE
        set(value) { field = value; invalidate() }

    /**
     * The player's own picture, already cropped square. Null falls back to the
     * drawn avatar, so a player who has not chosen one still has a face.
     */
    var photo: Bitmap? = null
        set(value) { field = value; invalidate() }

    /** Drawn as a computer opponent instead of a person. */
    var isBot: Boolean = false
        set(value) { field = value; invalidate() }

    /** The seat colour, used for the backing so seats stay tellable apart. */
    var accent: Int = Color.rgb(0x2B, 0x3A, 0x63)
        set(value) { field = value; invalidate() }

    // --------------------------------------------------------- the turn clock

    /** Seconds still on the clock, or null when this seat is not on the clock. */
    var secondsLeft: Float? = null
        set(value) {
            field = value
            if (value != null) startPulse() else stopPulse()
            invalidate()
        }

    var totalSeconds: Float = 15f

    private var pulse = 0f
    private val pulseTicker = object : Runnable {
        override fun run() {
            if (secondsLeft == null) return
            pulse += 0.28f
            invalidate()
            postDelayed(this, 45)
        }
    }

    private fun startPulse() {
        removeCallbacks(pulseTicker)
        post(pulseTicker)
    }

    private fun stopPulse() {
        removeCallbacks(pulseTicker)
        pulse = 0f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(pulseTicker)
    }

    // ------------------------------------------------------------------ paint

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val clockTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(150, 0, 0, 0)
    }
    private val clockLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val clockGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val box = RectF()
    private val clockPath = Path()
    private val clockSegment = Path()
    private val measure = PathMeasure()
    private val textBounds = Rect()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val s = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val frameW = s * 0.11f
        val half = s * 0.5f
        val corner = s * 0.24f

        // the portrait sits inside the frame band
        val inner = RectF(
            cx - half + frameW, cy - half + frameW,
            cx + half - frameW, cy + half - frameW
        )
        drawPortrait(canvas, inner, corner - frameW * 0.6f)

        val bandMid = RectF(
            cx - half + frameW * 0.5f, cy - half + frameW * 0.5f,
            cx + half - frameW * 0.5f, cy + half - frameW * 0.5f
        )
        drawFrame(canvas, bandMid, corner - frameW * 0.25f, frameW)
        drawClock(canvas, bandMid, corner - frameW * 0.25f, frameW)
    }

    // ------------------------------------------------------------- portrait

    private fun drawPortrait(canvas: Canvas, r: RectF, corner: Float) {
        val size = min(r.width(), r.height())

        // backing in the seat colour
        shade.shader = RadialGradient(
            r.centerX() - size * 0.3f, r.centerY() - size * 0.4f, size * 1.4f,
            intArrayOf(lighten(accent, 0.35f), accent, darken(accent, 0.35f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, corner, corner, shade)
        shade.shader = null

        canvas.save()
        val clip = Path()
        clip.addRoundRect(r, corner, corner, Path.Direction.CW)
        canvas.clipPath(clip)

        val own = photo
        if (own != null && !own.isRecycled && avatarId == Cosmetics.AVATAR_PHOTO) {
            drawPhoto(canvas, r, own)
        } else if (isBot) {
            drawBot(canvas, r.centerX(), r.centerY(), size * 0.5f)
        } else {
            drawDrawnFace(canvas, r.centerX(), r.centerY(), size * 0.5f)
        }

        canvas.restore()

        // a soft light from the top left, over everything
        shade.shader = RadialGradient(
            r.centerX() - size * 0.4f, r.centerY() - size * 0.5f, size,
            intArrayOf(Color.argb(52, 255, 255, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, corner, corner, shade)
        shade.shader = null
    }

    /** Fills the square with the photograph, cropping rather than squashing it. */
    private fun drawPhoto(canvas: Canvas, r: RectF, bitmap: Bitmap) {
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        if (bw <= 0f || bh <= 0f) return
        val scale = maxOf(r.width() / bw, r.height() / bh)
        val dw = bw * scale
        val dh = bh * scale
        val dst = RectF(
            r.centerX() - dw / 2f, r.centerY() - dh / 2f,
            r.centerX() + dw / 2f, r.centerY() + dh / 2f
        )
        canvas.drawBitmap(bitmap, null, dst, photoPaint)
    }

    private fun drawDrawnFace(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (avatarId) {
            Cosmetics.AVATAR_KNIGHT -> drawKnight(canvas, cx, cy, r)
            Cosmetics.AVATAR_CROWN ->
                drawPerson(canvas, cx, cy, r, SKINS[0], HAIRS[3], Headgear.CROWN)
            Cosmetics.AVATAR_SULTAN ->
                drawPerson(canvas, cx, cy, r, SKINS[1], HAIRS[0], Headgear.TURBAN, beard = true)
            Cosmetics.AVATAR_WIZARD ->
                drawPerson(canvas, cx, cy, r, SKINS[0], HAIRS[4], Headgear.WIZARD_HAT, beard = true)
            Cosmetics.AVATAR_PHARAOH ->
                drawPerson(canvas, cx, cy, r, SKINS[2], HAIRS[2], Headgear.NEMES)
            Cosmetics.AVATAR_JOKER ->
                drawPerson(canvas, cx, cy, r, SKINS[0], HAIRS[1], Headgear.JESTER)
            Cosmetics.AVATAR_P2 -> drawPerson(canvas, cx, cy, r, SKINS[1], HAIRS[1])
            Cosmetics.AVATAR_P3 -> drawPerson(canvas, cx, cy, r, SKINS[2], HAIRS[2])
            // HAIRS[3] is almost exactly SKINS[3]; on the fourth seat that
            // read as a bald head rather than as hair.
            Cosmetics.AVATAR_P4 -> drawPerson(canvas, cx, cy, r, SKINS[3], HAIRS[2])
            else -> drawPerson(canvas, cx, cy, r, SKINS[0], HAIRS[0])
        }
    }

    private enum class Headgear { NONE, CROWN, TURBAN, WIZARD_HAT, NEMES, JESTER }

    private fun drawPerson(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        skin: Int, hair: Int, hat: Headgear = Headgear.NONE, beard: Boolean = false
    ) {
        // shoulders
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.86f, fill)

        if (hat == Headgear.NEMES) drawNemes(canvas, cx, cy, r)

        // head
        fill.color = skin
        canvas.drawCircle(cx, cy - r * 0.08f, r * 0.46f, fill)

        // hair as a cap over the top, unless a hat covers it entirely
        if (hat != Headgear.NEMES && hat != Headgear.WIZARD_HAT) {
            fill.color = hair
            canvas.drawArc(
                RectF(cx - r * 0.48f, cy - r * 0.58f, cx + r * 0.48f, cy + r * 0.38f),
                185f, 170f, true, fill
            )
        }

        if (beard) {
            fill.color = hair
            canvas.drawArc(
                RectF(cx - r * 0.40f, cy - r * 0.30f, cx + r * 0.40f, cy + r * 0.62f),
                12f, 156f, true, fill
            )
            // leave the mouth clear of the beard
            fill.color = skin
            canvas.drawArc(
                RectF(cx - r * 0.17f, cy - r * 0.04f, cx + r * 0.17f, cy + r * 0.22f),
                0f, 180f, true, fill
            )
        }

        // eyes
        fill.color = Color.rgb(0x22, 0x1A, 0x14)
        canvas.drawCircle(cx - r * 0.16f, cy - r * 0.09f, r * 0.055f, fill)
        canvas.drawCircle(cx + r * 0.16f, cy - r * 0.09f, r * 0.055f, fill)

        // a small smile
        stroke.shader = null
        stroke.color = Color.rgb(0x6B, 0x3A, 0x28)
        stroke.strokeWidth = r * 0.055f
        canvas.drawArc(
            RectF(cx - r * 0.18f, cy - r * 0.09f, cx + r * 0.18f, cy + r * 0.20f),
            20f, 140f, false, stroke
        )

        when (hat) {
            Headgear.CROWN -> drawCrown(canvas, cx, cy - r * 0.50f, r, GOLD_LIGHT)
            Headgear.TURBAN -> drawTurban(canvas, cx, cy, r)
            Headgear.WIZARD_HAT -> drawWizardHat(canvas, cx, cy, r)
            // NEMES is drawn before the face, not after: it frames the head
            // rather than sitting on top of it, so painting it last covered
            // the eyes it is supposed to sit beside.
            Headgear.NEMES -> Unit
            Headgear.JESTER -> drawJesterHat(canvas, cx, cy, r)
            Headgear.NONE -> Unit
        }
    }

    private fun drawCrown(canvas: Canvas, cx: Float, top: Float, r: Float, color: Int) {
        fill.color = color
        val p = Path()
        p.moveTo(cx - r * 0.44f, top + r * 0.20f)
        p.lineTo(cx - r * 0.44f, top - r * 0.16f)
        p.lineTo(cx - r * 0.18f, top + r * 0.06f)
        p.lineTo(cx, top - r * 0.30f)
        p.lineTo(cx + r * 0.18f, top + r * 0.06f)
        p.lineTo(cx + r * 0.44f, top - r * 0.16f)
        p.lineTo(cx + r * 0.44f, top + r * 0.20f)
        p.close()
        canvas.drawPath(p, fill)
        fill.color = Color.rgb(0xD9, 0x28, 0x3C)
        canvas.drawCircle(cx, top + r * 0.04f, r * 0.07f, fill)
    }

    private fun drawTurban(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = Color.rgb(0xF4, 0xF0, 0xE4)
        canvas.drawArc(
            RectF(cx - r * 0.56f, cy - r * 0.74f, cx + r * 0.56f, cy + r * 0.10f),
            180f, 180f, true, fill
        )
        stroke.shader = null
        stroke.color = Color.rgb(0xD8, 0xCF, 0xBA)
        stroke.strokeWidth = r * 0.05f
        canvas.drawArc(
            RectF(cx - r * 0.50f, cy - r * 0.66f, cx + r * 0.50f, cy + r * 0.02f),
            188f, 164f, false, stroke
        )
        // a jewel and a feather at the front
        fill.color = GOLD_LIGHT
        canvas.drawCircle(cx, cy - r * 0.46f, r * 0.10f, fill)
        fill.color = Color.rgb(0x2E, 0x8B, 0x6B)
        canvas.drawRoundRect(
            RectF(cx - r * 0.04f, cy - r * 0.94f, cx + r * 0.04f, cy - r * 0.52f),
            r * 0.04f, r * 0.04f, fill
        )
    }

    private fun drawWizardHat(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = Color.rgb(0x3B, 0x2A, 0x72)
        val p = Path()
        p.moveTo(cx - r * 0.60f, cy - r * 0.34f)
        p.lineTo(cx + r * 0.60f, cy - r * 0.34f)
        p.lineTo(cx + r * 0.12f, cy - r * 1.06f)
        p.close()
        canvas.drawPath(p, fill)
        // brim
        fill.color = Color.rgb(0x2C, 0x1F, 0x58)
        canvas.drawRoundRect(
            RectF(cx - r * 0.70f, cy - r * 0.40f, cx + r * 0.70f, cy - r * 0.26f),
            r * 0.07f, r * 0.07f, fill
        )
        // stars
        fill.color = GOLD_LIGHT
        canvas.drawCircle(cx - r * 0.16f, cy - r * 0.58f, r * 0.055f, fill)
        canvas.drawCircle(cx + r * 0.10f, cy - r * 0.78f, r * 0.04f, fill)
    }

    private fun drawNemes(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        // the striped headcloth falling either side of the face
        fill.color = Color.rgb(0x1E, 0x4F, 0x8A)
        val p = Path()
        p.moveTo(cx - r * 0.56f, cy + r * 0.52f)
        p.lineTo(cx - r * 0.52f, cy - r * 0.40f)
        p.quadTo(cx, cy - r * 0.86f, cx + r * 0.52f, cy - r * 0.40f)
        p.lineTo(cx + r * 0.56f, cy + r * 0.52f)
        p.lineTo(cx + r * 0.34f, cy + r * 0.52f)
        p.lineTo(cx + r * 0.36f, cy - r * 0.18f)
        p.lineTo(cx - r * 0.36f, cy - r * 0.18f)
        p.lineTo(cx - r * 0.34f, cy + r * 0.52f)
        p.close()
        canvas.drawPath(p, fill)

        stroke.shader = null
        stroke.color = GOLD_LIGHT
        stroke.strokeWidth = r * 0.05f
        canvas.drawLine(cx - r * 0.46f, cy - r * 0.10f, cx - r * 0.44f, cy + r * 0.40f, stroke)
        canvas.drawLine(cx + r * 0.46f, cy - r * 0.10f, cx + r * 0.44f, cy + r * 0.40f, stroke)

        // the cobra on the brow
        fill.color = GOLD_LIGHT
        canvas.drawCircle(cx, cy - r * 0.44f, r * 0.09f, fill)
    }

    private fun drawJesterHat(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val left = Color.rgb(0xD9, 0x28, 0x3C)
        val right = Color.rgb(0x2E, 0x8B, 0x6B)
        fill.color = left
        val a = Path()
        a.moveTo(cx, cy - r * 0.30f)
        a.lineTo(cx - r * 0.18f, cy - r * 0.62f)
        a.lineTo(cx - r * 0.72f, cy - r * 0.40f)
        a.lineTo(cx - r * 0.52f, cy - r * 0.16f)
        a.close()
        canvas.drawPath(a, fill)

        fill.color = right
        val b = Path()
        b.moveTo(cx, cy - r * 0.30f)
        b.lineTo(cx + r * 0.18f, cy - r * 0.62f)
        b.lineTo(cx + r * 0.72f, cy - r * 0.40f)
        b.lineTo(cx + r * 0.52f, cy - r * 0.16f)
        b.close()
        canvas.drawPath(b, fill)

        // bells
        fill.color = GOLD_LIGHT
        canvas.drawCircle(cx - r * 0.74f, cy - r * 0.40f, r * 0.10f, fill)
        canvas.drawCircle(cx + r * 0.74f, cy - r * 0.40f, r * 0.10f, fill)

        // band across the brow
        fill.color = Color.rgb(0xF2, 0xE6, 0xC8)
        canvas.drawRoundRect(
            RectF(cx - r * 0.50f, cy - r * 0.34f, cx + r * 0.50f, cy - r * 0.20f),
            r * 0.07f, r * 0.07f, fill
        )
    }

    private fun drawKnight(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.86f, fill)

        fill.shader = LinearGradient(
            cx, cy - r * 0.6f, cx, cy + r * 0.5f,
            intArrayOf(Color.rgb(0xE2, 0xEA, 0xF4), Color.rgb(0x8A, 0x9A, 0xB0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            RectF(cx - r * 0.46f, cy - r * 0.56f, cx + r * 0.46f, cy + r * 0.44f),
            r * 0.30f, r * 0.30f, fill
        )
        fill.shader = null

        fill.color = Color.rgb(0x1A, 0x22, 0x33)
        canvas.drawRoundRect(
            RectF(cx - r * 0.34f, cy - r * 0.18f, cx + r * 0.34f, cy + r * 0.02f),
            r * 0.06f, r * 0.06f, fill
        )
        for (i in -1..1) {
            canvas.drawRoundRect(
                RectF(cx + i * r * 0.16f - r * 0.03f, cy + r * 0.12f,
                      cx + i * r * 0.16f + r * 0.03f, cy + r * 0.34f),
                r * 0.03f, r * 0.03f, fill
            )
        }

        fill.color = Color.rgb(0xE5, 0x30, 0x35)
        canvas.drawRoundRect(
            RectF(cx - r * 0.07f, cy - r * 0.86f, cx + r * 0.07f, cy - r * 0.46f),
            r * 0.07f, r * 0.07f, fill
        )
    }

    private fun drawBot(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + r * 1.02f, r * 0.86f, fill)

        fill.shader = LinearGradient(
            cx, cy - r * 0.6f, cx, cy + r * 0.5f,
            intArrayOf(Color.rgb(0xCF, 0xDC, 0xEE), Color.rgb(0x7E, 0x90, 0xAA)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            RectF(cx - r * 0.48f, cy - r * 0.46f, cx + r * 0.48f, cy + r * 0.40f),
            r * 0.22f, r * 0.22f, fill
        )
        fill.shader = null

        fill.color = Color.rgb(0x16, 0x8D, 0xE8)
        canvas.drawCircle(cx - r * 0.18f, cy - r * 0.06f, r * 0.10f, fill)
        canvas.drawCircle(cx + r * 0.18f, cy - r * 0.06f, r * 0.10f, fill)

        stroke.shader = null
        stroke.color = Color.rgb(0x33, 0x42, 0x58)
        stroke.strokeWidth = r * 0.06f
        canvas.drawLine(cx - r * 0.18f, cy + r * 0.22f, cx + r * 0.18f, cy + r * 0.22f, stroke)

        stroke.strokeWidth = r * 0.07f
        canvas.drawLine(cx, cy - r * 0.46f, cx, cy - r * 0.74f, stroke)
        fill.color = GOLD_LIGHT
        canvas.drawCircle(cx, cy - r * 0.80f, r * 0.10f, fill)
    }

    // ---------------------------------------------------------------- frame

    /**
     * The frame band.
     *
     * Every tier is the same width and sits in the same place, so a Legendary
     * frame is showier but never bigger: nobody's face is squeezed for having
     * a better frame, and the clock always has the same track to run along.
     */
    private fun drawFrame(canvas: Canvas, r: RectF, corner: Float, w: Float) {
        if (frameId == Cosmetics.FRAME_NONE) return
        val look = lookFor(frameId)

        if (look.rainbow) {
            // the magic frame cycles through its colours round the band
            stroke.shader = SweepGradient(r.centerX(), r.centerY(), look.colors, null)
        } else {
            stroke.shader = LinearGradient(
                r.left, r.top, r.right, r.bottom,
                look.colors, floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        stroke.strokeWidth = w
        canvas.drawRoundRect(r, corner, corner, stroke)
        stroke.shader = null

        // an inner hairline, so the band reads as metal rather than a flat edge
        stroke.color = Color.argb(100, 255, 255, 255)
        stroke.strokeWidth = w * 0.18f
        val hair = RectF(
            r.left + w * 0.32f, r.top + w * 0.32f, r.right - w * 0.32f, r.bottom - w * 0.32f
        )
        canvas.drawRoundRect(hair, corner * 0.85f, corner * 0.85f, stroke)

        // studs at the corners on the better tiers
        if (look.studs) {
            fill.color = look.colors[0]
            val inset = corner * 0.42f
            for (x in listOf(r.left + inset, r.right - inset)) {
                for (y in listOf(r.top + inset, r.bottom - inset)) {
                    canvas.drawCircle(x, y, w * 0.30f, fill)
                }
            }
        }

        if (look.crown) {
            // Kept inside the view's own bounds on purpose: a View clips to its
            // rectangle, so a crown drawn above the frame would simply have its
            // top cut off. It overlaps the band instead, which reads as a crown
            // set into the frame rather than one balanced on top of it.
            drawCrown(canvas, r.centerX(), r.top + w * 0.72f, w * 3.1f, look.colors[0])
        }
    }

    private class FrameLook(
        val colors: IntArray,
        val studs: Boolean = false,
        val crown: Boolean = false,
        val rainbow: Boolean = false
    )

    private fun lookFor(id: String): FrameLook = when (id) {
        Cosmetics.FRAME_SILVER -> FrameLook(intArrayOf(
            Color.rgb(0xF2, 0xF6, 0xFC), Color.rgb(0xB4, 0xC2, 0xD4), Color.rgb(0x6E, 0x7E, 0x94)
        ))
        Cosmetics.FRAME_EMERALD -> FrameLook(intArrayOf(
            Color.rgb(0xBC, 0xFF, 0xD2), Color.rgb(0x25, 0xA8, 0x62), Color.rgb(0x07, 0x4A, 0x2C)
        ), studs = true)
        Cosmetics.FRAME_GOLD -> FrameLook(intArrayOf(
            Color.rgb(0xFF, 0xEE, 0xB4), Color.rgb(0xF2, 0xC1, 0x4E), Color.rgb(0x9A, 0x69, 0x06)
        ), studs = true)
        Cosmetics.FRAME_MAGIC -> FrameLook(intArrayOf(
            Color.rgb(0x7A, 0xE8, 0xFF), Color.rgb(0xC0, 0x8A, 0xFF), Color.rgb(0xFF, 0x8A, 0xD2),
            Color.rgb(0xFF, 0xE0, 0x8A), Color.rgb(0x7A, 0xE8, 0xFF)
        ), rainbow = true, studs = true)
        Cosmetics.FRAME_FLAME -> FrameLook(intArrayOf(
            Color.rgb(0xFF, 0xF0, 0xB4), Color.rgb(0xFF, 0x7A, 0x1E), Color.rgb(0x8A, 0x14, 0x04)
        ), studs = true)
        Cosmetics.FRAME_DIAMOND -> FrameLook(intArrayOf(
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0xAE, 0xE4, 0xFF), Color.rgb(0x4C, 0x8F, 0xC4)
        ), studs = true)
        Cosmetics.FRAME_PEACOCK -> FrameLook(intArrayOf(
            Color.rgb(0x8A, 0xFF, 0xE0), Color.rgb(0x18, 0x9A, 0xC8), Color.rgb(0x2A, 0x1E, 0x7A)
        ), studs = true)
        Cosmetics.FRAME_ROYAL -> FrameLook(intArrayOf(
            Color.rgb(0xDC, 0xC6, 0xFF), Color.rgb(0x8E, 0x63, 0xE0), Color.rgb(0x40, 0x22, 0x8E)
        ), studs = true, crown = true)
        Cosmetics.FRAME_OBSIDIAN -> FrameLook(intArrayOf(
            Color.rgb(0x9A, 0xA6, 0xC0), Color.rgb(0x28, 0x2E, 0x44), Color.rgb(0x08, 0x0A, 0x12)
        ), studs = true, crown = true)
        Cosmetics.FRAME_LEGENDARY -> FrameLook(intArrayOf(
            Color.rgb(0xFF, 0xF0, 0xC0), Color.rgb(0xFF, 0x9A, 0x2E), Color.rgb(0xA8, 0x2A, 0x06)
        ), studs = true, crown = true)
        else -> FrameLook(intArrayOf(          // bronze, and anything unrecognised
            Color.rgb(0xE0, 0xA4, 0x6E), Color.rgb(0xA8, 0x63, 0x2E), Color.rgb(0x6B, 0x38, 0x14)
        ))
    }

    // ------------------------------------------------------------ turn clock

    /**
     * The seconds left, drawn as a line running clockwise from the top round
     * the frame band, shrinking as the clock runs down.
     *
     * It travels the frame's own path rather than a circle, so on a square
     * avatar it follows the corners instead of cutting across them.
     */
    private fun drawClock(canvas: Canvas, r: RectF, corner: Float, w: Float) {
        val left = secondsLeft ?: return
        val total = if (totalSeconds > 0f) totalSeconds else 15f

        clockPath.reset()
        clockPath.addRoundRect(r, corner, corner, Path.Direction.CW)

        // the track is wider than the line, so there is always dark on both
        // sides of the clock whatever colour the frame under it happens to be
        clockTrack.strokeWidth = w * 0.62f
        canvas.drawPath(clockPath, clockTrack)

        measure.setPath(clockPath, false)
        val length = measure.length
        if (length <= 0f) return

        val fraction = (left / total).coerceIn(0f, 1f)
        clockSegment.reset()
        // start at the middle of the top edge so it reads like a clock
        val start = corner * 0.0f
        measure.getSegment(start, start + length * fraction, clockSegment, true)

        // The calm colour used to be gold, which is exactly the colour of the
        // Gold frame — so on the frame most players wear, a clock with plenty
        // of time left was invisible. Cool white-blue reads against gold,
        // purple, green and black alike, and still leaves amber and red free
        // to mean "hurry up" and "now".
        val color = when {
            left > total * 0.4f -> Color.rgb(0x9A, 0xE8, 0xFF)
            left > total * 0.15f -> Color.rgb(0xFF, 0x98, 0x1F)
            else -> Color.rgb(0xF2, 0x3B, 0x3B)
        }

        if (left <= total * 0.15f) {
            val p = 0.5f + 0.5f * kotlin.math.sin(pulse)
            clockGlow.strokeWidth = w * (0.6f + 0.5f * p)
            clockGlow.color = Color.argb((70 + 70 * p).toInt().coerceIn(0, 255), 0xF2, 0x3B, 0x3B)
            canvas.drawPath(clockSegment, clockGlow)
        }

        clockLine.color = color
        clockLine.strokeWidth = w * 0.38f
        canvas.drawPath(clockSegment, clockLine)

        // the number itself, in the corner, for the last few seconds
        if (left <= 5f) {
            val text = kotlin.math.ceil(left.toDouble()).toInt().coerceAtLeast(0).toString()
            fill.color = Color.argb(215, 0x10, 0x0C, 0x06)
            val plate = w * 1.5f
            val box = RectF(
                r.right - plate, r.bottom - plate * 0.85f,
                r.right + plate * 0.1f, r.bottom + plate * 0.15f
            )
            canvas.drawRoundRect(box, plate * 0.3f, plate * 0.3f, fill)
            clockText.textSize = plate * 0.72f
            clockText.color = color
            clockText.getTextBounds(text, 0, text.length, textBounds)
            canvas.drawText(text, box.centerX(), box.centerY() + textBounds.height() / 2f, clockText)
        }
    }

    private val clockText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD
        )
    }

    // ---------------------------------------------------------------- colour

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    private companion object {
        val GOLD_LIGHT = Color.rgb(0xF2, 0xC1, 0x4E)
        val SKINS = intArrayOf(
            Color.rgb(0xF2, 0xC6, 0xA0), Color.rgb(0xD9, 0xA3, 0x74),
            Color.rgb(0xA8, 0x71, 0x4A), Color.rgb(0x74, 0x4A, 0x2E)
        )
        val HAIRS = intArrayOf(
            Color.rgb(0x2A, 0x1C, 0x12), Color.rgb(0x5A, 0x3A, 0x1E),
            Color.rgb(0x1A, 0x14, 0x10), Color.rgb(0x3C, 0x2A, 0x18),
            Color.rgb(0xE4, 0xE8, 0xEE)   // white, for the wizard
        )
    }
}
