plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ludoroyale"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.ludoroyale"
        minSdk = 24          // covers low-end phones per spec section 1
        targetSdk = 34
        versionCode = 7
        versionName = "0.7.0"
    }

    /**
     * WHY THIS KEYSTORE IS HERE, AND WHY IT IS COMMITTED
     *
     * Android will only install an APK over an existing one when both are
     * signed with the SAME key. Left to itself, `gradle assembleDebug` makes a
     * throwaway debug key in the home directory of whatever machine it runs
     * on — and every GitHub Actions run is a brand-new machine. So every build
     * came out signed with a different key, and the phone refused each new APK
     * as if it were a different app from a different developer. That is what
     * "the new version will not install until I delete the old one" was.
     *
     * The fix is one fixed key that every build uses, which means the key has
     * to travel with the project. It is checked in, with its password in plain
     * sight, exactly as Android's own debug keystore is.
     *
     * BE CLEAR ABOUT WHAT THAT MEANS: anybody who can read this repository can
     * sign an APK that this phone would accept as an update to Ludo Masha. For
     * a game handed round by file that is the right trade — the alternative is
     * never being able to update at all. Before this ever goes on Play Store,
     * generate a fresh key, keep it OFF the repository, and pass it in through
     * a GitHub secret instead.
     */
    signingConfigs {
        create("shared") {
            storeFile = file("keystore/ludomasha.jks")
            storePassword = "ludomasha"
            keyAlias = "ludomasha"
            keyPassword = "ludomasha"
        }
    }

    buildTypes {
        debug {
            // the point of the whole exercise: the same key every time
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            signingConfig = signingConfigs.getByName("shared")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    testImplementation("junit:junit:4.13.2")
}
