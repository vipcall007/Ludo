package com.example.ludoroyale.snakes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the 10x10 Snakes and Ladders board and the pieces on it.
 * Everything is drawn in code — no artwork files.
 */
class SnakesBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var players: List<SnakePlayer> = emptyList()
        set(value) { field = value; syncPositions(); invalidate() }

    /** Where each piece is drawn right now, in square-number space (can be fractional mid-move). */
    private val shown = mutableMapOf<String, Float>()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 0x33, 0x2A, 0x1A)
        textAlign = Paint.Align.LEFT
        isFakeBoldText = true
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }

    private var cell = 0f
    private var frame = 0f

    private val tokenColors = intArrayOf(
        Color.rgb(0xE5, 0x30, 0x35),
        Color.rgb(0x22, 0xA6, 0x4B),
        Color.rgb(0xFA, 0xBF, 0x16),
        Color.rgb(0x16, 0x8D, 0xE8)
    )

    // ---- geometry ----

    /** Board runs boustrophedon: 1 bottom-left, 10 bottom-right, 11 above 10, and so on. */
    private fun rowColOf(square: Int): Pair<Int, Int> {
        val s = square.coerceIn(1, SnakesEngine.FINAL_SQUARE) - 1
        val rowFromBottom = s / 10
        val within = s % 10
        val col = if (rowFromBottom % 2 == 0) within else 9 - within
        return (9 - rowFromBottom) to col          // screen row, 0 at the top
    }

    private fun centerOf(square: Float): Pair<Float, Float> {
        if (square < 1f) {
            // off the board: sit just below square 1
            val (r, c) = rowColOf(1)
            return (frame + (c + 0.5f) * cell) to (frame + (r + 1.25f) * cell)
        }
        val low = square.toInt().coerceIn(1, SnakesEngine.FINAL_SQUARE)
        val high = (low + 1).coerceAtMost(SnakesEngine.FINAL_SQUARE)
        val t = square - low
        val (r1, c1) = rowColOf(low)
        val (r2, c2) = rowColOf(high)
        val x = frame + ((c1 + (c2 - c1) * t) + 0.5f) * cell
        val y = frame + ((r1 + (r2 - r1) * t) + 0.5f) * cell
        return x to y
    }

    private fun squareCenter(square: Int): Pair<Float, Float> {
        val (r, c) = rowColOf(square)
        return (frame + (c + 0.5f) * cell) to (frame + (r + 0.5f) * cell)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.03f
        cell = (size - 2 * frame) / 10f
        text.textSize = cell * 0.26f
    }

    // ---- movement ----

    private fun syncPositions() {
        for (p in players) if (!shown.containsKey(p.id)) shown[p.id] = p.square.toFloat()
    }

    /** Walks a piece square by square, then (if it hit one) rides the snake or ladder. */
    fun animateMove(
        playerId: String,
        from: Int,
        landed: Int,
        finalSquare: Int,
        onStep: () -> Unit,
        onComplete: () -> Unit
    ) {
        walk(playerId, from.toFloat(), landed.toFloat(), 90L, onStep) {
            if (finalSquare != landed) {
                // slide down the snake / climb the ladder in one smooth glide
                slide(playerId, landed.toFloat(), finalSquare.toFloat(), 520L, onComplete)
            } else onComplete()
        }
    }

    private fun walk(id: String, from: Float, to: Float, perStep: Long, onStep: () -> Unit, done: () -> Unit) {
        val steps = (to - from).toInt()
        if (steps <= 0) { shown[id] = to; invalidate(); done(); return }
        var i = 0
        val tick = object : Runnable {
            override fun run() {
                i++
                shown[id] = from + i
                onStep()
                invalidate()
                if (i >= steps) done() else postDelayed(this, perStep)
            }
        }
        postDelayed(tick, perStep)
    }

    private fun slide(id: String, from: Float, to: Float, duration: Long, done: () -> Unit) {
        val start = System.currentTimeMillis()
        val tick = object : Runnable {
            override fun run() {
                val t = ((System.currentTimeMillis() - start).toFloat() / duration).coerceIn(0f, 1f)
                shown[id] = from + (to - from) * t
                invalidate()
                if (t >= 1f) { shown[id] = to; invalidate(); done() } else postDelayed(this, 16)
            }
        }
        post(tick)
    }

    fun snapTo(playerId: String, square: Int) {
        shown[playerId] = square.toFloat()
        invalidate()
    }

    // ---- drawing ----

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawGrid(canvas)
        drawLadders(canvas)
        drawSnakes(canvas)
        drawTokens(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        val size = min(width, height).toFloat()

        // wooden frame
        fill.color = Color.rgb(0xA8, 0x63, 0x24)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), size * 0.04f, size * 0.04f, fill)
        fill.color = Color.rgb(0xD9, 0x93, 0x4A)
        canvas.drawRoundRect(
            RectF(frame * 0.3f, frame * 0.3f, size - frame * 0.3f, size - frame * 0.3f),
            size * 0.035f, size * 0.035f, fill
        )

        for (square in 1..SnakesEngine.FINAL_SQUARE) {
            val (r, c) = rowColOf(square)
            val left = frame + c * cell
            val top = frame + r * cell
            val rect = RectF(left, top, left + cell, top + cell)

            // warm chequerboard
            fill.color = if ((r + c) % 2 == 0) Color.rgb(0xFD, 0xE4, 0xB4) else Color.rgb(0xF6, 0xCE, 0x8C)
            if (square == SnakesEngine.FINAL_SQUARE) fill.color = Color.rgb(0x8B, 0xD1, 0x7A)
            if (square == 1) fill.color = Color.rgb(0x9E, 0xD2, 0xF0)
            canvas.drawRect(rect, fill)

            line.color = Color.argb(70, 0x6B, 0x4A, 0x22)
            line.strokeWidth = 1.5f
            canvas.drawRect(rect, line)

            canvas.drawText(square.toString(), left + cell * 0.10f, top + cell * 0.30f, text)
        }
    }

    private fun drawLadders(canvas: Canvas) {
        for ((foot, top) in SnakesEngine.LADDERS) {
            val (x0, y0) = squareCenter(foot)
            val (x1, y1) = squareCenter(top)

            val dx = x1 - x0
            val dy = y1 - y0
            val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val nx = -dy / len * cell * 0.17f      // sideways offset for the two rails
            val ny = dx / len * cell * 0.17f

            line.strokeWidth = cell * 0.075f
            line.color = Color.rgb(0x8D, 0x5A, 0x2B)
            canvas.drawLine(x0 + nx, y0 + ny, x1 + nx, y1 + ny, line)
            canvas.drawLine(x0 - nx, y0 - ny, x1 - nx, y1 - ny, line)

            // rungs
            line.strokeWidth = cell * 0.05f
            line.color = Color.rgb(0xB9, 0x7C, 0x3E)
            val rungs = (len / (cell * 0.45f)).toInt().coerceAtLeast(2)
            for (i in 1 until rungs) {
                val t = i.toFloat() / rungs
                val rx = x0 + dx * t
                val ry = y0 + dy * t
                canvas.drawLine(rx + nx, ry + ny, rx - nx, ry - ny, line)
            }
        }
    }

    private fun drawSnakes(canvas: Canvas) {
        for ((head, tail) in SnakesEngine.SNAKES) {
            val (x0, y0) = squareCenter(head)
            val (x1, y1) = squareCenter(tail)

            val dx = x1 - x0
            val dy = y1 - y0
            val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val nx = -dy / len
            val ny = dx / len

            // wavy body
            val path = Path()
            path.moveTo(x0, y0)
            val waves = 3
            for (i in 1..waves * 2) {
                val t = i.toFloat() / (waves * 2)
                val amp = cell * 0.55f * sin(i * Math.PI / 2).toFloat()
                path.lineTo(x0 + dx * t + nx * amp, y0 + dy * t + ny * amp)
            }
            path.lineTo(x1, y1)

            line.strokeCap = Paint.Cap.ROUND
            line.strokeJoin = Paint.Join.ROUND

            line.strokeWidth = cell * 0.30f
            line.color = Color.rgb(0x2E, 0x7D, 0x32)
            canvas.drawPath(path, line)

            line.strokeWidth = cell * 0.17f
            line.color = Color.rgb(0x66, 0xBB, 0x6A)
            canvas.drawPath(path, line)

            // head
            fill.color = Color.rgb(0x2E, 0x7D, 0x32)
            canvas.drawCircle(x0, y0, cell * 0.24f, fill)
            fill.color = Color.WHITE
            canvas.drawCircle(x0 - cell * 0.08f, y0 - cell * 0.05f, cell * 0.06f, fill)
            canvas.drawCircle(x0 + cell * 0.08f, y0 - cell * 0.05f, cell * 0.06f, fill)
            fill.color = Color.BLACK
            canvas.drawCircle(x0 - cell * 0.08f, y0 - cell * 0.05f, cell * 0.028f, fill)
            canvas.drawCircle(x0 + cell * 0.08f, y0 - cell * 0.05f, cell * 0.028f, fill)
        }
    }

    private fun drawTokens(canvas: Canvas) {
        // group pieces sharing a square so they don't hide each other
        val bySquare = players.groupBy { (shown[it.id] ?: 0f).toInt() }

        for ((_, group) in bySquare) {
            group.forEachIndexed { i, p ->
                val pos = shown[p.id] ?: p.square.toFloat()
                val (cx0, cy0) = centerOf(pos)
                val spread = if (group.size > 1) cell * 0.18f else 0f
                val cx = cx0 + (i - (group.size - 1) / 2f) * spread
                val cy = cy0

                val radius = cell * 0.28f
                val base = tokenColors[p.colorIndex % tokenColors.size]

                canvas.drawOval(
                    RectF(cx - radius * 0.9f, cy + radius * 0.35f, cx + radius * 0.9f, cy + radius * 0.95f),
                    shadow
                )

                fill.shader = RadialGradient(
                    cx - radius * 0.35f, cy - radius * 0.4f, radius * 1.6f,
                    intArrayOf(lighten(base, 0.5f), base, darken(base, 0.35f)),
                    floatArrayOf(0f, 0.55f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, cy, radius, fill)
                fill.shader = null

                line.strokeWidth = cell * 0.035f
                line.color = darken(base, 0.5f)
                canvas.drawCircle(cx, cy, radius, line)
            }
        }
    }

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )
}
