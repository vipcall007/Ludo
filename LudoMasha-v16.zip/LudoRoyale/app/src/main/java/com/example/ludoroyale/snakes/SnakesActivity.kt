package com.example.ludoroyale.snakes

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ConfettiView
import com.example.ludoroyale.DiceView
import com.example.ludoroyale.R
import com.example.ludoroyale.SoundFx
import com.example.ludoroyale.model.PlayerKind

/**
 * Snakes and Ladders. Same house style as the Ludo board: tap your dice, the
 * piece walks square by square, then climbs a ladder or slides down a snake.
 * Supports 2-4 players, any of whom can be played by the computer.
 */
class SnakesActivity : AppCompatActivity() {

    private lateinit var board: SnakesBoardView
    private lateinit var dice: DiceView
    private lateinit var turnLabel: TextView
    private lateinit var hint: TextView
    private lateinit var winOverlay: View
    private lateinit var winTitle: TextView
    private lateinit var confetti: ConfettiView

    private var engine: SnakesEngine? = null
    private var busy = false

    private var playerCount = 2
    private var botsOn = false
    private var botKind = PlayerKind.AI_MEDIUM
    private var typedNames: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_snakes)

        board = findViewById(R.id.snakesBoard)
        dice = findViewById(R.id.snakeDice)
        turnLabel = findViewById(R.id.snakeTurnLabel)
        hint = findViewById(R.id.snakeHint)
        winOverlay = findViewById(R.id.snakeWinOverlay)
        winTitle = findViewById(R.id.snakeWinTitle)
        confetti = findViewById(R.id.snakeConfetti)

        playerCount = intent.getIntExtra(EXTRA_PLAYERS, 2).coerceIn(2, 4)
        botsOn = intent.getBooleanExtra(EXTRA_BOTS, false)
        botKind = when (intent.getStringExtra(EXTRA_BOT_LEVEL)) {
            "easy" -> PlayerKind.AI_EASY
            "hard" -> PlayerKind.AI_HARD
            else -> PlayerKind.AI_MEDIUM
        }
        typedNames = intent.getStringArrayListExtra(EXTRA_NAMES).orEmpty()

        dice.setOnClickListener { rollForHuman() }
        findViewById<View>(R.id.snakeMenu).setOnClickListener { showMenu() }
        findViewById<View>(R.id.snakePlayAgain).setOnClickListener { hideWin(); newMatch() }
        findViewById<View>(R.id.snakeGoHome).setOnClickListener { finish() }

        newMatch()
    }

    override fun onResume() {
        super.onResume()
        SoundFx.resumeMusic()
    }

    override fun onPause() {
        super.onPause()
        SoundFx.pauseMusic()
    }

    private fun newMatch() {
        val players = (0 until playerCount).map { i ->
            val typed = typedNames.getOrNull(i)?.trim().orEmpty()
            SnakePlayer(
                id = "sp${i + 1}",
                name = when {
                    typed.isNotEmpty() -> typed
                    botsOn && i > 0 -> "Computer $i"
                    else -> "Player ${i + 1}"
                },
                colorIndex = i,
                kind = if (botsOn && i > 0) botKind else PlayerKind.HUMAN
            )
        }.toMutableList()

        val e = SnakesEngine(players)
        engine = e
        board.players = players
        for (p in players) board.snapTo(p.id, 0)
        busy = false
        hideWin()
        SoundFx.gameStart()
        render()
    }

    private fun rollForHuman() {
        val e = engine ?: return
        if (busy || e.gameOver) return
        if (e.currentPlayer.kind != PlayerKind.HUMAN) return
        playTurn()
    }

    private fun playTurn() {
        val e = engine ?: return
        if (busy || e.gameOver) return
        busy = true

        val player = e.currentPlayer
        SoundFx.diceRoll()
        shakeDice()

        // let the rattle run, then reveal the result and move
        dice.postDelayed({
            val turn = e.takeTurn()
            dice.value = turn.roll

            if (turn.blocked) {
                hint.text = getString(R.string.snakes_overshoot, turn.roll)
                busy = false
                render()
                return@postDelayed
            }

            board.animateMove(
                playerId = player.id,
                from = turn.from,
                landed = turn.landed,
                finalSquare = turn.finalSquare,
                onStep = { SoundFx.step() }
            ) {
                when {
                    turn.won -> SoundFx.win()
                    turn.tookLadder -> SoundFx.magic()
                    turn.tookSnake -> SoundFx.capture()
                    else -> SoundFx.tokenMove()
                }
                hint.text = when {
                    turn.won -> getString(R.string.snakes_won)
                    turn.tookLadder -> getString(R.string.snakes_ladder, turn.landed, turn.finalSquare)
                    turn.tookSnake -> getString(R.string.snakes_snake, turn.landed, turn.finalSquare)
                    turn.extraTurn -> getString(R.string.snakes_six)
                    else -> getString(R.string.snakes_tap_dice)
                }
                busy = false
                render()
            }
        }, 620)
    }

    private fun shakeDice() {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate().rotationBy(360f).scaleX(1.18f).scaleY(1.18f).setDuration(320)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    private fun render() {
        val e = engine ?: return
        board.invalidate()

        if (e.gameOver) {
            val winner = e.players.firstOrNull { it.finished }
            showWin(winner?.name ?: "")
            return
        }

        val p = e.currentPlayer
        turnLabel.text = getString(R.string.snakes_turn, p.name, p.square)
        dice.dimmed = p.kind != PlayerKind.HUMAN
        dice.isClickable = p.kind == PlayerKind.HUMAN && !busy

        // the computer takes its own turn, no tapping needed
        if (p.kind != PlayerKind.HUMAN && !busy) {
            board.postDelayed({ if (!busy && engine?.gameOver == false) playTurn() }, 700)
        }
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_close),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> newMatch()
                    1 -> finish()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun showWin(name: String) {
        if (winOverlay.visibility == View.VISIBLE) return
        winTitle.text = getString(R.string.snakes_winner, name)
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.animate().alpha(1f).setDuration(320).start()
        confetti.start()
    }

    private fun hideWin() {
        confetti.stop()
        winOverlay.visibility = View.GONE
    }

    companion object {
        const val EXTRA_PLAYERS = "players"
        const val EXTRA_BOTS = "bots"
        const val EXTRA_BOT_LEVEL = "botLevel"
        const val EXTRA_NAMES = "names"
    }
}
