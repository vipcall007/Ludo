package com.example.ludoroyale.snakes

import com.example.ludoroyale.model.PlayerKind
import java.security.SecureRandom

/** One player in a Snakes and Ladders match. */
data class SnakePlayer(
    val id: String,
    val name: String,
    val colorIndex: Int,
    val kind: PlayerKind,
    /** 0 = still off the board, 1..100 = square number. */
    var square: Int = 0,
    var finished: Boolean = false
)

/** What happened on one turn. */
data class SnakeTurn(
    val roll: Int,
    val from: Int,
    /** Where the plain dice move landed, before any snake or ladder. */
    val landed: Int,
    /** Where the piece ended up after a snake or ladder, same as [landed] if neither. */
    val finalSquare: Int,
    val tookLadder: Boolean,
    val tookSnake: Boolean,
    /** The roll overshot 100, so the piece did not move at all. */
    val blocked: Boolean,
    val extraTurn: Boolean,
    val won: Boolean
)

/**
 * Standard Snakes and Ladders.
 *
 * Rules used (the common board and the usual house rules):
 *  - board of 100 squares, everyone starts off the board
 *  - roll a die and advance; landing on a ladder's foot climbs it, landing on
 *    a snake's head slides down it
 *  - you must land on 100 EXACTLY; a roll that would overshoot does not move
 *  - a six earns another roll
 *  - first player to reach 100 wins
 */
class SnakesEngine(
    val players: MutableList<SnakePlayer>,
    private val random: SecureRandom = SecureRandom()
) {

    var currentIndex: Int = 0
        private set

    var lastRoll: Int? = null
        private set

    var gameOver: Boolean = false
        private set

    val currentPlayer: SnakePlayer get() = players[currentIndex]

    /** Plays one whole turn for the current player and reports what happened. */
    fun takeTurn(): SnakeTurn {
        check(!gameOver) { "Match is already finished." }
        val player = currentPlayer
        val roll = 1 + random.nextInt(6)
        lastRoll = roll

        val from = player.square
        val target = from + roll

        // must land exactly on 100
        if (target > FINAL_SQUARE) {
            val extra = roll == 6
            if (!extra) advance()
            return SnakeTurn(
                roll = roll, from = from, landed = from, finalSquare = from,
                tookLadder = false, tookSnake = false, blocked = true,
                extraTurn = extra, won = false
            )
        }

        val jumpTo = JUMPS[target]
        val finalSquare = jumpTo ?: target
        player.square = finalSquare

        val won = finalSquare == FINAL_SQUARE
        if (won) {
            player.finished = true
            gameOver = true
        }

        val extra = roll == 6 && !won
        if (!extra && !won) advance()

        return SnakeTurn(
            roll = roll,
            from = from,
            landed = target,
            finalSquare = finalSquare,
            tookLadder = jumpTo != null && jumpTo > target,
            tookSnake = jumpTo != null && jumpTo < target,
            blocked = false,
            extraTurn = extra,
            won = won
        )
    }

    private fun advance() {
        currentIndex = (currentIndex + 1) % players.size
    }

    companion object {
        const val FINAL_SQUARE = 100

        /** Ladders: foot -> top. The classic board. */
        val LADDERS: Map<Int, Int> = mapOf(
            1 to 38, 4 to 14, 9 to 31, 21 to 42, 28 to 84,
            36 to 44, 51 to 67, 71 to 91, 80 to 100
        )

        /** Snakes: head -> tail. The classic board. */
        val SNAKES: Map<Int, Int> = mapOf(
            16 to 6, 47 to 26, 49 to 11, 56 to 53, 62 to 19,
            64 to 60, 87 to 24, 93 to 73, 95 to 75, 98 to 78
        )

        /** Every jump on the board, looked up by the square you land on. */
        val JUMPS: Map<Int, Int> = LADDERS + SNAKES
    }
}
