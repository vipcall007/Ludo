## Round 16 — Snakes & Ladders added, music wired, duplicates cleaned

SNAKES & LADDERS as a third mode, in its own screen:
- `snakes/SnakesEngine.kt` — classic 100-square board with the standard ladder
  and snake map, must land on 100 exactly (an overshoot doesn't move), a six
  earns another roll, first to 100 wins.
- `snakes/SnakesBoardView.kt` — 10x10 boustrophedon grid with numbers, drawn
  ladders (two rails + rungs) and drawn snakes (wavy body, head with eyes),
  shaded 3D pieces that fan out when they share a square, and animation that
  walks the piece square by square then glides it up a ladder or down a snake.
- `snakes/SnakesActivity.kt` — tap-to-roll, computer players take their own
  turns, menu, and the same confetti win screen as Ludo.
- Reached from a third SNAKES card on the setup screen; it carries over the
  player count, typed names, bot setting and difficulty.

MUSIC: there was already a synthesised looping background bed inside SoundFx
from an earlier round — I had started writing a second one. Deleted my
duplicate and wired the new music button to the existing implementation, with
a ♫ / ♫̸ toggle beside the sound button.

TWO CLEANUPS FOUND BY VERIFICATION, BOTH MY OWN MISTAKES:
- An earlier round had already created a Snakes attempt in the root and engine
  packages whose layout ids no longer existed, so it was dead code that would
  have failed to compile against the new layout. Deleted those four files;
  a grep confirms nothing references them.
- My own edit to insert the SNAKES card had removed the mode-hint line and the
  2/3/4 player pills from the layout, which would have crashed `findViewById`
  at startup. Restored them.

## Round 15 — Arrow Mode replaced by Quick Mode

ARROW MODE FULLY REMOVED: `ArrowConfig.kt`, `ArrowModeTest.kt`, the arrow
fields on `Move`/`MoveResult`, the arrow branch in `applyMove`, every arrow
renderer, the glow/slide animation, the `arrowMode` flag, the arrow icon, the
arrow strings and the arrow card. Verified by a project-wide grep — nothing
arrow-related is left except the board's own centre arrowheads, which are
part of the artwork.

QUICK MODE, built from the supplied spec:
- Two pieces per player start ACTIVE on their own starting square, no six
  needed; the other two wait in base and still need a six (sections 2, 10, 11).
- HOME starts LOCKED. The finishing move is simply never offered while
  `hasCapturedOpponent` is false, which is the cleanest way to satisfy
  sections 5 and 14 — a piece may travel and may sit in its home lane, it just
  cannot complete.
- A legal capture sets `hasCapturedOpponent = true` permanently (section 6),
  and being captured later never resets it (section 20).
- A safe square captures nothing, so it unlocks nothing (section 7).
- Win is 1 kill + 1 token home, checked after every move and ending the match
  at once (sections 3, 12, 18). Classic still needs all four home.
- Status strip shows "HOME LOCKED · KILL 0/1" then "HOME UNLOCKED · KILL 1/1",
  with a brief "HOME UNLOCKED!" pulse (~1.3s) on the unlocking capture
  (sections 15, 16), and the win banner gains "Quick Mode Victory" (section 17).
- AI (section 22): while HOME is locked a capture is worth more than twice its
  normal score, so the computer actively hunts the kill it needs. It still
  only ever picks from the same legal-move list a human sees.

TESTS: new `QuickModeTest` covering the locked/unlocked finishing move, the
capture unlocking HOME, the unlock surviving a later capture, safe squares not
unlocking, 1-kill-plus-1-home winning immediately, classic still needing four,
the 2-active/2-base start, and base pieces still needing a six.

STILL OUTSTANDING: Snakes & Ladders as a separate mode, and background music
(needs a real audio file).

## Round 14 — Arrow Mode built to the written specification

Implemented the supplied Arrow Mode spec exactly, replacing the previous
guesswork (and the 12-arrow version from the round before).

EXACTLY 8 GAMEPLAY ARROWS — one STRAIGHT and one HOME per colour. New
`engine/ArrowConfig.kt` holds every position in one place, with nothing
hard-coded into UI or engine code, so entries/exits can be retuned freely.

COLOUR OWNERSHIP IS STRUCTURAL: arrow positions are expressed in the owning
colour's OWN step numbers, so a red token's step 22 is a physically different
square from a green token's step 22. Red literally cannot reach green's arrow
— it is not a check that can be forgotten, it falls out of the addressing.
On top of that, `acceptsToken` also requires the right token state:
STRAIGHT needs ACTIVE, HOME needs HOME_LANE.

MOVEMENT ORDER per section 7: dice move first, THEN the arrow check on the
square the move ended on, THEN captures at the FINAL destination, then home,
then turn rules. Captures were previously resolved before the arrow, which
was wrong.

LANDING IS EXACT: the arrow is only ever tested against the square a move
finished on, so passing over an entry can never fire it.

NO CHAINING: at most one activation per move, and a test asserts no arrow's
exit is another arrow's entry for the same colour.

SIX RULE: the arrow no longer grants a roll of its own and no longer cancels
the extra roll a six earned — it is part of the same move, per section 9.
(This reverses the "arrow forces an immediate re-roll" behaviour from the
earlier round, because the written spec overrides it.)

ANIMATION per section 12: token settles, 200ms pause, the arrow glows, then a
single smooth ~500ms slide to the exit.

VISUALS per section 13: glow pass, drop shadow, metallic body, bright core and
an entry knob, all tinted to the owning colour.

TESTS per section 16: new `ArrowModeTest` covering all eight arrows existing,
colour ownership both ways, state requirements, passing-vs-landing, no extra
dice cost, no chaining, capture judged at the arrow exit, the six keeping its
extra roll, and arrows never pushing a token off its valid path. The
configuration was also simulated independently before writing the tests.

STILL OUTSTANDING: Snakes & Ladders as a separate mode, and background music
(needs a real audio file).

## Round 13 — real arrow rule, 3D pieces, new dice sound, avatars

ARROW MODE REBUILT TO THE ACTUAL RULE (researched rather than guessed):
the standard board carries 12 arrows, 3 in each colour zone; landing on an
arrow's TAIL sends the piece straight to its HEAD and grants another chance.
Implemented exactly that — 12 tails computed to sit on straight runs of the
track, none on a safe star or a colour's start square. Every tail and head is
on the SHARED outer track, so an arrow can never drop a piece into another
colour's home column (the rule the user kept stressing). Deleted the old
per-colour arrow scheme and the decorative direction marks — Classic is now a
completely clean board.

DICE SOUND: replaced again, this time plainly realistic — a few dry wooden
taps as the cube tumbles, spacing out as it slows, then one settling knock.
Noise-based knocks rather than tones, so it reads as a die rather than a beep.

3D LOOK: pieces are now lit domes — flattened contact shadow on the board, a
dark rim, a radial body gradient shaded from a top-left light, white inset
with the star, and a specular highlight. Arrows are drawn with a shadow pass
underneath so they sit above the board.

AVATARS: computer players get a robot face (visor, antenna, grille); human
players get four distinct faces with different skin, hair and shirt colours.

Palette remains red -> dark blue throughout.

STILL OUTSTANDING (not dropped): Snakes & Ladders as a separate mode, and
background music (needs a real audio file — effects are synthesised, a music
loop is not something worth synthesising).

## Round 12 — the turn rule, fair dice, cut animation, real AI difficulty

THE IMPORTANT RULE (rewritten): a cut, an arrow, or sending a piece home now
forces the SAME player to roll again IMMEDIATELY. Anything already banked
stays banked and can only be spent after that roll. Sixes keep banking and
re-rolling; on three in a row only THOSE THREE SIXES are wasted — any other
banked numbers survive and are still playable. Removed the old `bonusRolls`
mechanism, which deferred the extra roll instead of forcing it.

LUCKY DICE BUG (this is why a piece needing a 1 could sit forever): lucky mode
was max(two draws), which makes low faces nearly unreachable. It now just
raises the chance of a six. Verified by simulation — normal: every face ~16%;
lucky: six 33%, every other face still ~13%.

CUT ANIMATION: a cut piece now races back along its own path to its base slot
(fast, reversed) with the comic sound, instead of vanishing.

BOARD JUMPING: the banked-dice strips were `wrap_content`, so the board slid
up and down as dice appeared. Fixed at 34dp.

ARROWS: direction marks restored at exactly the circled positions — a U-turn
curling into each colour's home column, a diagonal arrow pointing in toward
the centre, and triple chevrons before the home turn.

AI: rewritten with genuinely different levels. Easy plays mostly at random
like a child; Medium is sensible but slips; Hard evaluates danger both ways —
it runs threatened pieces out of reach, refuses to park in front of an enemy,
prefers safe squares and pushes for home. It still only ever picks from the
same legal-move list a human sees.

WIN SCREEN: replaced the plain dialog with a full celebration — falling
confetti, the winner's name, and PLAY AGAIN / GO TO HOME.

SOUND: on/off button on the game screen.

Palette moved to red -> dark blue as asked.

STILL TO DO (told the user, not dropped): Snakes & Ladders as a separate game
mode, and real background music (needs an actual audio file — the current
effects are synthesised, but a music loop is not something to synthesise).

## Round 11 — bot actually plays, arrows cut back, dice rattle rewritten

1+5. ARROWS: `drawDirectionMarks` was drawing U-turns, chevrons and home-entry
   arrows on EVERY board including Classic, and arrow mode added ten shortcuts
   per colour on top — the board was unreadable. Deleted the decorative marks
   entirely (Classic now has zero arrows) and cut arrow mode to TWO shortcuts
   per colour plus the home-run arrow.
2. DICE SOUND: the old one played after the die had already landed. Rewritten
   as a tumble across a hard surface — many sharp clicks that start fast and
   thin out as the die slows, ending in a settling knock — and it now starts
   AT the roll, with the reveal animation lengthened to 700ms to match.
3. BOT BUG (the real one): `maybeRunBot()` was defined but NEVER CALLED — an
   earlier patch targeted a version of `render()` that no longer existed, so it
   silently did nothing and the computer just sat there. Now called at the end
   of every render, and `maybeAutoPlay` hands straight over to the bot on a
   bot's turn so the "let the human choose" guard can't stall it.
4. ARROW RE-ROLL: riding an arrow now forces the SAME player to roll again
   immediately, and anything already banked stays banked to be spent after.
   (Cuts and finishes still bank their bonus for after the current values.)
6. Palette moved off the flat blue to deep plum/near-black with warm gold
   edges and a warm pool of light behind the board.

## Round 10 — build fix (missing imports)

BUILD FIX: `MainActivity.kt:58` — "Unresolved reference: RadioGroup", and the
knock-on "Not enough information to infer type variable T" at line 93 (the
`findViewById` whose target type couldn't be resolved). When the mode radio
buttons were replaced with cards and pills a few rounds back, the
`android.widget.RadioGroup` import was dropped — then the bot-difficulty radio
group reintroduced the type without the import coming back. Added it, plus
`android.widget.Toast` (which was being used fully-qualified).

Added an import checker that walks every Kotlin file, finds Android
widget/graphics/media types used in the body, and reports any that are neither
imported, fully qualified, nor declared in the project. Only false positive
was a ToneGenerator mention inside a comment.

## Round 9 — build fix + classic arrow styling

BUILD FIX: `LudoBoard.kt:51` — "Variable 'HOME_RUN_ARROW_END' must be
initialized". `ARROW_PAIRS`' initializer referenced `HOME_RUN_ARROW_START/END`
that were declared *below* it in the same object, and Kotlin initialises
object properties in declaration order. Moved both constants above their
first use. Also added a scan over every object/class for the same
forward-reference pattern; nothing else hits it.

ARROW STYLING (matching the reference board): direction marks are now drawn
in the classic thin grey style instead of bold shapes —
- a rounded U-turn curve at each of the four outer tips of the track,
- triple chevrons along the straights,
- a slim arrow turning into each colour's home column.
These are always visible (they explain how the board flows), and the
ARROW-MODE shortcuts reuse the same thin chevron style, just tinted in each
colour so it stays obvious that an arrow belongs to one colour only.
Removed the old per-cell travel-arrow renderer and its paint.

## Round 8 — computer opponent, fair dice, colour-locked arrows

1. COMPUTER OPPONENT: setup now has "Play against the computer" plus
   Easy / Medium / Hard. Player 1 stays you; the rest are driven by the
   existing LudoAI, which only ever picks from the same legal-move list a
   human would see. `maybeRunBot()` takes the bot's turn after a short pause
   so it reads naturally.
2. DICE SOUND: the roll is now a real rattle — bursts of low-passed noise
   spaced further apart as the die loses energy, ending in a landing knock —
   instead of a beep.
4. FAIR DICE (default on): each player draws from their OWN shuffled bag of
   1..6; a face leaves the bag when drawn and the bag reshuffles when empty.
   Over each set of six rolls every player gets exactly the same faces, so
   nobody sits there getting nothing while someone else keeps rolling sixes —
   but the order stays random, so a roll still feels like a roll. It balances
   luck between players; it does not favour anyone.
5. Movement was already a continuous glide; removed the per-square tick sound
   that still made it *feel* step-by-step.
7. ARROWS REBUILT, COLOUR-LOCKED: arrows are now defined in each colour's OWN
   step numbers rather than on the shared ring. That structurally guarantees
   the rule that was emphasised — a red piece can only ever be carried along
   red's route, never into green's or anyone else's home. Drawn per colour in
   that colour's tint.
   Layout implemented from the description: an arrow runs 4->5, then the next
   starts 4 after the previous ended (9->10, 14->15 ... 44->45), and a final
   arrow at 48 carries the piece into its own home column landing on 52, so a
   5 finishes it. THIS GEOMETRY IS A BEST-GUESS FROM THE DESCRIPTION and was
   flagged to the user for correction.

## Round 7 — thin arrows, smooth glide, bonus rolls, drawn golden dice

ARROWS: redrawn as a thin pencil-line stroke with a small open arrowhead and
a tail tick, instead of the heavy orange band.

BONUS ROLLS (the real fix): cutting a piece, riding an arrow, or getting a
piece home now all earn ANOTHER roll — but the bonus is STORED, not taken
immediately. Any values already banked are spent first; only when nothing is
left to play does the same player roll again. GameState gained `bonusRolls`
and the engine a `takeBonusOrAdvance()` step. Previously the extra turn was
only granted when the bank happened to be empty, so banked values could be
silently thrown away.

MOVEMENT: pieces now glide continuously along the real path (turning corners
correctly) instead of teleporting square to square. `glide()` interpolates
between cell centres at ~110ms per square, with a soft tick as each square is
crossed.

DICE: reverted to a drawn face — the cropped photo parts looked wrong at
small sizes. Same clean shape as before, but golden: warm gold gradient body,
bright inner bevel, deep gold border, glossy sheen, and black pips with a
specular dot. Crisp at any size, no bitmaps.

BACKGROUND: the XML layer-list wasn't rendering, so the backdrop is now a
custom `GameBackgroundView` drawn in code — blue-violet gradient, a warm pool
of light behind the board, faint scattered pips, corner vignette. Added to
both the game and splash screens.

SOUND: notes can now slide in pitch. A cut plays a comic falling
"wah-wah-wahhh"; a win plays a longer rising celebration fanfare.

## Round 6 — golden dice, fixed arrows, on-board number chips, game background

1. DICE: replaced the drawn dice with the golden artwork the user supplied.
   Sliced the 3x2 sheet into six faces (dice_1..dice_6 at 192px), and DiceView
   now renders the matching image, desaturating it off-turn and drawing a thin
   ring in the owner's colour.
2. ARROWS FIXED: the real bug was WHERE they sat, not how they were drawn.
   The old indices (4, 17, 30, 43) fall on corners of the track, so a straight
   shaft from start to landing cell cut diagonally across the board. Checked
   every ring index for a straight 3-cell run and moved the arrows to
   1, 12, 20, 32 (landing on 4, 15, 23, 35) — all straight, and none landing
   on a safe star or a colour's start cell.
3/5. BACKGROUND: game and splash now use layered gradients (night-blue base,
   warm radial glow behind the board, corner vignette) instead of a flat
   colour. Board frame reworked too: drop shadow, two-tone wood, thin gold
   inner edge, softer off-white playfield.
4. "Give how many?" dialog is gone. Tapping a piece now floats small gold
   number chips directly over that piece; tapping a chip plays that value.
   Chips flip below the piece when it sits near the top edge, and clear
   themselves whenever the turn moves on.

## Round 5 — build fix + real artwork icon

BUILD FIX: `LudoBoardView.onTouchEvent` failed to compile —
"Smart cast to 'Token' is impossible, because 'best' is a local variable
captured by a changing closure". The `var best` was written inside a
`forEachIndexed` lambda and then dereferenced afterwards, which Kotlin will
not smart-cast. Copied it into a local `val chosen` before use.

ICON: replaced the hand-drawn vector logo with the artwork the user supplied.
Generated proper launcher PNGs at every density (mdpi 48 -> xxxhdpi 192,
plus round variants) and a 512px copy used on the splash and setup screens.
Deleted the old adaptive-icon XML and vector foreground/background, which
would otherwise have overridden the PNG on Android 8+.

## Round 4 — arrows, sound, per-player rolls, pick-your-points

1. Arrow markers redrawn as a real arrow that spans the cells it covers:
   shaft starts on the arrow's own cell, head sits on the exact cell the piece
   lands on. No more guessing where it goes.
8. Arrow jump shortened from 6 cells to 3 — the piece stops on the arrow's
   TIP instead of skipping a whole side of the board.
2. Sound rewritten from scratch: ToneGenerator was silent on some phones, so
   SoundFx now synthesises sine tones into an AudioTrack (still no audio files
   bundled, nothing copied). Game-start flourish now actually plays, along
   with dice, step, cut, magic, three-six buzzer and win fanfare.
3. Banked rolls now appear UNDER each player's own avatar, not in a shared
   tray in the middle.
4. Tapping a piece asks "Give how many?" and lists the banked values that can
   move it, each labelled with what it would do (cuts / comes out / goes home).
5. It auto-plays only when there is genuinely nothing to decide (one piece and
   one value). As soon as a six is banked next to another number, or several
   pieces are out, the choice comes back to the player.
6. The current player's movable pieces gently pulse (grow/shrink) so it is
   obvious which pieces are theirs and which can actually move.
7. Stacked pieces are fanned out and shrunk to fit instead of being replaced
   by a number badge — you can literally count the pieces on the square.

## Round 3 — banked rolls, magic arrows, team turn order

1. Setup screen restyled to match the reference: selectable Classic / Arrow
   mode cards with icons, player-count pills, name fields, teams + lucky
   toggles, big gold START.
2. ARROW MODE redesigned: bolder orange arrow markers, and landing on one now
   makes the piece VANISH and REAPPEAR at the arrow's end (fade out / fade in)
   with a sparkle sound, instead of walking the gap. Same player rolls again.
3. Game-start flourish sound added. Logo and launcher icon redrawn (crown +
   gold ring + four-quadrant board + big dice).
4. Team mode now uses the SAME clockwise turn order as classic
   (Red -> Green -> Yellow -> Blue), which naturally alternates A, B, A, B.
   Team is shown as a separate label, not jammed into the name.
5+6. Rolls are now BANKED, not spent immediately:
   - a six banks the value and forces another roll (the six is not used yet)
   - three sixes in a row burn the turn and every banked value
   - when rolling stops, banked values appear in a tray under the board; the
     player taps WHICH value to spend, then which piece to spend it on, and
     repeats until all values are used. Works with a single piece too.
7. Home pieces sit closer together (tight 2x2 in each yard circle).
8. Piles are now unmistakable: stacked pieces are drawn stepped behind the
   front one AND carry a numbered badge; two colours on one safe cell sit
   side by side.

Engine note: GameState now carries `pendingRolls`, and Move carries the
`usedRoll` it spends, so the same rules drive UI, future AI and any future
server without special-casing.

## Round 2 — "Ludo Masha" rebrand + modes (14 of the 20 requests)
Done this round:
1. Animated splash: logo scales/spins in, title + tagline fade up, then the
   game opens (view animation, not a video file — costs no APK size).
2. New premium app icon + logo (gold badge, four ludo quadrants, dice, crown).
3. Home pieces now sit as a neat centred 2x2 in each yard (the old slots were
   off-centre, which is why they looked scattered).
4. Player name entry for each seat on the setup screen.
6. Board vertically centred in the game screen.
7. Premium dice: gradient body, gloss highlight, player-coloured rim,
   recessed pips.
8/19. ARROW MODE as a separate mode — landing on an arrow carries the piece
   to where the arrow ends and the same player rolls again. Arrows are drawn
   on the board only in that mode.
9. TEAM MODE (2v2): Red+Yellow vs Green+Blue, partners sit opposite, you
   cannot cut your own partner, and a team wins only when both partners are
   home.
10. Active player's arrow pulses (blinks) so the turn is unmissable.
12. Removed the "tap your dice" hint line.
13. Capture now plays a comic descending slide.
14. Win plays a rising celebration fanfare + a winner dialog.
15. Menu button (top-right): Restart / New game / Close.
17. "Lucky Dice" is an explicit, labelled setting (rolls twice, keeps the
    higher face) applied identically to every player — deliberately NOT a
    hidden tilt toward anyone, so the game stays fair.

Also: single-legal-move turns now auto-play instead of forcing a pointless tap.

Deferred to the next round (told the user, not silently dropped):
- 5/11: accumulating rolls after a six and letting the player choose which
  value to use.
- 16: removing a player mid-game (and clearing their pieces).
- 18: Easy/Medium/Hard — these only mean something against AI opponents, and
  pass-n-play is all humans; needs a decision on adding AI players first.

# Ludo Royale — Phase 1 (Offline Rule Engine)

## What's actually working right now
A complete, UI-independent Ludo **rules engine** in Kotlin — the piece every other
phase (AI, local multiplayer, online sync) depends on:

- `model/` — `PlayerColor`, `Token`, `Player` (pure data, no Android deps)
- `engine/` — `LudoBoard` (52-cell track + safe cells + home stretch geometry),
  `RuleConfig` (toggleable rules: extra turn on six, 3-six forfeit, capture
  extra turn, exact-roll-to-finish, safe-cell capture blocking...),
  `DiceRoller` (SecureRandom, unbiased, never favors anyone),
  `LudoEngine` (roll → legalMoves → applyMove → turn advance / win detection)
- `ai/LudoAI.kt` — Easy (random legal move), Medium/Hard (heuristic scoring:
  captures > finishing > home-stretch entry > leaving base). The AI is only
  ever given the same `List<Move>` a human would see — it cannot cheat.
- `MainActivity.kt` — a bare, text-only screen that plays a full human-vs-AI
  game end to end through the real engine (roll, move, capture, win). This is
  **not** the premium UI from the spec — it exists to prove the engine is
  actually wired to something runnable, per "don't stop at a mockup."
- `LudoEngineTest.kt` — 6 JUnit tests covering: can't leave base without a six,
  leaving base on six, capture + extra turn, exact-roll-to-finish (overshoot
  rejected), three-consecutive-sixes forfeit, normal turn advancement.

## Getting an actual APK on your phone (no coding needed)
A `.github/workflows/build-apk.yml` file is included — it builds the APK
automatically in the cloud when you upload this project to GitHub. Steps are
in the chat reply.

## Phase 1b update — real visible board
Added: `BoardGeometry.kt` (classic 15x15 cross-board coordinate mapping),
`LudoBoardView.kt` (Canvas-drawn board: 4 colored home squares, 52-cell ring,
safe-cell markers, colored home stretches, center pinwheel, circular tokens,
tap-to-move with yellow highlight on legal tokens). `MainActivity.kt` now
wires taps on the real board to the engine instead of auto-picking moves.
Still original artwork — nothing copied from any reference app.
Not yet done: dice-roll animation, token-slide animation, sound.

## Phase 1c update — local pass-and-play (2-4 players, one phone)
Added a setup screen: pick 2, 3, or 4 players, then everyone takes turns
passing the same phone. No AI needed for this mode — Ludo has no hidden
information, so this is fair and simple. `MainActivity.kt` now creates
that many `PlayerKind.HUMAN` players and the real board drives it.
Not yet done: dice-roll animation, token-slide animation, sound,
"pass to next player" confirmation screen (optional nicety, not required).

## Phase 1d update — animation + sound
Tokens now slide (animated, ~260ms) between positions instead of jumping.
Dice shows a quick random-cycling animation before landing on the real
(already-decided) result. Added `SoundFx.kt` — short original beep tones
via Android's built-in ToneGenerator for dice/move/capture/win (no external
audio files needed, nothing copied).

## Phase 1e update — closer to a "real board" look
Added `DiceView.kt` — dice now shows real pip dots (like a physical die),
not a plain digit. Safe cells now draw as a yellow star instead of a plain
gray dot. Compared against reference screenshots the person shared —
matched the dice-face and star-cell look; didn't copy any art files
(everything above is drawn in code).

## Bugfix — MainActivity out of sync with new box-by-box board API
LudoBoardView was upgraded to move tokens box-by-box (snapToState / hopToken)
but MainActivity.kt still tried the old direct `boardView.state = ...`
assignment, which no longer compiles (state's setter is now private by
design). Rewrote MainActivity to use snapToState (initial/instant sync) and
hopToken (animated box-by-box move, then snap to the true post-move state —
this is also what naturally resets a captured token back to its base).

## Visual overhaul — matching the reference screenshots more closely
Compared my build's screenshot against the reference game's screenshots the
person shared, and closed the gaps that were actually closable in code:
- Board: wooden/orange rounded frame, white playfield, circular home yards
  (were plain white squares), gray star safe cells, white travel-direction
  chevrons on each color's entry cell.
- Tokens: styled piece (colored disc + white ring + colored star + drop
  shadow) instead of a flat circle. Stacked pieces now show a numbered
  badge, and two colors sharing a safe cell are drawn offset — so you can
  always tell how many pieces are on a square.
- Players: each player now sits at their own corner of the board with an
  avatar (color-tinted ring) + name + their OWN dice, top players rotated
  180° so they face the board — replaces the single status-text line.
- Rolling: tap your own dice to roll (no separate button); the dice shakes
  and spins through random faces before landing on the real result, with a
  green arrow marking whose turn it is and inactive dice dimmed.
- Movement: a soft step tick on each box as the piece walks.
All drawn in code; no artwork, sound, or code copied from the reference app.
Still not matched (would need an artist / real asset pipeline): painted
3D artwork, gradient backgrounds, character illustrations, animated
victory sequences, and the reference's globe/decorative path icons.

## Honest caveats
- **This was not compiled.** The sandbox that wrote this code has no network
  access, so it can't download the Android Gradle Plugin, Kotlin compiler, or
  Gradle wrapper jar to actually build/run it. Open it in Android Studio and
  hit Sync — that's the first real build/test pass. I re-read every file by
  hand for syntax/logic errors, but treat that as "should compile," not "did compile."
- **No launcher icon** — `AndroidManifest.xml` points at `@mipmap/ic_launcher`,
  which doesn't exist yet. Use Android Studio's Image Asset tool (right-click
  `res` → New → Image Asset) before your first build or it'll fail on that.
- **No gradlew wrapper jar** — Android Studio will offer to generate one on
  first open; let it.
- 4-player and 3-player games, team mode pairing, and the online-sync layer
  (server, matchmaking, reconnect) aren't built yet — the engine's `GameState`
  is already the exact object a server would serialize/broadcast, so that
  layer plugs in without changing engine logic.

## Suggested next slices (small, testable, in order)
1. Real board rendering (Canvas/Compose) + tap-to-select tokens, replacing
   the text placeholder screen — sections 7-9 of the spec.
2. Local multiplayer (3-4 players, same device, pass-and-play).
3. Coins/XP/profile persistence (Room database) + daily reward + missions.
4. Server-authoritative online play: this is the point where I'd need you to
   provide a backend target (Firebase project, or a server you control) —
   see spec section 45/46. I won't pretend one is already configured.

## Scope note on the original master prompt
The uploaded spec asks for a full commercial-grade game (online multiplayer,
matchmaking, private rooms, chat, monetization architecture, Play Store
release) — that's realistically weeks of work, not one response. I built the
foundation everything else stacks on and I'm stopping here to check in before
going further, per the spec's own "build in phases, don't dump everything
at once" instruction (section 40/45).
