package com.example.ludoroyale.engine

import java.security.SecureRandom

/**
 * Dice source.
 *
 * FAIRNESS MODE (default): each player draws from their OWN shuffled bag
 * holding one of each face, 1..6. A face leaves the bag when it is drawn, and
 * the bag is reshuffled once empty. So every player gets exactly the same
 * faces over each set of six rolls — nobody sits there getting nothing while
 * someone else keeps rolling sixes — yet the ORDER is genuinely random, so a
 * roll still feels like a roll. This balances luck between players; it does
 * not favour any one of them.
 *
 * PURE MODE ([balanced] = false): plain uniform 1..6 from SecureRandom.
 *
 * LUCKY ([lucky] = true): rolls twice and keeps the higher face, applied
 * identically to every player. Speeds the game up; favours nobody.
 */
class DiceRoller(
    private val random: SecureRandom = SecureRandom(),
    private val lucky: Boolean = false,
    private val balanced: Boolean = true
) {
    private val bags = mutableMapOf<String, MutableList<Int>>()

    private fun freshBag(): MutableList<Int> =
        (1..6).toMutableList().also { it.shuffle(java.util.Random(random.nextLong())) }

    private fun drawFromBag(playerId: String): Int {
        val bag = bags.getOrPut(playerId) { freshBag() }
        if (bag.isEmpty()) bags[playerId] = freshBag()
        return bags.getValue(playerId).removeAt(0)
    }

    /** [playerId] is only used to keep each player's fairness bag separate. */
    fun roll(playerId: String = "solo"): Int {
        if (!balanced) {
            val first = 1 + random.nextInt(6)
            if (!lucky) return first
            return maxOf(first, 1 + random.nextInt(6))
        }
        val first = drawFromBag(playerId)
        if (!lucky) return first
        return maxOf(first, drawFromBag(playerId))
    }
}
