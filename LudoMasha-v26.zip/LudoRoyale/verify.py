#!/usr/bin/env python3
"""
Pre-build verification for LUDO MASHA.

This sandbox has no Android SDK or Gradle, so the real compiler cannot run
here. This script checks, statically, every class of mistake that has actually
broken a build on this project so far. Run it before packaging.

Exit code 0 = all checks pass, 1 = at least one problem found.
"""
import glob
import os
import math
import re
import sys
import xml.dom.minidom

ROOT = os.path.dirname(os.path.abspath(__file__))
MAIN = os.path.join(ROOT, "app/src/main")
problems = []


def report(check, detail):
    problems.append(f"{check}: {detail}")


# ---------------------------------------------------------------- resources
def values_files():
    return glob.glob(os.path.join(MAIN, "res/values*/*.xml"))


def check_duplicate_resources():
    """Two <string name="x"> in one file fails mergeDebugResources."""
    for f in values_files():
        names = re.findall(r'name="([A-Za-z0-9_.]+)"', open(f, encoding="utf-8").read())
        seen, dupes = set(), set()
        for n in names:
            if n in seen:
                dupes.add(n)
            seen.add(n)
        for d in sorted(dupes):
            report("DUPLICATE RESOURCE", f"{os.path.basename(f)} defines '{d}' more than once")


def defined(kind):
    out = set()
    for f in values_files():
        src = open(f, encoding="utf-8").read()
        out |= set(re.findall(r'<' + kind + r'\s+name="([A-Za-z0-9_.]+)"', src))
    return out


def referenced(kind, rprefix):
    out = set()
    for f in glob.glob(os.path.join(ROOT, "app/src/**/*.kt"), recursive=True):
        out |= set(re.findall(r"R\." + rprefix + r"\.([A-Za-z0-9_]+)", open(f).read()))
    for f in glob.glob(os.path.join(MAIN, "res/**/*.xml"), recursive=True):
        out |= set(re.findall(r"@" + kind + r"/([A-Za-z0-9_.]+)", open(f, encoding="utf-8").read()))
    manifest = os.path.join(MAIN, "AndroidManifest.xml")
    out |= set(re.findall(r"@" + kind + r"/([A-Za-z0-9_.]+)", open(manifest, encoding="utf-8").read()))
    return out


def check_missing_resources():
    for kind, rprefix in [("string", "string"), ("color", "color")]:
        missing = referenced(kind, rprefix) - defined(kind)
        for m in sorted(missing):
            report("MISSING RESOURCE", f"@{kind}/{m} referenced but never defined")

    # drawables live as files, not <item> entries
    have = set()
    for d in glob.glob(os.path.join(MAIN, "res/drawable*")) + glob.glob(os.path.join(MAIN, "res/mipmap*")):
        for f in os.listdir(d):
            have.add(os.path.splitext(f)[0])
    used = referenced("drawable", "drawable") | referenced("mipmap", "mipmap")
    for m in sorted(used - have):
        report("MISSING RESOURCE", f"drawable/mipmap '{m}' referenced but no such file")


def check_ids():
    declared = set()
    for f in glob.glob(os.path.join(MAIN, "res/layout/*.xml")):
        declared |= set(re.findall(r'android:id="@\+id/([A-Za-z0-9_]+)"', open(f, encoding="utf-8").read()))
    used = set()
    for f in glob.glob(os.path.join(ROOT, "app/src/main/**/*.kt"), recursive=True):
        used |= set(re.findall(r"R\.id\.([A-Za-z0-9_]+)", open(f).read()))
    for m in sorted(used - declared):
        report("MISSING ID", f"R.id.{m} used in code but not in any layout")


# ------------------------------------------------------------------- kotlin
def kt_files():
    return glob.glob(os.path.join(ROOT, "app/src/**/*.kt"), recursive=True)


DECL = re.compile(r"^    (?:private |internal )?(?:lateinit )?va[lr] ([A-Za-z_][A-Za-z0-9_]*)")


def check_duplicate_declarations():
    """Two 'private val x' in the body of one class is a conflicting declaration.

    Only body members count. A line inside a primary constructor's parameter
    list is indented the same way but belongs to that constructor, so the scan
    tracks bracket depth and skips anything that is not at depth zero. Brace
    depth separates one top-level class in a file from the next, so two data
    classes that each carry a 'val id' are left alone.
    """
    for f in kt_files():
        src = open(f).read()
        brackets = 0          # ( and [ — constructor and call argument lists
        braces = 0            # { } — which class body we are in
        scopes = {}
        for line in src.splitlines():
            if brackets == 0:
                m = DECL.match(line)
                if m:
                    seen = scopes.setdefault(braces, set())
                    if m.group(1) in seen:
                        report("DUPLICATE DECLARATION",
                               f"{os.path.basename(f)} declares '{m.group(1)}' more than once")
                    seen.add(m.group(1))
            code = re.sub(r'"[^"]*"|//.*', "", line)
            brackets += code.count("(") + code.count("[") - code.count(")") - code.count("]")
            brackets = max(brackets, 0)
            opened = code.count("{")
            closed = code.count("}")
            braces += opened - closed
            if closed and braces <= 1:
                # a top-level class just ended — its members go out of scope
                scopes = {k: v for k, v in scopes.items() if k <= braces}


def check_braces():
    for f in kt_files():
        src = open(f).read()
        if src.count("{") != src.count("}"):
            report("UNBALANCED BRACES", os.path.basename(f))


ANDROID_TYPES = {
    "android.widget": ["RadioGroup", "RadioButton", "CheckBox", "EditText", "TextView",
                       "Button", "FrameLayout", "LinearLayout", "ImageView", "Toast"],
    "android.view": ["View", "MotionEvent", "Gravity"],
    "android.graphics": ["Canvas", "Color", "Paint", "Path", "RectF", "Rect",
                         "LinearGradient", "RadialGradient", "Shader"],
    "android.content": ["Context", "Intent"],
    "android.content.res": ["ColorStateList"],
    "android.os": ["Bundle", "Handler", "Looper"],
    "android.util": ["AttributeSet"],
    "android.media": ["AudioAttributes", "AudioFormat", "AudioTrack"],
    "androidx.appcompat.app": ["AlertDialog", "AppCompatActivity"],
}


def check_imports():
    cls_to_pkg = {c: p for p, cs in ANDROID_TYPES.items() for c in cs}
    for f in kt_files():
        src = open(f).read()
        body = re.sub(r"^import .*$", "", src, flags=re.M)
        imported = {i.rsplit(".", 1)[1] for i in re.findall(r"^import ([\w.]+)", src, flags=re.M)}
        for cls, pkg in cls_to_pkg.items():
            if not re.search(r"\b" + cls + r"\b", body):
                continue
            if cls in imported or f"{pkg}.{cls}" in body:
                continue
            if re.search(r"\b(class|object|interface) " + cls + r"\b", src):
                continue
            report("MISSING IMPORT", f"{os.path.basename(f)} uses {cls} (needs {pkg}.{cls})")


def check_custom_views():
    """A view named in XML must exist as a class."""
    classes = set()
    for f in kt_files():
        for m in re.findall(r"^(?:class|object) ([A-Za-z0-9_]+)", open(f).read(), re.M):
            classes.add(m)
    for f in glob.glob(os.path.join(MAIN, "res/layout/*.xml")):
        for fq in re.findall(r"<(com\.example\.ludoroyale\.[A-Za-z0-9_.]+)", open(f, encoding="utf-8").read()):
            if fq.rsplit(".", 1)[1] not in classes:
                report("MISSING CLASS", f"{os.path.basename(f)} uses <{fq}> but no such class")


def check_manifest_activities():
    manifest = open(os.path.join(MAIN, "AndroidManifest.xml"), encoding="utf-8").read()
    classes = set()
    for f in kt_files():
        for m in re.findall(r"^class ([A-Za-z0-9_]+)", open(f).read(), re.M):
            classes.add(m)
    for name in re.findall(r'android:name="(\.[A-Za-z0-9_.]+)"', manifest):
        if name.rsplit(".", 1)[1] not in classes:
            report("MISSING ACTIVITY", f"manifest declares {name} but no such class")


def check_xml_wellformed():
    targets = glob.glob(os.path.join(MAIN, "res/**/*.xml"), recursive=True)
    targets.append(os.path.join(MAIN, "AndroidManifest.xml"))
    for f in targets:
        try:
            xml.dom.minidom.parse(f)
        except Exception as e:
            report("BAD XML", f"{os.path.relpath(f, ROOT)}: {e}")


def catalog_ids(kind):
    """The cosmetic ids the catalog declares for one type."""
    src = open(os.path.join(MAIN, "java/com/example/ludoroyale/cosmetics/Catalog.kt")).read()
    consts = dict(re.findall(r'const val (\w+) = "([^"]+)"', src))
    out = set()
    for name, ctype in re.findall(r"item\((\w+),[^,]+, CosmeticType\.(\w+)", src):
        if ctype == kind and name in consts:
            out.add(consts[name])
    return out


def check_cosmetic_art():
    """Every cosmetic in the catalog must have artwork, and the other way round.

    The catalog decides what exists and what it costs; separate files hold the
    colours. That split is what keeps a re-price from touching a renderer — but
    it also means the two can drift, and a cosmetic with no artwork would be a
    blank square in the shop. So they are checked against each other here.
    """
    pairs = [
        # a dice is either drawn from colours, or a picture with a fallback row
        ("DICE_SKIN", "DiceSkins.kt",
         r'(?:DiceSkin|picture)\(\s*(?:Cosmetics\.(\w+)|"([^"]+)")'),
        ("TOKEN_SKIN", "cosmetics/TokenArt.kt", r"TokenArt\(Cosmetics\.(\w+)()"),
    ]
    catalog_src = open(os.path.join(MAIN, "java/com/example/ludoroyale/cosmetics/Catalog.kt")).read()
    consts = dict(re.findall(r'const val (\w+) = "([^"]+)"', catalog_src))

    for kind, path, pattern in pairs:
        art_src = open(os.path.join(MAIN, "java/com/example/ludoroyale", path)).read()
        drawn = set()
        for a, b in re.findall(pattern, art_src):
            drawn.add(consts.get(a, a) if a else b)
        declared = catalog_ids(kind)
        for missing in sorted(declared - drawn):
            report("COSMETIC WITHOUT ART", f"{kind} '{missing}' is in the catalog but not in {path}")
        for orphan in sorted(drawn - declared):
            report("ART WITHOUT COSMETIC", f"{kind} '{orphan}' is drawn in {path} but not in the catalog")


def check_dice_pictures():
    """Every picture dice must have all six faces, and nothing spare.

    A dice that is a picture depends on twelve separate things lining up: an id
    in the catalog, six entries in DiceFaceArt and six files on disk. Miss one
    and the player gets a blank square for exactly one number, which is the
    kind of fault that survives a whole play-through without being noticed.
    """
    art_path = os.path.join(MAIN, "java/com/example/ludoroyale/DiceFaceArt.kt")
    if not os.path.exists(art_path):
        return
    art = open(art_path).read()
    consts = dict(re.findall(r'const val (\w+) = "([^"]+)"',
                             open(os.path.join(MAIN, "java/com/example/ludoroyale/cosmetics/Catalog.kt")).read()))

    listed = set()
    for name in re.findall(r"Cosmetics\.(\w+) to intArrayOf", art):
        listed.add(consts.get(name, name))

    drawables = set()
    for folder in glob.glob(os.path.join(MAIN, "res/drawable*")):
        for f in os.listdir(folder):
            drawables.add(os.path.splitext(f)[0])

    catalog_dice = catalog_ids("DICE_SKIN")

    for ident in sorted(listed):
        if ident not in catalog_dice:
            report("DICE PICTURE UNLISTED", f"'{ident}' has artwork but is not in the catalog")
        for value in range(1, 7):
            if f"{ident}_{value}" not in drawables:
                report("DICE FACE MISSING", f"{ident}: no drawable for face {value}")

    # every face named in the code must actually exist
    for name in sorted(set(re.findall(r"R\.drawable\.(dx_\w+)", art))):
        if name not in drawables:
            report("DICE FACE MISSING", f"R.drawable.{name} is referenced but there is no such file")


def check_engine_is_pure():
    """The rules engine must never be able to see progression or Android.

    This is the fairness rule made mechanical. If the engine could read a
    player's level or their coins, a future change could quietly let those
    influence a roll. It cannot read them, and this check is what keeps it so.
    """
    banned = ("android.", "com.example.ludoroyale.progression", "com.example.ludoroyale.cosmetics")
    for f in kt_files():
        rel = os.path.relpath(f, ROOT)
        if "/engine/" not in rel and "/ai/" not in rel and "/model/" not in rel:
            continue
        if "/test/" in rel:
            continue
        for imp in re.findall(r"^import ([\w.]+)", open(f).read(), flags=re.M):
            if imp.startswith(banned):
                report("ENGINE NOT PURE", f"{rel} imports {imp}")


def check_theme_readability():
    """A themed board still has to be a board you can read.

    Atmosphere is not allowed to cost legibility, so this measures the three
    worlds rather than trusting them: the two square colours must be far apart
    in brightness, and each number colour must stand well clear of the square
    it is printed on. It lives here, not in a unit test, because every colour
    in SnlTheme.kt comes from android.graphics.Color, which only exists on a
    real device.
    """
    path = os.path.join(MAIN, "java/com/example/ludoroyale/snl/SnlTheme.kt")
    src = open(path).read()

    def lum(r, g, b):
        return (r * 299 + g * 587 + b * 114) // 1000

    # every "name = rgb(r, g, b)" inside each theme block
    for block in re.findall(r"val (\w+) = SnlTheme\((.*?)\n        \)", src, re.S):
        name, body = block
        fields = {}
        for field, r, g, b in re.findall(r"(\w+) = rgb\((0x[0-9A-Fa-f]+|\d+), *(0x[0-9A-Fa-f]+|\d+), *(0x[0-9A-Fa-f]+|\d+)\)", body):
            fields[field] = lum(int(r, 0), int(g, 0), int(b, 0))

        need = ("tilePale", "tileDark", "numberOnPale", "numberOnDark")
        if not all(k in fields for k in need):
            report("THEME INCOMPLETE", f"{name} is missing one of {need}")
            continue

        gap = abs(fields["tilePale"] - fields["tileDark"])
        if gap < 60:
            report("THEME UNREADABLE",
                   f"{name}: the two square colours are only {gap} apart in brightness")

        for number, tile in (("numberOnPale", "tilePale"), ("numberOnDark", "tileDark")):
            contrast = abs(fields[number] - fields[tile])
            if contrast < 80:
                report("THEME UNREADABLE",
                       f"{name}: {number} is only {contrast} from {tile}")


def check_snl_shapes_do_not_touch():
    """No snake or ladder may touch another one on the 1-100 board.

    The tables were produced by a search that measured this, but a table can be
    edited by hand afterwards and a width can be changed in the renderer, and
    either would quietly put two shapes back on top of each other. So the check
    is repeated here, from the two files that actually decide it: the widths in
    SnlBoardView.kt and the squares in SnlConfig.kt.
    """
    board = open(os.path.join(MAIN, "java/com/example/ludoroyale/snl/SnlBoardView.kt")).read()
    cfg = open(os.path.join(MAIN, "java/com/example/ludoroyale/snl/SnlConfig.kt")).read()

    def const(name, default):
        m = re.search(r"const val " + name + r" = ([0-9.]+)f", board)
        return float(m.group(1)) if m else default

    snake_w = const("SNAKE_MAX_W", 0.22)
    ladder_half = const("LADDER_HALF", 0.24)

    # buildSpine() has two `when` blocks: wave counts first, then amplitudes.
    # Each contributes one line per named span, so four values in all.
    waves_amp = re.findall(r"span >= (\d+) -> ([0-9.]+)f", board)
    if len(waves_amp) != 4:
        report("SPINE UNREADABLE",
               f"buildSpine() gave {len(waves_amp)} tuning values, expected 4 — "
               "this check can no longer prove the shapes stay apart")
        return
    waves = {40: float(waves_amp[0][1]), 26: float(waves_amp[1][1])}
    amps = {40: float(waves_amp[2][1]), 26: float(waves_amp[3][1])}

    def wave_amp(span):
        if span >= 40:
            return waves.get(40, 1.40), amps.get(40, 0.62)
        if span >= 26:
            return waves.get(26, 1.10), amps.get(26, 0.50)
        return 0.85, 0.38

    def grid(cell):
        i = cell - 1
        rfb, within = divmod(i, 10)
        col = within if rfb % 2 == 0 else 9 - within
        return (9 - rfb, col)

    def centre(cell):
        r, c = grid(cell)
        return (c + 0.5, r + 0.5)

    def points(kind, a, b):
        pa, pb = centre(a), centre(b)
        dx, dy = pb[0] - pa[0], pb[1] - pa[1]
        if kind == "ladder":
            return [(pa[0] + dx * i / 40.0, pa[1] + dy * i / 40.0) for i in range(41)], ladder_half
        length = max(math.hypot(dx, dy), 1e-6)
        nx, ny = -dy / length, dx / length
        w, amp = wave_amp(abs(a - b))
        out = []
        for i in range(41):
            t = i / 40.0
            off = amp * (math.sin(t * math.pi) ** 0.65) * math.sin(t * w * 2 * math.pi)
            x = min(max(pa[0] + dx * t + nx * off, 0.20), 9.80)
            y = min(max(pa[1] + dy * t + ny * off, 0.20), 9.80)
            out.append((x, y))
        return out, snake_w / 2.0

    for table in ("EASY", "MEDIUM", "HARD"):
        m = re.search(r"private val " + table + r": List<SnlSpecial> = listOf\((.*?)\n    \)", cfg, re.S)
        if not m:
            report("BOARD TABLE MISSING", table)
            continue
        shapes = []
        for kind, a, b in re.findall(r"(snake|ladder)\(\"[^\"]+\", SpecialSize\.\w+, (\d+), (\d+),", m.group(1)):
            shapes.append((kind, int(a), int(b)) + points(kind, int(a), int(b)))

        for i in range(len(shapes)):
            for j in range(i + 1, len(shapes)):
                ka, aa, ab, pa, ha = shapes[i]
                kb, ba, bb, pb, hb = shapes[j]
                closest = min(math.dist(p, q) for p in pa for q in pb)
                if closest < ha + hb:
                    report("SHAPES TOUCH",
                           f"{table}: {ka} {aa}->{ab} touches {kb} {ba}->{bb}")


def main():
    check_xml_wellformed()
    check_duplicate_resources()
    check_missing_resources()
    check_ids()
    check_duplicate_declarations()
    check_braces()
    check_imports()
    check_custom_views()
    check_manifest_activities()
    check_cosmetic_art()
    check_dice_pictures()
    check_engine_is_pure()
    check_theme_readability()
    check_snl_shapes_do_not_touch()

    if problems:
        print(f"FAILED — {len(problems)} problem(s):\n")
        for p in problems:
            print("  " + p)
        return 1
    print("All pre-build checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
