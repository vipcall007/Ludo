package com.example.ludoroyale

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Original sound effects synthesised on the fly and written straight into an
 * AudioTrack — no audio files are bundled and nothing is copied from anywhere.
 *
 * The dice is the important one. A dice thrown on a board is not an even
 * rattle: it is one hard first strike, then a few bounces that get closer
 * together and quieter as it loses energy, then silence. [diceRoll] is built
 * from that shape — the gap between bounces shrinks by a fixed factor each
 * time, which is what makes it sound thrown rather than shaken.
 *
 * There is no background music. The game is quiet between actions on purpose.
 */
object SoundFx {

    private const val RATE = 22050
    private val exec = Executors.newSingleThreadExecutor()
    private val rnd = Random(System.nanoTime())

    var enabled: Boolean = true

    // ------------------------------------------------------------- the sounds

    /**
     * A dice thrown into a wooden cup, then tipped out.
     *
     * The old one was a long even rattle, which is what a dice shaken in a
     * closed fist sounds like — not what a dice thrown on a board sounds like.
     * A thrown dice is a sharp first impact, then three or four bounces that
     * get closer together and quieter as it loses energy, then it stops. So
     * that is what this is: real bounce spacing, not a uniform buzz.
     */
    fun diceRoll() {
        val ms = 620
        val buf = DoubleArray(RATE * ms / 1000)

        // the throw: one bright, hard first strike
        knock(buf, 10.0, 26.0, 240.0, 3600.0, 0.62, decay = 8.0)

        // the bounces, each closer to the last and softer
        var at = 78.0
        var gap = 96.0
        var level = 0.52
        while (at < ms - 90 && gap > 16.0) {
            knock(buf, at, 22.0 + rnd.nextDouble() * 10.0,
                  200.0 + rnd.nextDouble() * 90.0,
                  2200.0 + rnd.nextDouble() * 1400.0,
                  level, decay = 9.5)
            at += gap
            gap *= 0.68                      // energy lost on every bounce
            level *= 0.74
        }

        // a short skitter as it turns over, then it settles
        var skit = at
        while (skit < ms - 40) {
            knock(buf, skit, 14.0, 300.0, 5200.0, 0.10, decay = 14.0)
            skit += 11.0 + rnd.nextDouble() * 7.0
        }
        knock(buf, (ms - 44).toDouble(), 40.0, 140.0, 900.0, 0.38, decay = 6.5)
        render(buf)
    }

    /**
     * The turn passing to the next player.
     *
     * Slow and soft on purpose — it marks a change rather than announcing one,
     * so it can play every single turn without becoming irritating. Two low
     * notes a fifth apart, the second rising, with a long tail.
     */
    fun turnChange() {
        val buf = DoubleArray(RATE * 620 / 1000)
        tone(buf, 0.0, 300.0, 196.00, 0.20, endFreq = 196.00)
        tone(buf, 150.0, 420.0, 293.66, 0.17, endFreq = 329.63)
        // a breath of air underneath, so it does not sound like a beep
        knock(buf, 0.0, 240.0, 120.0, 500.0, 0.07, decay = 2.2)
        render(buf)
    }

    /**
     * A snake striking.
     *
     * A short hiss that steepens into the bite, then the dull thud of it
     * landing. It plays the moment the counter is caught, before the slide.
     */
    fun snakeBite() {
        val ms = 420
        val buf = DoubleArray(RATE * ms / 1000)
        // the hiss: band-limited noise high up, rising as the strike comes in
        var at = 0.0
        while (at < 170.0) {
            val t = at / 170.0
            knock(buf, at, 30.0, 2600.0 + 2200.0 * t, 9000.0 + 3000.0 * t, 0.13 + 0.10 * t, decay = 2.0)
            at += 12.0
        }
        // the strike
        knock(buf, 176.0, 46.0, 420.0, 6200.0, 0.58, decay = 9.0)
        // and the weight of it
        tone(buf, 186.0, 200.0, 150.0, 0.30, endFreq = 82.0)
        knock(buf, 190.0, 120.0, 90.0, 420.0, 0.22, decay = 5.0)
        render(buf)
    }

    /** One crisp tick as a piece hops a square. */
    fun step() {
        val buf = DoubleArray(RATE * 40 / 1000)
        knock(buf, 0.0, 34.0, 1800.0, 7200.0, 0.30, decay = 11.0)
        render(buf)
    }

    /** The softer knock when a piece settles at the end of its move. */
    fun tokenMove() {
        val buf = DoubleArray(RATE * 70 / 1000)
        knock(buf, 0.0, 60.0, 420.0, 2300.0, 0.34, decay = 8.0)
        render(buf)
    }

    /** A hard clack, then a short drop — something just got sent home. */
    fun capture() {
        val buf = DoubleArray(RATE * 340 / 1000)
        knock(buf, 0.0, 70.0, 260.0, 4200.0, 0.52, decay = 7.0)
        tone(buf, 60.0, 190.0, 520.0, 0.30, endFreq = 190.0)
        render(buf)
    }

    /** Wind under the piece as an arrow carries it. */
    fun arrow() {
        val ms = 300
        val buf = DoubleArray(RATE * ms / 1000)
        var at = 0.0
        while (at < ms - 40) {
            val t = at / ms
            val centre = 500.0 + 3400.0 * t
            knock(buf, at, 46.0, centre * 0.55, centre * 1.7, 0.16 * (1.0 - t * 0.35), decay = 3.2)
            at += 14.0
        }
        tone(buf, 40.0, 240.0, 520.0, 0.16, endFreq = 1500.0)
        render(buf)
    }

    /** Rungs going by, one after another. */
    fun ladderClimb() {
        val buf = DoubleArray(RATE * 380 / 1000)
        for (i in 0 until 6) {
            knock(buf, i * 58.0, 46.0, 500.0 + i * 180.0, 2400.0 + i * 500.0, 0.26, decay = 7.0)
        }
        render(buf)
    }

    /** A long slide down. */
    fun snakeSlide() {
        val buf = DoubleArray(RATE * 460 / 1000)
        tone(buf, 0.0, 420.0, 900.0, 0.30, endFreq = 180.0)
        var at = 0.0
        while (at < 400) {
            knock(buf, at, 40.0, 240.0, 1500.0, 0.10, decay = 4.0)
            at += 26.0
        }
        render(buf)
    }

    /** Small sparkle for a bonus. */
    fun magic() {
        val buf = DoubleArray(RATE * 340 / 1000)
        tone(buf, 0.0, 90.0, 880.0, 0.26)
        tone(buf, 70.0, 90.0, 1175.0, 0.24)
        tone(buf, 140.0, 140.0, 1568.0, 0.22)
        render(buf)
    }

    /** Short fanfare. */
    fun win() {
        val buf = DoubleArray(RATE * 780 / 1000)
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
        notes.forEachIndexed { i, f ->
            tone(buf, i * 150.0, if (i == 3) 300.0 else 170.0, f, 0.30)
        }
        render(buf)
    }

    /** Two low taps — the turn is gone. */
    fun turnLost() {
        val buf = DoubleArray(RATE * 380 / 1000)
        tone(buf, 0.0, 150.0, 330.0, 0.28, endFreq = 247.0)
        tone(buf, 170.0, 190.0, 247.0, 0.26, endFreq = 165.0)
        render(buf)
    }

    /** A short step backwards — the same two taps as a lost turn, in reverse. */
    fun undo() {
        val buf = DoubleArray(RATE * 300 / 1000)
        knock(buf, 0.0, 50.0, 300.0, 2600.0, 0.26, decay = 9.0)
        tone(buf, 30.0, 190.0, 300.0, 0.22, endFreq = 470.0)
        render(buf)
    }

    /** The chest: a lid creaking open, then coins landing. */
    fun chest() {
        val ms = 900
        val buf = DoubleArray(RATE * ms / 1000)
        // the hinge
        knock(buf, 0.0, 120.0, 130.0, 900.0, 0.34, decay = 5.0)
        tone(buf, 20.0, 220.0, 180.0, 0.16, endFreq = 300.0)
        // coins tumbling in
        var at = 220.0
        while (at < ms - 120) {
            knock(buf, at, 40.0, 2200.0, 9000.0, 0.16 + rnd.nextDouble() * 0.10, decay = 13.0)
            at += 26.0 + rnd.nextDouble() * 34.0
        }
        // and a small bright flourish
        tone(buf, 430.0, 120.0, 784.0, 0.22)
        tone(buf, 540.0, 120.0, 1046.50, 0.22)
        tone(buf, 650.0, 220.0, 1318.51, 0.24)
        render(buf)
    }

    /** A brief roll of the table as the match opens. */
    fun gameStart() {
        val buf = DoubleArray(RATE * 460 / 1000)
        tone(buf, 0.0, 130.0, 392.0, 0.26)
        tone(buf, 120.0, 130.0, 523.25, 0.26)
        tone(buf, 240.0, 200.0, 659.25, 0.28)
        render(buf)
    }

    // ------------------------------------------------------------- synthesis

    /**
     * A short burst of band-limited noise — one knock of wood on wood. The two
     * one-pole filters in series keep the energy between [lowHz] and [highHz],
     * which is what makes it read as a knock rather than a hiss.
     */
    private fun knock(
        buf: DoubleArray,
        atMs: Double,
        lenMs: Double,
        lowHz: Double,
        highHz: Double,
        vol: Double,
        decay: Double
    ) {
        val start = (atMs * RATE / 1000.0).toInt()
        val len = (lenMs * RATE / 1000.0).toInt()
        if (start >= buf.size || len <= 0) return
        val aLp = 1.0 - exp(-2.0 * PI * highHz / RATE)
        val aHp = 1.0 - exp(-2.0 * PI * lowHz / RATE)
        var lp = 0.0
        var hp = 0.0
        val end = min(buf.size, start + len)
        for (i in start until end) {
            val white = rnd.nextDouble() * 2.0 - 1.0
            lp += (white - lp) * aLp
            hp += (lp - hp) * aHp
            val band = lp - hp
            val k = (i - start).toDouble() / len
            buf[i] += band * exp(-decay * k) * vol
        }
    }

    /** A plain tone, optionally sliding to [endFreq]. */
    private fun tone(
        buf: DoubleArray,
        atMs: Double,
        lenMs: Double,
        freq: Double,
        vol: Double,
        endFreq: Double = -1.0
    ) {
        val start = (atMs * RATE / 1000.0).toInt()
        val len = (lenMs * RATE / 1000.0).toInt()
        if (start >= buf.size || len <= 0) return
        val end = min(buf.size, start + len)
        var phase = 0.0
        for (i in start until end) {
            val k = (i - start).toDouble() / len
            val f = if (endFreq > 0) freq + (endFreq - freq) * k else freq
            phase += 2.0 * PI * f / RATE
            // quick attack, smooth tail, so nothing clicks at the edges
            val env = if (k < 0.06) k / 0.06 else exp(-3.2 * (k - 0.06))
            buf[i] += sin(phase) * env * vol
        }
    }

    private fun render(buf: DoubleArray) {
        if (!enabled) return
        exec.execute {
            try {
                val pcm = ShortArray(buf.size)
                for (i in buf.indices) {
                    val v = buf[i].coerceIn(-1.0, 1.0)
                    pcm[i] = (v * 32767).toInt().toShort()
                }
                val bytes = pcm.size * 2
                if (bytes <= 0) return@execute
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(pcm, 0, pcm.size)
                track.setNotificationMarkerPosition(pcm.size)
                track.setPlaybackPositionUpdateListener(
                    object : AudioTrack.OnPlaybackPositionUpdateListener {
                        override fun onMarkerReached(t: AudioTrack?) {
                            try { t?.stop(); t?.release() } catch (_: Exception) {}
                        }
                        override fun onPeriodicNotification(t: AudioTrack?) = Unit
                    }
                )
                track.play()
            } catch (_: Exception) {
                // audio is a nicety — never let it take the game down
            }
        }
    }
}
