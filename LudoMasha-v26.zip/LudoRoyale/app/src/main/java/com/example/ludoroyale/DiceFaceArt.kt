package com.example.ludoroyale

import com.example.ludoroyale.cosmetics.Cosmetics

/**
 * The dice that are pictures rather than drawings.
 *
 * Every other dice in the game is built from a handful of colours and drawn by
 * [DiceView] at whatever size it is asked for. These twelve are rendered
 * isometric cubes supplied as artwork, so there is nothing to compute: the
 * right face is simply drawn into the view.
 *
 * WHY BOTH KINDS EXIST. A drawn dice costs nothing to ship, stays razor sharp
 * on any screen and can be re-coloured by editing one line. A picture can show
 * things no amount of gradient code will — a dragon, a face, a rendered metal
 * edge. Neither is better; they are for different jobs, so the game keeps both
 * and [DiceView] decides which path to take from the id alone.
 *
 * FAIRNESS, unchanged: a dice skin is a picture. It is not visible to
 * [com.example.ludoroyale.engine.DiceRoller], so every one of these rolls from
 * exactly the same distribution as the free one.
 */
object DiceFaceArt {

    /**
     * id to the six faces, in order 1..6.
     *
     * The resource names are written out rather than looked up by string at
     * runtime: that way a missing or misspelled file is a compile error here
     * instead of a blank square on somebody's phone.
     */
    private val FACES: Map<String, IntArray> = mapOf(
        Cosmetics.DX_HEART to intArrayOf(
            R.drawable.dx_heart_1, R.drawable.dx_heart_2, R.drawable.dx_heart_3,
            R.drawable.dx_heart_4, R.drawable.dx_heart_5, R.drawable.dx_heart_6
        ),
        Cosmetics.DX_GHOST to intArrayOf(
            R.drawable.dx_ghost_1, R.drawable.dx_ghost_2, R.drawable.dx_ghost_3,
            R.drawable.dx_ghost_4, R.drawable.dx_ghost_5, R.drawable.dx_ghost_6
        ),
        Cosmetics.DX_GIFT to intArrayOf(
            R.drawable.dx_gift_1, R.drawable.dx_gift_2, R.drawable.dx_gift_3,
            R.drawable.dx_gift_4, R.drawable.dx_gift_5, R.drawable.dx_gift_6
        ),
        Cosmetics.DX_ROBOT to intArrayOf(
            R.drawable.dx_robot_1, R.drawable.dx_robot_2, R.drawable.dx_robot_3,
            R.drawable.dx_robot_4, R.drawable.dx_robot_5, R.drawable.dx_robot_6
        ),
        Cosmetics.DX_ALIEN to intArrayOf(
            R.drawable.dx_alien_1, R.drawable.dx_alien_2, R.drawable.dx_alien_3,
            R.drawable.dx_alien_4, R.drawable.dx_alien_5, R.drawable.dx_alien_6
        ),
        Cosmetics.DX_WYRM to intArrayOf(
            R.drawable.dx_wyrm_1, R.drawable.dx_wyrm_2, R.drawable.dx_wyrm_3,
            R.drawable.dx_wyrm_4, R.drawable.dx_wyrm_5, R.drawable.dx_wyrm_6
        ),
        Cosmetics.DX_STAR to intArrayOf(
            R.drawable.dx_star_1, R.drawable.dx_star_2, R.drawable.dx_star_3,
            R.drawable.dx_star_4, R.drawable.dx_star_5, R.drawable.dx_star_6
        ),
        Cosmetics.DX_COSMOS to intArrayOf(
            R.drawable.dx_cosmos_1, R.drawable.dx_cosmos_2, R.drawable.dx_cosmos_3,
            R.drawable.dx_cosmos_4, R.drawable.dx_cosmos_5, R.drawable.dx_cosmos_6
        ),
        Cosmetics.DX_EIGHT to intArrayOf(
            R.drawable.dx_eight_1, R.drawable.dx_eight_2, R.drawable.dx_eight_3,
            R.drawable.dx_eight_4, R.drawable.dx_eight_5, R.drawable.dx_eight_6
        ),
        Cosmetics.DX_RUBY to intArrayOf(
            R.drawable.dx_ruby_1, R.drawable.dx_ruby_2, R.drawable.dx_ruby_3,
            R.drawable.dx_ruby_4, R.drawable.dx_ruby_5, R.drawable.dx_ruby_6
        ),
        Cosmetics.DX_KING to intArrayOf(
            R.drawable.dx_king_1, R.drawable.dx_king_2, R.drawable.dx_king_3,
            R.drawable.dx_king_4, R.drawable.dx_king_5, R.drawable.dx_king_6
        ),
        Cosmetics.DX_ROYALS to intArrayOf(
            R.drawable.dx_royals_1, R.drawable.dx_royals_2, R.drawable.dx_royals_3,
            R.drawable.dx_royals_4, R.drawable.dx_royals_5, R.drawable.dx_royals_6
        )
    )

    /** True when this dice is a picture rather than something drawn. */
    fun isPicture(id: String): Boolean = id in FACES

    /** The drawable for [value], or 0 when this dice is drawn in code. */
    fun face(id: String, value: Int): Int {
        val faces = FACES[id] ?: return 0
        return faces[value.coerceIn(1, 6) - 1]
    }

    val ids: Set<String> get() = FACES.keys
}
