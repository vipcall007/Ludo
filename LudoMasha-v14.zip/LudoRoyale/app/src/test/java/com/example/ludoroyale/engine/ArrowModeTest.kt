package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Covers the validation list in the Arrow Mode specification (section 16). */
class ArrowModeTest {

    private fun fourPlayers(): GameState = GameState(
        gameId = "arrow-test",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Green", PlayerColor.GREEN, PlayerKind.HUMAN),
            Player.create("p3", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN),
            Player.create("p4", "Blue", PlayerColor.BLUE, PlayerKind.HUMAN)
        )
    )

    private fun engine(state: GameState) = LudoEngine(state, RuleConfig(arrowMode = true))

    private fun bank(state: GameState, vararg values: Int) {
        state.pendingRolls.clear()
        state.pendingRolls.addAll(values.toList())
        state.phase = TurnPhase.AWAITING_MOVE
        state.lastDiceRoll = values.lastOrNull()
    }

    // ---- there are exactly 8 gameplay arrows ----

    @Test
    fun `exactly eight gameplay arrows, one straight and one home per colour`() {
        assertEquals(8, ArrowConfig.ARROWS.size)
        for (color in PlayerColor.entries) {
            val mine = ArrowConfig.arrowsFor(color)
            assertEquals(2, mine.size)
            assertEquals(1, mine.count { it.type == ArrowType.STRAIGHT })
            assertEquals(1, mine.count { it.type == ArrowType.HOME })
        }
    }

    // ---- tests 1-4: a straight arrow belongs to one colour only ----

    @Test
    fun `green token activates the green straight arrow`() {
        val arrow = ArrowConfig.arrowAt(PlayerColor.GREEN, TokenState.ACTIVE, ArrowConfig.STRAIGHT_ENTRY)
        assertNotNull(arrow)
        assertEquals(PlayerColor.GREEN, arrow!!.color)
        assertEquals(ArrowType.STRAIGHT, arrow.type)
    }

    @Test
    fun `no colour can trigger another colour's straight arrow`() {
        // Arrows are keyed on the colour's OWN step numbers, so the arrow found
        // at a given step is always that same colour's arrow — never anyone else's.
        for (color in PlayerColor.entries) {
            val arrow = ArrowConfig.arrowAt(color, TokenState.ACTIVE, ArrowConfig.STRAIGHT_ENTRY)
            assertNotNull(arrow)
            assertEquals(color, arrow!!.color)
        }
        val green = ArrowConfig.arrowsFor(PlayerColor.GREEN).first { it.type == ArrowType.STRAIGHT }
        assertFalse(green.acceptsToken(PlayerColor.RED, TokenState.ACTIVE))
        assertFalse(green.acceptsToken(PlayerColor.BLUE, TokenState.ACTIVE))
        assertFalse(green.acceptsToken(PlayerColor.YELLOW, TokenState.ACTIVE))
    }

    // ---- tests 5-8: home arrows are private to their colour ----

    @Test
    fun `green token in its home lane activates the green home arrow`() {
        val arrow = ArrowConfig.arrowAt(PlayerColor.GREEN, TokenState.HOME_STRETCH, ArrowConfig.HOME_ENTRY)
        assertNotNull(arrow)
        assertEquals(ArrowType.HOME, arrow!!.type)
        assertEquals(PlayerColor.GREEN, arrow.color)
    }

    @Test
    fun `other colours cannot activate the green home arrow`() {
        val greenHome = ArrowConfig.arrowsFor(PlayerColor.GREEN).first { it.type == ArrowType.HOME }
        assertFalse(greenHome.acceptsToken(PlayerColor.RED, TokenState.HOME_STRETCH))
        assertFalse(greenHome.acceptsToken(PlayerColor.BLUE, TokenState.HOME_STRETCH))
        assertFalse(greenHome.acceptsToken(PlayerColor.YELLOW, TokenState.HOME_STRETCH))
    }

    @Test
    fun `a home arrow ignores a token still on the main route`() {
        // right colour, wrong state
        val greenHome = ArrowConfig.arrowsFor(PlayerColor.GREEN).first { it.type == ArrowType.HOME }
        assertFalse(greenHome.acceptsToken(PlayerColor.GREEN, TokenState.ACTIVE))
    }

    @Test
    fun `a straight arrow ignores a token already in the home lane`() {
        val greenStraight = ArrowConfig.arrowsFor(PlayerColor.GREEN).first { it.type == ArrowType.STRAIGHT }
        assertFalse(greenStraight.acceptsToken(PlayerColor.GREEN, TokenState.HOME_STRETCH))
    }

    // ---- test 9/10: landing triggers, passing over does not ----

    @Test
    fun `passing over an arrow does not trigger it, landing on it does`() {
        val before = ArrowConfig.STRAIGHT_ENTRY - 2
        val state = fourPlayers()
        val e = engine(state)
        state.currentPlayerIndex = 0                    // RED
        val token = state.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = before

        // rolling 4 goes straight past the entry — no arrow
        bank(state, 4)
        val passing = e.legalMovesFor(4).first { it.token.id == token.id }
        val passResult = e.applyMove(passing)
        assertNull("passing over must not fire the arrow", passResult.arrowLandedSteps)
        assertEquals(before + 4, token.steps)

        // now land exactly on it
        val state2 = fourPlayers()
        val e2 = engine(state2)
        state2.currentPlayerIndex = 0
        val t2 = state2.players[0].tokens[0]
        t2.state = TokenState.ACTIVE
        t2.steps = before
        bank(state2, 2)
        val landing = e2.legalMovesFor(2).first { it.token.id == t2.id }
        val landResult = e2.applyMove(landing)
        assertEquals(ArrowConfig.STRAIGHT_EXIT, landResult.arrowLandedSteps)
        assertEquals(ArrowConfig.STRAIGHT_EXIT, t2.steps)
    }

    // ---- test 11: the arrow costs no extra dice roll ----

    @Test
    fun `arrow movement consumes no extra banked value`() {
        val state = fourPlayers()
        val e = engine(state)
        state.currentPlayerIndex = 0
        val token = state.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = ArrowConfig.STRAIGHT_ENTRY - 3

        bank(state, 3, 5)                                // two values banked
        val move = e.legalMovesFor(3).first { it.token.id == token.id }
        e.applyMove(move)
        assertEquals("only the value played should be spent", listOf(5), state.pendingRolls.toList())
    }

    // ---- test 12: no chained arrows ----

    @Test
    fun `an arrow never chains into another arrow`() {
        // the exit of any arrow must not itself be an entry for the same colour
        for (arrow in ArrowConfig.ARROWS) {
            val chained = ArrowConfig.ARROWS.firstOrNull {
                it.color == arrow.color && it.entryStep == arrow.exitStep
            }
            assertNull("arrow exit ${arrow.exitStep} chains into another arrow", chained)
        }
        assertEquals(1, ArrowConfig.MAX_ACTIVATIONS_PER_MOVE)
    }

    // ---- test 13: capture is judged AFTER the arrow ----

    @Test
    fun `capture is checked at the arrow exit, not the dice landing square`() {
        val state = fourPlayers()
        val e = engine(state)
        state.currentPlayerIndex = 0                     // RED moves

        val red = state.players[0].tokens[0]
        red.state = TokenState.ACTIVE
        red.steps = ArrowConfig.STRAIGHT_ENTRY - 1       // one short of the entry

        // park a green token on the square RED's arrow EXIT lands on
        val exitGlobal = LudoBoard.toGlobalIndex(PlayerColor.RED, ArrowConfig.STRAIGHT_EXIT - 1)
        val green = state.players[1].tokens[0]
        green.state = TokenState.ACTIVE
        green.steps = ((exitGlobal - PlayerColor.GREEN.startOffset + LudoBoard.TRACK_LENGTH)
            % LudoBoard.TRACK_LENGTH) + 1

        bank(state, 1)
        val move = e.legalMovesFor(1).first { it.token.id == red.id }
        val result = e.applyMove(move)

        assertEquals(ArrowConfig.STRAIGHT_EXIT, result.arrowLandedSteps)
        assertTrue("the piece sitting on the arrow exit must be cut",
            result.capturedTokens.any { it.id == green.id })
        assertEquals(TokenState.BASE, green.state)
    }

    // ---- test 15: a six still grants its extra roll ----

    @Test
    fun `a six keeps its extra roll even when the move ends on an arrow`() {
        val state = fourPlayers()
        val e = engine(state)
        state.currentPlayerIndex = 0
        val token = state.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = ArrowConfig.STRAIGHT_ENTRY - 6

        // a six banks and demands another roll before anything is moved
        state.pendingRolls.clear()
        state.pendingRolls.add(6)
        state.consecutiveSixes = 1
        state.phase = TurnPhase.AWAITING_MOVE

        val move = e.legalMovesFor(6).first { it.token.id == token.id }
        val result = e.applyMove(move)
        assertEquals(ArrowConfig.STRAIGHT_EXIT, result.arrowLandedSteps)
        assertEquals("the same player keeps the turn", 0, state.currentPlayerIndex)
    }

    // ---- test 14: finishing via the home arrow ----

    @Test
    fun `home arrow never pushes a token past the final square`() {
        for (arrow in ArrowConfig.ARROWS.filter { it.type == ArrowType.HOME }) {
            assertTrue(arrow.exitStep <= LudoEngine.FINISH_STEPS)
            assertTrue("a home arrow must stay inside the home lane",
                arrow.entryStep > LudoBoard.TRACK_LENGTH - 1)
        }
    }

    @Test
    fun `straight arrows stay on the main route`() {
        for (arrow in ArrowConfig.ARROWS.filter { it.type == ArrowType.STRAIGHT }) {
            assertTrue(arrow.entryStep in 1..(LudoBoard.TRACK_LENGTH - 1))
            assertTrue(arrow.exitStep in 1..(LudoBoard.TRACK_LENGTH - 1))
            assertTrue("an arrow must move the piece forward", arrow.exitStep > arrow.entryStep)
        }
    }
}
