package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.TokenState

/** The two kinds of gameplay arrow. Nothing else on the board teleports. */
enum class ArrowType { STRAIGHT, HOME }

/**
 * One gameplay arrow.
 *
 * [entryStep] and [exitStep] are expressed in the OWNING COLOUR'S own step
 * numbers (1..57), which is what makes an arrow belong to exactly one colour:
 * a red token's step 22 is a different square from a green token's step 22, so
 * red can never trigger green's arrow.
 *
 *  - STRAIGHT: both ends on the main circular route (steps 1..51)
 *  - HOME:     both ends inside that colour's own home lane (steps 52..57)
 */
data class Arrow(
    val color: PlayerColor,
    val type: ArrowType,
    val entryStep: Int,
    val exitStep: Int
) {
    /** A token may ride this arrow only if it is the right colour AND the right state. */
    fun acceptsToken(tokenColor: PlayerColor, state: TokenState): Boolean {
        if (tokenColor != color) return false
        return when (type) {
            ArrowType.STRAIGHT -> state == TokenState.ACTIVE
            ArrowType.HOME -> state == TokenState.HOME_STRETCH
        }
    }
}

/**
 * THE board configuration for ARROW MODE — exactly 8 gameplay arrows,
 * one STRAIGHT and one HOME per colour. Positions live here alone so they can
 * be retuned without touching the engine or any drawing code.
 */
object ArrowConfig {

    /** Straight arrow: where it starts / ends on the main route. */
    const val STRAIGHT_ENTRY = 22
    const val STRAIGHT_EXIT = 30

    /** Home arrow: where it starts / ends inside the colour's own home lane. */
    const val HOME_ENTRY = 53
    const val HOME_EXIT = 55

    /** Only ONE arrow may fire per dice move — this is what stops loops. */
    const val MAX_ACTIVATIONS_PER_MOVE = 1

    val ARROWS: List<Arrow> = PlayerColor.entries.flatMap { color ->
        listOf(
            Arrow(color, ArrowType.STRAIGHT, STRAIGHT_ENTRY, STRAIGHT_EXIT),
            Arrow(color, ArrowType.HOME, HOME_ENTRY, HOME_EXIT)
        )
    }

    fun arrowsFor(color: PlayerColor): List<Arrow> = ARROWS.filter { it.color == color }

    /**
     * The arrow a token has just LANDED on, or null. Landing is exact —
     * passing over an arrow's entry never triggers it, because this is only
     * ever asked about the square the token finished its dice move on.
     */
    fun arrowAt(tokenColor: PlayerColor, state: TokenState, landedStep: Int): Arrow? =
        ARROWS.firstOrNull { it.entryStep == landedStep && it.acceptsToken(tokenColor, state) }
}
