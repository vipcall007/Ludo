package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor

/**
 * Pure geometry of a classic Ludo board — no rendering, no Android
 * dependencies. UI layers map these indices onto screen coordinates.
 */
object LudoBoard {
    const val TRACK_LENGTH = 52          // shared outer ring, indices 0..51
    const val HOME_STRETCH_LENGTH = 6    // private final path per color, 0..5
    const val FINAL_INDEX = HOME_STRETCH_LENGTH - 1

    /** Global (0..51) cells that are safe — no captures allowed there. */
    val SAFE_CELLS: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    fun isSafeCell(globalIndex: Int): Boolean = globalIndex in SAFE_CELLS

    /** Converts a token's own relative track position to the shared global index. */
    fun toGlobalIndex(color: PlayerColor, relativeIndex: Int): Int =
        (color.startOffset + relativeIndex) % TRACK_LENGTH

    /** Steps remaining on the shared track before this color enters its home stretch. */
    fun stepsToHomeEntry(color: PlayerColor, relativeIndex: Int): Int {
        val entryRelative = ((color.homeEntryOffset - color.startOffset) + TRACK_LENGTH) % TRACK_LENGTH
        return entryRelative - relativeIndex
    }

    /**
     * ARROW MODE, per the standard rule: there are 12 arrows on the board,
     * 3 in each colour zone. Land on an arrow's TAIL and the piece goes
     * straight to its HEAD, and the player gets another chance.
     *
     * Every tail and head sits on the SHARED outer track, so an arrow can
     * never carry a piece into anyone's home column — which is exactly the
     * "red can't enter green's home" rule. Tails are on straight runs and
     * avoid the safe stars and the colour start squares.
     */
    const val ARROW_HOP = 3

    /** Ring indices where an arrow's tail sits. */
    val ARROW_TAILS: List<Int> = listOf(
        1, 6, 12,        // zone 1
        14, 19, 25,      // zone 2
        27, 32, 38,      // zone 3
        40, 45, 51       // zone 4
    )

    /** Head of the arrow whose tail is [tailIndex]. */
    fun arrowHead(tailIndex: Int): Int = (tailIndex + ARROW_HOP) % TRACK_LENGTH

    /** True if a piece standing on this shared-track cell is on an arrow tail. */
    fun isArrowTail(globalIndex: Int): Boolean = globalIndex in ARROW_TAILS
}
