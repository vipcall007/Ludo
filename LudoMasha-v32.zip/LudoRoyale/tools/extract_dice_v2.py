#!/usr/bin/env python3
"""
Cuts the eight supplied dice sheets into forty-eight face sprites.

WHY THESE SHEETS REPLACED THE LAST ONES

The previous dice were photographed as CUBES standing at an angle, so the face
carrying the number was tilted away from the player and five pips were hard to
count on a small screen. These sheets give each value as a FLAT square, drawn
straight on. That is the actual fix for readability, and it is why every one of
the old dice comes out of the game.

WHAT EACH SHEET HOLDS

A three-by-two grid of flat faces on the left, and a display cube plus a
"FOR FRAME" label on the right. Only the six flat faces are wanted; the cube
and the label are cropped away and never reach the app.

TWO KINDS OF BACKGROUND

Seven sheets sit on black, so the background is separated by flood-filling
inwards from the border — keying on darkness alone would punch holes straight
through the genuinely black faces on the dragon and robot sets.

The heart sheet sits on a lit orange glow instead, which no flood fill
separates cleanly. Its faces are plain rounded squares with nothing sticking
out of them, so that one is masked to its own shape. The other seven cannot be
masked that way: their crowns and tiaras rise above the square, and a rounded
rectangle would cut them off.
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'source_art')
OUT = os.path.join(HERE, '..', 'app', 'src', 'main', 'res', 'drawable-nodpi')

# id in the game  ->  file in source_art
SHEETS = {
    'dn_heart': 'dice_heart.png',
    'dn_royal': 'dice_royal.png',
    'dn_dragon': 'dice_dragon.png',
    'dn_alien': 'dice_alien.png',
    'dn_diamond': 'dice_diamond.png',
    'dn_ghost': 'dice_ghost.png',
    'dn_robot': 'dice_robot.png',
    'dn_gift': 'dice_gift.png',
}

# the sheet whose background is a lit glow rather than black
LIT_BACKGROUND = {'dn_heart'}

FACE_PX = 256          # what ships; a 52dp dice on a 4x screen is ~208px
BG_TOLERANCE = 42      # how far from the border colour still counts as background


def bands(proj, thresh, span):
    """Runs of True in a 1-D projection, ignoring anything too thin to be a face."""
    on = proj > thresh
    out, start = [], None
    for i, v in enumerate(on):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(on)))
    return [b for b in out if b[1] - b[0] > span * 0.04]


def grid_for(arr):
    """The six cell rectangles, found from the sheet itself."""
    mask = arr.sum(2) > 60
    left = mask[:, :int(mask.shape[1] * 0.68)]
    cols = bands(left.sum(0), left.shape[0] * 0.02, left.shape[1])
    rows = bands(left.sum(1), left.shape[1] * 0.02, left.shape[0])
    if len(cols) != 3 or len(rows) != 2:
        return None
    return cols, rows


# Measured off the seven sheets that detect cleanly, and used for the one that
# does not. They were all laid out to the same template, so this is the same
# grid rather than a guess.
FALLBACK_COLS = [(0.024, 0.232), (0.250, 0.454), (0.471, 0.674)]
FALLBACK_ROWS = [(0.071, 0.436), (0.470, 0.833)]


def alpha_from_border(rgb):
    """Transparent wherever the background reaches in from the edge.

    Flood-filling from the border rather than keying on darkness is what keeps
    a black face black instead of punching a hole through it.
    """
    h, w, _ = rgb.shape
    border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]])
    bg = np.median(border, axis=0)
    close = (np.abs(rgb.astype(int) - bg).sum(2) < BG_TOLERANCE)

    # flood inwards from every edge pixel that matches the background
    from collections import deque
    seen = np.zeros((h, w), bool)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if close[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if close[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))
    while q:
        y, x = q.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and not seen[ny, nx] and close[ny, nx]:
                seen[ny, nx] = True
                q.append((ny, nx))

    alpha = np.where(seen, 0, 255).astype(np.uint8)
    return Image.fromarray(alpha, 'L').filter(ImageFilter.GaussianBlur(0.6))


def rounded_mask(size, radius_frac=0.20):
    """The face's own shape, for the sheet whose background cannot be keyed."""
    m = Image.new('L', size, 0)
    ImageDraw.Draw(m).rounded_rectangle(
        [0, 0, size[0] - 1, size[1] - 1], radius=int(min(size) * radius_frac), fill=255
    )
    return m.filter(ImageFilter.GaussianBlur(0.8))


def lit_face_bounds(cell):
    """Where the face actually is inside a cell cut from the lit sheet.

    The glow behind these faces is orange — red high, GREEN AROUND FIFTY. The
    face's body is a deep red with green near zero. Nothing else in the cell is
    both that red and that free of green, so the green channel separates the two
    where brightness and redness both fail. The gold corner pieces sit at the
    corners of the same square, so the body's bounding box is the square's.
    """
    a = np.array(cell).astype(int)
    body = (a[:, :, 1] < 30) & (a[:, :, 0] > 90)
    ys, xs = np.nonzero(body)
    if len(xs) < 50:
        return None
    # ignore stray specks: keep the middle 99% of the found pixels
    x0, x1 = np.percentile(xs, 0.5), np.percentile(xs, 99.5)
    y0, y1 = np.percentile(ys, 0.5), np.percentile(ys, 99.5)
    return int(x0), int(y0), int(x1) + 1, int(y1) + 1


def tighten(im, pad_frac=0.02):
    """Crop to what is actually drawn, then pad back out to a square."""
    bbox = im.getchannel('A').point(lambda v: 255 if v > 18 else 0).getbbox()
    if bbox:
        im = im.crop(bbox)
    side = int(max(im.size) * (1 + pad_frac * 2))
    out = Image.new('RGBA', (side, side), (0, 0, 0, 0))
    out.alpha_composite(im, ((side - im.width) // 2, (side - im.height) // 2))
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    written = 0
    for dice_id, filename in SHEETS.items():
        path = os.path.join(SRC, filename)
        sheet = Image.open(path).convert('RGB')
        arr = np.array(sheet)
        H, W, _ = arr.shape

        found = grid_for(arr)
        if found and dice_id not in LIT_BACKGROUND:
            cols, rows = found
        else:
            cols = [(int(a * W), int(b * W)) for a, b in FALLBACK_COLS]
            rows = [(int(a * H), int(b * H)) for a, b in FALLBACK_ROWS]

        value = 0
        for (y0, y1) in rows:
            for (x0, x1) in cols:
                value += 1
                cell = sheet.crop((x0, y0, x1, y1))
                if dice_id in LIT_BACKGROUND:
                    bounds = lit_face_bounds(cell)
                    if bounds:
                        cell = cell.crop(bounds)
                    rgba = cell.convert('RGBA')
                    rgba.putalpha(rounded_mask(cell.size))
                else:
                    rgba = cell.convert('RGBA')
                    rgba.putalpha(alpha_from_border(np.array(cell)))
                face = tighten(rgba).resize((FACE_PX, FACE_PX), Image.LANCZOS)
                face.save(os.path.join(OUT, f'{dice_id}_{value}.webp'),
                          'WEBP', quality=92, method=6)
                written += 1
        print(f'{dice_id}: 6 faces')
    print(f'{written} sprites written to drawable-nodpi')


if __name__ == '__main__':
    main()
