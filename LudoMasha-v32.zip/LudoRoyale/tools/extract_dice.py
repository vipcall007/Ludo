#!/usr/bin/env python3
"""
Turn the supplied dice sheets into one sprite per face.

Each sheet is a 3x2 grid of isometric cubes showing values 1..6 on the top
face. For every cube we drop the black backdrop, crop to what is left, pad it
back to a square so all six faces line up, and write a small WebP.

The backdrop is removed by flooding inwards from the border rather than by
keying out "everything dark", because several of these dice have genuinely
black faces — keying on colour alone would punch holes straight through them.
"""
import os
import sys
from collections import deque

import numpy as np
from PIL import Image

SRC = "/root/.claude/uploads/abd22cb2-376e-513e-b0f2-b8bf3705e121"
OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/dice/out"

# file -> (cosmetic id, human name)
SHEETS = [
    ("7c3c48be-image.png", "dx_heart",   "Burning Heart"),
    ("6489c8c4-image.png", "dx_ghost",   "Ghost Charm"),
    ("9f7bcef4-image.png", "dx_gift",    "Gift Box"),
    ("0d3b07c7-image.png", "dx_robot",   "Robo"),
    ("322c526b-image.png", "dx_alien",   "Alien"),
    ("b62df02c-image.png", "dx_wyrm",    "Wyrm"),
    ("17805463-image.png", "dx_star",    "Starburst"),
    ("28674109-image.png", "dx_cosmos",  "Cosmos"),
    ("b7aa8656-image.png", "dx_eight",   "Eight Ball"),
    ("fbf72e90-image.png", "dx_ruby",    "Ruby Crown"),
    ("645ed0a5-image.png", "dx_king",    "The King"),
    ("274fa3bc-image.png", "dx_royals",  "King & Queen"),
]

SIZE = 220          # final sprite, square
BG_MAX = 42         # a pixel this dark on the border counts as backdrop


def strip_backdrop(cell):
    """Alpha out the backdrop, flooding in from the border only."""
    rgb = np.asarray(cell.convert("RGB")).astype(np.int16)
    h, w, _ = rgb.shape
    dark = rgb.max(axis=2) <= BG_MAX

    seen = np.zeros((h, w), dtype=bool)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if dark[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if dark[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))

    while q:
        y, x = q.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and dark[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                q.append((ny, nx))

    alpha = np.where(seen, 0, 255).astype(np.uint8)
    out = np.dstack([np.asarray(cell.convert("RGB")), alpha])
    return Image.fromarray(out, "RGBA")


def trim_reflection(img):
    """Drop a mirrored reflection, if the render has one.

    Four of these sheets were shot on a polished floor, so each cube trails a
    dimmer copy of itself underneath. Floating over the game's background that
    reads as the dice leaking rather than as a reflection, and it shoves the
    cube off centre. The cube is the one wide, solid band of rows in the cell;
    the reflection is narrower and fainter, so keeping only the band around the
    widest row removes it without touching dice that never had one.
    """
    alpha = np.asarray(img)[:, :, 3]
    coverage = (alpha > 24).sum(axis=1)
    peak = int(coverage.max())
    if peak == 0:
        return img
    keep = coverage >= peak * 0.30
    middle = int(coverage.argmax())

    top = middle
    while top > 0 and keep[top - 1]:
        top -= 1
    bottom = middle
    while bottom < len(keep) - 1 and keep[bottom + 1]:
        bottom += 1
    return img.crop((0, top, img.width, bottom + 1))


def square(img):
    """Crop to content, then pad back to a centred square."""
    img = trim_reflection(img)
    box = img.getbbox()
    if box:
        img = img.crop(box)
    side = max(img.size)
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.paste(img, ((side - img.width) // 2, (side - img.height) // 2))
    return canvas


def main():
    os.makedirs(OUT, exist_ok=True)
    total = 0
    for filename, ident, name in SHEETS:
        sheet = Image.open(os.path.join(SRC, filename))
        cw, ch = sheet.width // 3, sheet.height // 2
        for index in range(6):
            row, col = divmod(index, 3)
            cell = sheet.crop((col * cw, row * ch, (col + 1) * cw, (row + 1) * ch))
            sprite = square(strip_backdrop(cell)).resize((SIZE, SIZE), Image.LANCZOS)
            path = os.path.join(OUT, f"{ident}_{index + 1}.webp")
            sprite.save(path, "WEBP", quality=88, method=6)
            total += os.path.getsize(path)
        print(f"{ident:<10} {name}")
    print(f"\n{len(SHEETS) * 6} sprites, {total / 1024:.0f} KB in all")


if __name__ == "__main__":
    main()
