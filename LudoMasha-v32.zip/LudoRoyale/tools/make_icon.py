#!/usr/bin/env python3
"""
Draws Ludo Masha's launcher icon.

WHY THIS IS A SCRIPT AND NOT A PNG SOMEBODY DREW

The icon has to exist at six sizes, twice over (foreground and background for
the adaptive icon Android has wanted since Oreo), plus the two legacy files for
older phones. Keeping fourteen PNGs in step by hand is how icons end up slightly
different from each other. So the icon is drawn from these numbers, and running
this script again regenerates every size from the same source.

WHAT IT DRAWS, AND WHY

A crown over a dice, on deep royal purple. The old icon was a photograph of a
board with the game's name written across it: at the size a launcher actually
shows an icon, the name is unreadable and the board is mush. A crown and a dice
are two shapes with strong silhouettes that stay themselves at 48 pixels, which
is the only size that really matters.

THE SAFE ZONE IS NOT OPTIONAL

An adaptive icon is 108 units square, but the launcher may mask it to a circle,
a squircle or a rounded square, and it may also move it about for a parallax
effect. Only the middle 72 units are guaranteed to survive. Everything that has
to be seen is kept inside that circle.
"""
import math, os
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'app', 'src', 'main', 'res')

# render big, then downsample: cheap antialiasing that costs nothing at runtime
S = 1080

DENSITIES = [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]
FG_DENSITIES = [('mdpi', 108), ('hdpi', 162), ('xhdpi', 216), ('xxhdpi', 324), ('xxxhdpi', 432)]

PURPLE_MID  = (0x4A, 0x32, 0x8E)
PURPLE_DEEP = (0x16, 0x0C, 0x30)
GOLD_LIGHT  = (0xFF, 0xEC, 0xB4)
GOLD        = (0xF2, 0xC1, 0x4E)
GOLD_DEEP   = (0x9A, 0x69, 0x06)
RUBY        = (0xD9, 0x28, 0x3C)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def background():
    """Deep purple, lit from the middle, with faint rays from behind the crown."""
    im = Image.new('RGBA', (S, S), PURPLE_DEEP + (255,))
    d = ImageDraw.Draw(im)
    c = S / 2

    # radial glow, drawn as rings from the outside in
    for i in range(140, 0, -1):
        t = i / 140.0
        r = c * 1.05 * t
        d.ellipse([c - r, c - r, c + r, c + r], fill=lerp(PURPLE_MID, PURPLE_DEEP, t) + (255,))

    # rays, kept very faint so they read as light rather than as stripes
    rays = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(rays)
    for i in range(16):
        a0 = math.radians(i * 22.5 - 5)
        a1 = math.radians(i * 22.5 + 5)
        far = S
        rd.polygon(
            [(c, c),
             (c + math.cos(a0) * far, c + math.sin(a0) * far),
             (c + math.cos(a1) * far, c + math.sin(a1) * far)],
            fill=GOLD + (16,)
        )
    rays = rays.filter(ImageFilter.GaussianBlur(S * 0.012))
    im.alpha_composite(rays)
    return im


def crown(d, cx, cy, w, h):
    """Three points, a jewelled band, and a highlight down the left of each peak."""
    half = w / 2
    base = cy + h / 2
    top = cy - h / 2
    dip = top + h * 0.46

    body = [
        (cx - half, base),
        (cx - half, top + h * 0.10),
        (cx - half * 0.46, dip),
        (cx, top),
        (cx + half * 0.46, dip),
        (cx + half, top + h * 0.10),
        (cx + half, base),
    ]
    d.polygon(body, fill=GOLD)

    # the lit left face of the crown, so it is not a flat cut-out
    lit = [
        (cx - half, base),
        (cx - half, top + h * 0.10),
        (cx - half * 0.46, dip),
        (cx, top),
        (cx, base),
    ]
    d.polygon(lit, fill=GOLD_LIGHT)
    d.polygon(body, outline=GOLD_DEEP, width=int(S * 0.010))

    # the band, and the stones set in it
    band_top = base - h * 0.30
    d.rounded_rectangle([cx - half * 1.06, band_top, cx + half * 1.06, base + h * 0.06],
                        radius=h * 0.09, fill=GOLD, outline=GOLD_DEEP, width=int(S * 0.009))
    for i, sx in enumerate((-0.58, 0.0, 0.58)):
        r = h * (0.10 if i == 1 else 0.078)
        x = cx + half * sx
        y = (band_top + base) / 2 + h * 0.03
        d.ellipse([x - r, y - r, x + r, y + r], fill=RUBY)
        d.ellipse([x - r * 0.42, y - r * 0.52, x - r * 0.02, y - r * 0.12],
                  fill=(0xFF, 0x9A, 0xA8))

    # a stone on each peak
    for px, py, pr in ((cx, top, h * 0.085),
                       (cx - half, top + h * 0.10, h * 0.068),
                       (cx + half, top + h * 0.10, h * 0.068)):
        d.ellipse([px - pr, py - pr, px + pr, py + pr], fill=GOLD_LIGHT,
                  outline=GOLD_DEEP, width=int(S * 0.006))


def dice(im, cx, cy, side, tilt=-12):
    """A white dice showing five, tilted, drawn on its own layer so it can rotate."""
    pad = int(side * 0.5)
    layer = Image.new('RGBA', (int(side) + pad * 2, int(side) + pad * 2), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    x0 = y0 = pad
    x1 = y1 = pad + side
    r = side * 0.22

    # a soft shadow under it
    sh = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle(
        [x0 + side * 0.05, y0 + side * 0.09, x1 + side * 0.05, y1 + side * 0.09],
        radius=r, fill=(0, 0, 0, 130))
    sh = sh.filter(ImageFilter.GaussianBlur(side * 0.05))
    layer.alpha_composite(sh)

    ld.rounded_rectangle([x0, y0, x1, y1], radius=r, fill=(0xFC, 0xFD, 0xFF))
    # the face is lit from the top left and falls away to the bottom right
    grad = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    steps = 60
    for i in range(steps):
        t = i / steps
        gd.rounded_rectangle(
            [x0 + side * 0.5 * t, y0 + side * 0.5 * t, x1, y1],
            radius=r, fill=(0xC6, 0xD2, 0xE4, 7))
    grad = grad.filter(ImageFilter.GaussianBlur(side * 0.02))
    layer.alpha_composite(grad)
    ld.rounded_rectangle([x0, y0, x1, y1], radius=r, outline=GOLD_DEEP,
                         width=int(side * 0.055))
    ld.rounded_rectangle([x0 + side * 0.075, y0 + side * 0.075,
                          x1 - side * 0.075, y1 - side * 0.075],
                         radius=r * 0.8, outline=GOLD + (170,), width=int(side * 0.022))

    # five pips, the classic quincunx
    pr = side * 0.088
    for fx, fy in ((0.28, 0.28), (0.72, 0.28), (0.5, 0.5), (0.28, 0.72), (0.72, 0.72)):
        px = x0 + side * fx
        py = y0 + side * fy
        ld.ellipse([px - pr, py - pr, px + pr, py + pr], fill=(0x1C, 0x14, 0x06))
        ld.ellipse([px - pr * 0.45, py - pr * 0.55, px - pr * 0.05, py - pr * 0.15],
                   fill=(0x6E, 0x62, 0x50))

    layer = layer.rotate(tilt, resample=Image.BICUBIC, expand=False)
    im.alpha_composite(layer, (int(cx - layer.width / 2), int(cy - layer.height / 2)))


def foreground():
    """The crown and dice, kept inside the safe circle an adaptive icon promises."""
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = S / 2
    # the safe zone is the middle 72 of 108 units
    safe = S * (72.0 / 108.0)

    crown(d, c, c - safe * 0.280, safe * 0.62, safe * 0.32)
    dice(im, c, c + safe * 0.185, safe * 0.48)
    return im


def legacy():
    """One flat square for phones too old for adaptive icons."""
    im = background()
    # on the legacy icon nothing is masked away, so it can be drawn larger
    d = ImageDraw.Draw(im)
    c = S / 2
    crown(d, c, c - S * 0.235, S * 0.50, S * 0.255)
    dice(im, c, c + S * 0.150, S * 0.385)
    return im


def rim(im, shape):
    """A gold edge, following whatever shape the icon is about to be cut to.

    Drawn after the masking decision rather than before it, so the round icon
    gets a round rim and the square one gets a square rim — a circular rim
    inside a rounded square looks like a mistake, because it is one.
    """
    d = ImageDraw.Draw(im)
    inset = S * 0.015
    box = [inset, inset, S - 1 - inset, S - 1 - inset]
    w = int(S * 0.020)
    if shape == 'circle':
        d.ellipse(box, outline=GOLD + (130,), width=w)
    else:
        d.rounded_rectangle(box, radius=S * 0.205, outline=GOLD + (130,), width=w)
    return im


def rounded_square(im, radius_frac=0.22):
    mask = Image.new('L', (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1],
                                           radius=S * radius_frac, fill=255)
    out = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    out.paste(im, (0, 0), mask)
    return out


def circle(im):
    mask = Image.new('L', (S, S), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, S - 1, S - 1], fill=255)
    out = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    out.paste(im, (0, 0), mask)
    return out


def save(im, folder, name, size):
    path = os.path.join(RES, folder)
    os.makedirs(path, exist_ok=True)
    im.resize((size, size), Image.LANCZOS).save(os.path.join(path, name + '.png'))


def main():
    bg = background()
    fg = foreground()
    flat = legacy()

    square_icon = rim(rounded_square(flat), 'square')
    round_icon = rim(circle(flat), 'circle')
    for d, px in DENSITIES:
        save(square_icon, f'mipmap-{d}', 'ic_launcher', px)
        save(round_icon, f'mipmap-{d}', 'ic_launcher_round', px)
    for d, px in FG_DENSITIES:
        save(fg, f'mipmap-{d}', 'ic_launcher_foreground', px)
        save(bg, f'mipmap-{d}', 'ic_launcher_background', px)

    # a preview at the size a launcher really shows it
    square_icon.resize((48, 48), Image.LANCZOS).resize((192, 192), Image.NEAREST) \
        .save(os.path.join(HERE, 'icon_preview_48.png'))
    print('icon written for', ', '.join(d for d, _ in DENSITIES))


if __name__ == '__main__':
    main()
