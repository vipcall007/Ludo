package com.example.ludoroyale.snl

import android.graphics.Color
import com.example.ludoroyale.engine.SnakeDifficulty

/** What crowds the border of a board. */
enum class Ambience { REEF, GARDEN, JUNGLE, TEMPLE }

/**
 * A world for the 1..100 board to live in.
 *
 * Every colour the board draws with comes from here, which is what makes three
 * completely different-looking boards possible without three copies of the
 * drawing code.
 *
 * THE RULE THESE THEMES OBEY: a theme changes the paint and nothing else. The
 * squares, the snakes, the ladders and the odds are identical in all three —
 * Hard looks more dangerous because it HAS more snakes, not because its paint
 * is darker. And whatever the mood, the two tile colours are kept far apart in
 * brightness and the numbers are kept high-contrast against them, because a
 * board you cannot read is not atmospheric, it is broken.
 */
data class SnlTheme(
    val id: String,
    val title: String,
    val ambience: Ambience,

    // the backdrop behind everything
    val skyTop: Int,
    val skyMid: Int,
    val skyDeep: Int,
    /** The overhead light wash. */
    val lightTint: Int,
    /** Drifting detail across the backdrop: ribbons, pollen, motes, dust. */
    val driftTint: Int,

    // the border and the frame around the playfield
    val borderFill: Int,
    val frameLight: Int,
    val frameMid: Int,
    val frameDark: Int,
    val frameEdge: Int,
    val lashing: Int,
    val innerEdge: Int,

    // the squares
    val tilePale: Int,
    val tileDark: Int,
    val numberOnPale: Int,
    val numberOnDark: Int,
    val starColor: Int,

    // the inhabitants
    val snakeSkins: List<IntArray>,
    val ladderWoods: List<IntArray>,
    val ropeColor: Int
) {
    fun snakeSkin(index: Int): IntArray = snakeSkins[((index % snakeSkins.size) + snakeSkins.size) % snakeSkins.size]
    fun ladderWood(index: Int): IntArray = ladderWoods[((index % ladderWoods.size) + ladderWoods.size) % ladderWoods.size]

    companion object {

        private fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)

        /**
         * ROYAL GARDEN — Easy.
         *
         * Bright, green and gold, a palace lawn in the middle of the afternoon.
         * The snakes here are handsome rather than frightening.
         */
        val ROYAL_GARDEN = SnlTheme(
            id = "royal_garden",
            title = "ROYAL GARDEN",
            ambience = Ambience.GARDEN,
            skyTop = rgb(0x8F, 0xE0, 0x9A),
            skyMid = rgb(0x4C, 0xB0, 0x6E),
            skyDeep = rgb(0x1E, 0x6E, 0x44),
            lightTint = Color.argb(110, 0xFF, 0xF6, 0xC8),
            driftTint = Color.argb(70, 0xFF, 0xF4, 0xB0),
            borderFill = rgb(0x1A, 0x5E, 0x3A),
            frameLight = rgb(0xF6, 0xDC, 0x92),
            frameMid = rgb(0xD8, 0xB1, 0x4E),
            frameDark = rgb(0x9A, 0x74, 0x1E),
            frameEdge = rgb(0x6B, 0x4C, 0x10),
            lashing = rgb(0xFF, 0xF0, 0xC0),
            innerEdge = rgb(0x14, 0x52, 0x32),
            tilePale = rgb(0xF6, 0xEE, 0xCE),
            tileDark = rgb(0x3E, 0x7C, 0x52),
            numberOnPale = rgb(0x5C, 0x44, 0x12),
            numberOnDark = rgb(0xF4, 0xEC, 0xC4),
            starColor = rgb(0xF2, 0xC1, 0x4E),
            snakeSkins = listOf(
                // base, belly, dark, pattern, pattern kind
                intArrayOf(rgb(46, 138, 62), rgb(226, 240, 164), rgb(18, 68, 30), rgb(22, 86, 38), 0),
                intArrayOf(rgb(206, 158, 44), rgb(250, 238, 190), rgb(112, 78, 14), rgb(76, 52, 10), 1),
                intArrayOf(rgb(74, 150, 196), rgb(216, 240, 250), rgb(28, 74, 104), rgb(24, 66, 92), 2),
                intArrayOf(rgb(190, 96, 138), rgb(250, 220, 234), rgb(96, 34, 64), rgb(84, 28, 56), 0),
                intArrayOf(rgb(122, 176, 70), rgb(238, 246, 196), rgb(56, 88, 26), rgb(48, 78, 22), 1)
            ),
            ladderWoods = listOf(
                intArrayOf(rgb(0xD2, 0xA8, 0x54), rgb(0xFA, 0xE6, 0xAE), rgb(0x7E, 0x5C, 0x18)),
                intArrayOf(rgb(0xC4, 0x8A, 0x45), rgb(0xF0, 0xC5, 0x83), rgb(0x6E, 0x42, 0x15)),
                intArrayOf(rgb(0xE0, 0xC2, 0x76), rgb(0xFF, 0xF2, 0xC8), rgb(0x8E, 0x70, 0x22))
            ),
            ropeColor = rgb(0xF2, 0xE0, 0xB4)
        )

        /**
         * DARK JUNGLE — Medium.
         *
         * Deeper greens, light coming through leaves, and snakes that mean it.
         * The tiles stay bright so the numbers survive the gloom.
         */
        val DARK_JUNGLE = SnlTheme(
            id = "dark_jungle",
            title = "DARK JUNGLE",
            ambience = Ambience.JUNGLE,
            skyTop = rgb(0x2E, 0x6E, 0x48),
            skyMid = rgb(0x16, 0x46, 0x30),
            skyDeep = rgb(0x08, 0x24, 0x1A),
            lightTint = Color.argb(95, 0xC8, 0xF0, 0xA8),
            driftTint = Color.argb(55, 0xD8, 0xFF, 0xC0),
            borderFill = rgb(0x0C, 0x2E, 0x20),
            frameLight = rgb(0x9E, 0x7A, 0x46),
            frameMid = rgb(0x74, 0x55, 0x2C),
            frameDark = rgb(0x46, 0x30, 0x16),
            frameEdge = rgb(0x28, 0x1A, 0x0A),
            lashing = rgb(0xC6, 0xD9, 0x96),
            innerEdge = rgb(0x06, 0x1C, 0x14),
            tilePale = rgb(0xEC, 0xE6, 0xC8),
            tileDark = rgb(0x2C, 0x5A, 0x40),
            numberOnPale = rgb(0x3E, 0x36, 0x10),
            numberOnDark = rgb(0xE8, 0xF2, 0xCE),
            starColor = rgb(0xE8, 0xC2, 0x5A),
            snakeSkins = listOf(
                intArrayOf(rgb(30, 104, 48), rgb(200, 220, 140), rgb(10, 48, 22), rgb(14, 62, 28), 0),
                intArrayOf(rgb(150, 38, 34), rgb(232, 196, 166), rgb(78, 14, 14), rgb(52, 10, 12), 1),
                intArrayOf(rgb(84, 54, 132), rgb(214, 198, 238), rgb(36, 18, 64), rgb(32, 16, 60), 2),
                intArrayOf(rgb(168, 128, 34), rgb(240, 222, 168), rgb(88, 62, 10), rgb(60, 40, 6), 1),
                intArrayOf(rgb(22, 92, 120), rgb(186, 222, 234), rgb(8, 44, 62), rgb(6, 38, 54), 0),
                intArrayOf(rgb(62, 68, 80), rgb(196, 202, 214), rgb(22, 26, 34), rgb(18, 22, 30), 2)
            ),
            ladderWoods = listOf(
                intArrayOf(rgb(0xA9, 0x6B, 0x33), rgb(0xDD, 0xAA, 0x66), rgb(0x5A, 0x33, 0x0E)),
                intArrayOf(rgb(0x8E, 0x5A, 0x28), rgb(0xC2, 0x93, 0x52), rgb(0x48, 0x28, 0x0A)),
                intArrayOf(rgb(0xB8, 0x80, 0x3E), rgb(0xE6, 0xB8, 0x74), rgb(0x64, 0x3C, 0x12))
            ),
            ropeColor = rgb(0xB8, 0xCE, 0x8A)
        )

        /**
         * DANGEROUS ROYAL TEMPLE — Hard.
         *
         * Old stone, torchlight and a great deal of gold. The mood is heavy;
         * the tiles are deliberately the brightest of the three so the board
         * still reads at a glance under all that drama.
         */
        val ROYAL_TEMPLE = SnlTheme(
            id = "royal_temple",
            title = "DANGEROUS ROYAL TEMPLE",
            ambience = Ambience.TEMPLE,
            skyTop = rgb(0x5E, 0x3E, 0x22),
            skyMid = rgb(0x32, 0x1E, 0x12),
            skyDeep = rgb(0x14, 0x0A, 0x08),
            lightTint = Color.argb(120, 0xFF, 0xB4, 0x5E),
            driftTint = Color.argb(60, 0xFF, 0xC8, 0x7A),
            borderFill = rgb(0x24, 0x16, 0x0E),
            frameLight = rgb(0xFF, 0xE2, 0x9C),
            frameMid = rgb(0xD4, 0xA4, 0x3C),
            frameDark = rgb(0x8A, 0x63, 0x14),
            frameEdge = rgb(0x4C, 0x33, 0x08),
            lashing = rgb(0xFF, 0xD9, 0x8E),
            innerEdge = rgb(0x1A, 0x10, 0x08),
            tilePale = rgb(0xF8, 0xEF, 0xD6),
            tileDark = rgb(0x5A, 0x40, 0x2C),
            numberOnPale = rgb(0x4A, 0x2E, 0x0A),
            numberOnDark = rgb(0xFF, 0xE8, 0xBE),
            starColor = rgb(0xFF, 0xD1, 0x62),
            snakeSkins = listOf(
                intArrayOf(rgb(150, 26, 30), rgb(238, 190, 160), rgb(74, 10, 12), rgb(48, 8, 10), 1),
                intArrayOf(rgb(168, 130, 26), rgb(246, 226, 160), rgb(88, 62, 6), rgb(58, 40, 4), 2),
                intArrayOf(rgb(46, 46, 58), rgb(186, 190, 204), rgb(16, 16, 24), rgb(12, 12, 20), 2),
                intArrayOf(rgb(96, 34, 120), rgb(220, 194, 238), rgb(44, 14, 58), rgb(38, 12, 52), 0),
                intArrayOf(rgb(24, 92, 84), rgb(188, 226, 218), rgb(8, 44, 40), rgb(6, 38, 34), 0),
                intArrayOf(rgb(190, 86, 20), rgb(248, 214, 172), rgb(98, 40, 6), rgb(70, 28, 4), 1)
            ),
            ladderWoods = listOf(
                intArrayOf(rgb(0xD4, 0xA4, 0x3C), rgb(0xFF, 0xE6, 0xA8), rgb(0x7E, 0x58, 0x0E)),
                intArrayOf(rgb(0x9A, 0x8E, 0x7E), rgb(0xD8, 0xCE, 0xBE), rgb(0x54, 0x4A, 0x3C)),
                intArrayOf(rgb(0xC8, 0x96, 0x40), rgb(0xF6, 0xD8, 0x9E), rgb(0x70, 0x4C, 0x12))
            ),
            ropeColor = rgb(0xE8, 0xC8, 0x8C)
        )

        /**
         * The theme each difficulty plays in.
         *
         * This is the ONLY place difficulty and appearance meet. Nothing that
         * decides a rule ever reads a theme, and nothing that draws ever reads
         * the difficulty except through this one function.
         */
        fun of(difficulty: SnakeDifficulty): SnlTheme = when (difficulty) {
            SnakeDifficulty.EASY -> ROYAL_GARDEN
            SnakeDifficulty.MEDIUM -> DARK_JUNGLE
            SnakeDifficulty.HARD -> ROYAL_TEMPLE
        }

        val ALL: List<SnlTheme> = listOf(ROYAL_GARDEN, DARK_JUNGLE, ROYAL_TEMPLE)

        /**
         * Rough perceived brightness, 0..255.
         *
         * The contrast rules these themes have to obey are enforced by the
         * `check_theme_readability` pass in verify.py, which reads the numbers
         * out of this file directly. It is done there rather than in a unit
         * test because every colour here comes from `android.graphics.Color`,
         * which cannot be called outside a real device or emulator.
         */
        fun luminance(color: Int): Int =
            (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
    }
}
