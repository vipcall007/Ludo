package com.example.ludoroyale

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * THE SIX SECONDS BEFORE THE LOBBY.
 *
 * Four counters fly in out of the dark, the name builds itself a letter at a
 * time, a light runs across the gold, and a crown comes down over the lot of
 * it. Then it clears and the lobby is there.
 *
 * WHY IT IS DRAWN RATHER THAN PLAYED. A video would have been the easy answer
 * and the wrong one: it would have to be made at one size and then stretched
 * to fit every phone, it would weigh several megabytes in an app that is
 * mostly pictures already, and it would look soft on a tall screen. Drawn, it
 * is a few hundred lines, it is sharp at any size, and every number in it can
 * be changed without re-rendering anything.
 *
 * WHAT MAKES IT READ AS THREE-DIMENSIONAL. Nothing here is a 3D engine. The
 * counters come in small and grow, which is distance; they arrive squashed
 * flat and open out, which is a disc turning to face you; the letters swing in
 * on their own vertical axis, narrow to wide, which is a card being turned
 * over; and the name has ten copies of itself stacked behind it going down and
 * to the right, which is thickness. Four cheap tricks, and together they are
 * enough.
 *
 * IT CAN ALWAYS BE SKIPPED. Six seconds is a pleasure the first time and a
 * toll the twentieth, so a tap anywhere ends it immediately.
 */
class IntroView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** Called once, on the main thread, when the intro is over or was skipped. */
    var onFinished: (() -> Unit)? = null

    private var startedAt = 0L
    private var done = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val textEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        style = Paint.Style.STROKE
    }
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    /** Fixed stars, so the sky does not crawl between frames. */
    private val starX = FloatArray(STAR_COUNT)
    private val starY = FloatArray(STAR_COUNT)
    private val starR = FloatArray(STAR_COUNT)
    private val starPhase = FloatArray(STAR_COUNT)

    private val counters = HashMap<PlayerSeat, Bitmap?>()

    private var faceShader: Shader? = null
    private var faceSize = 0f

    private enum class PlayerSeat(
        val res: Int, val bright: Int, val dark: Int, val sx: Int, val sy: Int, val delay: Int
    ) {
        RED(R.drawable.tn_red, 0xFFEE3333.toInt(), 0xFF990011.toInt(), -1, -1, 0),
        GREEN(R.drawable.tn_green, 0xFF11CC44.toInt(), 0xFF006622.toInt(), 1, -1, 140),
        YELLOW(R.drawable.tn_yellow, 0xFFFFCC22.toInt(), 0xFFAA7700.toInt(), -1, 1, 280),
        BLUE(R.drawable.tn_blue, 0xFF2288EE.toInt(), 0xFF003366.toInt(), 1, 1, 420)
    }

    init {
        // A repeatable sky. A fresh Random each time would have the stars in a
        // different place on every launch, which is not wrong but is restless.
        var seed = 987654321L
        fun next(): Float {
            seed = (seed * 6364136223846793005L + 1442695040888963407L)
            return (((seed ushr 33).toInt() and 0x7FFFFF).toFloat() / 0x7FFFFF.toFloat())
        }
        for (i in 0 until STAR_COUNT) {
            starX[i] = next(); starY[i] = next()
            starR[i] = 0.4f + next() * 1.4f
            starPhase[i] = next() * 6.283f
        }
        isClickable = true
    }

    /** Begins the run. Calling it again while it is running does nothing. */
    fun start() {
        if (startedAt != 0L) return
        done = false
        startedAt = System.currentTimeMillis()
        visibility = VISIBLE
        invalidate()
    }

    /** Ends it now, whatever it was in the middle of. */
    fun skip() {
        if (done) return
        done = true
        visibility = GONE
        onFinished?.invoke()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) { skip(); return true }
        return true
    }

    // --------------------------------------------------------------- timing

    private fun clamp01(v: Float) = if (v < 0f) 0f else if (v > 1f) 1f else v

    /** 0 before [from], 1 after [to], straight line between. */
    private fun seg(now: Float, from: Float, to: Float) = clamp01((now - from) / (to - from))

    /** Fast at first, settling at the end. */
    private fun easeOut(t: Float): Float {
        val u = 1f - clamp01(t)
        return 1f - u * u * u
    }

    /** Overshoots and comes back — the small bounce that makes an arrival land. */
    private fun easeBack(t: Float): Float {
        val u = clamp01(t) - 1f
        val s = 1.70158f
        return 1f + (s + 1f) * u * u * u + s * u * u
    }

    // --------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        if (done) return
        if (startedAt == 0L) start()
        val now = (System.currentTimeMillis() - startedAt).toFloat()

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        drawSky(canvas, now, w, h)
        drawCounters(canvas, now, w, h)

        val band = shineBand(now, w, h)
        drawWord(canvas, now, w, h, "LUDO", 1700f, h * TITLE_1_Y, band)
        drawWord(canvas, now, w, h, "MASHA", 2150f, h * TITLE_2_Y, band)

        drawCrown(canvas, now, w, h)
        drawTagline(canvas, now, w, h)
        drawFade(canvas, now, w, h)

        if (now >= DURATION_MS) { skip(); return }
        postInvalidateOnAnimation()
    }

    private fun drawSky(canvas: Canvas, now: Float, w: Float, h: Float) {
        fill.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF2A1454.toInt(), 0xFF140B33.toInt(), 0xFF070418.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, fill)

        nebula(canvas, w * 0.28f, h * 0.30f, w * 0.60f, 0x557A3FCF, w, h)
        nebula(canvas, w * 0.75f, h * 0.68f, w * 0.60f, 0x552F5FD0, w, h)

        fill.shader = null
        val fade = seg(now, 0f, 900f)
        val scale = minOf(w, h) / 720f
        for (i in 0 until STAR_COUNT) {
            val twinkle = 0.55f + 0.45f * Math.sin((now / 420f + starPhase[i]).toDouble()).toFloat()
            fill.color = Color.WHITE
            fill.alpha = (255f * fade * twinkle).toInt().coerceIn(0, 255)
            canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * scale, fill)
        }
        fill.alpha = 255
    }

    private fun nebula(canvas: Canvas, cx: Float, cy: Float, r: Float, colour: Int, w: Float, h: Float) {
        fill.shader = RadialGradient(
            cx, cy, r, intArrayOf(colour, colour and 0x00FFFFFF),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, fill)
    }

    private fun drawCounters(canvas: Canvas, now: Float, w: Float, h: Float) {
        val cx = w / 2f
        val cy = h * COUNTERS_Y
        val unit = minOf(w, h * 0.5625f)          // a 16:9 phone's usable width
        for (seat in PlayerSeat.values()) {
            val t = seg(now, 500f + seat.delay, 1900f + seat.delay)
            if (t <= 0f) continue
            val e = easeBack(t)
            val restX = cx + seat.sx * unit * 0.185f
            val restY = cy + seat.sy * unit * 0.176f
            val farX = cx + seat.sx * w * 1.1f
            val farY = cy + seat.sy * h * 0.8f
            val x = farX + (restX - farX) * e
            val y = farY + (restY - farY) * e
            // small and flat when it is far away, full and open when it lands
            val r = unit * 0.134f * (0.25f + 0.75f * easeOut(t))
            val squash = Math.abs(Math.cos(((1f - easeOut(t)) * 7f).toDouble())).toFloat()
                .coerceAtLeast(0.12f)
            drawCounter(canvas, seat, x, y, r, squash)
        }
    }

    private fun drawCounter(
        canvas: Canvas, seat: PlayerSeat, x: Float, y: Float, r: Float, squash: Float
    ) {
        val art = counterArt(seat)
        val box = RectF(x - r, y - r * squash, x + r, y + r * squash)
        if (art != null) {
            canvas.drawBitmap(art, null, box, bitmapPaint)
            return
        }
        // The picture could not be decoded — draw the piece instead of nothing.
        fill.shader = null
        fill.color = seat.dark
        canvas.drawOval(RectF(box.left, box.top + r * 0.12f, box.right, box.bottom + r * 0.12f), fill)
        fill.color = seat.bright
        canvas.drawOval(box, fill)
        stroke.color = 0xFFF5C542.toInt()
        stroke.strokeWidth = r * 0.14f
        canvas.drawOval(
            RectF(x - r * 0.72f, y - r * 0.72f * squash, x + r * 0.72f, y + r * 0.72f * squash),
            stroke
        )
    }

    private fun counterArt(seat: PlayerSeat): Bitmap? {
        if (counters.containsKey(seat)) return counters[seat]
        val art = try {
            BitmapFactory.decodeResource(resources, seat.res)
        } catch (e: Throwable) {
            null
        }
        counters[seat] = art
        return art
    }

    /**
     * The moving highlight, or null when it is not running.
     *
     * It is handed to [drawWord] and painted over the letters themselves. An
     * earlier version swept a bright band straight across the screen, and what
     * it actually produced was a pale slab sitting over the sky — the light has
     * to have something to catch on, so it is the gold that catches it.
     */
    private fun shineBand(now: Float, w: Float, h: Float): Shader? {
        val t = seg(now, 3100f, 4300f)
        if (t <= 0f || t >= 1f) return null
        val half = w * 0.19f
        val x = -half * 2f + t * (w + half * 4f)
        return LinearGradient(
            x - half, 0f, x + half, 0f,
            intArrayOf(0x00FFFCEB, 0xD9FFFCEB.toInt(), 0x00FFFCEB),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun drawWord(
        canvas: Canvas, now: Float, w: Float, h: Float,
        word: String, from: Float, baseline: Float, band: Shader?
    ) {
        val size = minOf(w * 0.155f, h * 0.088f)
        text.textSize = size
        textEdge.textSize = size
        textEdge.strokeWidth = size * 0.022f
        textEdge.color = 0xFF5A3200.toInt()

        val step = size * 0.66f
        val total = (word.length - 1) * step
        val depth = size * 0.085f

        // BUILT ONCE PER FRAME, NOT ONCE PER LETTER. Each letter is drawn after
        // the canvas has been moved to it, so every letter sees the same local
        // coordinates and can share one gradient. Nine words' worth of new
        // shader objects sixty times a second is a lot of rubbish to make for
        // a picture that never changes.
        if (faceShader == null || faceSize != size) {
            faceSize = size
            faceShader = LinearGradient(
                0f, -size * 0.72f, 0f, size * 0.24f,
                intArrayOf(0xFFFFF3B0.toInt(), 0xFFF5C542.toInt(),
                           0xFFC9891B.toInt(), 0xFFFFE27A.toInt()),
                floatArrayOf(0f, 0.45f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }

        for (i in word.indices) {
            val t = seg(now, from + i * 90f, from + i * 90f + 620f)
            if (t <= 0f) continue
            val e = easeOut(t)
            val letter = word[i].toString()
            val x = w / 2f - total / 2f + i * step
            val y = baseline - (1f - e) * size * 1.45f
            // turning on its own vertical axis: wide when facing you, a sliver
            // when edge-on, which is all "rotating in 3D" has to mean here
            val turn = (1f - e) * 3.45f
            val faceOn = Math.abs(Math.cos(turn.toDouble())).toFloat().coerceAtLeast(0.05f)

            canvas.save()
            canvas.translate(x, y)
            canvas.scale(faceOn, 1f)
            val a = (255 * e).toInt().coerceIn(0, 255)

            // THICKNESS: copies going back into the picture, darkest first
            text.shader = null
            text.color = 0xFF3C1E00.toInt()
            text.alpha = (a * 0.55f).toInt()
            for (d in 10 downTo 1) {
                val o = d * depth / 10f
                canvas.drawText(letter, o, o, text)
            }

            // the face
            text.shader = faceShader
            text.alpha = a
            canvas.drawText(letter, 0f, 0f, text)

            textEdge.alpha = a
            canvas.drawText(letter, 0f, 0f, textEdge)

            if (band != null) {
                // the band is positioned in screen space, so undo this letter's
                // own move before using it and put it back afterwards
                canvas.translate(-x, 0f)
                text.shader = band
                text.alpha = a
                canvas.drawText(letter, x, 0f, text)
                canvas.translate(x, 0f)
            }

            canvas.restore()
        }
        text.shader = null
        text.alpha = 255
        textEdge.alpha = 255
    }

    private fun drawCrown(canvas: Canvas, now: Float, w: Float, h: Float) {
        val t = seg(now, 3400f, 4400f)
        if (t <= 0f) return
        val e = easeBack(t)
        val unit = minOf(w, h * 0.5625f)
        val cx = w / 2f
        val cy = h * COUNTERS_Y - unit * 0.372f + (1f - e) * unit * 0.125f
        val s = unit * 0.00160f * e

        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(s, s)
        val alpha = (255 * seg(now, 3400f, 3750f)).toInt().coerceIn(0, 255)

        // the burst behind it
        val rt = seg(now, 3900f, 5200f)
        if (rt > 0f && rt < 1f) {
            val strength = Math.sin((rt * Math.PI)).toFloat()
            fill.shader = RadialGradient(
                0f, 0f, 300f,
                intArrayOf(argb(0.85f * strength, 0xFFE28C),
                           argb(0.26f * strength, 0xFFBE46),
                           argb(0f, 0xFFAA28)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, 300f, fill)
            fill.shader = null

            canvas.save()
            canvas.rotate(now / 1400f * 57.3f)
            fill.color = argb(0.32f * strength, 0xFFEBA5)
            for (i in 0 until 14) {
                canvas.rotate(360f / 14f)
                path.reset()
                path.moveTo(0f, 0f)
                path.lineTo(-16f, -320f)
                path.lineTo(16f, -320f)
                path.close()
                canvas.drawPath(path, fill)
            }
            canvas.restore()
        }

        path.reset()
        path.moveTo(-72f, 34f); path.lineTo(-88f, -52f); path.lineTo(-38f, -8f)
        path.lineTo(0f, -70f); path.lineTo(38f, -8f); path.lineTo(88f, -52f)
        path.lineTo(72f, 34f); path.close()
        fill.shader = LinearGradient(
            0f, -70f, 0f, 34f,
            intArrayOf(0xFFFFF0A8.toInt(), 0xFFD08C14.toInt()),
            null, Shader.TileMode.CLAMP
        )
        fill.alpha = alpha
        canvas.drawPath(path, fill)
        fill.shader = null

        stroke.color = 0xFF6E3F00.toInt()
        stroke.alpha = alpha
        stroke.strokeWidth = 4f
        canvas.drawPath(path, stroke)

        fill.color = 0xFFE0344B.toInt()
        fill.alpha = alpha
        canvas.drawCircle(0f, 16f, 15f, fill)
        fill.alpha = 255
        stroke.alpha = 255
        canvas.restore()
    }

    private fun argb(a: Float, rgb: Int): Int =
        ((a.coerceIn(0f, 1f) * 255).toInt() shl 24) or (rgb and 0xFFFFFF)

    private fun drawTagline(canvas: Canvas, now: Float, w: Float, h: Float) {
        val t = seg(now, 4600f, 5300f)
        if (t <= 0f) return
        text.shader = null
        text.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        text.textSize = minOf(w * 0.042f, h * 0.024f)
        text.color = 0xFFEBD9FF.toInt()
        text.alpha = (255 * easeOut(t)).toInt().coerceIn(0, 255)
        canvas.drawText("ROYAL  BOARD  GAME", w / 2f, h * TAGLINE_Y, text)
        text.alpha = 255
    }

    private fun drawFade(canvas: Canvas, now: Float, w: Float, h: Float) {
        val t = seg(now, DURATION_MS - 500f, DURATION_MS)
        if (t <= 0f) return
        fill.shader = null
        fill.color = 0xFF070418.toInt()
        fill.alpha = (255 * t).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, w, h, fill)
        fill.alpha = 255
    }

    companion object {
        /** Six seconds — the middle of the five-to-seven that was asked for. */
        const val DURATION_MS = 6000f

        private const val STAR_COUNT = 170
        private const val COUNTERS_Y = 0.30f
        private const val TITLE_1_Y = 0.555f
        private const val TITLE_2_Y = 0.648f
        private const val TAGLINE_Y = 0.735f
    }
}
