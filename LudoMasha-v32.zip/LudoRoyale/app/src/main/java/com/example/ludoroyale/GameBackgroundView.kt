package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * The backdrop behind every screen: a royal night sky.
 *
 * WHAT IT REPLACED, AND WHY
 *
 * This used to be deep blue water with bubbles drifting through it. Against a
 * gold-and-purple game it read as a fish tank, and the owner asked for royal
 * and galaxy instead. So: a deep violet-to-midnight sky, one purple nebula
 * bloom and one blue one, a field of stars with a handful of bright ones, and
 * a soft gold vignette round the edge to hold the whole screen together.
 *
 * There were dust lanes across the middle for a while. Thin, they read as
 * scratches on the screen; wide, they read as soft grey bars. Neither looked
 * like a galaxy, and the two nebulae already do that job, so they are gone —
 * this is a case where the honest fix was to draw less, not to draw it better.
 *
 * WHY IT IS DRAWN AND NOT A PICTURE
 *
 * A background is the one thing on screen at every size and every aspect ratio
 * a phone can have. A picture would have to be cropped or stretched on most of
 * them, and it would be the largest file in the app for something nobody looks
 * at directly. Drawn from these numbers it fits any screen exactly, costs
 * nothing to ship, and the star field is laid out from a fixed seed so it is
 * the same sky every time rather than shuffling on each redraw.
 */
class GameBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** x, y, radius, brightness — fractions of the view, so it scales anywhere. */
    private val stars = mutableListOf<FloatArray>()

    /** The bright ones, which get a cross of light: x, y, size, tilt. */
    private val brightStars = mutableListOf<FloatArray>()

    init {
        // One fixed seed, so it is the same sky on every redraw rather than a
        // field that reshuffles itself whenever the view is invalidated.
        val rnd = Random(20260921)
        repeat(150) {
            stars += floatArrayOf(
                rnd.nextFloat(), rnd.nextFloat(),
                0.0012f + rnd.nextFloat() * 0.0030f,
                0.25f + rnd.nextFloat() * 0.75f
            )
        }
        repeat(9) {
            brightStars += floatArrayOf(
                rnd.nextFloat(), rnd.nextFloat(),
                0.005f + rnd.nextFloat() * 0.008f,
                rnd.nextFloat() * 90f
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        drawSky(canvas, w, h)
        drawNebula(canvas, w * 0.22f, h * 0.20f, w * 0.85f, NEBULA_VIOLET)
        drawNebula(canvas, w * 0.86f, h * 0.68f, w * 0.75f, NEBULA_BLUE)
        drawStars(canvas, w, h)
        drawBrightStars(canvas, w, h)
        drawVignette(canvas, w, h)
    }

    /** Deep violet at the top falling to midnight at the bottom. */
    private fun drawSky(canvas: Canvas, w: Float, h: Float) {
        paint.shader = LinearGradient(
            0f, 0f, w * 0.35f, h,
            intArrayOf(
                Color.rgb(0x2A, 0x14, 0x5C),   // royal violet
                Color.rgb(0x16, 0x0D, 0x3A),
                Color.rgb(0x09, 0x06, 0x1C)    // midnight
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    /** One soft bloom of colour, the thing that makes it a galaxy and not a wall. */
    private fun drawNebula(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int) {
        paint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(
                Color.argb(96, Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb(34, Color.red(color), Color.green(color), Color.blue(color)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        for (star in stars) {
            val a = (star[3] * 210).toInt().coerceIn(0, 255)
            // a touch of gold in the brighter ones, so the sky belongs with the
            // gold everything else in this game is trimmed with
            paint.color =
                if (star[3] > 0.72f) Color.argb(a, 0xFF, 0xEC, 0xB8)
                else Color.argb(a, 0xE8, 0xE4, 0xFF)
            canvas.drawCircle(star[0] * w, star[1] * h, star[2] * w, paint)
        }
    }

    /** A few stars get a cross of light, which is what sells a night sky. */
    private fun drawBrightStars(canvas: Canvas, w: Float, h: Float) {
        for (star in brightStars) {
            val cx = star[0] * w
            val cy = star[1] * h
            val r = star[2] * w

            paint.shader = RadialGradient(
                cx, cy, r * 2.4f,
                intArrayOf(Color.argb(150, 0xFF, 0xF4, 0xD0), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 2.4f, paint)
            paint.shader = null

            paint.color = Color.argb(235, 0xFF, 0xFF, 0xFF)
            val spike = Path()
            for (i in 0 until 4) {
                val angle = Math.toRadians((star[3] + i * 90f).toDouble())
                val tip = if (i % 2 == 0) r * 2.3f else r * 1.3f
                val side = r * 0.20f
                val ax = cos(angle).toFloat()
                val ay = sin(angle).toFloat()
                spike.moveTo(cx, cy)
                spike.lineTo(cx + ax * tip - ay * side, cy + ay * tip + ax * side)
                spike.lineTo(cx + ax * tip + ay * side, cy + ay * tip - ax * side)
                spike.close()
            }
            canvas.drawPath(spike, paint)
            canvas.drawCircle(cx, cy, r * 0.45f, paint)
        }
    }

    /**
     * A dark edge with a warm gold lip.
     *
     * It does two jobs: it stops the sky competing with the board in the middle
     * of the screen, and the gold ties the backdrop to the frames, the dice and
     * the counters, which are all gold.
     */
    private fun drawVignette(canvas: Canvas, w: Float, h: Float) {
        val r = kotlin.math.max(w, h)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, r * 0.78f,
            intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        stroke.color = Color.argb(60, 0xF2, 0xC1, 0x4E)
        stroke.strokeWidth = w * 0.010f
        val inset = w * 0.012f
        canvas.drawRoundRect(
            RectF(inset, inset, w - inset, h - inset), w * 0.06f, w * 0.06f, stroke
        )
    }

    private companion object {
        val NEBULA_VIOLET = Color.rgb(0x9A, 0x5C, 0xFF)
        val NEBULA_BLUE = Color.rgb(0x2E, 0x8A, 0xFF)
    }
}
