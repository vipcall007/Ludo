package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor

/** The two kinds of arrow painted on the ARROW MODE board. */
enum class ArrowKind { STRAIGHT, HOME }

/**
 * One arrow on the shared 52-cell ring.
 *
 * [cell] is the square it sits on. A STRAIGHT arrow carries any piece that
 * lands exactly on it [forward] squares further along its own route. A HOME
 * arrow belongs to one [color] and carries only that colour's piece straight
 * to the mouth of its home lane; other colours pass over it untouched.
 */
data class BoardArrow(
    val id: String,
    val kind: ArrowKind,
    val cell: Int,
    val forward: Int = 0,
    val color: PlayerColor? = null
)

/**
 * ARROW MODE, laid out exactly as the board is painted: eight arrows in all —
 * four straight and four home, one of each per colour — sitting on the two
 * squares just before each colour turns off the ring into its home lane.
 *
 * Nothing about their behaviour lives in drawing code, so the board can be
 * retuned by editing this one table.
 */
object ArrowConfig {

    /** Only one arrow may fire per dice move — this is what stops a chain. */
    const val MAX_ARROW_MOVES_PER_DICE_MOVE = 1

    /** How far a straight arrow carries a piece. */
    const val STRAIGHT_JUMP = 6

    /** The first square of a colour's home lane, in that colour's own steps. */
    const val HOME_LANE_STEPS = LudoBoard.TRACK_LENGTH   // 52

    private fun straight(id: String, cell: Int) =
        BoardArrow(id, ArrowKind.STRAIGHT, cell, forward = STRAIGHT_JUMP)

    private fun home(id: String, cell: Int, color: PlayerColor) =
        BoardArrow(id, ArrowKind.HOME, cell, color = color)

    /**
     * Ring squares 4/5, 17/18, 30/31 and 43/44 — the pair at the end of each
     * arm, which is where the board art puts them.
     */
    val ARROWS: List<BoardArrow> = listOf(
        straight("straight_1", 4),
        straight("straight_2", 17),
        straight("straight_3", 30),
        straight("straight_4", 43),

        home("home_yellow", 5, PlayerColor.YELLOW),
        home("home_blue", 18, PlayerColor.BLUE),
        home("home_red", 31, PlayerColor.RED),
        home("home_green", 44, PlayerColor.GREEN)
    )

    fun arrowAt(cell: Int): BoardArrow? = ARROWS.firstOrNull { it.cell == cell }

    /** Where each colour leaves the ring for its home lane — drawn as a U-turn. */
    val HOME_TURNS: Map<PlayerColor, Int> =
        PlayerColor.entries.associateWith { it.homeEntryOffset }

    /** Each colour's entry square, drawn with a globe. */
    val START_CELLS: Map<PlayerColor, Int> =
        PlayerColor.entries.associateWith { it.startOffset }

    /**
     * Safety check, also asserted by the tests: every arrow sits on the ring,
     * no square carries two arrows, a straight arrow never lands on another
     * arrow, and each colour has exactly one straight and one home arrow.
     */
    fun isSane(): Boolean {
        val cells = ARROWS.map { it.cell }
        if (cells.size != cells.toSet().size) return false
        if (cells.any { it !in 0 until LudoBoard.TRACK_LENGTH }) return false
        if (ARROWS.count { it.kind == ArrowKind.STRAIGHT } != 4) return false
        if (ARROWS.count { it.kind == ArrowKind.HOME } != 4) return false
        if (ARROWS.filter { it.kind == ArrowKind.HOME }.mapNotNull { it.color }.toSet().size != 4) return false
        return true
    }
}
