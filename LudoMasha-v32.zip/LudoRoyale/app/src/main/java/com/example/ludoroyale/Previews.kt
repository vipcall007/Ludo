package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.TokenArt
import com.example.ludoroyale.cosmetics.TokenArts
import com.example.ludoroyale.cosmetics.TokenOrnament
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * One token, shown on the customize screen.
 *
 * It is drawn from the same [TokenArt] the board uses, so what a player sees in
 * the shop is exactly what they get on the table. A preview that flatters is a
 * small lie that gets discovered at the first match.
 */
class TokenPreviewView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var artId: String = Cosmetics.TOKEN_CROWN
        set(value) { field = value; invalidate() }

    /** The seat colour the preview is drawn in. */
    var pieceColor: Int = Color.rgb(0xE5, 0x30, 0x35)
        set(value) { field = value; invalidate() }

    var dimmed: Boolean = false
        set(value) { field = value; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val r = s * 0.34f
        val art = TokenArts.byId(artId)
        val base = pieceColor
        alpha = if (dimmed) 0.45f else 1f

        if (art.halo != 0) {
            shade.shader = RadialGradient(
                cx, cy, r * 1.9f,
                intArrayOf(art.halo, Color.TRANSPARENT), floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 1.9f, shade)
            shade.shader = null
        }

        fill.color = darken(base, 0.55f)
        canvas.drawCircle(cx, cy + r * 0.05f, r * 1.06f, fill)

        if (art.id != Cosmetics.TOKEN_CROWN) {
            fill.color = art.trim
            canvas.drawCircle(cx, cy + r * 0.02f, r, fill)
        }

        shade.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.40f, r * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null

        fill.color = art.inset
        canvas.drawCircle(cx, cy, r * 0.62f, fill)

        fill.color = base
        ornament(canvas, cx, cy, r * 0.52f, art.ornament, base)

        shade.shader = RadialGradient(
            cx - r * 0.34f, cy - r * 0.46f, r * 0.75f,
            Color.argb((140 + 115 * art.sheen).toInt().coerceIn(0, 255), 255, 255, 255),
            Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null
    }

    private fun ornament(canvas: Canvas, cx: Float, cy: Float, r: Float, o: TokenOrnament, base: Int) {
        fill.color = base
        when (o) {
            TokenOrnament.STAR -> canvas.drawPath(star(cx, cy, r), fill)
            TokenOrnament.GEM -> {
                val p = Path()
                p.moveTo(cx, cy - r); p.lineTo(cx + r * 0.86f, cy - r * 0.18f)
                p.lineTo(cx, cy + r); p.lineTo(cx - r * 0.86f, cy - r * 0.18f); p.close()
                canvas.drawPath(p, fill)
            }
            TokenOrnament.FLAME -> {
                val p = Path()
                p.moveTo(cx, cy - r * 1.05f)
                p.cubicTo(cx + r * 0.90f, cy - r * 0.25f, cx + r * 0.55f, cy + r, cx, cy + r)
                p.cubicTo(cx - r * 0.55f, cy + r, cx - r * 0.90f, cy - r * 0.25f, cx, cy - r * 1.05f)
                p.close()
                canvas.drawPath(p, fill)
            }
            TokenOrnament.CRYSTAL -> {
                val p = Path()
                p.moveTo(cx, cy - r); p.lineTo(cx + r * 0.52f, cy - r * 0.30f)
                p.lineTo(cx + r * 0.34f, cy + r * 0.92f); p.lineTo(cx - r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.52f, cy - r * 0.30f); p.close()
                canvas.drawPath(p, fill)
            }
            TokenOrnament.CROWN -> {
                val p = Path()
                p.moveTo(cx - r * 0.88f, cy + r * 0.62f); p.lineTo(cx - r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx - r * 0.40f, cy + r * 0.06f); p.lineTo(cx, cy - r * 0.86f)
                p.lineTo(cx + r * 0.40f, cy + r * 0.06f); p.lineTo(cx + r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx + r * 0.88f, cy + r * 0.62f); p.close()
                canvas.drawPath(p, fill)
            }
            TokenOrnament.BOLT -> {
                val p = Path()
                p.moveTo(cx + r * 0.30f, cy - r); p.lineTo(cx - r * 0.55f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.02f, cy + r * 0.12f); p.lineTo(cx - r * 0.28f, cy + r)
                p.lineTo(cx + r * 0.58f, cy - r * 0.18f); p.lineTo(cx + r * 0.04f, cy - r * 0.18f)
                p.close()
                canvas.drawPath(p, fill)
            }
            TokenOrnament.PRISM -> {
                for (i in 0 until 3) {
                    val a = (-Math.PI / 2 + i * 2 * Math.PI / 3).toFloat()
                    val p = Path()
                    p.moveTo(cx, cy)
                    p.lineTo(cx + r * cos((a - 0.42f).toDouble()).toFloat(),
                             cy + r * sin((a - 0.42f).toDouble()).toFloat())
                    p.lineTo(cx + r * cos((a + 0.42f).toDouble()).toFloat(),
                             cy + r * sin((a + 0.42f).toDouble()).toFloat())
                    p.close()
                    fill.color = if (i == 1) lighten(base, 0.30f) else base
                    canvas.drawPath(p, fill)
                }
            }
            TokenOrnament.SCALE -> {
                for (i in 0 until 3) {
                    val oy = cy - r * 0.45f + i * r * 0.46f
                    val rr = r * (0.92f - i * 0.16f)
                    fill.color = if (i % 2 == 0) base else darken(base, 0.18f)
                    canvas.drawArc(RectF(cx - rr, oy - rr * 0.8f, cx + rr, oy + rr * 0.8f), 180f, 180f, true, fill)
                }
            }
            TokenOrnament.RING -> {
                stroke.color = base
                stroke.strokeWidth = r * 0.42f
                canvas.drawCircle(cx, cy, r * 0.66f, stroke)
            }
        }
    }

    private fun star(cx: Float, cy: Float, r: Float): Path {
        val p = Path()
        for (i in 0 until 10) {
            val rr = if (i % 2 == 0) r else r * 0.46f
            val a = (-Math.PI / 2 + i * Math.PI / 5)
            val x = cx + (rr * cos(a)).toFloat()
            val y = cy + (rr * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )
}

/**
 * A still frame of a victory effect, so a player can see what they are choosing
 * without having to win a match to find out.
 */
class VictoryEffectPreview @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var effectId: String = Cosmetics.FX_CONFETTI
        set(value) { field = value; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        fill.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.rgb(0x16, 0x1E, 0x46), Color.rgb(0x0A, 0x0E, 0x2C), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(0f, 0f, w, h), h * 0.12f, h * 0.12f, fill)
        fill.shader = null

        val rnd = kotlin.random.Random(effectId.hashCode())
        when (effectId) {
            Cosmetics.FX_GOLD_RAIN -> {
                fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
                repeat(26) {
                    val x = rnd.nextFloat() * w
                    val y = rnd.nextFloat() * h
                    canvas.drawRoundRect(
                        RectF(x, y, x + w * 0.012f, y + h * 0.16f), w * 0.006f, w * 0.006f, fill
                    )
                }
            }
            Cosmetics.FX_FIREWORKS -> {
                val bursts = listOf(
                    Triple(w * 0.28f, h * 0.38f, Color.rgb(0xFF, 0x6B, 0x8A)),
                    Triple(w * 0.68f, h * 0.30f, Color.rgb(0x6B, 0xC8, 0xFF)),
                    Triple(w * 0.50f, h * 0.68f, Color.rgb(0xFF, 0xD1, 0x62))
                )
                for ((bx, by, color) in bursts) {
                    fill.color = color
                    for (i in 0 until 12) {
                        val a = 2.0 * Math.PI * i / 12
                        val rr = h * 0.22f
                        canvas.drawCircle(
                            bx + (rr * cos(a)).toFloat(),
                            by + (rr * sin(a)).toFloat(),
                            h * 0.030f, fill
                        )
                    }
                    fill.color = Color.WHITE
                    canvas.drawCircle(bx, by, h * 0.026f, fill)
                }
            }
            Cosmetics.FX_ROYAL_CROWN -> {
                shade.shader = RadialGradient(
                    w / 2f, h / 2f, h * 0.6f,
                    intArrayOf(Color.argb(140, 0xFF, 0xD1, 0x62), Color.TRANSPARENT),
                    floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
                )
                canvas.drawCircle(w / 2f, h / 2f, h * 0.6f, shade)
                shade.shader = null
                fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
                val r = h * 0.30f
                val cx = w / 2f
                val cy = h * 0.52f
                val p = Path()
                p.moveTo(cx - r, cy + r * 0.52f)
                p.lineTo(cx - r, cy - r * 0.40f)
                p.lineTo(cx - r * 0.42f, cy + r * 0.10f)
                p.lineTo(cx, cy - r * 0.86f)
                p.lineTo(cx + r * 0.42f, cy + r * 0.10f)
                p.lineTo(cx + r, cy - r * 0.40f)
                p.lineTo(cx + r, cy + r * 0.52f)
                p.close()
                canvas.drawPath(p, fill)
            }
            else -> {
                val colors = intArrayOf(
                    Color.rgb(0xE5, 0x30, 0x35), Color.rgb(0x22, 0xA6, 0x4B),
                    Color.rgb(0xFA, 0xBF, 0x16), Color.rgb(0x16, 0x8D, 0xE8)
                )
                repeat(30) {
                    fill.color = colors[rnd.nextInt(colors.size)]
                    val x = rnd.nextFloat() * w
                    val y = rnd.nextFloat() * h
                    canvas.save()
                    canvas.rotate(rnd.nextFloat() * 360f, x, y)
                    canvas.drawRect(x, y, x + w * 0.030f, y + h * 0.055f, fill)
                    canvas.restore()
                }
            }
        }
    }
}
