package com.example.ludoroyale.online

import com.example.ludoroyale.model.GameMode
import com.example.ludoroyale.progression.League

/**
 * The shapes online play will need, and an honest account of what this build
 * can actually do.
 *
 * Everything in this file is a model or an interface. Not one line of it
 * pretends to reach another device, because nothing in this app can: there is
 * no account system, no server and no network code. A phone's own preferences
 * file is not a friends list — it is one phone's notes — and presenting it as
 * a social graph would be a lie the player would discover the moment they
 * asked a friend to check.
 *
 * So every service here is implemented once, by [NotConnected], which reports
 * [ServiceState.NEEDS_BACKEND] and returns nothing. The screens read that
 * state and say plainly that the feature needs an account. When a server does
 * arrive, a real implementation of these same interfaces drops in behind the
 * screens without any of them changing.
 */
enum class ServiceState {
    /** A server exists and this device is talking to it. */
    CONNECTED,
    /** A server exists, but this device cannot reach it right now. */
    OFFLINE,
    /** No server has been built yet. This is the state in this build. */
    NEEDS_BACKEND
}

/** Why a feature is unavailable, in words a player screen can show. */
data class Unavailable(val state: ServiceState, val reason: String)

// --------------------------------------------------------------- identity

/**
 * Who a player is ACROSS devices. Local statistics are not an identity: two
 * phones have no way to agree on who anybody is without one.
 */
data class AccountId(val value: String) {
    companion object {
        val NONE = AccountId("")
    }
}

data class PublicProfile(
    val accountId: AccountId,
    val displayName: String,
    val level: Int,
    val league: League,
    val leaguePoints: Int,
    val avatarId: String,
    val frameId: String
)

// ---------------------------------------------------------------- friends

enum class FriendStatus { ONLINE, IN_MATCH, OFFLINE, UNKNOWN }

data class Friend(
    val accountId: AccountId,
    val displayName: String,
    val status: FriendStatus,
    val level: Int,
    val league: League
)

data class FriendRequest(
    val from: AccountId,
    val to: AccountId,
    val sentAtMs: Long
)

interface FriendService {
    val state: ServiceState
    fun friends(): List<Friend>
    fun pending(): List<FriendRequest>
    fun send(to: AccountId): Unavailable?
    fun accept(request: FriendRequest): Unavailable?
    fun decline(request: FriendRequest): Unavailable?
}

// ------------------------------------------------------------ leaderboard

enum class LeaderboardScope { GLOBAL, FRIENDS }

data class LeaderboardRow(
    val rank: Int,
    val profile: PublicProfile,
    val points: Int
)

interface LeaderboardService {
    val state: ServiceState
    fun rows(scope: LeaderboardScope, limit: Int): List<LeaderboardRow>
    /** Where this player stands, or null when nobody can say. */
    fun myRank(scope: LeaderboardScope): Int?
}

// ------------------------------------------------------------ private room

enum class RoomState { CREATING, WAITING, READY, STARTED, CLOSED }

data class RoomMember(
    val accountId: AccountId,
    val displayName: String,
    val ready: Boolean
)

/**
 * A private room. The code is generated and validated by the SERVER: a code
 * made up on the phone means nothing to anybody else's phone, so this build
 * generates none.
 */
data class PrivateRoom(
    val code: String,
    val host: AccountId,
    val mode: GameMode,
    val maxPlayers: Int,
    val members: List<RoomMember>,
    val state: RoomState
) {
    companion object {
        /** Six digits, the shape the server will be asked to produce. */
        const val CODE_LENGTH = 6

        fun isWellFormed(code: String): Boolean =
            code.length == CODE_LENGTH && code.all { it.isDigit() }
    }
}

interface RoomService {
    val state: ServiceState
    fun create(mode: GameMode, maxPlayers: Int): Result<PrivateRoom>
    fun join(code: String): Result<PrivateRoom>
    fun setReady(ready: Boolean): Unavailable?
    fun leave(): Unavailable?
}

// --------------------------------------------------------------- rematch

enum class RematchState { NONE, REQUESTED, ACCEPTED, DECLINED, EXPIRED }

/**
 * A rematch between two people needs both to agree, which needs a message to
 * travel between two devices. Against the computer, or around one phone, PLAY
 * AGAIN simply rebuilds the same match — that part is real and works now.
 */
interface RematchService {
    val state: ServiceState
    fun request(): Unavailable?
    fun respond(accept: Boolean): Unavailable?
    fun rematchState(): RematchState
}

// -------------------------------------------------------------- reactions

enum class Reaction(val glyph: String) {
    LAUGH("😂"),
    SHOCK("😱"),
    FIRE("🔥"),
    CLAP("👏"),
    COOL("😎"),
    CRY("😭"),
    HEART("❤️"),
    MIND_BLOWN("🤯");

    companion object {
        val PRESET_TEXT = listOf("Nice!", "Got You!", "Wow!", "Good Game!")
    }
}

/**
 * Sending a reaction to an opponent needs a connection. The cooldown is here
 * already so the rule exists before the feature does — a reaction button that
 * can be held down is a way to harass someone, and that should not be the
 * thing we discover after launch.
 */
interface ReactionService {
    val state: ServiceState
    fun send(reaction: Reaction): Unavailable?
    fun sendText(preset: String): Unavailable?

    companion object {
        const val COOLDOWN_MS = 2_000L
        const val MAX_PER_MATCH = 30
    }
}

/**
 * Keeps a sender honest about the cooldown. Works offline; used by both.
 *
 * The first reaction of a match is always allowed: the cooldown is a gap
 * between two sends, and there is nothing before the first one to be too close
 * to. That is what [sent] guards, rather than leaning on a zero timestamp,
 * which would wrongly block the first send on a clock that starts at zero.
 */
class ReactionThrottle(private val nowMs: () -> Long = { System.currentTimeMillis() }) {
    private var lastAtMs = 0L
    private var sent = 0

    fun maySend(): Boolean {
        if (sent >= ReactionService.MAX_PER_MATCH) return false
        if (sent == 0) return true
        return nowMs() - lastAtMs >= ReactionService.COOLDOWN_MS
    }

    fun record() {
        lastAtMs = nowMs()
        sent++
    }

    fun reset() {
        lastAtMs = 0L
        sent = 0
    }
}

// ------------------------------------------------------------- tournament

enum class TournamentRound { QUARTER_FINAL, SEMI_FINAL, FINAL, CHAMPION }

data class TournamentSlot(val profile: PublicProfile?, val eliminated: Boolean)

/**
 * A bracket of eight. Modelled only — running one means matchmaking, waiting
 * rooms and re-seeding between rounds, all of which are server work.
 */
data class Tournament(
    val id: String,
    val name: String,
    val round: TournamentRound,
    val slots: List<TournamentSlot>
) {
    companion object {
        const val SIZE = 8
    }
}

interface TournamentService {
    val state: ServiceState
    fun currentTournament(): Tournament?
    fun join(): Unavailable?
}

// ------------------------------------------------------- the only build we have

/**
 * Every online service, in the only state this build can honestly be in.
 *
 * It returns empty lists rather than invented players, and a reason rather
 * than a fake success, so a screen written against these interfaces today
 * behaves correctly the day a real server replaces it.
 */
object NotConnected :
    FriendService, LeaderboardService, RoomService, RematchService, ReactionService, TournamentService {

    private const val REASON =
        "This needs a Ludo Masha account and a server. The game is offline, so there is nothing to connect to yet."

    private val unavailable = Unavailable(ServiceState.NEEDS_BACKEND, REASON)

    override val state: ServiceState = ServiceState.NEEDS_BACKEND

    val reason: String get() = REASON

    // friends
    override fun friends(): List<Friend> = emptyList()
    override fun pending(): List<FriendRequest> = emptyList()
    override fun send(to: AccountId): Unavailable = unavailable
    override fun accept(request: FriendRequest): Unavailable = unavailable
    override fun decline(request: FriendRequest): Unavailable = unavailable

    // leaderboard
    override fun rows(scope: LeaderboardScope, limit: Int): List<LeaderboardRow> = emptyList()
    override fun myRank(scope: LeaderboardScope): Int? = null

    // rooms
    override fun create(mode: GameMode, maxPlayers: Int): Result<PrivateRoom> =
        Result.failure(IllegalStateException(REASON))

    override fun join(code: String): Result<PrivateRoom> =
        Result.failure(IllegalStateException(REASON))

    override fun setReady(ready: Boolean): Unavailable = unavailable
    override fun leave(): Unavailable = unavailable

    // rematch
    override fun request(): Unavailable = unavailable
    override fun respond(accept: Boolean): Unavailable = unavailable
    override fun rematchState(): RematchState = RematchState.NONE

    // reactions
    override fun send(reaction: Reaction): Unavailable = unavailable
    override fun sendText(preset: String): Unavailable = unavailable

    // tournaments
    override fun currentTournament(): Tournament? = null
    override fun join(): Unavailable = unavailable
}
