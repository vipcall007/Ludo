package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * The celebration over the win screen — drawn in code, no assets.
 *
 * Which one plays is the player's chosen victory effect. They differ only in
 * how they look; each keeps to the same particle budget and the same frame
 * rate, so picking the showiest one never costs anybody a slower phone.
 */
class ConfettiView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Style { CONFETTI, GOLD_RAIN, FIREWORKS, ROYAL_CROWN }

    var style: Style = Style.CONFETTI
        set(value) {
            field = value
            if (running) respawn()
            invalidate()
        }

    private class Piece(
        var x: Float, var y: Float, var vy: Float, var vx: Float,
        var spin: Float, var angle: Float, var w: Float, var h: Float, var color: Int,
        /** Fireworks only: how far through its burst this spark is. */
        var life: Float = 0f,
        var maxLife: Float = 1f,
        var originX: Float = 0f,
        var originY: Float = 0f
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pieces = mutableListOf<Piece>()
    private var running = false
    private val rnd = Random.Default

    /** The same count whichever style is playing. */
    private val budget = 90

    private val palette = intArrayOf(
        Color.rgb(0xE5, 0x30, 0x35), Color.rgb(0x22, 0xA6, 0x4B),
        Color.rgb(0xFA, 0xBF, 0x16), Color.rgb(0x16, 0x8D, 0xE8),
        Color.rgb(0xF2, 0xC1, 0x4E), Color.WHITE
    )

    private val golds = intArrayOf(
        Color.rgb(0xFF, 0xE9, 0xA8), Color.rgb(0xF2, 0xC1, 0x4E),
        Color.rgb(0xD8, 0xA2, 0x28), Color.rgb(0xFF, 0xF4, 0xD0)
    )

    private val sparkColors = intArrayOf(
        Color.rgb(0xFF, 0x6B, 0x8A), Color.rgb(0x6B, 0xC8, 0xFF),
        Color.rgb(0xFF, 0xD1, 0x62), Color.rgb(0x8A, 0xF0, 0xC0),
        Color.rgb(0xC0, 0x8A, 0xFF)
    )

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            step()
            invalidate()
            postDelayed(this, 16)
        }
    }

    fun start() {
        if (running) return
        running = true
        respawn()
        post(ticker)
    }

    fun stop() {
        running = false
        removeCallbacks(ticker)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }

    private fun w() = if (width > 0) width.toFloat() else 1080f
    private fun h() = if (height > 0) height.toFloat() else 1920f

    private fun respawn() {
        pieces.clear()
        repeat(budget) { pieces += newPiece() }
    }

    private fun newPiece(): Piece = when (style) {
        Style.GOLD_RAIN -> Piece(
            x = rnd.nextFloat() * w(),
            y = -rnd.nextFloat() * h(),
            vy = 7f + rnd.nextFloat() * 9f,
            vx = -0.4f + rnd.nextFloat() * 0.8f,
            spin = 0f,
            angle = 0f,
            w = 2.5f + rnd.nextFloat() * 2.5f,
            h = 18f + rnd.nextFloat() * 26f,
            color = golds[rnd.nextInt(golds.size)]
        )

        Style.FIREWORKS -> newSpark()

        Style.ROYAL_CROWN -> Piece(
            x = rnd.nextFloat() * w(),
            y = -rnd.nextFloat() * h(),
            vy = 2f + rnd.nextFloat() * 4f,
            vx = -0.8f + rnd.nextFloat() * 1.6f,
            spin = -3f + rnd.nextFloat() * 6f,
            angle = rnd.nextFloat() * 360f,
            w = 14f + rnd.nextFloat() * 12f,
            h = 14f + rnd.nextFloat() * 12f,
            color = golds[rnd.nextInt(golds.size)]
        )

        Style.CONFETTI -> Piece(
            x = rnd.nextFloat() * w(),
            y = -rnd.nextFloat() * h(),
            vy = 3f + rnd.nextFloat() * 6f,
            vx = -1.2f + rnd.nextFloat() * 2.4f,
            spin = -6f + rnd.nextFloat() * 12f,
            angle = rnd.nextFloat() * 360f,
            w = 8f + rnd.nextFloat() * 10f,
            h = 12f + rnd.nextFloat() * 14f,
            color = palette[rnd.nextInt(palette.size)]
        )
    }

    private fun newSpark(): Piece {
        val ox = w() * (0.15f + rnd.nextFloat() * 0.70f)
        val oy = h() * (0.18f + rnd.nextFloat() * 0.45f)
        val angle = rnd.nextFloat() * (2f * Math.PI.toFloat())
        val speed = 3f + rnd.nextFloat() * 5f
        return Piece(
            x = ox, y = oy,
            vy = sin(angle) * speed,
            vx = cos(angle) * speed,
            spin = 0f, angle = 0f,
            w = 4f + rnd.nextFloat() * 3f,
            h = 4f + rnd.nextFloat() * 3f,
            color = sparkColors[rnd.nextInt(sparkColors.size)],
            life = 0f,
            maxLife = 40f + rnd.nextFloat() * 35f,
            originX = ox, originY = oy
        )
    }

    private fun step() {
        val h = h()
        for (p in pieces) {
            when (style) {
                Style.FIREWORKS -> {
                    p.life += 1f
                    p.x += p.vx
                    p.y += p.vy
                    p.vy += 0.10f          // sparks arc over and fall
                    p.vx *= 0.985f
                    if (p.life >= p.maxLife) {
                        val fresh = newSpark()
                        p.x = fresh.x; p.y = fresh.y
                        p.vx = fresh.vx; p.vy = fresh.vy
                        p.life = 0f; p.maxLife = fresh.maxLife
                        p.color = fresh.color
                        p.w = fresh.w; p.h = fresh.h
                    }
                }
                else -> {
                    p.y += p.vy
                    p.x += p.vx
                    p.angle += p.spin
                    if (p.y > h + 40f) {
                        p.x = rnd.nextFloat() * w()
                        p.y = -30f
                        p.vy = when (style) {
                            Style.GOLD_RAIN -> 7f + rnd.nextFloat() * 9f
                            Style.ROYAL_CROWN -> 2f + rnd.nextFloat() * 4f
                            else -> 3f + rnd.nextFloat() * 6f
                        }
                    }
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        when (style) {
            Style.GOLD_RAIN -> for (p in pieces) {
                paint.color = p.color
                canvas.drawRoundRect(
                    RectF(p.x, p.y, p.x + p.w, p.y + p.h), p.w / 2f, p.w / 2f, paint
                )
            }

            Style.FIREWORKS -> for (p in pieces) {
                val fade = (1f - p.life / p.maxLife).coerceIn(0f, 1f)
                paint.color = Color.argb(
                    (255 * fade).toInt().coerceIn(0, 255),
                    Color.red(p.color), Color.green(p.color), Color.blue(p.color)
                )
                canvas.drawCircle(p.x, p.y, p.w * fade, paint)
            }

            Style.ROYAL_CROWN -> for (p in pieces) {
                paint.color = p.color
                canvas.save()
                canvas.rotate(p.angle, p.x, p.y)
                canvas.drawPath(crown(p.x, p.y, p.w / 2f), paint)
                canvas.restore()
            }

            Style.CONFETTI -> for (p in pieces) {
                paint.color = p.color
                canvas.save()
                canvas.rotate(p.angle, p.x, p.y)
                canvas.drawRect(
                    RectF(p.x - p.w / 2, p.y - p.h / 2, p.x + p.w / 2, p.y + p.h / 2), paint
                )
                canvas.restore()
            }
        }
    }

    private fun crown(cx: Float, cy: Float, r: Float): Path {
        val p = Path()
        p.moveTo(cx - r, cy + r * 0.52f)
        p.lineTo(cx - r, cy - r * 0.40f)
        p.lineTo(cx - r * 0.42f, cy + r * 0.10f)
        p.lineTo(cx, cy - r * 0.86f)
        p.lineTo(cx + r * 0.42f, cy + r * 0.10f)
        p.lineTo(cx + r, cy - r * 0.40f)
        p.lineTo(cx + r, cy + r * 0.52f)
        p.close()
        return p
    }
}
