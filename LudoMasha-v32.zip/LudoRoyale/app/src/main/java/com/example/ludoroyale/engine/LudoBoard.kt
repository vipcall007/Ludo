package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor

/**
 * Pure geometry of a classic Ludo board — no rendering, no Android
 * dependencies. UI layers map these indices onto screen coordinates.
 */
object LudoBoard {
    const val TRACK_LENGTH = 52          // shared outer ring, indices 0..51
    const val HOME_STRETCH_LENGTH = 6    // private final path per color, 0..5
    const val FINAL_INDEX = HOME_STRETCH_LENGTH - 1

    /** Global (0..51) cells that are safe — no captures allowed there. */
    val SAFE_CELLS: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    fun isSafeCell(globalIndex: Int): Boolean = globalIndex in SAFE_CELLS

    /** Converts a token's own relative track position to the shared global index. */
    fun toGlobalIndex(color: PlayerColor, relativeIndex: Int): Int =
        (color.startOffset + relativeIndex) % TRACK_LENGTH

    /** Steps remaining on the shared track before this color enters its home stretch. */
    fun stepsToHomeEntry(color: PlayerColor, relativeIndex: Int): Int {
        val entryRelative = ((color.homeEntryOffset - color.startOffset) + TRACK_LENGTH) % TRACK_LENGTH
        return entryRelative - relativeIndex
    }
}
