package com.example.ludoroyale.progression

import com.example.ludoroyale.cosmetics.CosmeticItem
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.UnlockMethod

/** One rung of the mission track: finish [missionsDone] missions, get [cosmeticId]. */
data class MissionMilestone(val missionsDone: Int, val cosmeticId: String) {
    val item: CosmeticItem? get() = Cosmetics.byId(cosmeticId)
}

/**
 * THE MISSION TRACK — how dice, tokens, avatars and frames are come by.
 *
 * Everything showy in this game is earned by playing, not bought. The player
 * finishes daily missions; the count of missions they have ever finished only
 * ever goes up; and each rung of this track hands over one item when that
 * count passes it.
 *
 * WHY A RUNNING TOTAL RATHER THAN A PRICE
 *
 * A price means the same item can be had twice as fast by playing twice as
 * long in one day, and it means a player who has nothing has no route at all.
 * A running total cannot be rushed and cannot be missed: every mission the
 * player has ever finished still counts, whatever else has happened since, so
 * the track never resets and an item once earned is never taken back.
 *
 * FAIRNESS: every item on this track is a picture. Nothing here touches the
 * dice odds, the rules or the computer players — a Legendary dice rolls the
 * same numbers as the free one.
 */
object MissionRewards {

    /**
     * The rungs, in order.
     *
     * The first few come quickly so a new player sees the track working within
     * a day or two; the later ones stretch out so the Legendary pieces stay
     * worth having. Nothing is ever removed from this list — removing a rung
     * would take an item away from a player who had already earned it.
     */
    val TRACK: List<MissionMilestone> = listOf(
        // Seven rungs, one dice each, and they are the ONLY way to get a dice.
        // The gaps widen as they go, so the Dragon at the end is a season's
        // work rather than a weekend's, and the first one arrives soon enough
        // that a new player can see the track is real.
        MissionMilestone(2, Cosmetics.DN_HEART),
        MissionMilestone(6, Cosmetics.DN_ROBOT),
        MissionMilestone(12, Cosmetics.DN_GHOST),
        MissionMilestone(20, Cosmetics.DN_ALIEN),
        MissionMilestone(32, Cosmetics.DN_ROYAL),
        MissionMilestone(48, Cosmetics.DN_DIAMOND),
        MissionMilestone(70, Cosmetics.DN_DRAGON)
    )

    /** Every item owed to somebody who has finished [total] missions in all. */
    fun unlockedAt(total: Int): List<String> =
        TRACK.filter { it.missionsDone <= total }.map { it.cosmeticId }

    /**
     * What crossing from [before] to [after] hands over, so the game can show
     * it once, at the moment it happens.
     */
    fun earnedBetween(before: Int, after: Int): List<MissionMilestone> {
        if (after <= before) return emptyList()
        return TRACK.filter { it.missionsDone in (before + 1)..after }
    }

    /** The next rung, or null once the whole track is done. */
    fun next(total: Int): MissionMilestone? =
        TRACK.firstOrNull { it.missionsDone > total }

    /** How many missions still to go for [cosmeticId], or null if it is not on the track. */
    fun requiredFor(cosmeticId: String): Int? =
        TRACK.firstOrNull { it.cosmeticId == cosmeticId }?.missionsDone

    /** How far along the whole track somebody is, 0f..1f. */
    fun progress(total: Int): Float {
        val last = TRACK.lastOrNull()?.missionsDone ?: return 1f
        return (total.toFloat() / last).coerceIn(0f, 1f)
    }

    /**
     * The track has to line up with the catalog or somebody is promised an item
     * that does not exist, or owns one there is no way to earn.
     */
    fun isSane(): Boolean {
        // ascending, no rung shared by two items
        val steps = TRACK.map { it.missionsDone }
        if (steps != steps.sorted() || steps.size != steps.toSet().size) return false
        if (steps.any { it < 1 }) return false

        // every rung names a real cosmetic, and never the same one twice
        val ids = TRACK.map { it.cosmeticId }
        if (ids.size != ids.toSet().size) return false
        if (ids.any { Cosmetics.byId(it) == null }) return false

        // and the two lists agree about which items are earned this way
        val claimed = ids.toSet()
        val declared = Cosmetics.ALL
            .filter { it.unlock == UnlockMethod.MISSION }
            .map { it.id }
            .toSet()
        return claimed == declared
    }
}
