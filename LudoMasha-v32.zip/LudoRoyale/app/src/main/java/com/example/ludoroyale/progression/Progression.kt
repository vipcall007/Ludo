package com.example.ludoroyale.progression

/**
 * XP, levels and the coins a match pays — all of it in one place.
 *
 * Every number the player's progress depends on lives here, so the whole curve
 * can be re-balanced by editing this file and nothing else. Nothing in this
 * package imports Android, which is what lets the unit tests run against it.
 *
 * FAIRNESS: nothing here is ever consulted by the rules engine. Level, XP and
 * coins cannot reach [com.example.ludoroyale.engine.LudoEngine] or
 * [com.example.ludoroyale.engine.DiceRoller], so no amount of progress can
 * change a dice result, a legal move, a capture or a win.
 */
object Progression {

    const val MAX_LEVEL = 100

    /** XP needed to climb out of [level] into the next one. */
    fun xpForLevel(level: Int): Int {
        if (level < 1) return 0
        if (level >= MAX_LEVEL) return 0
        return BASE_STEP + (level - 1) * STEP_GROWTH
    }

    /** Total XP a player must have earned in all to stand at [level]. */
    fun totalXpForLevel(level: Int): Long {
        val capped = level.coerceIn(1, MAX_LEVEL)
        var sum = 0L
        for (l in 1 until capped) sum += xpForLevel(l)
        return sum
    }

    /** The level a lifetime total of [xp] puts the player at. */
    fun levelForXp(xp: Long): Int {
        if (xp <= 0L) return 1
        var level = 1
        var spent = 0L
        while (level < MAX_LEVEL) {
            val need = xpForLevel(level)
            if (xp < spent + need) break
            spent += need
            level++
        }
        return level
    }

    /** How far into the current level [xp] stands. */
    fun xpIntoLevel(xp: Long): Int {
        val level = levelForXp(xp)
        return (xp - totalXpForLevel(level)).toInt().coerceAtLeast(0)
    }

    /** How much XP this level asks for in total. 0 at the very top. */
    fun xpSpanForLevel(level: Int): Int = xpForLevel(level)

    /** 0f..1f across the current level, and 1f once the cap is reached. */
    fun progress(xp: Long): Float {
        val level = levelForXp(xp)
        val span = xpSpanForLevel(level)
        if (span <= 0) return 1f
        return (xpIntoLevel(xp).toFloat() / span).coerceIn(0f, 1f)
    }

    /** The milestone title carried at [level]. */
    fun titleFor(level: Int): String {
        var title = TITLES.first().second
        for ((minLevel, name) in TITLES) {
            if (level >= minLevel) title = name else break
        }
        return title
    }

    /** The next milestone above [level], or null at the top. */
    fun nextTitle(level: Int): Pair<Int, String>? =
        TITLES.firstOrNull { it.first > level }

    /** The milestone ladder, exactly as the brief specifies it. */
    val TITLES: List<Pair<Int, String>> = listOf(
        1 to "BEGINNER",
        5 to "BRONZE",
        10 to "SILVER",
        20 to "GOLD",
        30 to "PLATINUM",
        50 to "DIAMOND",
        100 to "LUDO MASHA KING"
    )

    /** XP to leave level 1. */
    private const val BASE_STEP = 120

    /** How much steeper each level is than the one below it. */
    private const val STEP_GROWTH = 30
}

/**
 * What a finished match pays. Fixed, published rules — a match is worth what
 * happened in it and nothing else. No purchase, level or cosmetic changes any
 * of these numbers.
 */
object MatchRewards {

    /** Everyone who plays a match through to the end earns this much XP. */
    const val XP_COMPLETE = 20

    /** On top of that, for winning. */
    const val XP_WIN = 50

    /** Per opponent piece cut, up to [XP_CAPTURE_CAP]. */
    const val XP_PER_CAPTURE = 3
    const val XP_CAPTURE_CAP = 30

    /** Per own piece brought home. */
    const val XP_PER_TOKEN_HOME = 5

    /** Coins for a win, plus a little more for each win in a row. */
    const val COINS_WIN = 100
    const val COINS_STREAK_BONUS = 25

    /** Coins for finishing a match you did not win — effort still counts. */
    const val COINS_COMPLETE = 20

    /** Cap on the streak bonus so a long run cannot run away with the economy. */
    const val COINS_STREAK_CAP = 10

    /** XP for a completed match, from what actually happened in it. */
    fun xpFor(won: Boolean, captures: Int, tokensHome: Int): Int {
        var xp = XP_COMPLETE
        if (won) xp += XP_WIN
        xp += (captures * XP_PER_CAPTURE).coerceAtMost(XP_CAPTURE_CAP)
        xp += tokensHome * XP_PER_TOKEN_HOME
        return xp
    }

    /** Coins for a completed match. [streak] is the run AFTER this match. */
    fun coinsFor(won: Boolean, streak: Int): Int {
        if (!won) return COINS_COMPLETE
        val steps = (streak - 1).coerceIn(0, COINS_STREAK_CAP - 1)
        return COINS_WIN + steps * COINS_STREAK_BONUS
    }
}
