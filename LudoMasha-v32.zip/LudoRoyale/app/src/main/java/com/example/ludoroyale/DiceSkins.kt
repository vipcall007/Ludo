package com.example.ludoroyale

import android.graphics.Color
import com.example.ludoroyale.cosmetics.Cosmetics

/**
 * One dice design. Every value here is a colour, so the face is drawn in code
 * and stays sharp on any screen — there are no image files to ship.
 */
data class DiceSkin(
    val id: String,
    val label: String,
    /** Body gradient, top-left to bottom-right. */
    val top: Int,
    val bottom: Int,
    /** Bright inner bevel and the deeper outer border. */
    val bevel: Int,
    val border: Int,
    val pip: Int,
    /** 0 round pips, 1 rounded-square pips, 2 tiny star pips. */
    val pipStyle: Int = 0
)

/**
 * How every dice looks. What each one COSTS and how it is unlocked lives in
 * [Cosmetics], so a price can be changed without touching a colour, and this
 * file never has to be kept in step with the shop by hand.
 *
 * FAIRNESS: a dice skin is a set of colours and nothing else. None of these
 * values is visible to [com.example.ludoroyale.engine.DiceRoller], so the
 * Dragon dice and the free one roll from exactly the same distribution.
 */
object DiceSkins {

    const val DEFAULT_ID = Cosmetics.DN_GIFT

    /**
     * The nineteen drawn dice the game used to sell.
     *
     * The owner asked for the twelve picture dice to be the whole collection,
     * so none of these is in [ALL] and none of them can be selected or earned.
     * They are kept here, still compiling, because deleting working artwork is
     * easy and drawing it again is not: putting one back in the game is a
     * matter of moving its line into [ALL] and adding it to the catalog.
     */
    val RETIRED: List<DiceSkin> = listOf(
        DiceSkin(
            "gold", "Royal Gold",
            Color.rgb(0xFF, 0xE3, 0x8A), Color.rgb(0xC8, 0x8B, 0x12),
            Color.rgb(0xFF, 0xF2, 0xBE), Color.rgb(0x8A, 0x5B, 0x00),
            Color.rgb(0x14, 0x11, 0x08)
        ),
        DiceSkin(
            "ivory", "Ivory",
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0xD3, 0xDB, 0xE6),
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0x8E, 0x9C, 0xB2),
            Color.rgb(0x1E, 0x28, 0x3C)
        ),
        DiceSkin(
            "ocean", "Ocean",
            Color.rgb(0x6B, 0xE0, 0xF2), Color.rgb(0x10, 0x7A, 0xA8),
            Color.rgb(0xC6, 0xF6, 0xFF), Color.rgb(0x08, 0x46, 0x66),
            Color.WHITE
        ),
        DiceSkin(
            "coral", "Coral",
            Color.rgb(0xFF, 0x9E, 0xA8), Color.rgb(0xD1, 0x3A, 0x52),
            Color.rgb(0xFF, 0xD8, 0xDC), Color.rgb(0x7E, 0x16, 0x28),
            Color.rgb(0xFF, 0xF2, 0xE6), pipStyle = 1
        ),
        DiceSkin(
            "emerald", "Emerald",
            Color.rgb(0x86, 0xE8, 0x9A), Color.rgb(0x18, 0x87, 0x45),
            Color.rgb(0xD2, 0xFA, 0xDA), Color.rgb(0x0B, 0x4A, 0x25),
            Color.rgb(0xF2, 0xFF, 0xF4)
        ),
        DiceSkin(
            "amber", "Amber",
            Color.rgb(0xFF, 0xC9, 0x70), Color.rgb(0xE0, 0x6E, 0x10),
            Color.rgb(0xFF, 0xEA, 0xC2), Color.rgb(0x8C, 0x3C, 0x04),
            Color.rgb(0x35, 0x1A, 0x02), pipStyle = 1
        ),
        DiceSkin(
            "violet", "Violet",
            Color.rgb(0xC9, 0xAA, 0xFF), Color.rgb(0x63, 0x3B, 0xC8),
            Color.rgb(0xE8, 0xDA, 0xFF), Color.rgb(0x33, 0x1A, 0x78),
            Color.WHITE, pipStyle = 2
        ),
        DiceSkin(
            "midnight", "Midnight",
            Color.rgb(0x4A, 0x5C, 0x86), Color.rgb(0x13, 0x1D, 0x3A),
            Color.rgb(0x7E, 0x94, 0xC4), Color.rgb(0x07, 0x0C, 0x1E),
            Color.rgb(0xF2, 0xC1, 0x4E), pipStyle = 2
        ),
        DiceSkin(
            "reef", "Reef",
            Color.rgb(0x7E, 0xF0, 0xD2), Color.rgb(0x0E, 0x8E, 0x86),
            Color.rgb(0xCC, 0xFF, 0xF2), Color.rgb(0x06, 0x50, 0x4C),
            Color.rgb(0x05, 0x33, 0x30)
        ),
        DiceSkin(
            "ruby", "Ruby",
            Color.rgb(0xFF, 0x7A, 0x7A), Color.rgb(0x9E, 0x0B, 0x22),
            Color.rgb(0xFF, 0xC8, 0xC8), Color.rgb(0x5A, 0x04, 0x12),
            Color.WHITE, pipStyle = 2
        ),
        DiceSkin(
            "sand", "Driftwood",
            Color.rgb(0xF0, 0xD8, 0xA8), Color.rgb(0xB0, 0x82, 0x44),
            Color.rgb(0xFF, 0xF0, 0xD4), Color.rgb(0x6B, 0x46, 0x18),
            Color.rgb(0x4A, 0x2E, 0x0C)
        ),
        DiceSkin(
            "storm", "Storm",
            Color.rgb(0xB8, 0xC6, 0xD8), Color.rgb(0x46, 0x56, 0x6E),
            Color.rgb(0xE4, 0xEE, 0xFA), Color.rgb(0x22, 0x2E, 0x42),
            Color.rgb(0x10, 0x18, 0x28), pipStyle = 1
        ),

        // ---- the named set the brief asks for. The number on the face is the
        // first thing each of these is checked against: whatever the body does,
        // the pips stay high-contrast, because a dice you have to squint at is
        // a worse dice however handsome it is.
        DiceSkin(
            "dice_golden", "Golden",
            Color.rgb(0xFF, 0xEB, 0xA6), Color.rgb(0xB8, 0x7A, 0x06),
            Color.rgb(0xFF, 0xF8, 0xD8), Color.rgb(0x70, 0x47, 0x00),
            Color.rgb(0x20, 0x14, 0x00)
        ),
        DiceSkin(
            "dice_diamond", "Diamond",
            Color.rgb(0xF2, 0xFB, 0xFF), Color.rgb(0x9F, 0xC6, 0xE2),
            Color.WHITE, Color.rgb(0x5A, 0x7E, 0x9A),
            Color.rgb(0x10, 0x2A, 0x3C), pipStyle = 2
        ),
        DiceSkin(
            "dice_fire", "Fire",
            Color.rgb(0xFF, 0xC2, 0x4A), Color.rgb(0xC4, 0x26, 0x08),
            Color.rgb(0xFF, 0xE8, 0xB4), Color.rgb(0x6E, 0x14, 0x02),
            Color.rgb(0xFF, 0xF6, 0xE2), pipStyle = 1
        ),
        DiceSkin(
            "dice_ice", "Ice",
            Color.rgb(0xDC, 0xF6, 0xFF), Color.rgb(0x5E, 0xAE, 0xD8),
            Color.rgb(0xF4, 0xFD, 0xFF), Color.rgb(0x2A, 0x6A, 0x92),
            Color.rgb(0x0B, 0x2E, 0x46)
        ),
        DiceSkin(
            "dice_royal", "Royal",
            Color.rgb(0xB9, 0x9A, 0xF4), Color.rgb(0x4A, 0x27, 0xA8),
            Color.rgb(0xE6, 0xD8, 0xFF), Color.rgb(0x26, 0x0F, 0x66),
            Color.rgb(0xFF, 0xE9, 0xA8), pipStyle = 2
        ),
        DiceSkin(
            "dice_neon", "Neon",
            Color.rgb(0x2A, 0xF0, 0xC8), Color.rgb(0x0A, 0x46, 0x6E),
            Color.rgb(0xB6, 0xFF, 0xF0), Color.rgb(0x04, 0x22, 0x36),
            Color.rgb(0x03, 0x1A, 0x2A), pipStyle = 1
        ),
        DiceSkin(
            "dice_dragon", "Dragon",
            Color.rgb(0x74, 0xE8, 0xB0), Color.rgb(0x14, 0x5C, 0x44),
            Color.rgb(0xC8, 0xFF, 0xE4), Color.rgb(0x07, 0x30, 0x24),
            Color.rgb(0x03, 0x1C, 0x14), pipStyle = 2
        )
    )

    /**
     * The eight dice in the game.
     *
     * Every one of them is a PICTURE: DiceView draws it from the files in
     * DiceFaceArt, and these colours are only a fallback for a face that cannot
     * be decoded. A dice that is briefly the wrong colour beats a blank hole.
     */
    val ALL: List<DiceSkin> = listOf(
        picture(Cosmetics.DN_GIFT, "Gift Box", Color.rgb(0xFF, 0xC9, 0x5E), Color.rgb(0x9A, 0x18, 0x18)),
        picture(Cosmetics.DN_HEART, "Ruby Heart", Color.rgb(0xFF, 0x8A, 0x8A), Color.rgb(0x8A, 0x08, 0x10)),
        picture(Cosmetics.DN_ROBOT, "Robo", Color.rgb(0xCB, 0xDA, 0xEE), Color.rgb(0x10, 0x2A, 0x6E)),
        picture(Cosmetics.DN_GHOST, "Ghost Charm", Color.rgb(0xFF, 0x9E, 0xD2), Color.rgb(0x6A, 0x08, 0x3A)),
        picture(Cosmetics.DN_ALIEN, "Alien", Color.rgb(0x8A, 0xF0, 0x5E), Color.rgb(0x0C, 0x2A, 0x3A)),
        picture(Cosmetics.DN_ROYAL, "Royal Crown", Color.rgb(0xFF, 0x8A, 0xC8), Color.rgb(0x6E, 0x04, 0x36)),
        picture(Cosmetics.DN_DIAMOND, "Diamond", Color.rgb(0xF4, 0xFA, 0xFF), Color.rgb(0x16, 0x34, 0x78)),
        picture(Cosmetics.DN_DRAGON, "Dragon Fire", Color.rgb(0xFF, 0xA0, 0x2E), Color.rgb(0x2A, 0x08, 0x04))
    )

    /** A stand-in entry for a dice whose real face is a picture. */
    private fun picture(id: String, label: String, light: Int, dark: Int) = DiceSkin(
        id, label,
        top = light, bottom = dark,
        bevel = Color.rgb(0xFF, 0xF2, 0xC8), border = dark,
        pip = Color.rgb(0x1A, 0x12, 0x06)
    )

    /**
     * The plain dice the computer players roll.
     *
     * The owner asked that only the PERSON playing gets the good dice. A
     * computer rolling a Dragon Fire dice makes the thing the player worked
     * several weeks of hard missions for look like something anybody gets, so
     * the seats that are not a person get the ordinary white one instead.
     *
     * It comes out of [RETIRED] on purpose: it is a real, finished design that
     * simply is not collectable, so it is not in the catalog and cannot be
     * chosen — which is exactly what a plain dice should be.
     */
    val PLAIN: DiceSkin = RETIRED.firstOrNull { it.id == "ivory" } ?: RETIRED.first()

    fun byId(id: String): DiceSkin? = ALL.firstOrNull { it.id == id }

    /**
     * The dice to draw for [id].
     *
     * An id this build does not know — a retired dice still named in a save
     * file from an older version — quietly becomes the free dice rather than
     * leaving a blank square where the dice should be.
     */
    fun resolve(id: String): DiceSkin = byId(id) ?: byId(DEFAULT_ID) ?: ALL.first()
}
