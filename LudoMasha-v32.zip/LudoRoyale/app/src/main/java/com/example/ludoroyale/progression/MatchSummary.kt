package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode

/**
 * Everything one finished match amounted to, worked out once.
 *
 * The victory screen, the share card, the missions and the statistics all read
 * from this single object. Before it existed each of them counted captures its
 * own way and they disagreed; now there is one answer and they quote it.
 */
data class MatchSummary(
    val matchId: String,
    val mode: GameMode,
    val players: Int,
    val teamMode: Boolean,
    val winnerName: String,
    val winnerIsLocal: Boolean,
    val durationMs: Long,

    // what the person holding the phone actually did
    val captures: Int,
    val tokensHome: Int,
    val diceRolls: Int,
    val snakeTriggers: Int,
    val ladderTriggers: Int,
    val arrowTriggers: Int,

    // what it paid
    val xpEarned: Int,
    val coinsEarned: Int,
    val xpBefore: Long,
    val xpAfter: Long,
    val levelBefore: Int,
    val levelAfter: Int,
    val winStreak: Int,
    val bestStreak: Int,

    // local competitive standing
    val leaguePointsBefore: Int,
    val leaguePointsAfter: Int,
    val leagueBefore: League,
    val leagueAfter: League,

    val epicMoments: List<EpicMoment>,
    val missionsCompleted: List<String>,
    val unlocked: List<String>
) {
    val leveledUp: Boolean get() = levelAfter > levelBefore
    val promoted: Boolean get() = leagueAfter.ordinal > leagueBefore.ordinal
    val durationSeconds: Int get() = (durationMs / 1000L).toInt()

    /** "4:12" — the length of the match, for the summary and the share card. */
    fun durationText(): String {
        val total = durationSeconds.coerceAtLeast(0)
        return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
    }
}

/**
 * Counts what the local player did, from the events the match posts.
 *
 * It counts nothing by itself and inspects no game state, so it cannot
 * disagree with the engine: whatever the match reported is what it reports.
 */
class MatchStatsTracker(private val nowMs: () -> Long = { System.currentTimeMillis() }) :
    GameEventListener {

    var startedAtMs: Long = 0L
        private set
    var finishedAtMs: Long = 0L
        private set

    var captures = 0
        private set
    var tokensHome = 0
        private set
    var diceRolls = 0
        private set
    var snakeTriggers = 0
        private set
    var ladderTriggers = 0
        private set
    var arrowTriggers = 0
        private set
    var mode: GameMode = GameMode.CLASSIC
        private set

    /** True once MATCH_COMPLETED has been seen — the guard against paying twice. */
    var completed = false
        private set

    fun reset() {
        startedAtMs = 0L
        finishedAtMs = 0L
        captures = 0
        tokensHome = 0
        diceRolls = 0
        snakeTriggers = 0
        ladderTriggers = 0
        arrowTriggers = 0
        completed = false
    }

    val durationMs: Long
        get() {
            if (startedAtMs == 0L) return 0L
            val end = if (finishedAtMs != 0L) finishedAtMs else nowMs()
            return (end - startedAtMs).coerceAtLeast(0L)
        }

    override fun onGameEvent(event: GameEvent) {
        when (event.type) {
            GameEventType.MATCH_STARTED -> {
                reset()
                startedAtMs = nowMs()
                mode = event.mode
            }
            GameEventType.MATCH_COMPLETED -> {
                if (!completed) {
                    completed = true
                    finishedAtMs = nowMs()
                }
            }
            else -> {
                if (!event.byLocalPlayer) return
                when (event.type) {
                    GameEventType.DICE_ROLLED -> diceRolls += event.count
                    GameEventType.TOKEN_CAPTURED -> captures += event.count
                    GameEventType.TOKEN_HOME -> tokensHome += event.count
                    GameEventType.SNAKE_TRIGGERED -> snakeTriggers += event.count
                    GameEventType.LADDER_TRIGGERED -> ladderTriggers += event.count
                    GameEventType.ARROW_TRIGGERED -> arrowTriggers += event.count
                    else -> Unit
                }
            }
        }
    }
}
