package com.example.ludoroyale.engine

data class RuleConfig(
    val extraTurnOnSix: Boolean = true,
    val threeSixCancelsTurn: Boolean = true,
    val captureGrantsExtraTurn: Boolean = true,
    /** Sending one of your pieces home also earns another roll. */
    val finishGrantsExtraTurn: Boolean = true,
    /** Being carried by an arrow earns another roll (arrow mode only). */
    val arrowGrantsExtraTurn: Boolean = true,
    val exactRollToFinish: Boolean = true,
    val safeCellsBlockCapture: Boolean = true,
    val sixRequiredToLeaveBase: Boolean = true,

    /**
     * BLOCK RULE: two pieces of the same colour standing on one square guard
     * each other. An opponent may still land on that square — it simply cuts
     * nothing. Three or more are protected for the same reason.
     *
     * Note the pair protects itself only: a lone piece sharing the square with
     * somebody else's lone piece is not a block, and is cut as usual.
     */
    val pairBlocksCapture: Boolean = true,

    /**
     * QUICK MODE: a much faster game.
     *  - each player starts with TWO tokens already on the board
     *  - HOME stays LOCKED until that player captures an opponent
     *  - the first player with 1 kill AND 1 token home wins outright
     */
    val quickMode: Boolean = false,

    /** LUDO SNAKE MODE: snakes and ladders act as shortcuts on the Ludo route. */
    val snakeMode: Boolean = false,

    /** ARROW MODE: straight and home arrows painted on the ring carry pieces. */
    val arrowMode: Boolean = false,
    val snakeDifficulty: SnakeDifficulty = SnakeDifficulty.EASY,

    /** Consecutive sixes allowed before the turn is forfeited. */
    val maxConsecutiveSixes: Int = 3,

    /** TEAM MODE (2v2): partners sit opposite each other and cannot capture
     *  their own team's pieces. */
    val teamMode: Boolean = false,

    /** Openly-labelled "lucky dice": rolls the die twice and keeps the higher
     *  face, so sixes and captures happen more often. Applied identically to
     *  EVERY player — it speeds the game up, it does not favour anyone. */
    val luckyDice: Boolean = false
)
