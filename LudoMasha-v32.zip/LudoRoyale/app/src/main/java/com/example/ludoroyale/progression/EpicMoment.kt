package com.example.ludoroyale.progression

/**
 * The moments worth shouting about.
 *
 * Each one is a plain, checkable fact about what happened — no judgement, no
 * fuzzy scoring. If the game says EPIC MOVE, the player can point at the move
 * that earned it.
 */
enum class EpicMomentType(val label: String, val glyph: String, val detail: String) {
    /** One move cut two or more opponent pieces at once. */
    DOUBLE_CAPTURE("DOUBLE CAPTURE", "🔥", "Two pieces sent home in one move"),

    /**
     * The match was won on the last value left on the table — no other banked
     * roll remained to play. The brief calls this both LAST-MOVE WIN and FINAL
     * MOVE WIN; they are the same moment, so it is detected once.
     */
    LAST_MOVE_WIN("LAST MOVE WIN", "👑", "Won on the very last roll in hand"),

    /** A third piece reached home. */
    THREE_TOKENS_HOME("THREE HOME", "🎯", "Three pieces home"),

    /** The run of wins reached five. */
    FIVE_WIN_STREAK("5 WIN STREAK", "👑", "Five wins in a row"),

    /** Sent down a snake during the match, and won it anyway. */
    SNAKE_SAVE("SNAKE SAVE", "🐍", "Bitten by a snake and still won"),

    /** A ladder carried the player up twenty squares or more. */
    LADDER_CLIMB("BIG CLIMB", "🪜", "A ladder worth twenty squares or more");
}

/** One Epic Moment, and when in the match it happened. */
data class EpicMoment(val type: EpicMomentType, val atEventIndex: Int)

/**
 * Watches the match go by and notices the moments above.
 *
 * It only ever watches the person holding the phone: a computer opponent's
 * double capture is not this player's Epic Moment. [onMoment] fires the first
 * time each type is seen, so a long match cannot spam the same banner.
 */
class EpicMomentDetector(
    private val onMoment: (EpicMoment) -> Unit = {}
) : GameEventListener {

    private val seen = LinkedHashSet<EpicMomentType>()
    private val found = mutableListOf<EpicMoment>()
    private var index = 0
    private var tokensHome = 0
    private var bittenBySnake = false
    private var rollsInHandAtWin = 0

    /** Everything found so far, oldest first. */
    val moments: List<EpicMoment> get() = found.toList()

    /** Set before the match so a streak milestone can be spotted on the win. */
    var streakIfWon: Int = 0

    /** The number of banked rolls still unspent, reported with the winning move. */
    fun noteRollsLeftOnWin(rollsLeft: Int) {
        rollsInHandAtWin = rollsLeft
    }

    fun reset() {
        seen.clear()
        found.clear()
        index = 0
        tokensHome = 0
        bittenBySnake = false
        rollsInHandAtWin = 0
    }

    override fun onGameEvent(event: GameEvent) {
        index++
        if (!event.byLocalPlayer && event.type != GameEventType.MATCH_COMPLETED) return

        when (event.type) {
            GameEventType.TOKEN_CAPTURED ->
                if (event.count >= 2) fire(EpicMomentType.DOUBLE_CAPTURE)

            GameEventType.TOKEN_HOME -> {
                tokensHome += event.count
                if (tokensHome >= 3) fire(EpicMomentType.THREE_TOKENS_HOME)
            }

            GameEventType.SNAKE_TRIGGERED -> bittenBySnake = true

            GameEventType.LADDER_TRIGGERED ->
                if (event.value >= BIG_CLIMB) fire(EpicMomentType.LADDER_CLIMB)

            GameEventType.MATCH_WON -> {
                if (rollsInHandAtWin <= 0) fire(EpicMomentType.LAST_MOVE_WIN)
                if (bittenBySnake) fire(EpicMomentType.SNAKE_SAVE)
                if (streakIfWon >= 5) fire(EpicMomentType.FIVE_WIN_STREAK)
            }

            else -> Unit
        }
    }

    private fun fire(type: EpicMomentType) {
        if (!seen.add(type)) return
        val moment = EpicMoment(type, index)
        found += moment
        onMoment(moment)
    }

    private companion object {
        /** Squares a ladder must carry a piece for the big-climb banner. */
        const val BIG_CLIMB = 20
    }
}
