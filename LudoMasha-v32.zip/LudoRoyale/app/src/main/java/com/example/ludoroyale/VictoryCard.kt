package com.example.ludoroyale

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.ludoroyale.progression.MatchSummary
import java.io.File
import java.io.FileOutputStream

/**
 * The picture a player shares after a win.
 *
 * Every number on it comes from the [MatchSummary] the match produced. Nothing
 * is rounded up, padded or invented for effect: if the card says twelve
 * captures, twelve pieces were cut. A share card that flatters is a share card
 * that gets found out.
 */
object VictoryCard {

    private const val W = 1080
    private const val H = 1350

    private val gold = Color.rgb(0xF2, 0xC1, 0x4E)
    private val paleGold = Color.rgb(0xFF, 0xE9, 0xA8)
    private val ink = Color.rgb(0x08, 0x0C, 0x24)

    /** Draws the card. The caller owns the bitmap and should recycle it. */
    fun render(summary: MatchSummary, playerName: String): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        // ---- backdrop
        fill.shader = LinearGradient(
            0f, 0f, 0f, H.toFloat(),
            intArrayOf(Color.rgb(0x17, 0x20, 0x54), Color.rgb(0x0A, 0x0E, 0x2C), ink),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill)
        fill.shader = null

        fill.shader = RadialGradient(
            W / 2f, H * 0.30f, W * 0.75f,
            intArrayOf(Color.argb(90, 0xF2, 0xC1, 0x4E), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill)
        fill.shader = null

        // ---- gold border
        stroke.color = gold
        stroke.strokeWidth = 10f
        c.drawRoundRect(RectF(34f, 34f, W - 34f, H - 34f), 44f, 44f, stroke)
        stroke.color = Color.argb(120, 0xFF, 0xE9, 0xA8)
        stroke.strokeWidth = 3f
        c.drawRoundRect(RectF(54f, 54f, W - 54f, H - 54f), 34f, 34f, stroke)

        // ---- crown
        fill.color = gold
        val crown = Path()
        val cx = W / 2f
        val cy = 200f
        val r = 96f
        crown.moveTo(cx - r, cy + r * 0.52f)
        crown.lineTo(cx - r, cy - r * 0.40f)
        crown.lineTo(cx - r * 0.42f, cy + r * 0.10f)
        crown.lineTo(cx, cy - r * 0.86f)
        crown.lineTo(cx + r * 0.42f, cy + r * 0.10f)
        crown.lineTo(cx + r, cy - r * 0.40f)
        crown.lineTo(cx + r, cy + r * 0.52f)
        crown.close()
        c.drawPath(crown, fill)
        fill.color = Color.rgb(0xE5, 0x30, 0x35)
        c.drawCircle(cx, cy + r * 0.14f, r * 0.16f, fill)

        // ---- headline
        text.color = paleGold
        text.textSize = 96f
        text.letterSpacing = 0.08f
        c.drawText("CHAMPION", cx, 400f, text)

        text.color = Color.WHITE
        text.textSize = 76f
        text.letterSpacing = 0.02f
        c.drawText(playerName.ifBlank { summary.winnerName }.take(18), cx, 500f, text)

        text.color = Color.rgb(0x9F, 0xB6, 0xDE)
        text.textSize = 40f
        text.letterSpacing = 0.10f
        c.drawText(summary.mode.display, cx, 566f, text)

        // ---- the streak, when there is one worth showing
        var y = 660f
        if (summary.winStreak >= 2) {
            fill.color = Color.argb(70, 0xF2, 0xC1, 0x4E)
            c.drawRoundRect(RectF(cx - 300f, y - 66f, cx + 300f, y + 34f), 50f, 50f, fill)
            text.color = paleGold
            text.textSize = 64f
            c.drawText("${summary.winStreak} WIN STREAK", cx, y + 2f, text)
            y += 140f
        }

        // ---- the facts, two to a row
        val facts = buildList {
            add("CAPTURES" to summary.captures.toString())
            add("PIECES HOME" to summary.tokensHome.toString())
            add("DICE ROLLS" to summary.diceRolls.toString())
            add("MATCH TIME" to summary.durationText())
            if (summary.ladderTriggers > 0) add("LADDERS" to summary.ladderTriggers.toString())
            if (summary.snakeTriggers > 0) add("SNAKES" to summary.snakeTriggers.toString())
        }

        val boxW = 430f
        val boxH = 138f
        facts.forEachIndexed { i, (label, value) ->
            val col = i % 2
            val row = i / 2
            val left = cx - boxW - 16f + col * (boxW + 32f)
            val top = y + row * (boxH + 24f)
            fill.color = Color.argb(70, 0x2A, 0x38, 0x70)
            c.drawRoundRect(RectF(left, top, left + boxW, top + boxH), 26f, 26f, fill)
            stroke.color = Color.argb(80, 0xF2, 0xC1, 0x4E)
            stroke.strokeWidth = 2f
            c.drawRoundRect(RectF(left, top, left + boxW, top + boxH), 26f, 26f, stroke)

            text.color = Color.rgb(0x9F, 0xB6, 0xDE)
            text.textSize = 30f
            text.letterSpacing = 0.10f
            c.drawText(label, left + boxW / 2f, top + 52f, text)
            text.color = Color.WHITE
            text.textSize = 56f
            text.letterSpacing = 0.0f
            c.drawText(value, left + boxW / 2f, top + 112f, text)
        }
        y += ((facts.size + 1) / 2) * (boxH + 24f) + 30f

        // ---- level and league
        text.color = paleGold
        text.textSize = 40f
        text.letterSpacing = 0.06f
        c.drawText(
            "LEVEL ${summary.levelAfter}  ·  ${summary.leagueAfter.display}",
            cx, y + 40f, text
        )
        y += 96f

        // ---- epic moments
        if (summary.epicMoments.isNotEmpty()) {
            text.color = Color.rgb(0xFF, 0xB4, 0x5E)
            text.textSize = 34f
            text.letterSpacing = 0.04f
            val line = summary.epicMoments.joinToString("   ·   ") { it.type.label }
            c.drawText(line.take(46), cx, y + 34f, text)
        }

        // ---- signature
        text.color = gold
        text.textSize = 48f
        text.letterSpacing = 0.22f
        c.drawText("LUDO MASHA", cx, H - 110f, text)
        text.color = Color.rgb(0x6C, 0x7F, 0xA8)
        text.textSize = 26f
        text.letterSpacing = 0.06f
        c.drawText("offline pass-n-play", cx, H - 66f, text)

        return bmp
    }

    /**
     * Writes the card into the app's own cache and hands back a URI another
     * app is allowed to read. Nothing is written to shared storage and no
     * permission is asked for.
     */
    fun save(context: Context, bitmap: Bitmap): Uri? = try {
        val dir = File(context.cacheDir, "shared")
        dir.mkdirs()
        val file = File(dir, "ludo_masha_victory.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    } catch (e: Exception) {
        null
    }

    /** The share sheet, with the card attached and a line of text beside it. */
    fun shareIntent(uri: Uri, summary: MatchSummary, playerName: String): Intent {
        val who = playerName.ifBlank { summary.winnerName }
        val line = buildString {
            append("$who won a ${summary.mode.display} match on Ludo Masha")
            if (summary.winStreak >= 2) append(" — ${summary.winStreak} wins in a row")
            append("!")
        }
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, line)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
