package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState

/**
 * Deterministic, UI-independent Ludo rules engine.
 *
 * Turn shape (matches how people actually play):
 *  - Tap dice. A six banks the value and you MUST roll again — the six is not
 *    spent yet.
 *  - Three sixes in a row loses the whole turn and every banked value.
 *  - A non-six ends the rolling phase. You then spend the banked values one at
 *    a time, choosing for EACH value which piece moves it.
 *  - Cutting an opponent, or sending a piece home, earns another roll.
 */
class LudoEngine(
    val state: GameState,
    val rules: RuleConfig = RuleConfig(),
    private val dice: DiceRoller = DiceRoller(lucky = rules.luckyDice)
) {

    /** Rolls for the current player and banks the value. */
    fun rollDice(): RollOutcome {
        check(state.phase == TurnPhase.AWAITING_ROLL) { "Not awaiting a roll." }
        val value = dice.roll(state.currentPlayer.id)
        state.lastDiceRoll = value

        if (value == 6) {
            state.consecutiveSixes++
            if (rules.threeSixCancelsTurn && state.consecutiveSixes >= rules.maxConsecutiveSixes) {
                // Only the three sixes are wasted. Anything else already banked
                // stays and can still be played this turn.
                var toDrop = rules.maxConsecutiveSixes
                val it = state.pendingRolls.iterator()
                while (it.hasNext() && toDrop > 0) {
                    if (it.next() == 6) { it.remove(); toDrop-- }
                }
                state.consecutiveSixes = 0
                return if (state.pendingRolls.isNotEmpty() && legalMoves().isNotEmpty()) {
                    state.phase = TurnPhase.AWAITING_MOVE
                    RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = true)
                } else {
                    state.pendingRolls.clear()
                    advanceTurn(keepSamePlayer = false)
                    RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = true)
                }
            }
            state.pendingRolls.add(value)
            if (rules.extraTurnOnSix) {
                state.phase = TurnPhase.AWAITING_ROLL   // a six always means roll again
                return RollOutcome(value, mustRollAgain = true, turnLostToThreeSixes = false)
            }
        } else {
            state.consecutiveSixes = 0
            state.pendingRolls.add(value)
        }

        state.phase = TurnPhase.AWAITING_MOVE
        return RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = false)
    }

    /** Every legal move across all banked values. Empty = nothing can be played. */
    fun legalMoves(): List<Move> =
        state.pendingRolls.distinct().flatMap { legalMovesFor(it) }

    /** Legal moves that spend exactly the banked value [roll]. */
    fun legalMovesFor(roll: Int): List<Move> {
        val player = movingPlayer()
        val moves = mutableListOf<Move>()
        for (token in player.tokens) {
            when (token.state) {
                TokenState.BASE -> {
                    if (!rules.sixRequiredToLeaveBase || roll == 6) {
                        moves += Move(token, roll, fromSteps = 0, toSteps = 1, leavesBase = true)
                    }
                }
                TokenState.ACTIVE, TokenState.HOME_STRETCH -> {
                    val target = token.steps + roll

                    // QUICK MODE, LOCKED: the padlock is on the DOOR — the last
                    // square before a piece turns off the ring into its home
                    // column. Until this player has cut somebody it stays shut,
                    // and a piece that reaches it does not stop and does not go
                    // in: it carries straight on round the ring for another lap.
                    //
                    // Wrapping here rather than at the finish line matters. A
                    // piece that turned in and then sat in the home column with
                    // nothing to do was the old behaviour, and it is exactly the
                    // standing about the owner asked to be rid of.
                    if (rules.quickMode && !player.hasCapturedOpponent &&
                        token.state == TokenState.ACTIVE && target > RING_STEPS
                    ) {
                        val wrapped = ((target - 1) % RING_STEPS) + 1
                        val cut = capturablesAt(player, wrapped)
                        moves += Move(
                            token, roll, token.steps, wrapped,
                            capturesTokenIds = cut.map { it.id },
                            restartsLap = true
                        )
                        continue
                    }

                    if (target > FINISH_STEPS) continue
                    if (target == FINISH_STEPS) {
                        // A locked player cannot finish. Under the wrap rule
                        // above their pieces never reach the home column in the
                        // first place, so this should be unreachable — but a
                        // rule that says "you cannot go home without a kill"
                        // should be enforced where going home happens, not only
                        // where the piece is stopped from setting out.
                        if (rules.quickMode && !player.hasCapturedOpponent) continue
                        moves += Move(token, roll, token.steps, target, finishesToken = true)
                        continue
                    }
                    val entersHome = token.steps <= LudoBoard.TRACK_LENGTH - 1 &&
                        target > LudoBoard.TRACK_LENGTH - 1
                    val captured =
                        if (target <= LudoBoard.TRACK_LENGTH - 1) capturablesAt(player, target) else emptyList()
                    moves += Move(
                        token = token,
                        usedRoll = roll,
                        fromSteps = token.steps,
                        toSteps = target,
                        capturesTokenIds = captured.map { it.id },
                        entersHomeStretch = entersHome
                    )
                }
                TokenState.FINISHED -> Unit
            }
        }
        return moves
    }

    /** The banked values [token] could actually spend right now, in order. */
    fun rollsPlayableBy(token: Token): List<Int> =
        state.pendingRolls.distinct().sorted()
            .filter { roll -> legalMovesFor(roll).any { it.token.id == token.id } }

    /** Every way [token] could move right now, one per spendable value. */
    fun movesFor(token: Token): List<Move> =
        state.pendingRolls.distinct().sorted()
            .mapNotNull { roll -> legalMovesFor(roll).firstOrNull { it.token.id == token.id } }

    /**
     * The move to play without asking, or null if the player has a real choice.
     *
     * The rule the player sees: if there is only one thing that can be done,
     * the game just does it. "One thing" is counted across EVERY banked value
     * at once, so this covers "only one piece is out and nothing else can use
     * this number", and it also covers a banked value that nothing can spend.
     *
     * The moment two moves exist — two pieces, or one piece with two numbers it
     * could spend — it is the player's decision and the game waits for a tap.
     */
    fun forcedMove(): Move? {
        if (state.phase != TurnPhase.AWAITING_MOVE) return null
        val moves = legalMoves()
        return if (moves.size == 1) moves.first() else null
    }

    /** Plays [move], spending its banked value. */
    fun applyMove(move: Move): MoveResult {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        // TEAM MODE: a player who is already home keeps rolling for their
        // partner, so the piece being moved can belong to somebody else. Every
        // rule below is about the piece's OWNER — whose home it goes to, whose
        // pieces it may not cut — so that is who `player` has to be.
        val player = ownerOf(move.token)
        val playingForPartner = player.id != state.currentPlayer.id

        // ---- 0. QUICK MODE, LOCKED: turned back out for another lap ----
        //
        // The piece went all the way round and found the door shut, so it goes
        // back to its own starting square and sets off again. It does NOT go
        // back to base and it does NOT need another six: the player is being
        // told to go and cut somebody, not being sent to the back of the queue.
        if (move.restartsLap) {
            move.token.steps = move.toSteps
            move.token.state = TokenState.ACTIVE
            state.pendingRolls.remove(move.usedRoll)
            val cutOnArrival = capturablesAt(player, move.token.steps)
            for (victim in cutOnArrival) victim.resetToBase()
            var openedByLap = false
            if (rules.quickMode && cutOnArrival.isNotEmpty() && !player.hasCapturedOpponent) {
                player.hasCapturedOpponent = true
                openedByLap = true
            }
            val againAfterLap =
                rules.captureGrantsExtraTurn && cutOnArrival.isNotEmpty()
            if (againAfterLap) {
                state.consecutiveSixes = 0
                state.lastDiceRoll = null
                state.phase = TurnPhase.AWAITING_ROLL
            } else if (state.pendingRolls.isNotEmpty()) {
                state.phase = TurnPhase.AWAITING_MOVE
                if (legalMoves().isEmpty()) {
                    state.pendingRolls.clear()
                    advanceTurn(keepSamePlayer = false)
                }
            } else {
                advanceTurn(keepSamePlayer = false)
            }
            return MoveResult(
                move = move,
                capturedTokens = cutOnArrival,
                extraTurn = againAfterLap,
                gameWon = false,
                winnerPlayerId = null,
                unlockedHome = openedByLap,
                restartedLap = true,
                playedForPartner = playingForPartner,
                rollsLeft = state.pendingRolls.toList()
            )
        }

        // ---- 1. normal dice movement ----
        move.token.steps = move.toSteps
        move.token.state = when {
            move.finishesToken -> TokenState.FINISHED
            move.toSteps > LudoBoard.TRACK_LENGTH - 1 -> TokenState.HOME_STRETCH
            else -> TokenState.ACTIVE
        }

        // ---- LUDO SNAKE MODE: a snake or ladder fires only on an exact landing,
        // and at most one per dice move, so a chain can never loop. ----
        var specialUsed: Special? = null
        var specialFrom: Int? = null
        var specialTo: Int? = null
        if (rules.snakeMode && move.token.state == TokenState.ACTIVE) {
            val cell = LudoBoard.toGlobalIndex(move.token.color, move.token.steps - 1)
            val special = SnakeLadderConfig.specialAt(rules.snakeDifficulty, cell)
            if (special != null) {
                val newSteps = move.token.steps + special.delta
                // never push a piece off its own valid route
                if (newSteps in 1..(LudoBoard.TRACK_LENGTH - 1)) {
                    specialFrom = move.token.steps
                    specialTo = newSteps
                    move.token.steps = newSteps
                    specialUsed = special
                }
            }
        }

        // ---- ARROW MODE: an arrow fires only on an exact landing, and at most
        // one per dice move, so a piece can never be bounced from arrow to arrow.
        var arrowUsed: BoardArrow? = null
        var arrowFrom: Int? = null
        var arrowTo: Int? = null
        if (rules.arrowMode && move.token.state == TokenState.ACTIVE) {
            val cell = LudoBoard.toGlobalIndex(move.token.color, move.token.steps - 1)
            val arrow = ArrowConfig.arrowAt(cell)
            if (arrow != null) {
                val newSteps = when (arrow.kind) {
                    // a straight arrow dashes any piece further along its own route
                    ArrowKind.STRAIGHT -> {
                        val target = move.token.steps + arrow.forward
                        if (target <= LudoBoard.TRACK_LENGTH - 1) target else null
                    }
                    // a home arrow belongs to one colour and only serves that colour
                    ArrowKind.HOME ->
                        if (arrow.color == move.token.color) ArrowConfig.HOME_LANE_STEPS else null
                }
                if (newSteps != null && newSteps != move.token.steps) {
                    arrowFrom = move.token.steps
                    arrowTo = newSteps
                    move.token.steps = newSteps
                    move.token.state =
                        if (newSteps > LudoBoard.TRACK_LENGTH - 1) TokenState.HOME_STRETCH
                        else TokenState.ACTIVE
                    arrowUsed = arrow
                }
            }
        }

        val reachedHome = move.finishesToken || move.token.state == TokenState.FINISHED

        // ---- 3. captures, judged at the FINAL destination ----
        val capturedTokens = mutableListOf<Token>()
        if (move.token.state == TokenState.ACTIVE) {
            for (victim in capturablesAt(player, move.token.steps)) {
                victim.resetToBase()
                capturedTokens += victim
            }
        }

        // QUICK MODE: a legal capture unlocks HOME for good. Landing on a safe
        // cell captures nothing, so it does not unlock anything either.
        var unlockedHome = false
        if (rules.quickMode && capturedTokens.isNotEmpty() && !player.hasCapturedOpponent) {
            player.hasCapturedOpponent = true
            unlockedHome = true
        }

        state.pendingRolls.remove(move.usedRoll)   // spend exactly this value

        var gameWon = false
        if (reachedHome) {
            player.finishedCount++
            if (rules.quickMode) {
                // QUICK MODE: one kill plus one token home wins outright.
                if (player.hasCapturedOpponent && player.finishedCount >= 1) {
                    player.hasWon = true
                    if (!state.rankings.contains(player.id)) state.rankings += player.id
                    state.phase = TurnPhase.GAME_OVER
                    return MoveResult(
                        move = move,
                        capturedTokens = capturedTokens,
                        extraTurn = false,
                        gameWon = true,
                        winnerPlayerId = player.id,
                        unlockedHome = unlockedHome,
                        playedForPartner = playingForPartner,
                        rollsLeft = emptyList()
                    )
                }
            }
            if (player.finishedCount >= Player.TOKENS_PER_PLAYER) {
                player.hasWon = true
                state.rankings += player.id
                gameWon = if (rules.teamMode && player.team != 0) {
                    state.players.filter { it.team == player.team }.all { it.hasWon }
                } else {
                    state.rankings.size >= state.players.size - 1
                }
            }
        }

        // A cut, or sending a piece home, forces the SAME player to roll again
        // straight away. Whatever is still banked stays banked and can only be
        // spent after that roll.
        val forcesReRoll =
            (rules.captureGrantsExtraTurn && capturedTokens.isNotEmpty()) ||
            (rules.finishGrantsExtraTurn && reachedHome) ||
            (rules.arrowGrantsExtraTurn && arrowUsed != null)

        when {
            gameWon -> {
                // The moment somebody wins, the turn is over. Anything still
                // banked dies with it — a won match must not carry on being
                // played out with the numbers that were left over.
                state.pendingRolls.clear()
                state.lastDiceRoll = null
                state.phase = TurnPhase.GAME_OVER
            }

            forcesReRoll -> {
                state.consecutiveSixes = 0
                state.lastDiceRoll = null
                state.phase = TurnPhase.AWAITING_ROLL    // must roll before moving again
            }

            state.pendingRolls.isNotEmpty() -> {
                state.phase = TurnPhase.AWAITING_MOVE
                if (legalMoves().isEmpty()) {
                    state.pendingRolls.clear()
                    advanceTurn(keepSamePlayer = false)
                }
            }

            else -> advanceTurn(keepSamePlayer = false)
        }

        return MoveResult(
            move = move,
            capturedTokens = capturedTokens,
            extraTurn = forcesReRoll && !gameWon,
            gameWon = gameWon,
            winnerPlayerId = if (gameWon) player.id else null,
            unlockedHome = unlockedHome,
            playedForPartner = playingForPartner,
            special = specialUsed,
            specialFromSteps = specialFrom,
            specialToSteps = specialTo,
            arrow = arrowUsed,
            arrowFromSteps = arrowFrom,
            arrowToSteps = arrowTo,
            rollsLeft = state.pendingRolls.toList()
        )
    }

    /** Nothing playable — drop every banked value and hand over. */
    fun passTurn() {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        state.pendingRolls.clear()
        advanceTurn(keepSamePlayer = false)
    }

    private fun advanceTurn(keepSamePlayer: Boolean) {
        state.pendingRolls.clear()
        if (!keepSamePlayer) {
            var next = (state.currentPlayerIndex + 1) % state.players.size
            var guard = 0
            // A player who has finished is normally skipped. In TEAM MODE they
            // are not: they keep their seat and play it for their partner, so
            // finishing first helps the team instead of taking them out of it.
            while (!canTakeATurn(state.players[next]) && guard < state.players.size) {
                next = (next + 1) % state.players.size
                guard++
            }
            state.currentPlayerIndex = next
            state.consecutiveSixes = 0
        }
        state.lastDiceRoll = null
        state.phase = TurnPhase.AWAITING_ROLL
    }

    /** Whose piece this is — not necessarily whose turn it is. */
    private fun ownerOf(token: Token): Player =
        state.players.firstOrNull { p -> p.tokens.any { it.id == token.id } }
            ?: state.currentPlayer

    /**
     * Whether [player] still has a turn to take.
     *
     * Everyone plays until they are home. In TEAM MODE a player who IS home
     * carries on rolling as long as their partner has pieces left to move,
     * which is the whole point of having a partner.
     */
    private fun canTakeATurn(player: Player): Boolean {
        if (!player.hasWon) return true
        if (!rules.teamMode || player.team == 0) return false
        return state.players.any { it.team == player.team && it.id != player.id && !it.hasWon }
    }

    /** The partner [player] is allowed to move pieces for, if any. */
    fun partnerOf(player: Player): Player? {
        if (!rules.teamMode || player.team == 0) return null
        return state.players.firstOrNull {
            it.team == player.team && it.id != player.id && !it.hasWon
        }
    }

    /**
     * The pieces the player on turn may move right now.
     *
     * Normally their own. Once they are home, and only in TEAM MODE, their
     * partner's instead — which is how a finished player keeps helping.
     */
    private fun movingPlayer(): Player {
        val current = state.currentPlayer
        if (!current.hasWon) return current
        return partnerOf(current) ?: current
    }

    private fun capturablesAt(mover: Player, targetSteps: Int): List<Token> {
        val globalIndex = LudoBoard.toGlobalIndex(mover.color, targetSteps - 1)
        if (rules.safeCellsBlockCapture && LudoBoard.isSafeCell(globalIndex)) return emptyList()
        return state.players
            .filter { it.id != mover.id }
            // team mode: never cut your own partner
            .filter { !(rules.teamMode && it.team != 0 && it.team == mover.team) }
            .flatMap { owner ->
                val standing = owner.tokens.filter {
                    it.state == TokenState.ACTIVE &&
                        LudoBoard.toGlobalIndex(it.color, it.steps - 1) == globalIndex
                }
                // BLOCK RULE: two or more of one player's own pieces on the same
                // square guard each other, so none of them can be cut.
                if (rules.pairBlocksCapture && standing.size >= 2) emptyList() else standing
            }
    }

    /**
     * True if [player] is holding a block — two or more pieces together — on the
     * square [globalIndex]. The board asks this so it can draw the pair with a
     * shield, and so a player can see a block before walking into it.
     */
    fun isBlockedSquare(player: Player, globalIndex: Int): Boolean {
        if (!rules.pairBlocksCapture) return false
        return player.tokens.count {
            it.state == TokenState.ACTIVE &&
                LudoBoard.toGlobalIndex(it.color, it.steps - 1) == globalIndex
        } >= 2
    }

    /** Every square currently guarded by a block, whoever owns it. */
    fun blockedSquares(): Set<Int> {
        if (!rules.pairBlocksCapture) return emptySet()
        val out = mutableSetOf<Int>()
        for (player in state.players) {
            player.tokens
                .filter { it.state == TokenState.ACTIVE }
                .groupingBy { LudoBoard.toGlobalIndex(it.color, it.steps - 1) }
                .eachCount()
                .forEach { (cell, n) -> if (n >= 2) out += cell }
        }
        return out
    }

    companion object {
        /** 51 shared-track steps + 6 home-column steps. */
        const val FINISH_STEPS = 57

        /**
         * How many steps one lap of the shared ring is.
         *
         * A piece walks steps 1..51 on the ring and then turns into its own
         * home column at 52..57. When Quick mode's door is shut it never makes
         * that turn: it wraps back round to step 1 and keeps going, which is
         * what "the piece cannot go in, it comes out again and carries on"
         * means in step numbers.
         */
        const val RING_STEPS = LudoBoard.TRACK_LENGTH - 1
    }
}
