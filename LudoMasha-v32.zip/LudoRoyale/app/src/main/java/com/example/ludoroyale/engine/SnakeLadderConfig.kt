package com.example.ludoroyale.engine

/** How far a special object carries a piece. */
enum class SpecialSize { SMALL, MEDIUM, LARGE, VERY_LARGE }

enum class SpecialType { SNAKE, LADDER }

/**
 * One snake or ladder on the shared Ludo route.
 *
 * [entryCell] is a square on the 52-cell outer ring. [exitCell] is where the
 * piece ends up. Snakes always move a piece backwards, ladders forwards, and
 * both ends stay on the ring so a piece can never be pushed off its route.
 */
data class Special(
    val id: String,
    val type: SpecialType,
    val size: SpecialSize,
    val entryCell: Int,
    val exitCell: Int
) {
    /** Signed distance along the route: positive climbs, negative slides back. */
    val delta: Int get() = exitCell - entryCell
}

/** The three Ludo Snake difficulties. */
enum class SnakeDifficulty { EASY, MEDIUM, HARD }

/**
 * Every snake and ladder lives here — nothing about their behaviour is baked
 * into drawing or UI code, so a board can be retuned by editing this table
 * alone.
 *
 * Counts follow the specification exactly:
 *  EASY   — 3 snakes (2 small, 1 very large) and 6 ladders (1 very large, 2 medium, 3 small)
 *  MEDIUM — 6 small snakes and 6 small ladders
 *  HARD   — 8 mixed snakes and 5 ladders (1 very large, 2 medium, 2 small)
 */
object SnakeLadderConfig {

    /** Only one snake or ladder may fire per dice move — this is what stops loops. */
    const val MAX_SPECIAL_MOVEMENTS_PER_DICE_MOVE = 1

    private fun ladder(id: String, size: SpecialSize, from: Int, jump: Int) =
        Special(id, SpecialType.LADDER, size, from, from + jump)

    private fun snake(id: String, size: SpecialSize, from: Int, drop: Int) =
        Special(id, SpecialType.SNAKE, size, from, from - drop)

    private val EASY: List<Special> = listOf(
        snake("easy_1", SpecialSize.SMALL, 10, 4),
        snake("easy_2", SpecialSize.SMALL, 42, 4),
        snake("easy_3", SpecialSize.VERY_LARGE, 24, 19),
        ladder("easy_4", SpecialSize.VERY_LARGE, 3, 20),
        ladder("easy_5", SpecialSize.MEDIUM, 28, 8),
        ladder("easy_6", SpecialSize.MEDIUM, 37, 8),
        ladder("easy_7", SpecialSize.SMALL, 15, 3),
        ladder("easy_8", SpecialSize.SMALL, 12, 5),
        ladder("easy_9", SpecialSize.SMALL, 44, 4)
    )

    private val MEDIUM: List<Special> = listOf(
        snake("med_1", SpecialSize.SMALL, 28, 5),
        snake("med_2", SpecialSize.SMALL, 30, 4),
        snake("med_3", SpecialSize.SMALL, 20, 4),
        snake("med_4", SpecialSize.SMALL, 12, 3),
        snake("med_5", SpecialSize.SMALL, 50, 5),
        snake("med_6", SpecialSize.SMALL, 6, 3),
        ladder("med_7", SpecialSize.SMALL, 32, 5),
        ladder("med_8", SpecialSize.SMALL, 10, 4),
        ladder("med_9", SpecialSize.SMALL, 43, 3),
        ladder("med_10", SpecialSize.SMALL, 4, 3),
        ladder("med_11", SpecialSize.SMALL, 8, 5),
        ladder("med_12", SpecialSize.SMALL, 36, 4)
    )

    private val HARD: List<Special> = listOf(
        snake("hard_1", SpecialSize.SMALL, 9, 4),
        snake("hard_2", SpecialSize.SMALL, 36, 4),
        snake("hard_3", SpecialSize.MEDIUM, 46, 9),
        snake("hard_4", SpecialSize.MEDIUM, 23, 9),
        snake("hard_5", SpecialSize.LARGE, 25, 15),
        snake("hard_6", SpecialSize.LARGE, 15, 13),
        snake("hard_7", SpecialSize.VERY_LARGE, 38, 22),
        snake("hard_8", SpecialSize.MEDIUM, 27, 8),
        ladder("hard_9", SpecialSize.VERY_LARGE, 30, 19),
        ladder("hard_10", SpecialSize.MEDIUM, 13, 8),
        ladder("hard_11", SpecialSize.MEDIUM, 11, 9),
        ladder("hard_12", SpecialSize.SMALL, 1, 3),
        ladder("hard_13", SpecialSize.SMALL, 7, 5)
    )

    fun specialsFor(difficulty: SnakeDifficulty): List<Special> = when (difficulty) {
        SnakeDifficulty.EASY -> EASY
        SnakeDifficulty.MEDIUM -> MEDIUM
        SnakeDifficulty.HARD -> HARD
    }

    /**
     * The special a piece has LANDED on, or null. Landing is exact — this is
     * only ever asked about the square a dice move finished on, so passing
     * over a trigger can never fire it.
     */
    fun specialAt(difficulty: SnakeDifficulty, globalCell: Int): Special? =
        specialsFor(difficulty).firstOrNull { it.entryCell == globalCell }

    /**
     * Safety check used by the tests: no entry may sit on another special's
     * exit (that would chain), and every end must stay on the ring.
     */
    fun isSane(difficulty: SnakeDifficulty): Boolean {
        val list = specialsFor(difficulty)
        val entries = list.map { it.entryCell }.toSet()
        if (entries.size != list.size) return false                 // two specials on one square
        if (list.any { it.exitCell in entries }) return false        // an exit that chains
        return list.all { it.entryCell in 1..50 && it.exitCell in 1..50 }
    }
}
