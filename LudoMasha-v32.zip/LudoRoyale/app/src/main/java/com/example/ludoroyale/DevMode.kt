package com.example.ludoroyale

/**
 * The owner's test panel.
 *
 * Ludo Masha is offline. Coins, XP and levels are numbers in this phone's own
 * preferences file — there is no real money anywhere in the app, no server,
 * and nobody else's game to affect. So a panel that hands the owner whatever
 * they need in order to test the game is just a tool, and testing the later
 * half of the game any other way would mean playing several hundred matches.
 *
 * HOW IT IS KEPT OUT OF PLAYERS' HANDS
 *
 * There is no button. Nothing in the game hints that this exists. It opens
 * only by tapping the level line in the lobby [TAPS] times in a row and then
 * typing [PASSCODE]. An ordinary player will never find it by accident, and
 * that is the bar this needs to clear.
 *
 * BE CLEAR ABOUT WHAT THIS IS NOT
 *
 * A passcode compiled into an APK is not a secret from a determined person:
 * anyone who unpacks the file can read it. That is fine for what it is for —
 * stopping ordinary players from stumbling in — but it should not be mistaken
 * for security. The only way to make it truly unavailable in a published
 * build is to not ship it, which is what [ENABLED] is for: set it to false and
 * the taps do nothing and the panel cannot be reached at all.
 *
 * WHAT IT DELIBERATELY CANNOT DO
 *
 * Nothing here touches the dice, the rules or the board. The panel can give
 * coins, XP, levels and cosmetics, and it can wipe the save — and that is the
 * whole list. It cannot make a six more likely, because no such switch exists
 * anywhere in this game and this is not the place to add the first one.
 */
object DevMode {

    /**
     * Set this to false in the build you publish and the panel is gone: no
     * taps, no prompt, no way in. It is a compile-time constant, so the code
     * behind it is dropped from the build entirely.
     */
    const val ENABLED = true

    /**
     * CHANGE THIS before the app goes to anybody else.
     *
     * It is the only thing between a curious player and the panel, and the
     * value below is sitting in a public repository, so treat it as already
     * known until you replace it.
     */
    const val PASSCODE = "741963"

    /** Taps on the lobby's level line that bring up the passcode prompt. */
    const val TAPS = 7

    /** Taps this far apart start the count again. */
    const val TAP_WINDOW_MS = 900L

    fun accepts(entered: String): Boolean =
        ENABLED && entered.trim() == PASSCODE

    /** A named amount the panel can hand over, so the buttons stay readable. */
    enum class Grant(val label: String, val coins: Int, val xp: Int) {
        COINS_10K("+10,000 coins", 10_000, 0),
        COINS_100K("+100,000 coins", 100_000, 0),
        XP_5K("+5,000 XP", 0, 5_000),
        XP_50K("+50,000 XP", 0, 50_000)
    }

    /** The levels the panel can jump straight to. */
    val LEVEL_JUMPS = intArrayOf(5, 10, 20, 30, 50, 100)

    /** Counts taps, and forgets them if they come too slowly. */
    class TapCounter(private val nowMs: () -> Long = { System.currentTimeMillis() }) {
        private var count = 0
        private var lastAtMs = 0L

        /** True on the tap that completes the run. */
        fun tap(): Boolean {
            if (!ENABLED) return false
            val now = nowMs()
            count = if (now - lastAtMs > TAP_WINDOW_MS) 1 else count + 1
            lastAtMs = now
            if (count >= TAPS) {
                count = 0
                return true
            }
            return false
        }

        /** How many more are needed. Shown only once the run is well underway. */
        fun remaining(): Int = (TAPS - count).coerceAtLeast(0)

        fun reset() {
            count = 0
            lastAtMs = 0L
        }
    }
}
