package com.example.ludoroyale

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * A full-screen panel, built in code.
 *
 * There are nine of these screens now — profile, customize, missions, daily,
 * leaderboard, friends, rooms, settings, rules — and writing each one out in
 * XML would mean nine copies of the same title bar, scroll view and close
 * button, drifting apart as they were edited. One builder means a change to
 * the look reaches all of them, and a new screen costs a function instead of
 * two hundred lines of layout.
 *
 * The panel puts itself into the host [FrameLayout] and takes itself out again
 * when it is closed, so nothing is left behind holding on to a view.
 */
class SheetPanel private constructor(
    context: Context,
    private val host: FrameLayout,
    title: String,
    subtitle: String?,
    private val onClose: (() -> Unit)?
) {
    private val d = context.resources.displayMetrics.density

    private fun dp(v: Float) = (v * d).toInt()

    /** Everything a caller adds goes in here. */
    val content: LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val root: FrameLayout = FrameLayout(context).apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(Color.parseColor("#F2061128"))
        // swallow taps so the board underneath is never touched by accident
        isClickable = true
        isFocusable = true
    }

    private val ctx = context

    init {
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(10f), dp(14f), dp(14f))
        }

        column.addView(TextView(context).apply {
            text = title
            setTextColor(Color.parseColor("#F2C14E"))
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.10f
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6f)
            layoutParams = lp
        })

        if (!subtitle.isNullOrBlank()) {
            column.addView(TextView(context).apply {
                text = subtitle
                setTextColor(Color.parseColor("#8FB0E4"))
                textSize = 12f
                gravity = Gravity.CENTER
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(4f)
                lp.bottomMargin = dp(4f)
                layoutParams = lp
            })
        }

        val scroll = ScrollView(context).apply {
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            addView(content)
        }
        column.addView(scroll)
        root.addView(column)

        root.addView(TextView(context).apply {
            text = context.getString(R.string.glyph_close)
            setBackgroundResource(R.drawable.btn_close_red)
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            val lp = FrameLayout.LayoutParams(dp(40f), dp(40f), Gravity.TOP or Gravity.END)
            lp.setMargins(dp(12f), dp(12f), dp(12f), dp(12f))
            layoutParams = lp
            setOnClickListener { close() }
        })

        host.removeAllViews()
        host.addView(root)
        host.visibility = View.VISIBLE
    }

    fun close() {
        host.removeAllViews()
        host.visibility = View.GONE
        onClose?.invoke()
    }

    // ------------------------------------------------------ building blocks

    /**
     * A heading with a rule under it, to break a long panel into parts.
     *
     * Deliberately just a heading: everything that follows is added to the
     * panel's own column, so a caller writes `section(...)` then `row(...)`
     * and gets what it reads like. An earlier version returned a box to add
     * rows into, and every caller quietly ignored it and left an empty frame
     * on the screen.
     */
    fun section(title: String) {
        content.addView(TextView(ctx).apply {
            text = title
            setTextColor(Color.parseColor("#9FB6DE"))
            textSize = 11f
            letterSpacing = 0.10f
            setTypeface(typeface, Typeface.BOLD)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(16f)
            lp.bottomMargin = dp(4f)
            layoutParams = lp
        })
        content.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#33F2C14E"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1f)
            ).apply { bottomMargin = dp(4f) }
        })
    }

    fun body(text: String, color: String = "#C8D8F4", size: Float = 13f): TextView {
        val view = TextView(ctx).apply {
            this.text = text
            setTextColor(Color.parseColor(color))
            textSize = size
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4f)
            layoutParams = lp
        }
        content.addView(view)
        return view
    }

    /** A gold call-to-action across the width of the panel. */
    fun primaryButton(label: String, onClick: () -> Unit): TextView {
        val view = TextView(ctx).apply {
            text = label
            setBackgroundResource(R.drawable.bg_button_gold)
            setTextColor(Color.parseColor("#2A1A00"))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.06f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(10f), dp(15f), dp(10f), dp(15f))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14f)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        content.addView(view)
        return view
    }

    /** A quieter button, for a second choice. */
    fun secondaryButton(label: String, onClick: () -> Unit): TextView {
        val view = TextView(ctx).apply {
            text = label
            setBackgroundResource(R.drawable.pill_normal)
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(10f), dp(13f), dp(10f), dp(13f))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8f)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        content.addView(view)
        return view
    }

    /** A label on the left, a value on the right. */
    fun row(label: String, value: String, valueColor: String = "#FFFFFF"): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5f), 0, dp(5f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        row.addView(TextView(ctx).apply {
            text = label
            setTextColor(Color.parseColor("#9FB6DE"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(ctx).apply {
            text = value
            setTextColor(Color.parseColor(valueColor))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        })
        content.addView(row)
        return row
    }

    /** A blank stretch, for breathing room. */
    fun gap(height: Float = 10f) {
        content.addView(View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(height)
            )
        })
    }

    fun add(view: View) {
        content.addView(view)
    }

    companion object {
        /** Opens a panel in [host], replacing whatever was there. */
        fun open(
            context: Context,
            host: FrameLayout,
            title: String,
            subtitle: String? = null,
            onClose: (() -> Unit)? = null,
            build: SheetPanel.() -> Unit
        ): SheetPanel {
            val panel = SheetPanel(context, host, title, subtitle, onClose)
            panel.build()
            return panel
        }
    }
}
