package com.example.ludoroyale

import com.example.ludoroyale.cosmetics.Cosmetics

/**
 * Which picture is on which dice face.
 *
 * WHY THE WHOLE DICE COLLECTION CHANGED
 *
 * The dice before these were photographed as CUBES standing at an angle. The
 * face carrying the number was tilted away from the player, and on a small
 * screen a five was genuinely hard to count. Every one of them is gone.
 *
 * These are drawn FLAT, straight on: the number faces the player, so it can be
 * read at a glance without anything being stamped on top of it.
 *
 * EVERY FACE IS NAMED, ON PURPOSE
 *
 * The obvious way to do this is to look the drawable up by name at runtime.
 * That turns a missing face into a blank square on somebody's phone. Written
 * out like this, a missing face will not compile.
 */
object DiceFaceArt {

    private val FACES: Map<String, IntArray> = mapOf(
        Cosmetics.DN_HEART to intArrayOf(
            R.drawable.dn_heart_1, R.drawable.dn_heart_2, R.drawable.dn_heart_3,
            R.drawable.dn_heart_4, R.drawable.dn_heart_5, R.drawable.dn_heart_6
        ),
        Cosmetics.DN_ROYAL to intArrayOf(
            R.drawable.dn_royal_1, R.drawable.dn_royal_2, R.drawable.dn_royal_3,
            R.drawable.dn_royal_4, R.drawable.dn_royal_5, R.drawable.dn_royal_6
        ),
        Cosmetics.DN_DRAGON to intArrayOf(
            R.drawable.dn_dragon_1, R.drawable.dn_dragon_2, R.drawable.dn_dragon_3,
            R.drawable.dn_dragon_4, R.drawable.dn_dragon_5, R.drawable.dn_dragon_6
        ),
        Cosmetics.DN_ALIEN to intArrayOf(
            R.drawable.dn_alien_1, R.drawable.dn_alien_2, R.drawable.dn_alien_3,
            R.drawable.dn_alien_4, R.drawable.dn_alien_5, R.drawable.dn_alien_6
        ),
        Cosmetics.DN_DIAMOND to intArrayOf(
            R.drawable.dn_diamond_1, R.drawable.dn_diamond_2, R.drawable.dn_diamond_3,
            R.drawable.dn_diamond_4, R.drawable.dn_diamond_5, R.drawable.dn_diamond_6
        ),
        Cosmetics.DN_GHOST to intArrayOf(
            R.drawable.dn_ghost_1, R.drawable.dn_ghost_2, R.drawable.dn_ghost_3,
            R.drawable.dn_ghost_4, R.drawable.dn_ghost_5, R.drawable.dn_ghost_6
        ),
        Cosmetics.DN_ROBOT to intArrayOf(
            R.drawable.dn_robot_1, R.drawable.dn_robot_2, R.drawable.dn_robot_3,
            R.drawable.dn_robot_4, R.drawable.dn_robot_5, R.drawable.dn_robot_6
        ),
        Cosmetics.DN_GIFT to intArrayOf(
            R.drawable.dn_gift_1, R.drawable.dn_gift_2, R.drawable.dn_gift_3,
            R.drawable.dn_gift_4, R.drawable.dn_gift_5, R.drawable.dn_gift_6
        )
    )

    /** True if [id] is one of the picture dice. */
    fun isPicture(id: String): Boolean = id in FACES

    /** The drawable for [value] (1..6) of dice [id], or 0 if there is none. */
    fun face(id: String, value: Int): Int {
        val set = FACES[id] ?: return 0
        return set[(value - 1).coerceIn(0, 5)]
    }

    /** Every dice that has artwork. Used by the pre-build check. */
    fun ids(): Set<String> = FACES.keys
}

/**
 * The avatar portraits, the frames around them, and the counters on the board.
 *
 * All three used to be drawn in code. They are pictures now, and the ids live
 * here rather than being looked up by name for the same reason as the dice: a
 * missing one should stop the build, not appear as a blank square on a phone.
 */
object PictureArt {

    private val AVATARS: Map<String, Int> = mapOf(
        Cosmetics.AV_KING to R.drawable.an_king,
        Cosmetics.AV_TROOPER to R.drawable.an_trooper,
        Cosmetics.AV_THIEF to R.drawable.an_thief,
        Cosmetics.AV_SAMURAI to R.drawable.an_samurai,
        Cosmetics.AV_PANDA to R.drawable.an_panda,
        Cosmetics.AV_PRINCE to R.drawable.an_prince,
        Cosmetics.AV_QUEEN to R.drawable.an_queen,
        Cosmetics.AV_SKULL to R.drawable.an_skull,
        Cosmetics.AV_GAMER to R.drawable.an_gamer,
        Cosmetics.AV_LION to R.drawable.an_lion,
        Cosmetics.AV_NINJA to R.drawable.an_ninja,
        Cosmetics.AV_ALIEN to R.drawable.an_alien,
        Cosmetics.AV_CAT to R.drawable.an_cat,
        Cosmetics.AV_WIZARD to R.drawable.an_wizard,
        Cosmetics.AV_ANGEL to R.drawable.an_angel
    )

    private val FRAMES: Map<String, Int> = mapOf(
        Cosmetics.RK_BRONZE1 to R.drawable.rk_bronze1,
        Cosmetics.RK_BRONZE2 to R.drawable.rk_bronze2,
        Cosmetics.RK_BRONZE3 to R.drawable.rk_bronze3,
        Cosmetics.RK_SILVER1 to R.drawable.rk_silver1,
        Cosmetics.RK_SILVER2 to R.drawable.rk_silver2,
        Cosmetics.RK_SILVER3 to R.drawable.rk_silver3,
        Cosmetics.RK_GOLD1 to R.drawable.rk_gold1,
        Cosmetics.RK_GOLD2 to R.drawable.rk_gold2,
        Cosmetics.RK_GOLD3 to R.drawable.rk_gold3,
        Cosmetics.RK_PLAT1 to R.drawable.rk_plat1,
        Cosmetics.RK_PLAT2 to R.drawable.rk_plat2,
        Cosmetics.RK_PLAT3 to R.drawable.rk_plat3,
        Cosmetics.RK_DIAMOND1 to R.drawable.rk_diamond1,
        Cosmetics.RK_DIAMOND2 to R.drawable.rk_diamond2,
        Cosmetics.RK_DIAMOND3 to R.drawable.rk_diamond3,
        Cosmetics.RK_MASTER1 to R.drawable.rk_master1,
        Cosmetics.RK_MASTER2 to R.drawable.rk_master2,
        Cosmetics.RK_MASTER3 to R.drawable.rk_master3,
        Cosmetics.RK_GRAND1 to R.drawable.rk_grand1,
        Cosmetics.RK_GRAND2 to R.drawable.rk_grand2,
        Cosmetics.RK_GRAND3 to R.drawable.rk_grand3
    )

    fun avatar(id: String): Int = AVATARS[id] ?: 0
    fun frame(id: String): Int = FRAMES[id] ?: 0

    fun avatarIds(): Set<String> = AVATARS.keys
    fun frameIds(): Set<String> = FRAMES.keys
}
