package com.example.ludoroyale

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Choosing which square of a picture becomes the player's face.
 *
 * A photograph off a phone is almost never square and is almost always far
 * bigger than the 220 pixels this needs, so it cannot simply be dropped in: a
 * portrait squashed into a square looks wrong, and a middle crop cuts people's
 * heads off. This view shows the picture with a square window over it and lets
 * the player drag and pinch until the part they want is inside the window.
 *
 * WHY THE WINDOW IS FIXED AND THE PICTURE MOVES
 *
 * The window never changes size or shape. That way what the player sees inside
 * it during the drag is exactly what they get afterwards — the crop cannot come
 * out framed differently from the preview, whatever they did to get there.
 */
class PhotoCropView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var source: Bitmap? = null

    /** Where the picture currently sits, in view coordinates. */
    private var drawnLeft = 0f
    private var drawnTop = 0f
    private var scale = 1f
    private var minScale = 1f

    private val picture = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val scrim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 0, 0, 0)
    }
    private val windowEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xF2, 0xC1, 0x4E)
    }
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 255)
    }

    /**
     * Loads [uri] at roughly the size actually needed.
     *
     * A modern phone photograph is tens of megapixels; decoding one at full
     * size to make a 220-pixel avatar is how an app runs out of memory on the
     * cheaper handsets this game is meant to run on. So the file is measured
     * first, and then decoded subsampled.
     */
    fun load(uri: Uri): Boolean {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        } catch (e: Throwable) {
            return false
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        var sample = 1
        val longest = max(bounds.outWidth, bounds.outHeight)
        while (longest / sample > WORKING_PX * 2) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val loaded = try {
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Throwable) {
            null
        } ?: return false

        source = loaded
        requestLayout()
        post { fitToWindow() }
        invalidate()
        return true
    }

    fun hasPicture(): Boolean = source != null

    /** The square the player settled on, as a bitmap ready to be saved. */
    fun crop(size: Int = OUTPUT_PX): Bitmap? {
        val bitmap = source ?: return null
        val win = windowRect()
        // the window, expressed in the source picture's own pixels
        val sx = (win.left - drawnLeft) / scale
        val sy = (win.top - drawnTop) / scale
        val side = win.width() / scale

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val src = android.graphics.Rect(
            sx.toInt().coerceIn(0, bitmap.width),
            sy.toInt().coerceIn(0, bitmap.height),
            (sx + side).toInt().coerceIn(0, bitmap.width),
            (sy + side).toInt().coerceIn(0, bitmap.height)
        )
        if (src.width() <= 0 || src.height() <= 0) return null
        canvas.drawBitmap(bitmap, src, RectF(0f, 0f, size.toFloat(), size.toFloat()), picture)
        return out
    }

    /** The square window, always centred and always the same shape. */
    private fun windowRect(): RectF {
        val side = min(width, height) * 0.78f
        val cx = width / 2f
        val cy = height / 2f
        return RectF(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f)
    }

    /** Starts with the whole of the shorter side inside the window. */
    private fun fitToWindow() {
        val bitmap = source ?: return
        if (width == 0 || height == 0) return
        val win = windowRect()
        minScale = max(win.width() / bitmap.width, win.height() / bitmap.height)
        scale = minScale
        drawnLeft = win.centerX() - bitmap.width * scale / 2f
        drawnTop = win.centerY() - bitmap.height * scale / 2f
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fitToWindow()
    }

    // ------------------------------------------------------------ the drag

    private var lastX = 0f
    private var lastY = 0f
    private var pinchStart = 0f
    private var scaleAtPinchStart = 1f

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (source == null) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                pinchStart = spread(event)
                scaleAtPinchStart = scale
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2 && pinchStart > 0f) {
                    val factor = spread(event) / pinchStart
                    zoomAround(event, scaleAtPinchStart * factor)
                } else {
                    drawnLeft += event.x - lastX
                    drawnTop += event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    clampToWindow()
                    invalidate()
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                pinchStart = 0f
                // carry on dragging from whichever finger is still down
                val remaining = if (event.actionIndex == 0) 1 else 0
                lastX = event.getX(remaining)
                lastY = event.getY(remaining)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pinchStart = 0f
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun spread(event: MotionEvent): Float {
        if (event.pointerCount < 2) return 0f
        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)
        return sqrt(dx * dx + dy * dy)
    }

    /** Zooms while keeping the point between the fingers where it is. */
    private fun zoomAround(event: MotionEvent, wanted: Float) {
        val focusX = (event.getX(0) + event.getX(1)) / 2f
        val focusY = (event.getY(0) + event.getY(1)) / 2f
        val next = wanted.coerceIn(minScale, minScale * MAX_ZOOM)
        if (abs(next - scale) < 0.0001f) return
        val ratio = next / scale
        drawnLeft = focusX - (focusX - drawnLeft) * ratio
        drawnTop = focusY - (focusY - drawnTop) * ratio
        scale = next
        clampToWindow()
        invalidate()
    }

    /** The window can never show empty space beyond the edge of the picture. */
    private fun clampToWindow() {
        val bitmap = source ?: return
        val win = windowRect()
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        drawnLeft = drawnLeft.coerceIn(win.right - w, win.left)
        drawnTop = drawnTop.coerceIn(win.bottom - h, win.top)
    }

    // ------------------------------------------------------------ the draw

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = source ?: return
        val win = windowRect()
        val corner = win.width() * 0.16f

        canvas.drawBitmap(
            bitmap, null,
            RectF(drawnLeft, drawnTop, drawnLeft + bitmap.width * scale, drawnTop + bitmap.height * scale),
            picture
        )

        // Everything outside the window goes dark.
        //
        // Canvas.clipOutPath is the obvious way to do this and it would be a
        // crash on Android 7, which this game still supports — it arrived in
        // Android 8. Four rectangles around the window need no clipping at all
        // and work everywhere, and the window's rounded corners are covered by
        // the outline drawn over them afterwards.
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, win.top, scrim)
        canvas.drawRect(0f, win.bottom, w, h, scrim)
        canvas.drawRect(0f, win.top, win.left, win.bottom, scrim)
        canvas.drawRect(win.right, win.top, w, win.bottom, scrim)

        // thirds, to help line a face up
        guide.strokeWidth = 1f * resources.displayMetrics.density
        for (i in 1..2) {
            val x = win.left + win.width() * i / 3f
            val y = win.top + win.height() * i / 3f
            canvas.drawLine(x, win.top, x, win.bottom, guide)
            canvas.drawLine(win.left, y, win.right, y, guide)
        }

        windowEdge.strokeWidth = 2.5f * resources.displayMetrics.density
        canvas.drawRoundRect(win, corner, corner, windowEdge)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        source = null
    }

    private companion object {
        /** Big enough to crop from without holding a whole photograph in memory. */
        const val WORKING_PX = 1024

        /** What gets saved: plenty for a 52dp square on any screen. */
        const val OUTPUT_PX = 320

        const val MAX_ZOOM = 5f
    }
}
