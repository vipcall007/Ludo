package com.example.ludoroyale.snl

import com.example.ludoroyale.engine.DiceRoller
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind

/** Rules of the standalone 1..100 board, all in one place. */
data class SnlRules(
    /** Square 100 must be hit exactly; an overshooting roll simply does not move. */
    val exactRollToFinish: Boolean = true,
    /** A six earns another roll. */
    val extraTurnOnSix: Boolean = true,
    /** Three sixes in a row burns the turn. */
    val threeSixCancelsTurn: Boolean = true,
    val maxConsecutiveSixes: Int = 3,
    /**
     * Landing on an opponent sends that piece back to the start.
     *
     * OFF on this board. Two counters simply share a square: the classic
     * printed game has no capture rule, and adding one turns a race into a
     * scrap where whoever is in front gets punished for being in front.
     */
    val cutOpponents: Boolean = false,
    /** A cut earns another roll. Only meaningful when [cutOpponents] is on. */
    val cutGrantsExtraTurn: Boolean = true,

    /**
     * A counter must roll one of these to leave the start pad.
     *
     * The classic rule, and it does real work: the first few turns have some
     * tension in them instead of everyone setting off together on turn one.
     * The number rolled is the square you start on — a 6 starts you on 6.
     */
    val entryRolls: Set<Int> = setOf(1, 6),
    val requireEntryRoll: Boolean = true,

    val difficulty: SnakeDifficulty = SnakeDifficulty.EASY
)

/** One piece — the classic board gives each player exactly one. */
class SnlPlayer(
    val id: String,
    val displayName: String,
    val color: PlayerColor,
    val kind: PlayerKind,
    /** 0 = still on the start pad, 1..100 = on the board. */
    var cell: Int = 0,
    var hasWon: Boolean = false
)

enum class SnlPhase { AWAITING_ROLL, RESOLVING, GAME_OVER }

/** What a roll produced before anything moves. */
data class SnlRoll(
    val value: Int,
    val mustRollAgain: Boolean,
    val turnLostToThreeSixes: Boolean
)

/** Everything one dice move did, decided up front so the animation only replays it. */
data class SnlMoveResult(
    val playerId: String,
    val diceValue: Int,
    val fromCell: Int,
    /** Where the dice alone put the piece. Equals [fromCell] when the roll overshot 100. */
    val landedCell: Int,
    /** The snake or ladder that fired, or null. */
    val special: SnlSpecial?,
    /** Where the piece finally stands. */
    val finalCell: Int,
    /** Opponents knocked back to the start by this move. */
    val cutPlayerIds: List<String>,
    val blocked: Boolean,
    /** Blocked because the counter is still waiting for an entry roll. */
    val needsEntryRoll: Boolean = false,
    val won: Boolean,
    val extraTurn: Boolean
)

/**
 * Authoritative engine for SNAKE & LADDER. It owns the rules; the view only
 * plays back what this returns. Nothing here touches Android, so it is fully
 * unit-testable.
 */
class SnlEngine(
    val players: MutableList<SnlPlayer>,
    val rules: SnlRules = SnlRules(),
    private val dice: DiceRoller = DiceRoller()
) {
    var currentIndex: Int = 0
        private set
    var phase: SnlPhase = SnlPhase.AWAITING_ROLL
        private set
    var lastRoll: Int? = null
        private set
    var consecutiveSixes: Int = 0
        private set
    var winnerId: String? = null
        private set

    val current: SnlPlayer get() = players[currentIndex]

    val specials: List<SnlSpecial> get() = SnlConfig.specialsFor(rules.difficulty)

    // ------------------------------------------------------------------ dice

    fun rollDice(): SnlRoll {
        val value = dice.roll(current.id)
        lastRoll = value

        if (value == 6 && rules.extraTurnOnSix) {
            consecutiveSixes++
            if (rules.threeSixCancelsTurn && consecutiveSixes >= rules.maxConsecutiveSixes) {
                consecutiveSixes = 0
                advance()
                return SnlRoll(value, mustRollAgain = false, turnLostToThreeSixes = true)
            }
        } else {
            consecutiveSixes = 0
        }

        phase = SnlPhase.RESOLVING
        return SnlRoll(value, mustRollAgain = false, turnLostToThreeSixes = false)
    }

    // ------------------------------------------------------------------ move

    /**
     * Works out the whole consequence of [value] for the player to move, and
     * commits it. Order is fixed: dice movement, then the snake/ladder check,
     * then the capture check, then the home check.
     */
    fun resolve(value: Int): SnlMoveResult {
        val player = current
        val from = player.cell

        // --- still on the start pad: only an entry roll gets you onto the board
        if (rules.requireEntryRoll && from == 0 && value !in rules.entryRolls) {
            val extra = value == 6 && rules.extraTurnOnSix
            if (extra) phase = SnlPhase.AWAITING_ROLL else advance()
            return SnlMoveResult(
                playerId = player.id,
                diceValue = value,
                fromCell = from,
                landedCell = from,
                special = null,
                finalCell = from,
                cutPlayerIds = emptyList(),
                blocked = true,
                needsEntryRoll = true,
                won = false,
                extraTurn = extra
            )
        }

        val target = from + value

        // --- dice movement, with square 100 needing an exact roll
        val blocked = rules.exactRollToFinish && target > SnlConfig.LAST_CELL
        val landed = if (blocked) from else target

        // --- snake / ladder check (at most one per dice move, so no chaining)
        val special = if (blocked) null else SnlConfig.specialAt(rules.difficulty, landed)
        val finalCell = special?.exitCell ?: landed

        // --- capture check, on the square the piece actually ends on
        val cuts = mutableListOf<String>()
        if (rules.cutOpponents && finalCell in 1 until SnlConfig.LAST_CELL) {
            for (other in players) {
                if (other.id != player.id && other.cell == finalCell) {
                    other.cell = 0
                    cuts += other.id
                }
            }
        }

        player.cell = finalCell

        // --- home check
        val won = finalCell == SnlConfig.LAST_CELL
        if (won) {
            player.hasWon = true
            winnerId = player.id
            phase = SnlPhase.GAME_OVER
        }

        val extra = !won && (
            (value == 6 && rules.extraTurnOnSix) ||
            (cuts.isNotEmpty() && rules.cutGrantsExtraTurn)
        )

        if (!won) {
            if (extra) phase = SnlPhase.AWAITING_ROLL else advance()
        }

        return SnlMoveResult(
            playerId = player.id,
            diceValue = value,
            fromCell = from,
            landedCell = landed,
            special = special,
            finalCell = finalCell,
            cutPlayerIds = cuts,
            blocked = blocked,
            needsEntryRoll = false,
            won = won,
            extraTurn = extra
        )
    }

    private fun advance() {
        consecutiveSixes = 0
        phase = SnlPhase.AWAITING_ROLL
        if (players.size <= 1) return
        var next = currentIndex
        do {
            next = (next + 1) % players.size
        } while (players[next].hasWon && next != currentIndex)
        currentIndex = next
    }

    /**
     * The squares a piece walks through, one hop at a time, so the animation can
     * step along the board instead of teleporting.
     */
    fun walkPath(from: Int, to: Int): List<Int> {
        if (to <= from) return listOf(to)
        return (from + 1..to).toList()
    }
}
