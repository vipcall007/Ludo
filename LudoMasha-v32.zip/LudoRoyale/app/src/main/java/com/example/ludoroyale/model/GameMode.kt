package com.example.ludoroyale.model

/**
 * The ways Ludo Masha can be played. One name for a mode, used by the board,
 * the missions, the match summary and the statistics alike, so nothing has to
 * guess what kind of match just finished.
 */
enum class GameMode(val display: String) {
    /** Full Ludo: four pieces each, all four home to win. */
    CLASSIC("CLASSIC"),

    /** Fast Ludo: one piece out, home locked until a cut, one piece home wins. */
    QUICK("QUICK"),

    /** The standalone 1..100 board with its snakes and ladders. */
    SNAKES("SNAKES & LADDERS"),

    // LUDO SNAKE — Ludo with snakes and ladders laid over the Ludo track —
    // was removed on the owner's instruction. The standalone 1..100 board above
    // is a different thing and stays.

    /** Ludo, with the eight arrows painted on the track. */
    ARROW("ARROW MODE");

    /** True for the modes played on the Ludo board. */
    val isLudoBoard: Boolean get() = this != SNAKES
}
