package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The daily reward chest — original artwork, drawn here with plain shapes so it
 * costs nothing to ship and stays sharp on any screen.
 *
 * Two states. [ready] true shows the lid thrown open with coins spilling out
 * and a warm glow behind it; false shows it shut and a little dimmer, which is
 * how the player sees at a glance whether today's chest is still waiting.
 */
class ChestView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** Open, glowing and inviting when true; closed and quiet when false. */
    var ready: Boolean = true
        set(value) {
            field = value
            if (value) startShimmer() else stopShimmer()
            invalidate()
        }

    private var shimmer = 0f
    private val shimmerTicker = object : Runnable {
        override fun run() {
            if (!ready) return
            shimmer += 0.09f
            invalidate()
            postDelayed(this, 60)
        }
    }

    private fun startShimmer() {
        removeCallbacks(shimmerTicker)
        post(shimmerTicker)
    }

    private fun stopShimmer() {
        removeCallbacks(shimmerTicker)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (ready) startShimmer()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopShimmer()
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)

    private val woodDark = Color.rgb(0x5A, 0x32, 0x14)
    private val woodMid = Color.rgb(0x8A, 0x52, 0x24)
    private val woodLight = Color.rgb(0xB4, 0x74, 0x36)
    private val goldDark = Color.rgb(0xB8, 0x86, 0x14)
    private val goldMid = Color.rgb(0xF2, 0xC1, 0x4E)
    private val goldLight = Color.rgb(0xFF, 0xE9, 0xA8)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = min(w, h)
        val cx = w / 2f
        val cy = h / 2f

        if (ready) glow(canvas, cx, cy, s)

        // the chest sits in the lower two thirds so an open lid has room above
        val boxW = s * 0.68f
        val boxH = s * 0.34f
        val boxLeft = cx - boxW / 2f
        val boxTop = cy + s * 0.02f
        val boxRect = RectF(boxLeft, boxTop, boxLeft + boxW, boxTop + boxH)

        // soft shadow on the ground
        shade.shader = RadialGradient(
            cx, boxRect.bottom + s * 0.03f, s * 0.42f,
            Color.argb(90, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawOval(
            RectF(cx - s * 0.40f, boxRect.bottom - s * 0.03f, cx + s * 0.40f, boxRect.bottom + s * 0.07f),
            shade
        )
        shade.shader = null

        if (ready) coins(canvas, cx, boxTop, s)
        lid(canvas, cx, boxTop, boxW, s)
        body(canvas, boxRect, s)
        if (ready) sparkles(canvas, cx, boxTop, s)
    }

    /** The warm halo that says "this one is still waiting for you". */
    private fun glow(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        val breathe = 0.80f + 0.20f * sin(shimmer.toDouble()).toFloat()
        shade.shader = RadialGradient(
            cx, cy, s * 0.52f * breathe,
            Color.argb(110, 0xFF, 0xD1, 0x62), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, s * 0.52f * breathe, shade)
        shade.shader = null
    }

    /** The wooden box, with iron bands and a lock plate. */
    private fun body(canvas: Canvas, r: RectF, s: Float) {
        fill.shader = LinearGradient(
            r.left, r.top, r.left, r.bottom,
            intArrayOf(woodLight, woodMid, woodDark), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, s * 0.04f, s * 0.04f, fill)
        fill.shader = null

        // plank seams
        stroke.color = Color.argb(70, 0x30, 0x18, 0x08)
        stroke.strokeWidth = s * 0.012f
        val planks = 3
        for (i in 1 until planks) {
            val x = r.left + r.width() * i / planks
            canvas.drawLine(x, r.top + s * 0.02f, x, r.bottom - s * 0.02f, stroke)
        }

        // gold bands down the corners
        fill.color = goldDark
        val bandW = s * 0.05f
        canvas.drawRoundRect(
            RectF(r.left + s * 0.03f, r.top, r.left + s * 0.03f + bandW, r.bottom),
            bandW / 2f, bandW / 2f, fill
        )
        canvas.drawRoundRect(
            RectF(r.right - s * 0.03f - bandW, r.top, r.right - s * 0.03f, r.bottom),
            bandW / 2f, bandW / 2f, fill
        )

        // the lock plate
        val lockW = s * 0.13f
        val lockH = s * 0.15f
        val lock = RectF(r.centerX() - lockW / 2f, r.top - lockH * 0.35f, r.centerX() + lockW / 2f, r.top + lockH * 0.65f)
        fill.shader = LinearGradient(
            lock.left, lock.top, lock.left, lock.bottom,
            intArrayOf(goldLight, goldMid, goldDark), null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(lock, s * 0.025f, s * 0.025f, fill)
        fill.shader = null
        fill.color = Color.rgb(0x4A, 0x2A, 0x06)
        canvas.drawCircle(lock.centerX(), lock.centerY(), s * 0.022f, fill)
        canvas.drawRect(
            lock.centerX() - s * 0.008f, lock.centerY(),
            lock.centerX() + s * 0.008f, lock.centerY() + s * 0.045f, fill
        )

        // highlight along the top edge
        stroke.color = Color.argb(90, 0xFF, 0xE0, 0xB0)
        stroke.strokeWidth = s * 0.014f
        canvas.drawLine(r.left + s * 0.06f, r.top + s * 0.02f, r.right - s * 0.06f, r.top + s * 0.02f, stroke)
    }

    /** The curved lid — tipped back when the chest is open. */
    private fun lid(canvas: Canvas, cx: Float, boxTop: Float, boxW: Float, s: Float) {
        canvas.save()
        if (ready) {
            // hinge at the back edge, lid swung open
            canvas.rotate(-34f, cx - boxW / 2f, boxTop)
            canvas.translate(0f, -s * 0.02f)
        }

        val lidH = s * 0.22f
        val left = cx - boxW / 2f
        val right = cx + boxW / 2f
        val path = Path().apply {
            moveTo(left, boxTop)
            lineTo(left, boxTop - lidH * 0.35f)
            cubicTo(
                left + boxW * 0.12f, boxTop - lidH * 1.25f,
                right - boxW * 0.12f, boxTop - lidH * 1.25f,
                right, boxTop - lidH * 0.35f
            )
            lineTo(right, boxTop)
            close()
        }
        fill.shader = LinearGradient(
            left, boxTop - lidH, left, boxTop,
            intArrayOf(woodLight, woodMid, woodDark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, fill)
        fill.shader = null

        // iron band over the crown
        stroke.color = goldDark
        stroke.strokeWidth = s * 0.045f
        val band = Path().apply {
            moveTo(cx, boxTop)
            lineTo(cx, boxTop - lidH * 0.92f)
        }
        canvas.drawPath(band, stroke)

        stroke.color = Color.argb(120, 0xFF, 0xE9, 0xA8)
        stroke.strokeWidth = s * 0.014f
        canvas.drawPath(path, stroke)
        canvas.restore()
    }

    /** Coins heaped in the open chest. */
    private fun coins(canvas: Canvas, cx: Float, boxTop: Float, s: Float) {
        val spots = arrayOf(
            floatArrayOf(-0.16f, -0.02f, 0.072f),
            floatArrayOf(0.02f, -0.07f, 0.085f),
            floatArrayOf(0.18f, -0.01f, 0.068f),
            floatArrayOf(-0.06f, 0.02f, 0.060f),
            floatArrayOf(0.11f, 0.03f, 0.056f)
        )
        for (spot in spots) {
            val x = cx + spot[0] * s
            val y = boxTop + spot[1] * s
            val r = spot[2] * s
            fill.shader = LinearGradient(
                x, y - r, x, y + r,
                intArrayOf(goldLight, goldMid, goldDark), null, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(x, y, r, fill)
            fill.shader = null
            stroke.color = Color.argb(150, 0xFF, 0xF4, 0xD0)
            stroke.strokeWidth = s * 0.010f
            canvas.drawCircle(x, y, r * 0.62f, stroke)
        }
    }

    /** A few drifting glints above the open lid. */
    private fun sparkles(canvas: Canvas, cx: Float, boxTop: Float, s: Float) {
        stroke.strokeWidth = s * 0.014f
        for (i in 0 until 4) {
            val phase = shimmer + i * 1.7f
            val life = ((sin(phase.toDouble()) + 1.0) / 2.0).toFloat()
            val angle = (-2.6 + i * 0.55).toFloat()
            val dist = s * (0.20f + 0.16f * life)
            val x = cx + cos(angle.toDouble()).toFloat() * dist * 1.1f
            val y = boxTop - s * 0.10f + sin(angle.toDouble()).toFloat() * dist * 0.55f
            val arm = s * (0.026f + 0.022f * life)
            stroke.color = Color.argb((90 + 150 * life).toInt().coerceIn(0, 255), 0xFF, 0xF0, 0xC0)
            canvas.drawLine(x - arm, y, x + arm, y, stroke)
            canvas.drawLine(x, y - arm, x, y + arm, stroke)
        }
    }
}
