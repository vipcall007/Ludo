package com.example.ludoroyale.progression

/**
 * Competitive standing, which is NOT the same thing as player level.
 *
 * Level is how long someone has played and never goes down. League is how well
 * they are playing now and can go either way. Folding the two into one number
 * would mean a patient beginner outranking a sharp newcomer, so they are kept
 * apart everywhere: two fields, two screens, two meanings.
 *
 * OFFLINE HONESTY: what this file computes is a LOCAL standing from matches on
 * this phone. It is not a world rank and the game does not present it as one.
 * A real, comparable rank needs a server that sees everybody's matches; see
 * [com.example.ludoroyale.online.LeaderboardService].
 */
enum class League(val display: String, val minPoints: Int) {
    BRONZE("BRONZE", 0),
    SILVER("SILVER", 400),
    GOLD("GOLD", 900),
    PLATINUM("PLATINUM", 1500),
    DIAMOND("DIAMOND", 2200),
    MASTER("MASTER", 3000),
    GRAND_MASTER("GRAND MASTER", 4000);

    /** The next rung up, or null at the top. */
    val next: League? get() = entries.getOrNull(ordinal + 1)
}

/**
 * How league points move. Kept small and readable on purpose: a win is worth
 * more than a loss costs, so ordinary play drifts upward, but a losing run
 * still slides back down.
 */
object LeagueRules {

    const val WIN_POINTS = 30
    const val LOSS_POINTS = -18

    /** Points never fall below the floor of the league the player has reached. */
    const val FLOOR_PROTECTION = true

    fun leagueFor(points: Int): League {
        var league = League.BRONZE
        for (l in League.entries) if (points >= l.minPoints) league = l
        return league
    }

    /**
     * The player's points after a finished match. A demotion can happen, but a
     * player never drops below the floor of the league they climbed into, so
     * one bad evening cannot undo a season.
     */
    fun pointsAfter(current: Int, won: Boolean, playerCount: Int): Int {
        val swing = if (won) WIN_POINTS + (playerCount - 2) * 5 else LOSS_POINTS
        val raw = current + swing
        if (!FLOOR_PROTECTION) return raw.coerceAtLeast(0)
        val floor = leagueFor(current).minPoints
        return raw.coerceAtLeast(floor).coerceAtLeast(0)
    }

    /** How far into the current league a points total stands, 0f..1f. */
    fun progress(points: Int): Float {
        val league = leagueFor(points)
        val next = league.next ?: return 1f
        val span = (next.minPoints - league.minPoints).coerceAtLeast(1)
        return ((points - league.minPoints).toFloat() / span).coerceIn(0f, 1f)
    }
}

/** Where a season stands. */
enum class SeasonStatus { UPCOMING, ACTIVE, ENDED }

/**
 * A competitive season.
 *
 * Days are counted the same way the daily reward counts them, so the model
 * works offline today and can be handed real server dates later without
 * changing shape.
 *
 * A season end may adjust COMPETITIVE points. It must never touch permanent
 * progress — level, XP, coins and owned cosmetics all survive a season, and
 * [softReset] is written so it cannot do otherwise.
 */
data class Season(
    val id: Int,
    val name: String,
    val startDay: Int,
    val endDay: Int
) {
    fun statusOn(day: Int): SeasonStatus = when {
        day < startDay -> SeasonStatus.UPCOMING
        day > endDay -> SeasonStatus.ENDED
        else -> SeasonStatus.ACTIVE
    }

    fun daysLeftOn(day: Int): Int = (endDay - day).coerceAtLeast(0)

    companion object {
        const val LENGTH_DAYS = 30

        /** The season a given day falls in, counted from the first launch day. */
        fun forDay(day: Int, epochDay: Int): Season {
            val index = ((day - epochDay).coerceAtLeast(0)) / LENGTH_DAYS
            val start = epochDay + index * LENGTH_DAYS
            return Season(
                id = index + 1,
                name = "LUDO MASHA — SEASON ${index + 1}",
                startDay = start,
                endDay = start + LENGTH_DAYS - 1
            )
        }

        /**
         * Points carried into a new season: pulled back towards Bronze but not
         * wiped, so a strong player starts ahead of a new one without keeping
         * last season's whole lead.
         */
        fun softReset(points: Int): Int = (points * 60 / 100).coerceAtLeast(0)
    }
}
