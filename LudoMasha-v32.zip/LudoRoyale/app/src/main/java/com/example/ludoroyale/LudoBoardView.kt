package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.TokenArt
import com.example.ludoroyale.cosmetics.TokenArts
import com.example.ludoroyale.cosmetics.TokenOrnament
import com.example.ludoroyale.engine.ArrowConfig
import com.example.ludoroyale.engine.ArrowKind
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SnakeLadderConfig
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState
import kotlin.math.min

/**
 * Draws the classic Ludo cross board (wooden frame, circular home yards,
 * arrow-shaped home stretches, star safe cells, direction arrows) plus
 * styled tokens with stack counts, and moves tokens box-by-box.
 * Everything is drawn in code — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    /** Draw the ARROW MODE markings (straight arrows, home arrows, turns). */
    var arrowMode: Boolean = false
        set(value) { field = value; invalidate() }

    /**
     * The token skin in use. It changes the rim, the inset and the ornament —
     * never the body colour, which is how everyone tells whose piece is whose.
     */
    var tokenArt: TokenArt = TokenArts.byId(Cosmetics.TOKEN_CROWN)
        set(value) { field = value; invalidate() }

    /** Called once per square as a piece hops along, so the UI can tick. */
    var onStep: (() -> Unit)? = null

    // ------------------------------------------------- the Quick mode locks

    /**
     * QUICK MODE: whose door is still shut.
     *
     * A small padlock is drawn on the first square of each of these players'
     * home columns — the square a piece has to pass to get home. It is drawn
     * ON THE BOARD, where the rule actually applies, rather than as a message
     * somewhere else: a player looking at their own home column can see for
     * themselves that it is shut and why nothing is going in.
     *
     * Each player has their own. Opening one leaves the others shut.
     */
    var lockedColors: Set<PlayerColor> = emptySet()
        set(value) { field = value; invalidate() }

    private var openingLock: PlayerColor? = null
    private var lockOpenAt = 0L

    private val lockTick = object : Runnable {
        override fun run() {
            if (openingLock == null) return
            if (System.currentTimeMillis() - lockOpenAt >= LOCK_OPEN_MS) {
                openingLock = null
                invalidate()
                return
            }
            invalidate()
            postDelayed(this, 16)
        }
    }

    /**
     * Plays the lock on [color]'s door coming apart.
     *
     * It does not vanish: it flashes white, splits, and scatters as sparks, so
     * the player sees the thing that was stopping them being taken away rather
     * than simply finding it gone the next time they look.
     */
    fun openLockFor(color: PlayerColor) {
        openingLock = color
        lockOpenAt = System.currentTimeMillis()
        removeCallbacks(lockTick)
        post(lockTick)
    }

    // ------------------------------------------------------- the picture art

    private var boardArt: android.graphics.Bitmap? = null
    private var boardArtFailed = false

    /**
     * A colour wash laid over the board picture, or 0 for the plain board.
     *
     * ONE BOARD, SEVEN MOODS. Every game mode was asked to have a board of its
     * own. Seven separate board pictures would be seven things to keep in step
     * — every squint at a cell position, every measurement in BoardGeometry,
     * redone seven times — and the first one to drift would put pieces in the
     * wrong place in one mode only, which is the sort of bug that takes a week
     * to find. So the board stays one picture and one set of measurements, and
     * each mode gets its own light over it.
     *
     * The alpha in these colours is deliberately low. The board has to stay
     * readable above everything else: a player must be able to tell a green
     * square from a yellow one at a glance, and no amount of atmosphere is
     * worth taking that away.
     */
    var boardTint: Int = 0
        set(value) { field = value; invalidate() }
    private val tokenArtBitmaps = HashMap<PlayerColor, android.graphics.Bitmap?>()
    private val boardPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val piecePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    var tappableTokenIds: Set<String> = emptySet()
        set(value) {
            field = value
            if (value.isEmpty()) stopPulse() else startPulse()
            invalidate()
        }

    // Movable pieces breathe in and out so the player can spot them instantly.
    private var pulse = 1f
    private var pulseUp = true
    private var pulsing = false

    private val pulseTick = object : Runnable {
        override fun run() {
            if (!pulsing) return
            pulse += if (pulseUp) 0.022f else -0.022f
            if (pulse >= 1.18f) { pulse = 1.18f; pulseUp = false }
            if (pulse <= 1.0f) { pulse = 1.0f; pulseUp = true }
            invalidate()
            postDelayed(this, 32)
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        pulse = 1f
        pulseUp = true
        post(pulseTick)
    }

    private fun stopPulse() {
        pulsing = false
        pulse = 1f
        removeCallbacks(pulseTick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopPulse()   // don't keep ticking after the view is gone
        // and let the board and counter pictures go: they are several
        // megabytes together, and the next board will decode its own
        boardArt = null
        tokenArtBitmaps.clear()
    }

    var onTokenTapped: ((Token) -> Unit)? = null

    /** Picked one of the little number chips floating over a piece. */
    var onChoicePicked: ((Int) -> Unit)? = null

    // Small number chips shown right above a piece, so the player never
    // leaves the board to say how many points to give it.
    /** LUDO SNAKE MODE: which board to draw, or null for none. */
    var snakeDifficulty: SnakeDifficulty? = null
        set(value) { field = value; invalidate() }

    /** Ring cell of the snake head / ladder foot that is currently firing. */
    private var glowingSpecialCell: Int? = null
    private var specialGlow = 0f
    private var glowRunning = false

    private val glowTick = object : Runnable {
        override fun run() {
            if (!glowRunning) return
            specialGlow += 0.16f
            if (specialGlow > 2f * Math.PI.toFloat()) specialGlow -= 2f * Math.PI.toFloat()
            invalidate()
            postDelayed(this, 40)
        }
    }

    /** Lights up a snake head or ladder foot while its shortcut plays. */
    fun setSpecialGlow(cell: Int?) {
        glowingSpecialCell = cell
        if (cell != null) {
            if (!glowRunning) { glowRunning = true; post(glowTick) }
        } else {
            glowRunning = false
            removeCallbacks(glowTick)
            specialGlow = 0f
        }
        invalidate()
    }

    /**
     * Rides a snake or ladder: the piece follows the drawn shape rather than
     * cutting straight across, so a slide really looks like a slide and a
     * climb really looks like a climb.
     */
    fun rideSpecial(
        tokenId: String,
        color: PlayerColor,
        fromSteps: Int,
        toSteps: Int,
        isLadder: Boolean,
        onComplete: () -> Unit
    ) {
        val a = BoardGeometry.centerForSteps(color, fromSteps)
        val b = BoardGeometry.centerForSteps(color, toSteps)
        val path = mutableListOf<Pair<Float, Float>>()

        val steps = 22
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val r = a.first + (b.first - a.first) * t
            val c = a.second + (b.second - a.second) * t
            if (isLadder) {
                // climb straight, with a small rise so it reads as going up
                path += (r - kotlin.math.sin(t * Math.PI).toFloat() * 0.18f) to c
            } else {
                // follow the snake's wave, matching how it is drawn
                val dr = b.first - a.first
                val dc = b.second - a.second
                val len = kotlin.math.sqrt(dr * dr + dc * dc).coerceAtLeast(0.001f)
                val nr = -dc / len
                val nc = dr / len
                val amp = 0.42f * kotlin.math.sin(t * Math.PI * 3).toFloat()
                path += (r + nr * amp) to (c + nc * amp)
            }
        }
        glide(tokenId, path, onComplete, perLegMs = if (isLadder) 26L else 22L)
    }

    private var choiceTokenId: String? = null
    private var choiceValues: List<Int> = emptyList()
    private val chipRects = mutableListOf<Pair<Int, RectF>>()

    fun showChoices(tokenId: String, values: List<Int>) {
        choiceTokenId = tokenId
        choiceValues = values
        invalidate()
    }

    fun clearChoices() {
        choiceTokenId = null
        choiceValues = emptyList()
        chipRects.clear()
        invalidate()
    }

    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Token currently vanishing/reappearing for an ARROW-MODE magic jump. */
    private var fadingTokenId: String? = null
    private var fadeAlpha: Float = 1f

    /**
     * ARROW MODE magic move: the piece puffs out at the arrow's start and
     * reappears where the arrow ends, instead of walking the gap.
     */
    fun magicTeleport(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit) {
        fadingTokenId = tokenId
        fadeOut(tokenId, color, toSteps, onComplete, 1f)
    }

    private fun fadeOut(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit, a: Float) {
        if (a <= 0.05f) {
            // reappear at the arrow's end
            displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, toSteps)
            fadeIn(tokenId, onComplete, 0f)
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeOut(tokenId, color, toSteps, onComplete, a - 0.16f) }, 34)
    }

    private fun fadeIn(tokenId: String, onComplete: () -> Unit, a: Float) {
        if (a >= 1f) {
            fadeAlpha = 1f
            fadingTokenId = null
            invalidate()
            onComplete()
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeIn(tokenId, onComplete, a + 0.16f) }, 34)
    }

    /** Instantly syncs the board to [newState] (game start, or after a hop lands). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /** Moves one token cell-by-cell from [fromSteps] to [toSteps], then calls [onComplete]. */
    /**
     * Slides one piece smoothly along the squares from [fromSteps] to
     * [toSteps] — it walks the real path (so it turns the corners correctly)
     * but glides continuously instead of jumping square to square.
     */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        if (fromSteps <= 0) {
            path += BoardGeometry.centerForSteps(color, toSteps)
        } else {
            for (step in (fromSteps + 1)..toSteps) path += BoardGeometry.centerForSteps(color, step)
        }
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete)
    }

    /**
     * A cut piece races back the way it came — its path reversed, faster than a
     * normal move — instead of blinking straight to its base.
     */
    fun flyHome(tokenId: String, color: PlayerColor, fromSteps: Int, baseSlot: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        var step = fromSteps
        while (step > 1) {                       // retrace the lap backwards
            step -= maxOf(1, fromSteps / 8)      // skip a little so it stays quick
            path += BoardGeometry.centerForSteps(color, maxOf(step, 1))
        }
        path += BoardGeometry.BASE_SLOTS.getValue(color)[baseSlot.coerceIn(0, 3)]
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete, perLegMs = 34L)
    }

    private fun glide(tokenId: String, path: List<Pair<Float, Float>>, onComplete: () -> Unit, perLegMs: Long = 110L) {
        val legs = path.size - 1
        val perLeg = perLegMs                   // ms per square
        val total = (legs * perLeg).coerceAtLeast(160L)
        val startAt = System.currentTimeMillis()
        var lastLeg = -1

        val ticker = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - startAt
                val t = (elapsed.toFloat() / total).coerceIn(0f, 1f)
                val pos = t * legs
                val leg = pos.toInt().coerceAtMost(legs - 1)
                val f = pos - leg

                val a = path[leg]
                val b = path[leg + 1]
                displayedCenters[tokenId] =
                    (a.first + (b.first - a.first) * f) to (a.second + (b.second - a.second) * f)

                if (leg != lastLeg) {
                    lastLeg = leg
                    if (legs > 1) onStep?.invoke()
                }
                invalidate()

                if (t >= 1f) {
                    displayedCenters[tokenId] = path.last()
                    invalidate()
                    onComplete()
                } else {
                    postDelayed(this, 16)
                }
            }
        }
        post(ticker)
    }

    // ---- geometry ----
    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell
    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(px(c0), py(r0), px(c1), py(r1))

    // ---- paints ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xBD, 0xBD, 0xBD)
        strokeWidth = 1.5f
    }
    private val specialLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bodyShade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xFF, 0xEB, 0x3B)
        strokeWidth = 6f
    }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0x21, 0x21, 0x21)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.028f
        cell = (size - 2 * frame) / BoardGeometry.GRID_SIZE
        badgeText.textSize = cell * 0.46f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        if (!drawBoardArt(canvas)) {
            // no picture available — fall back to the board drawn in code, so a
            // missing or undecodable file costs a bit of polish and not the game
            drawFrame(canvas)
            drawHomeYards(canvas)
            drawTrack(canvas)
            drawHomeStretches(canvas)
            drawCenterArrows(canvas)
        }
        drawSpecials(canvas)
        drawLocks(canvas)
        if (arrowMode) drawArrows(canvas)
        drawSpecialGlow(canvas)
        drawTokens(canvas)
        drawChoiceChips(canvas)
    }

    /**
     * The board, as the supplied picture.
     *
     * HOW THE PICTURE AND THE GRID ARE KEPT IN STEP
     *
     * The rules engine thinks in a 15x15 grid of cells and knows nothing about
     * any picture. The picture has its own wooden border around its 15x15 play
     * area, so it cannot simply be stretched over the view: the border would eat
     * into the grid and every piece would sit slightly off its square.
     *
     * So the picture is placed by its PLAY AREA rather than by its edges. The
     * two numbers below were measured off the file — where its play area starts,
     * and how much of the file that play area takes up — and the picture is
     * scaled and offset so that its play area lands exactly on px(0)..px(15).
     * Measured, not guessed: the resting circles inside its yards then fall on
     * the same spots the engine already used for pieces waiting to come out.
     *
     * Returns false if the picture could not be loaded, so the caller can draw
     * the board in code instead.
     */
    private fun drawBoardArt(canvas: Canvas): Boolean {
        if (boardArtFailed) return false
        var art = boardArt
        if (art == null) {
            art = try {
                android.graphics.BitmapFactory.decodeResource(resources, R.drawable.board_royal)
            } catch (e: Throwable) {
                null
            }
            if (art == null) {
                boardArtFailed = true
                return false
            }
            boardArt = art
        }

        val gridSize = cell * BoardGeometry.GRID_SIZE
        val artSize = gridSize / ART_PLAY_SPAN
        val left = px(0f) - artSize * ART_PLAY_ORIGIN
        val top = py(0f) - artSize * ART_PLAY_ORIGIN
        val bounds = RectF(left, top, left + artSize, top + artSize)
        canvas.drawBitmap(art, null, bounds, boardPaint)

        // the mode's own light, over the play area only so the wooden frame
        // and the board's painted border keep their own colour
        if (boardTint != 0) {
            fill.shader = null
            fill.style = Paint.Style.FILL
            fill.color = boardTint
            canvas.drawRect(px(0f), py(0f), px(15f), py(15f), fill)
        }
        return true
    }

    /** Wooden outer frame, gold inner edge, soft off-white playfield. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.055f

        // outer shadow
        fill.color = Color.argb(90, 0, 0, 0)
        canvas.drawRoundRect(RectF(2f, 5f, size, size + 3f), r, r, fill)

        // dark wood edge
        fill.color = Color.rgb(0xA8, 0x63, 0x24)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, fill)

        // warm wood face
        fill.color = Color.rgb(0xD9, 0x93, 0x4A)
        canvas.drawRoundRect(RectF(frame * 0.28f, frame * 0.28f, size - frame * 0.28f, size - frame * 0.28f), r, r, fill)

        // thin gold inner edge framing the play area
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawRect(
            RectF(px(0f) - frame * 0.22f, py(0f) - frame * 0.22f,
                  px(15f) + frame * 0.22f, py(15f) + frame * 0.22f), fill
        )

        // playfield
        fill.color = Color.rgb(0xFA, 0xFA, 0xF5)
        canvas.drawRect(RectF(px(0f), py(0f), px(15f), py(15f)), fill)
    }

    /** The four colored corner yards, each with a white circle holding the 4 base slots. */
    private fun drawHomeYards(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0].toFloat(); val c0 = box[1].toFloat()
            val r1 = (box[2] + 1).toFloat(); val c1 = (box[3] + 1).toFloat()

            fill.color = colorOf(color)
            canvas.drawRect(rect(r0, c0, r1, c1), fill)

            // white circle in the middle of the yard
            val cx = px((c0 + c1) / 2f)
            val cy = py((r0 + r1) / 2f)
            val radius = cell * 2.1f
            canvas.drawCircle(cx + cell * 0.06f, cy + cell * 0.09f, radius, shadow)
            fill.color = Color.WHITE
            canvas.drawCircle(cx, cy, radius, fill)
        }
    }

    /** The 52-cell outer ring: white cells, colored start cells, star safe cells, direction arrows. */
    private fun drawTrack(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val r = rc.first.toFloat(); val c = rc.second.toFloat()
            var startColor: PlayerColor? = null
            for (color in PlayerColor.entries) if (color.startOffset == idx) startColor = color

            fill.color = if (startColor != null) colorOf(startColor) else Color.WHITE
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), fill)
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), gridLine)

            if (LudoBoard.isSafeCell(idx)) {
                val starColor = if (startColor != null) Color.WHITE else Color.rgb(0x9E, 0x9E, 0x9E)
                drawStar(canvas, px(c + 0.5f), py(r + 0.5f), cell * 0.3f, starColor)
            }
        }
    }

    /** A chevron on a start cell showing which way tokens travel from there. */

    /** Star path using whatever colour/alpha is already set on [fill]. */
    private fun drawStarPath(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            path.let { p ->
                val x = cx + (rr * Math.cos(angle)).toFloat()
                val y = cy + (rr * Math.sin(angle)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            val x = cx + (rr * Math.cos(angle)).toFloat()
            val y = cy + (rr * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    /** Each color's private path to home, drawn as one solid colored lane. */
    private fun drawHomeStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            fill.color = colorOf(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), fill)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), gridLine)
            }
        }
    }

    /** The four big arrowheads meeting at the center — the "win" zone. */
    private fun drawCenterArrows(canvas: Canvas) {
        val cx = px(7.5f); val cy = py(7.5f)
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(px(p1c), py(p1r))
            path.lineTo(px(p2c), py(p2r))
            path.lineTo(cx, cy)
            path.close()
            fill.color = colorOf(color)
            canvas.drawPath(path, fill)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    /**
     * Tokens, grouped so stacked pieces are obvious: one styled piece per
     * (cell, color) with a numbered badge when more than one sits there,
     * and a slight offset when two different colors share a safe cell.
     */
    /**
     * Every piece is drawn as its own piece — a pile of three shows three
     * discs fanned out, not one disc with a number on it. Movable pieces
     * gently grow and shrink so the player can see what they can play.
     */
    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return

        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            val shrink = when {
                tokens.size >= 4 -> 0.62f
                tokens.size == 3 -> 0.70f
                tokens.size == 2 -> 0.80f
                else -> 1f
            }
            tokens.forEachIndexed { i, token ->
                val (ox, oy) = offsets[i]
                val faded = token.id == fadingTokenId
                val alpha = if (faded) fadeAlpha else 1f
                val tappable = token.id in tappableTokenIds
                // A WAITING PIECE IS DRAWN BIGGER THAN A TRAVELLING ONE,
                // because the circle it is waiting in is bigger than a square.
                // At track size it sat in the middle of its resting circle with
                // a ring of grey showing all the way round — the gap in the
                // yards. It now covers the circle the board drew for it.
                val yard = if (token.state == TokenState.BASE) YARD_PIECE_SIZE else 1f
                val scale = shrink * yard * if (tappable) pulse else 1f
                drawToken(
                    canvas,
                    px(col) + ox * cell,
                    py(row) + oy * cell,
                    token.color, alpha, tappable, scale
                )
            }
        }
    }

    /** Where each piece sits when several share one square. */
    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.16f to 0f, 0.16f to 0f)
        3 -> listOf(0f to -0.17f, -0.17f to 0.13f, 0.17f to 0.13f)
        4 -> listOf(-0.16f to -0.16f, 0.16f to -0.16f, -0.16f to 0.16f, 0.16f to 0.16f)
        else -> {
            // 5+ : ring them around the cell centre
            val list = mutableListOf<Pair<Float, Float>>()
            for (i in 0 until count) {
                val angle = 2.0 * Math.PI * i / count
                list += (0.19f * Math.cos(angle).toFloat()) to (0.19f * Math.sin(angle).toFloat())
            }
            list
        }
    }

    /** A piece drawn as a lit dome: contact shadow, dark rim, shaded body, highlight. */
    private fun drawToken(
        canvas: Canvas, cx: Float, cy: Float,
        color: PlayerColor, alpha: Float, tappable: Boolean, scale: Float
    ) {
        if (alpha <= 0.02f) return
        val radius = cell * 0.36f * scale
        val a = (alpha * 255).toInt().coerceIn(0, 255)

        // The crown counters, drawn from the supplied pictures. They are the
        // board's own pieces, so they come first; the code-drawn dome below is
        // what happens only if a picture cannot be decoded.
        val picture = tokenPicture(color)
        if (picture != null) {
            // Sized to the board's own resting circles, which were measured at
            // 0.48 of a cell, plus a little so the counter covers one instead
            // of leaving a grey crescent showing round it.
            val r = radius * PIECE_SIZE
            // DEAD CENTRE. See PIECE_DROP: the counters are flat discs and
            // their middle is the middle of the picture, so the only shift
            // here is the sub-pixel one the measurement actually found.
            val y = cy + radius * PIECE_DROP
            piecePaint.alpha = a
            if (tappable) {
                // the one who can move glows, rather than growing enough to
                // overlap the piece beside it
                bodyShade.shader = RadialGradient(
                    cx, y, r * 1.7f,
                    intArrayOf(withAlphaScaled(Color.rgb(0xFF, 0xEB, 0x3B), alpha * 0.75f),
                               Color.TRANSPARENT),
                    floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, y, r * 1.7f, bodyShade)
                bodyShade.shader = null
            }
            canvas.drawBitmap(picture, null, RectF(cx - r, y - r, cx + r, y + r), piecePaint)
            piecePaint.alpha = 255
            return
        }
        val base = colorOf(color)
        val art = tokenArt
        // a rainbow skin walks its trim round the wheel; everything else is fixed
        val trim = if (art.shifting) shiftingTrim() else art.trim

        // the skin's halo, behind everything, so it never hides the piece
        if (art.halo != 0) {
            bodyShade.shader = RadialGradient(
                cx, cy, radius * 1.85f,
                intArrayOf(withAlphaScaled(art.halo, alpha), Color.TRANSPARENT),
                floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, radius * 1.85f, bodyShade)
            bodyShade.shader = null
        }

        // contact shadow flattened on the board
        shadow.alpha = (75 * alpha).toInt().coerceIn(0, 255)
        canvas.drawOval(
            RectF(cx - radius * 0.95f, cy + radius * 0.34f, cx + radius * 0.95f, cy + radius * 0.98f),
            shadow
        )
        shadow.alpha = 60

        // dark rim keeps overlapping pieces readable
        fill.color = darken(base, 0.55f)
        fill.alpha = a
        canvas.drawCircle(cx, cy + radius * 0.05f, radius * 1.06f, fill)

        // the skin's metal collar, drawn just inside that rim
        if (art.id != Cosmetics.TOKEN_CROWN) {
            fill.color = trim
            fill.alpha = (a * 0.92f).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy + radius * 0.02f, radius * 1.00f, fill)
            fill.alpha = 255
        }

        // body shaded from a top-left light source
        bodyShade.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.40f, radius * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        bodyShade.alpha = a
        canvas.drawCircle(cx, cy, radius, bodyShade)
        bodyShade.shader = null
        bodyShade.alpha = 255

        // the inset disc the ornament sits on
        fill.color = art.inset
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 0.62f, fill)

        // the ornament, in the player's own colour so the piece stays readable
        fill.color = base
        fill.alpha = a
        drawOrnament(canvas, cx, cy, radius * 0.52f, art.ornament, base, trim, a)
        fill.alpha = 255

        // specular highlight, stronger on the polished skins
        val sheen = (140f + 115f * art.sheen) * alpha
        gloss.shader = RadialGradient(
            cx - radius * 0.34f, cy - radius * 0.46f, radius * 0.75f,
            Color.argb(sheen.toInt().coerceIn(0, 255), 255, 255, 255),
            Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, gloss)
        gloss.shader = null

        if (tappable) canvas.drawCircle(cx, cy, radius + 5f, highlight)
    }

    /**
     * The little mark in the middle of a piece.
     *
     * Each one is drawn at the same size and weight, so no skin is easier or
     * harder to pick out on a crowded square than any other.
     */
    private fun drawOrnament(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        ornament: TokenOrnament, base: Int, trim: Int, a: Int
    ) {
        fill.color = base
        fill.alpha = a
        when (ornament) {
            TokenOrnament.STAR -> drawStarPath(canvas, cx, cy, r)

            TokenOrnament.GEM -> {
                val p = Path()
                p.moveTo(cx, cy - r)
                p.lineTo(cx + r * 0.86f, cy - r * 0.18f)
                p.lineTo(cx, cy + r)
                p.lineTo(cx - r * 0.86f, cy - r * 0.18f)
                p.close()
                canvas.drawPath(p, fill)
                specialLine.color = Color.argb((a * 0.55f).toInt(), 255, 255, 255)
                specialLine.strokeWidth = r * 0.16f
                canvas.drawLine(cx - r * 0.86f, cy - r * 0.18f, cx + r * 0.86f, cy - r * 0.18f, specialLine)
            }

            TokenOrnament.FLAME -> {
                val p = Path()
                p.moveTo(cx, cy - r * 1.05f)
                p.cubicTo(cx + r * 0.90f, cy - r * 0.25f, cx + r * 0.55f, cy + r, cx, cy + r)
                p.cubicTo(cx - r * 0.55f, cy + r, cx - r * 0.90f, cy - r * 0.25f, cx, cy - r * 1.05f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.CRYSTAL -> {
                val p = Path()
                p.moveTo(cx, cy - r)
                p.lineTo(cx + r * 0.52f, cy - r * 0.30f)
                p.lineTo(cx + r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.34f, cy + r * 0.92f)
                p.lineTo(cx - r * 0.52f, cy - r * 0.30f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.CROWN -> {
                val p = Path()
                p.moveTo(cx - r * 0.88f, cy + r * 0.62f)
                p.lineTo(cx - r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx - r * 0.40f, cy + r * 0.06f)
                p.lineTo(cx, cy - r * 0.86f)
                p.lineTo(cx + r * 0.40f, cy + r * 0.06f)
                p.lineTo(cx + r * 0.88f, cy - r * 0.42f)
                p.lineTo(cx + r * 0.88f, cy + r * 0.62f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.BOLT -> {
                val p = Path()
                p.moveTo(cx + r * 0.30f, cy - r)
                p.lineTo(cx - r * 0.55f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.02f, cy + r * 0.12f)
                p.lineTo(cx - r * 0.28f, cy + r)
                p.lineTo(cx + r * 0.58f, cy - r * 0.18f)
                p.lineTo(cx + r * 0.04f, cy - r * 0.18f)
                p.close()
                canvas.drawPath(p, fill)
            }

            TokenOrnament.PRISM -> {
                // three facets in the player's colour, so it still reads as theirs
                for (i in 0 until 3) {
                    val angle = (-Math.PI / 2 + i * 2 * Math.PI / 3).toFloat()
                    val p = Path()
                    p.moveTo(cx, cy)
                    p.lineTo(
                        cx + r * Math.cos((angle - 0.42f).toDouble()).toFloat(),
                        cy + r * Math.sin((angle - 0.42f).toDouble()).toFloat()
                    )
                    p.lineTo(
                        cx + r * Math.cos((angle + 0.42f).toDouble()).toFloat(),
                        cy + r * Math.sin((angle + 0.42f).toDouble()).toFloat()
                    )
                    p.close()
                    fill.color = if (i == 1) lighten(base, 0.30f) else base
                    fill.alpha = a
                    canvas.drawPath(p, fill)
                }
            }

            TokenOrnament.SCALE -> {
                // three overlapping scales
                for (i in 0 until 3) {
                    val oy = cy - r * 0.45f + i * r * 0.46f
                    val rr = r * (0.92f - i * 0.16f)
                    fill.color = if (i % 2 == 0) base else darken(base, 0.18f)
                    fill.alpha = a
                    canvas.drawArc(
                        RectF(cx - rr, oy - rr * 0.8f, cx + rr, oy + rr * 0.8f),
                        180f, 180f, true, fill
                    )
                }
            }

            TokenOrnament.RING -> {
                specialLine.color = base
                specialLine.strokeWidth = r * 0.42f
                canvas.drawCircle(cx, cy, r * 0.66f, specialLine)
            }
        }
        fill.color = base
        fill.alpha = 255
    }

    /** The rainbow skin's trim, cycling slowly so it never strobes. */
    private fun shiftingTrim(): Int {
        val t = (System.currentTimeMillis() % 6000L) / 6000f
        val hue = t * 360f
        return Color.HSVToColor(floatArrayOf(hue, 0.55f, 1f))
    }

    private fun withAlphaScaled(color: Int, alpha: Float): Int = Color.argb(
        (Color.alpha(color) * alpha).toInt().coerceIn(0, 255),
        Color.red(color), Color.green(color), Color.blue(color)
    )

    private fun lighten(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    /**
     * Snakes and ladders on the Ludo route. A ladder is two rails with rungs,
     * a snake is a wavy green body with a head — both drawn between the exact
     * squares they connect, so it is obvious where a piece will be carried.
     */
    /** Pulsing halo on the snake head / ladder foot that is firing. */
    private fun drawSpecialGlow(canvas: Canvas) {
        val cell0 = glowingSpecialCell ?: return
        val ring = BoardGeometry.RING
        val (r, c) = ring[cell0 % ring.size]
        val cx = px(c + 0.5f)
        val cy = py(r + 0.5f)
        val pulse = 0.5f + 0.5f * kotlin.math.sin(specialGlow)
        val radius = cell * (0.42f + 0.22f * pulse)

        fill.color = Color.argb((90 + 90 * pulse).toInt().coerceIn(0, 255), 0xFF, 0xE0, 0x7A)
        canvas.drawCircle(cx, cy, radius, fill)
        fill.color = Color.argb((140 + 80 * pulse).toInt().coerceIn(0, 255), 0xFF, 0xF3, 0xC4)
        canvas.drawCircle(cx, cy, radius * 0.55f, fill)
    }

    private fun drawSpecials(canvas: Canvas) {
        val diff = snakeDifficulty ?: return
        val ring = BoardGeometry.RING

        for (sp in SnakeLadderConfig.specialsFor(diff)) {
            val a = ring[sp.entryCell % ring.size]
            val b = ring[sp.exitCell % ring.size]
            val x0 = px(a.second + 0.5f); val y0 = py(a.first + 0.5f)
            val x1 = px(b.second + 0.5f); val y1 = py(b.first + 0.5f)

            if (sp.type == SpecialType.LADDER) drawLadder(canvas, x0, y0, x1, y1)
            else drawSnake(canvas, x0, y0, x1, y1)
        }
    }

    private fun drawLadder(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val nx = -dy / len * cell * 0.15f
        val ny = dx / len * cell * 0.15f

        specialLine.strokeWidth = cell * 0.065f
        specialLine.color = Color.rgb(0x8D, 0x5A, 0x2B)
        canvas.drawLine(x0 + nx, y0 + ny, x1 + nx, y1 + ny, specialLine)
        canvas.drawLine(x0 - nx, y0 - ny, x1 - nx, y1 - ny, specialLine)

        specialLine.strokeWidth = cell * 0.045f
        specialLine.color = Color.rgb(0xC9, 0x8A, 0x45)
        val rungs = (len / (cell * 0.5f)).toInt().coerceAtLeast(2)
        for (i in 1 until rungs) {
            val t = i.toFloat() / rungs
            val rx = x0 + dx * t
            val ry = y0 + dy * t
            canvas.drawLine(rx + nx, ry + ny, rx - nx, ry - ny, specialLine)
        }
    }

    private fun drawSnake(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len

        val path = Path()
        path.moveTo(x0, y0)
        val waves = 3
        for (i in 1..waves * 2) {
            val t = i.toFloat() / (waves * 2)
            val amp = cell * 0.42f * kotlin.math.sin(i * Math.PI / 2).toFloat()
            path.lineTo(x0 + dx * t + nx * amp, y0 + dy * t + ny * amp)
        }
        path.lineTo(x1, y1)

        specialLine.strokeCap = Paint.Cap.ROUND
        specialLine.strokeJoin = Paint.Join.ROUND
        specialLine.strokeWidth = cell * 0.24f
        specialLine.color = Color.rgb(0x1B, 0x5E, 0x20)
        canvas.drawPath(path, specialLine)
        specialLine.strokeWidth = cell * 0.13f
        specialLine.color = Color.rgb(0x66, 0xBB, 0x6A)
        canvas.drawPath(path, specialLine)

        // head sits on the entry square
        fill.color = Color.rgb(0x1B, 0x5E, 0x20)
        canvas.drawCircle(x0, y0, cell * 0.21f, fill)
        fill.color = Color.WHITE
        canvas.drawCircle(x0 - cell * 0.07f, y0 - cell * 0.04f, cell * 0.055f, fill)
        canvas.drawCircle(x0 + cell * 0.07f, y0 - cell * 0.04f, cell * 0.055f, fill)
        fill.color = Color.BLACK
        canvas.drawCircle(x0 - cell * 0.07f, y0 - cell * 0.04f, cell * 0.025f, fill)
        canvas.drawCircle(x0 + cell * 0.07f, y0 - cell * 0.04f, cell * 0.025f, fill)
    }

    /** Number chips floating just above the chosen piece. */
    private fun drawChoiceChips(canvas: Canvas) {
        chipRects.clear()
        val tokenId = choiceTokenId ?: return
        if (choiceValues.isEmpty()) return
        val pos = displayedCenters[tokenId] ?: return

        // SMALL, and close in. These used to be two-thirds of a square each,
        // sitting a whole square above the piece — a popup in all but name,
        // covering the board at the moment the player is trying to read it.
        // They are now a little strip of buttons just over the piece's head.
        val r = cell * 0.21f
        val gap = cell * 0.07f
        val totalW = choiceValues.size * (r * 2) + (choiceValues.size - 1) * gap
        var x = px(pos.second) - totalW / 2f + r
        // sit just above the piece, but flip below if it would fall off the top
        var y = py(pos.first) - cell * 0.62f
        if (y - r < 0f) y = py(pos.first) + cell * 0.62f

        for (value in choiceValues) {
            // shadow + gold chip
            canvas.drawCircle(x + r * 0.08f, y + r * 0.14f, r, shadow)
            fill.color = Color.rgb(0x1E, 0x28, 0x32)
            canvas.drawCircle(x, y, r, fill)
            fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
            canvas.drawCircle(x, y, r * 0.84f, fill)

            badgeText.color = Color.rgb(0x1E, 0x14, 0x00)
            badgeText.textSize = r * 1.20f
            canvas.drawText(value.toString(), x, y + r * 0.44f, badgeText)

            // The TAP target stays generous even though the chip is small: a
            // finger is the same size whatever the picture under it, so the
            // rectangle recorded here is bigger than the chip that was drawn.
            val touch = kotlin.math.max(r, cell * 0.36f)
            chipRects += value to RectF(x - touch, y - touch, x + touch, y + touch)
            x += r * 2 + gap
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell <= 0f) return true

        // a visible number chip wins the tap
        for ((value, rect) in chipRects) {
            if (rect.contains(event.x, event.y)) {
                onChoicePicked?.invoke(value)
                return true
            }
        }

        // rebuild the same layout used for drawing, so taps hit what you see
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            tokens.forEachIndexed { i, token ->
                if (token.id !in tappableTokenIds) return@forEachIndexed
                val (ox, oy) = offsets[i]
                val dx = event.x - (px(col) + ox * cell)
                val dy = event.y - (py(row) + oy * cell)
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }

        // copy to a local val: Kotlin cannot smart-cast a var written inside a lambda
        val chosen = best
        val touchRadius = cell * 0.8f
        if (chosen != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(chosen)
        }
        return true
    }

    // ---------------------------------------------------------- ARROW MODE

    /** Unit direction of travel along the ring at [index], in cell units. */
    private fun ringDirection(index: Int): Pair<Float, Float> {
        val ring = BoardGeometry.RING
        val a = ring[index % ring.size]
        val b = ring[(index + 1) % ring.size]
        val dx = (b.second - a.second).toFloat()
        val dy = (b.first - a.first).toFloat()
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.0001f)
        return (dx / len) to (dy / len)
    }

    private fun ringCentre(index: Int): Pair<Float, Float> {
        val ring = BoardGeometry.RING
        val (r, c) = ring[index % ring.size]
        return px(c + 0.5f) to py(r + 0.5f)
    }

    /**
     * The markings that make ARROW MODE readable at a glance: a feathered dart
     * on every straight arrow, a solid arrow in the owner's colour on every
     * home arrow, a U-turn hook where each colour leaves the ring, and a small
     * globe on each starting square.
     */
    private fun drawArrows(canvas: Canvas) {
        specialLine.strokeCap = Paint.Cap.ROUND
        specialLine.strokeJoin = Paint.Join.ROUND

        for ((color, startCell) in ArrowConfig.START_CELLS) {
            drawGlobe(canvas, startCell, colorOf(color))
        }
        for ((color, turnCell) in ArrowConfig.HOME_TURNS) {
            drawHomeTurn(canvas, turnCell, colorOf(color))
        }
        for (arrow in ArrowConfig.ARROWS) {
            val (cx, cy) = ringCentre(arrow.cell)
            val (dx, dy) = ringDirection(arrow.cell)
            val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
            canvas.save()
            canvas.rotate(angle, cx, cy)
            if (arrow.kind == ArrowKind.STRAIGHT) {
                drawDart(canvas, cx, cy)
            } else {
                drawSolidArrow(canvas, cx, cy, arrow.color?.let { colorOf(it) } ?: Color.DKGRAY)
            }
            canvas.restore()
        }
    }

    /** A feathered dart: the straight arrow, drawn pointing along the route. */
    private fun drawDart(canvas: Canvas, cx: Float, cy: Float) {
        val len = cell * 0.36f
        specialLine.color = Color.argb(215, 0x37, 0x44, 0x5E)
        specialLine.strokeWidth = cell * 0.075f
        canvas.drawLine(cx - len, cy, cx + len * 0.55f, cy, specialLine)
        // head
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.10f, cy - cell * 0.20f, specialLine)
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.10f, cy + cell * 0.20f, specialLine)
        // three feathers at the tail
        specialLine.strokeWidth = cell * 0.055f
        for (i in 0 until 3) {
            val x = cx - len + i * cell * 0.13f
            canvas.drawLine(x, cy - cell * 0.17f, x + cell * 0.11f, cy, specialLine)
            canvas.drawLine(x, cy + cell * 0.17f, x + cell * 0.11f, cy, specialLine)
        }
    }

    /** A solid arrow in the owner's colour: the home arrow. */
    private fun drawSolidArrow(canvas: Canvas, cx: Float, cy: Float, color: Int) {
        val len = cell * 0.34f
        val head = cell * 0.19f
        val body = Path()
        body.moveTo(cx + len, cy)
        body.lineTo(cx + len - head, cy - head)
        body.lineTo(cx + len - head, cy - head * 0.42f)
        body.lineTo(cx - len, cy - head * 0.42f)
        body.lineTo(cx - len, cy + head * 0.42f)
        body.lineTo(cx + len - head, cy + head * 0.42f)
        body.lineTo(cx + len - head, cy + head)
        body.close()

        fill.color = Color.argb(70, 0, 0, 0)
        canvas.save()
        canvas.translate(cell * 0.03f, cell * 0.04f)
        canvas.drawPath(body, fill)
        canvas.restore()

        fill.color = color
        canvas.drawPath(body, fill)
        specialLine.color = darken(color, 0.45f)
        specialLine.strokeWidth = cell * 0.035f
        canvas.drawPath(body, specialLine)
    }

    /** The hook that shows where a colour turns off the ring into its lane. */
    private fun drawHomeTurn(canvas: Canvas, ringCell: Int, color: Int) {
        val (cx, cy) = ringCentre(ringCell)
        val (dx, dy) = ringDirection(ringCell)
        val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
        canvas.save()
        canvas.rotate(angle, cx, cy)
        specialLine.color = Color.argb(150, Color.red(color), Color.green(color), Color.blue(color))
        specialLine.strokeWidth = cell * 0.060f
        val r = cell * 0.30f
        val hook = Path()
        hook.moveTo(cx - cell * 0.42f, cy + r)
        hook.lineTo(cx + cell * 0.10f, cy + r)
        hook.quadTo(cx + cell * 0.10f + r, cy + r, cx + cell * 0.10f + r, cy)
        hook.quadTo(cx + cell * 0.10f + r, cy - r, cx + cell * 0.10f, cy - r)
        hook.lineTo(cx - cell * 0.18f, cy - r)
        canvas.drawPath(hook, specialLine)
        // little head on the returning end
        canvas.drawLine(cx - cell * 0.18f, cy - r, cx - cell * 0.06f, cy - r - cell * 0.11f, specialLine)
        canvas.drawLine(cx - cell * 0.18f, cy - r, cx - cell * 0.06f, cy - r + cell * 0.11f, specialLine)
        canvas.restore()
    }

    /**
     * The crown counter for [color], decoded once and kept.
     *
     * Four bitmaps are held for a whole match — sixteen pieces share them —
     * rather than decoding per piece per frame, which on a cheap phone is the
     * difference between a board that slides and a board that stutters.
     */
    private fun tokenPicture(color: PlayerColor): android.graphics.Bitmap? {
        if (tokenArtBitmaps.containsKey(color)) return tokenArtBitmaps[color]
        val res = when (color) {
            PlayerColor.RED -> R.drawable.tn_red
            PlayerColor.BLUE -> R.drawable.tn_blue
            PlayerColor.GREEN -> R.drawable.tn_green
            PlayerColor.YELLOW -> R.drawable.tn_yellow
        }
        val bitmap = try {
            android.graphics.BitmapFactory.decodeResource(resources, res)
        } catch (e: Throwable) {
            null
        }
        tokenArtBitmaps[color] = bitmap
        return bitmap
    }

    /**
     * The padlocks on the doors that are still shut, and the one coming apart.
     */
    private fun drawLocks(canvas: Canvas) {
        val opening = openingLock
        for (color in PlayerColor.entries) {
            val isOpening = color == opening
            if (color !in lockedColors && !isOpening) continue
            // THE DOOR: the last square on the shared ring before this colour
            // turns off into its home column. That is where a piece is stopped,
            // so that is where the padlock goes — not inside the home column,
            // which under the wrap rule a locked piece never even reaches.
            val ring = BoardGeometry.RING.getOrNull(color.homeEntryOffset) ?: continue
            val cx = px(ring.second + 0.5f)
            val cy = py(ring.first + 0.5f)
            if (isOpening) {
                val t = ((System.currentTimeMillis() - lockOpenAt).toFloat() / LOCK_OPEN_MS)
                    .coerceIn(0f, 1f)
                drawOpeningLock(canvas, cx, cy, t)
            } else {
                drawLock(canvas, cx, cy, 0f, 255)
            }
        }
    }

    /**
     * One padlock, small enough to sit on a square without hiding it.
     *
     * [swing] tips the shackle up as it lets go; [alpha] fades the whole thing.
     */
    private fun drawLock(canvas: Canvas, cx: Float, cy: Float, swing: Float, alpha: Int) {
        if (alpha <= 2) return
        val u = cell * 0.17f

        // the shackle, behind the body
        canvas.save()
        canvas.translate(cx, cy - u * 0.95f - u * 0.7f * swing)
        canvas.rotate(30f * swing, -u * 0.6f, 0f)
        specialLine.color = Color.argb(alpha, 0xE2, 0xEA, 0xF4)
        specialLine.strokeWidth = u * 0.40f
        specialLine.style = Paint.Style.STROKE
        canvas.drawArc(RectF(-u * 0.62f, -u * 0.62f, u * 0.62f, u * 0.62f), 180f, 180f, false, specialLine)
        canvas.restore()

        // the body
        val body = RectF(cx - u, cy - u * 0.35f, cx + u, cy + u * 1.05f)
        fill.color = Color.argb(alpha, 0xF2, 0xC1, 0x4E)
        canvas.drawRoundRect(body, u * 0.32f, u * 0.32f, fill)
        specialLine.color = Color.argb(alpha, 0x8A, 0x5B, 0x00)
        specialLine.strokeWidth = u * 0.16f
        canvas.drawRoundRect(body, u * 0.32f, u * 0.32f, specialLine)

        // the keyhole
        fill.color = Color.argb(alpha, 0x2A, 0x1C, 0x06)
        canvas.drawCircle(cx, cy + u * 0.22f, u * 0.24f, fill)
        canvas.drawRect(
            RectF(cx - u * 0.10f, cy + u * 0.22f, cx + u * 0.10f, cy + u * 0.80f), fill
        )
    }

    /** The padlock coming apart: a flash, the shackle springing, then sparks. */
    private fun drawOpeningLock(canvas: Canvas, cx: Float, cy: Float, t: Float) {
        val u = cell * 0.17f

        // the flash, brightest right at the start
        if (t < 0.45f) {
            val k = 1f - t / 0.45f
            bodyShade.shader = RadialGradient(
                cx, cy, u * (2.2f + 3.4f * t),
                intArrayOf(Color.argb((210 * k).toInt(), 255, 245, 200), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, u * (2.2f + 3.4f * t), bodyShade)
            bodyShade.shader = null
        }

        val fade = (1f - (t - 0.35f) / 0.65f).coerceIn(0f, 1f)
        drawLock(canvas, cx, cy, (t / 0.5f).coerceAtMost(1f), (255 * fade).toInt())

        // sparks flying outward
        if (t > 0.2f) {
            val k = (t - 0.2f) / 0.8f
            fill.color = Color.argb(((1f - k) * 235).toInt().coerceIn(0, 255), 0xFF, 0xEC, 0xB8)
            for (i in 0 until 8) {
                val angle = 2.0 * Math.PI * i / 8 + 0.3
                val d = u * (0.8f + 3.2f * k)
                canvas.drawCircle(
                    cx + (Math.cos(angle) * d).toFloat(),
                    cy + (Math.sin(angle) * d).toFloat(),
                    u * 0.20f * (1f - k), fill
                )
            }
        }
    }

    /** A small globe on a colour's starting square. */
    private fun drawGlobe(canvas: Canvas, ringCell: Int, color: Int) {
        val (cx, cy) = ringCentre(ringCell)
        val r = cell * 0.26f
        fill.color = Color.argb(235, 255, 255, 255)
        canvas.drawCircle(cx, cy, r, fill)
        specialLine.color = darken(color, 0.25f)
        specialLine.strokeWidth = cell * 0.045f
        canvas.drawCircle(cx, cy, r, specialLine)
        specialLine.strokeWidth = cell * 0.032f
        canvas.drawLine(cx - r, cy, cx + r, cy, specialLine)
        canvas.drawOval(RectF(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r), specialLine)
    }

    private companion object {
        /**
         * Where the supplied board picture's play area sits inside the file.
         *
         * MEASURED OFF THE FILE, NOT CHOSEN. The picture is 1024 square; its
         * wooden border ends and the 15x15 play area begins at pixel 27.5, and
         * the play area runs 969 pixels from there. Everything on the board is
         * positioned from these two numbers, so if the picture is ever replaced
         * these are the only two values that need measuring again.
         */
        /**
         * The counter's radius, as a multiple of the drawing radius (0.36 of a
         * cell), so 0.36 x 1.40 = 0.504 of a cell for the drawn box. The
         * coloured disc fills 0.969 of that box, giving a visible radius of
         * 0.488 of a cell against yard circles measured at 0.461 — big enough
         * to cover one with no grey showing round the edge.
         */
        const val PIECE_SIZE = 1.40f

        /**
         * How much bigger a piece is drawn while it is still in the yard.
         *
         * A square on the track is one cell across; a resting circle in the
         * yard is 1.164 across (BoardGeometry.BASE_SLOT_RADIUS, doubled). Drawn
         * at track size, a waiting piece covered a visible 0.488 of a cell
         * inside a circle of 0.582 and left a tenth of a square of grey showing
         * right round it — four of them, in every yard, all the time.
         *
         * 0.504 x 1.20 = 0.605 for the box, 0.586 visible, against a circle of
         * 0.582: covered, with nothing left over to reach the piece beside it,
         * which is 1.313 away.
         */
        const val YARD_PIECE_SIZE = 1.20f

        /**
         * How far down the counter is nudged, as a multiple of that radius.
         *
         * THIS USED TO BE 0.25, AND THAT WAS A MISTAKE. The counters were read
         * as three-dimensional pieces standing at an angle, with the flat top
         * face sitting high in the picture, so every one of them was pushed
         * down by 9% of a square to compensate. Measuring the sprites settles
         * it: they are flat discs seen straight down, and the disc's centre of
         * mass sits at 0.497 of the image — dead centre to within a third of a
         * percent. The nudge was not correcting anything. It was the reason a
         * crescent of the yard circle showed above every waiting piece and the
         * reason nothing on the board looked quite square in its cell.
         *
         * What is left is that measured third of a percent, which at any real
         * board size is less than one pixel.
         */
        const val PIECE_DROP = 0.007f

        /** How long a padlock takes to come apart. */
        const val LOCK_OPEN_MS = 900f

        const val ART_PLAY_ORIGIN = 27.5f / 1024f
        const val ART_PLAY_SPAN = 969f / 1024f
    }
}

/**
 * The board colour each game mode is played under.
 *
 * A top-level object rather than something inside the view, because the lobby
 * is what chooses a mode and the lobby has no business reaching inside the
 * board to find out what that mode looks like.
 */
object BoardTints {
    /**
     * The seven modes' board colours — see [boardTint].
     *
     * All at the same strength, 34 of 255, which is about a seventh. Every
     * one of these was rendered over the real board picture and looked at
     * before being written down: at this strength the yards stay plainly
     * green, yellow, red and blue, and it is the white track that carries
     * the mood. Two-player keeps the board exactly as painted, so the
     * plainest game looks like the board everybody already knows.
     */
    const val TINT_TWO = 0
    const val TINT_FOUR = 0x222E7DFF          // deep blue
    const val TINT_QUICK = 0x22FF4500         // hot orange
    const val TINT_SNAKE = 0x221DB954         // jungle green
    const val TINT_TEAM = 0x229C27B0          // purple
    const val TINT_COMPUTER = 0x2200BCD4      // cold cyan
    const val TINT_CUSTOM = 0x22FFC107        // amber
}
