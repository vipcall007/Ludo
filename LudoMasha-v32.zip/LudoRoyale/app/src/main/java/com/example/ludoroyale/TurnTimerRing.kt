package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/**
 * The countdown ring that sits around a player's avatar.
 *
 * It shows how much of the ten seconds is left as a shrinking arc, and changes
 * colour as the clock runs down: calm gold at first, amber from five seconds,
 * then a pulsing red for the last two. Setting [secondsLeft] to null hides it.
 */
class TurnTimerRing @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** Seconds still on the clock, or null when this player is not on the clock. */
    var secondsLeft: Float? = null
        set(value) {
            field = value
            if (value != null) startPulse() else stopPulse()
            invalidate()
        }

    var totalSeconds: Float = 10f

    private var pulse = 0f
    private val pulseTicker = object : Runnable {
        override fun run() {
            if (secondsLeft == null) return
            pulse += 0.28f
            invalidate()
            postDelayed(this, 45)
        }
    }

    private fun startPulse() {
        removeCallbacks(pulseTicker)
        post(pulseTicker)
    }

    private fun stopPulse() {
        removeCallbacks(pulseTicker)
        pulse = 0f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(pulseTicker)
    }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(70, 0, 0, 0)
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = secondsLeft ?: return
        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val w = size * 0.10f
        arc.strokeWidth = w
        track.strokeWidth = w
        val inset = w / 2f + size * 0.02f
        box.set(inset, inset, size - inset, size - inset)

        canvas.drawArc(box, 0f, 360f, false, track)

        val fraction = (left / totalSeconds).coerceIn(0f, 1f)
        val sweep = 360f * fraction

        // 10-6s calm gold, 5-3s warning amber, 2-1s urgent red
        val color = when {
            left > 5f -> Color.rgb(0xF2, 0xC8, 0x4B)
            left > 2f -> Color.rgb(0xFF, 0x98, 0x1F)
            else -> Color.rgb(0xF2, 0x3B, 0x3B)
        }

        if (left <= 2f) {
            val p = 0.5f + 0.5f * kotlin.math.sin(pulse)
            glow.strokeWidth = w * (1.7f + 0.9f * p)
            glow.color = Color.argb((70 + 70 * p).toInt().coerceIn(0, 255), 0xF2, 0x3B, 0x3B)
            canvas.drawArc(box, -90f, sweep, false, glow)
        }

        arc.color = color
        canvas.drawArc(box, -90f, sweep, false, arc)
    }
}
