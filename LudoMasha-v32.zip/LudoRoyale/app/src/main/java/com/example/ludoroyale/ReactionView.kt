package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** The faces that can appear when somebody's piece gets sent home. */
enum class TauntFace { LAUGHING, DIZZY, TONGUE, SMUG, SHOCKED }

/**
 * The small face that flies out of a player's avatar.
 *
 * WHY IT IS SMALL, AND WHY IT COMES OUT OF THE AVATAR
 *
 * It used to be a big face in the middle of the screen. That covered the board
 * at the exact moment the player wanted to see what had just happened, and it
 * did not say WHO had done it — in a four-handed match that is most of the
 * information. Now it is a small face that pops out of the avatar of whoever
 * cut, won, or opened their lock, rises a little, and fades. It says who, it
 * says what, and it never hides the board.
 *
 * DRAWN, NOT TYPED
 *
 * The obvious way is a text view with an emoji in it. The trouble is that the
 * emoji a phone draws is the phone's, not the game's: the same laugh is yellow
 * and round on one handset, flat and grey on another, and on an old one it is
 * an empty box. So the faces are drawn here and look the same everywhere.
 */
class ReactionView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var face: TauntFace? = null
    private var startedAt = 0L

    /** Where on this view the face springs from. */
    private var fromX = 0f
    private var fromY = 0f

    /** How big the face is, in pixels. */
    private var faceRadius = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        // it is a decoration; it must never eat a tap meant for the board
        isClickable = false
        isFocusable = false
        visibility = GONE
    }

    /**
     * Pops a face out of the point ([x], [y]) on this view.
     *
     * [size] is the avatar's size, so the face comes out about a third as big
     * as the face it came from — big enough to read, small enough that four of
     * them round a board are not a mess.
     */
    fun popFrom(x: Float, y: Float, size: Float, which: TauntFace = TauntFace.entries.random()) {
        fromX = x
        fromY = y
        faceRadius = (size * 0.34f).coerceIn(18f, 60f)
        face = which
        startedAt = System.currentTimeMillis()
        visibility = VISIBLE
        alpha = 1f
        removeCallbacks(ticker)
        post(ticker)
    }

    fun clear() {
        removeCallbacks(ticker)
        face = null
        visibility = GONE
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (face == null) return
            val age = System.currentTimeMillis() - startedAt
            if (age >= LIFE_MS) {
                clear()
                return
            }
            invalidate()
            postDelayed(this, 16)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(ticker)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val which = face ?: return
        val age = (System.currentTimeMillis() - startedAt).toFloat()
        val life = (age / LIFE_MS).coerceIn(0f, 1f)

        // springs out, drifts upward, then fades
        val grow = (age / 150f).coerceAtMost(1f)
        val overshoot = 1f + 0.25f * sin(grow * Math.PI).toFloat()
        val fade = if (life > 0.62f) 1f - (life - 0.62f) / 0.38f else 1f
        val rise = faceRadius * 1.5f * life
        val sway = sin(age / 140f).toFloat() * faceRadius * 0.16f * life

        val r = faceRadius * grow * overshoot
        if (r <= 1f) return
        val cx = fromX + sway
        val cy = fromY - rise
        val a = (255 * fade).toInt().coerceIn(0, 255)

        canvas.save()
        canvas.rotate(10f * sin(age / 110f).toFloat() * (1f - life), cx, cy)

        // a soft halo so the face reads over a busy board
        glow.shader = RadialGradient(
            cx, cy, r * 1.8f,
            intArrayOf(Color.argb((a * 0.40f).toInt(), 0, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.8f, glow)
        glow.shader = null

        fill.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.35f, r * 1.5f,
            intArrayOf(Color.rgb(0xFF, 0xE9, 0x8A), Color.rgb(0xF2, 0xB5, 0x14)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        fill.alpha = a
        canvas.drawCircle(cx, cy, r, fill)
        fill.shader = null
        fill.alpha = 255

        stroke.color = Color.argb(a, 0x8A, 0x5B, 0x00)
        stroke.strokeWidth = r * 0.08f
        canvas.drawCircle(cx, cy, r, stroke)

        val ink = Color.argb(a, 0x2A, 0x1C, 0x06)
        when (which) {
            TauntFace.LAUGHING -> drawLaughing(canvas, cx, cy, r, ink, a)
            TauntFace.DIZZY -> drawDizzy(canvas, cx, cy, r, ink)
            TauntFace.TONGUE -> drawTongue(canvas, cx, cy, r, ink, a)
            TauntFace.SMUG -> drawSmug(canvas, cx, cy, r, ink)
            TauntFace.SHOCKED -> drawShocked(canvas, cx, cy, r, ink, a)
        }
        canvas.restore()
    }

    // ------------------------------------------------------------- the faces

    private fun drawLaughing(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        // eyes squeezed shut into two arcs
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        for (s in intArrayOf(-1, 1)) {
            canvas.drawArc(
                RectF(cx + s * r * 0.36f - r * 0.20f, cy - r * 0.34f,
                      cx + s * r * 0.36f + r * 0.20f, cy - r * 0.02f),
                200f, 140f, false, stroke
            )
        }
        // a wide open laugh
        fill.color = ink
        val mouth = Path()
        mouth.addArc(RectF(cx - r * 0.44f, cy - r * 0.02f, cx + r * 0.44f, cy + r * 0.66f), 0f, 180f)
        mouth.close()
        canvas.drawPath(mouth, fill)
        fill.color = Color.argb(a, 0xFF, 0x7A, 0x8A)
        canvas.drawArc(
            RectF(cx - r * 0.20f, cy + r * 0.16f, cx + r * 0.20f, cy + r * 0.58f),
            0f, 180f, true, fill
        )
        // two tears of laughter
        fill.color = Color.argb(a, 0x5E, 0xC8, 0xFF)
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.66f, cy - r * 0.02f, r * 0.10f, fill)
        }
    }

    private fun drawDizzy(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int) {
        stroke.color = ink
        stroke.strokeWidth = r * 0.10f
        // crossed-out eyes
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * r * 0.34f
            val ey = cy - r * 0.16f
            val d = r * 0.15f
            canvas.drawLine(ex - d, ey - d, ex + d, ey + d, stroke)
            canvas.drawLine(ex - d, ey + d, ex + d, ey - d, stroke)
        }
        // a wavy mouth
        stroke.strokeWidth = r * 0.09f
        val m = Path()
        m.moveTo(cx - r * 0.36f, cy + r * 0.38f)
        m.quadTo(cx - r * 0.18f, cy + r * 0.20f, cx, cy + r * 0.38f)
        m.quadTo(cx + r * 0.18f, cy + r * 0.56f, cx + r * 0.36f, cy + r * 0.38f)
        canvas.drawPath(m, stroke)
    }

    private fun drawTongue(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        // one eye winking
        fill.color = ink
        canvas.drawCircle(cx - r * 0.34f, cy - r * 0.16f, r * 0.10f, fill)
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        canvas.drawArc(
            RectF(cx + r * 0.16f, cy - r * 0.32f, cx + r * 0.54f, cy),
            200f, 140f, false, stroke
        )
        // and a tongue out
        stroke.strokeWidth = r * 0.08f
        canvas.drawArc(
            RectF(cx - r * 0.34f, cy + r * 0.06f, cx + r * 0.34f, cy + r * 0.48f),
            10f, 160f, false, stroke
        )
        fill.color = Color.argb(a, 0xFF, 0x6E, 0x86)
        canvas.drawRoundRect(
            RectF(cx - r * 0.14f, cy + r * 0.28f, cx + r * 0.14f, cy + r * 0.66f),
            r * 0.14f, r * 0.14f, fill
        )
    }

    private fun drawSmug(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int) {
        stroke.color = ink
        stroke.strokeWidth = r * 0.09f
        // half-closed, pleased-with-itself eyes
        for (s in intArrayOf(-1, 1)) {
            canvas.drawLine(
                cx + s * r * 0.50f, cy - r * 0.20f,
                cx + s * r * 0.18f, cy - r * 0.16f, stroke
            )
        }
        fill.color = ink
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.02f, r * 0.08f, fill)
        }
        // a one-sided smirk
        val m = Path()
        m.moveTo(cx - r * 0.30f, cy + r * 0.32f)
        m.quadTo(cx + r * 0.10f, cy + r * 0.52f, cx + r * 0.42f, cy + r * 0.18f)
        canvas.drawPath(m, stroke)
    }

    private fun drawShocked(canvas: Canvas, cx: Float, cy: Float, r: Float, ink: Int, a: Int) {
        fill.color = Color.argb(a, 0xFF, 0xFF, 0xFF)
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.16f, r * 0.17f, fill)
        }
        fill.color = ink
        for (s in intArrayOf(-1, 1)) {
            canvas.drawCircle(cx + s * r * 0.34f, cy - r * 0.16f, r * 0.08f, fill)
        }
        // a round, open mouth
        fill.color = ink
        canvas.drawOval(RectF(cx - r * 0.20f, cy + r * 0.14f, cx + r * 0.20f, cy + r * 0.62f), fill)
        // and a sweat drop
        fill.color = Color.argb(a, 0x5E, 0xC8, 0xFF)
        val drop = Path()
        drop.moveTo(cx + r * 0.72f, cy - r * 0.46f)
        drop.quadTo(cx + r * 0.90f, cy - r * 0.10f, cx + r * 0.72f, cy - r * 0.04f)
        drop.quadTo(cx + r * 0.54f, cy - r * 0.10f, cx + r * 0.72f, cy - r * 0.46f)
        drop.close()
        canvas.drawPath(drop, fill)
    }

    private companion object {
        const val LIFE_MS = 1000f
    }
}
