package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode

/**
 * The things that happen in a match, named once.
 *
 * Missions, statistics and Epic Moments all want to know when a piece was cut
 * or a ladder fired. Without one vocabulary each of them would have to reach
 * into the engine and work it out again, and they would drift apart. So the
 * match reports what happened through these events and every progression
 * system listens instead of looking.
 */
enum class GameEventType {
    MATCH_STARTED,
    DICE_ROLLED,
    TOKEN_MOVED,
    TOKEN_CAPTURED,
    TOKEN_HOME,
    SNAKE_TRIGGERED,
    LADDER_TRIGGERED,
    ARROW_TRIGGERED,
    TURN_COMPLETED,
    MATCH_WON,
    MATCH_COMPLETED
}

/**
 * One thing that happened.
 *
 * [byLocalPlayer] is the important flag: this phone keeps a record for the
 * person holding it, so a computer's capture must never feed their missions.
 * [count] lets one move report a double capture as a single event.
 */
data class GameEvent(
    val type: GameEventType,
    val playerId: String = "",
    val byLocalPlayer: Boolean = false,
    val count: Int = 1,
    val value: Int = 0,
    val mode: GameMode = GameMode.CLASSIC
)

/** Anything that wants to hear about a match as it is played. */
fun interface GameEventListener {
    fun onGameEvent(event: GameEvent)
}

/**
 * Hands each event to everyone listening.
 *
 * Deliberately not a singleton: the activity owns one and drops it when the
 * match ends, so a listener cannot outlive its screen and leak, and two
 * matches can never post into each other.
 */
class GameEventBus {

    private val listeners = mutableListOf<GameEventListener>()

    fun register(listener: GameEventListener) {
        if (listeners.none { it === listener }) listeners += listener
    }

    fun unregister(listener: GameEventListener) {
        listeners.removeAll { it === listener }
    }

    fun clear() = listeners.clear()

    /** Delivers to a copy of the list, so a listener may unregister mid-post. */
    fun post(event: GameEvent) {
        for (listener in listeners.toList()) listener.onGameEvent(event)
    }

    fun post(
        type: GameEventType,
        playerId: String = "",
        byLocalPlayer: Boolean = false,
        count: Int = 1,
        value: Int = 0,
        mode: GameMode = GameMode.CLASSIC
    ) = post(GameEvent(type, playerId, byLocalPlayer, count, value, mode))

    val listenerCount: Int get() = listeners.size
}
