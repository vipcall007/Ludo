package com.example.ludoroyale.engine

import com.example.ludoroyale.model.TokenState

/**
 * A complete, frozen copy of a Ludo match — everything UNDO needs to put the
 * board back exactly as it stood.
 *
 * The engine works by mutating [GameState] in place, which is fast and simple
 * but means a move cannot be reversed by arithmetic: a capture, a home entry
 * and a turn change all happen at once. So instead of trying to invert a move,
 * the game photographs the state just before the piece is committed and, if the
 * player asks to take the move back, puts the photograph back.
 *
 * What is deliberately NOT restored is the dice: a snapshot is only ever taken
 * AFTER the dice has been rolled and its value is already on the table. Undo
 * therefore lets a player change which piece they moved — it never lets anyone
 * roll again for a better number.
 */
data class TokenSnapshot(
    val id: String,
    val state: TokenState,
    val steps: Int
)

data class PlayerSnapshot(
    val id: String,
    val finishedCount: Int,
    val hasCapturedOpponent: Boolean,
    val hasWon: Boolean,
    val tokens: List<TokenSnapshot>
)

data class GameSnapshot(
    val currentPlayerIndex: Int,
    val lastDiceRoll: Int?,
    val consecutiveSixes: Int,
    val pendingRolls: List<Int>,
    val phase: TurnPhase,
    val rankings: List<String>,
    val players: List<PlayerSnapshot>
) {
    /** Puts [state] back exactly as it was when this snapshot was taken. */
    fun restoreInto(state: GameState) {
        state.currentPlayerIndex = currentPlayerIndex.coerceIn(0, state.players.size - 1)
        state.lastDiceRoll = lastDiceRoll
        state.consecutiveSixes = consecutiveSixes
        state.pendingRolls.clear()
        state.pendingRolls.addAll(pendingRolls)
        state.phase = phase
        state.rankings.clear()
        state.rankings.addAll(rankings)

        for (saved in players) {
            val player = state.players.firstOrNull { it.id == saved.id } ?: continue
            player.finishedCount = saved.finishedCount
            player.hasCapturedOpponent = saved.hasCapturedOpponent
            player.hasWon = saved.hasWon
            for (savedToken in saved.tokens) {
                val token = player.tokens.firstOrNull { it.id == savedToken.id } ?: continue
                token.state = savedToken.state
                token.steps = savedToken.steps
            }
        }
    }

    companion object {
        /** Photographs [state]. Nothing in the result shares memory with it. */
        fun of(state: GameState): GameSnapshot = GameSnapshot(
            currentPlayerIndex = state.currentPlayerIndex,
            lastDiceRoll = state.lastDiceRoll,
            consecutiveSixes = state.consecutiveSixes,
            pendingRolls = state.pendingRolls.toList(),
            phase = state.phase,
            rankings = state.rankings.toList(),
            players = state.players.map { p ->
                PlayerSnapshot(
                    id = p.id,
                    finishedCount = p.finishedCount,
                    hasCapturedOpponent = p.hasCapturedOpponent,
                    hasWon = p.hasWon,
                    tokens = p.tokens.map { TokenSnapshot(it.id, it.state, it.steps) }
                )
            }
        )
    }
}
