package com.example.ludoroyale.engine

import java.security.SecureRandom

/**
 * Dice source.
 *
 * FAIRNESS MODE (default): each player draws from their OWN shuffled bag
 * holding one of each face, 1..6. A face leaves the bag when it is drawn, and
 * the bag is reshuffled once empty. So every player gets exactly the same
 * faces over each set of six rolls — nobody sits there getting nothing while
 * someone else keeps rolling sixes — yet the ORDER is genuinely random, so a
 * roll still feels like a roll. This balances luck between players; it does
 * not favour any one of them.
 *
 * PURE MODE ([balanced] = false): plain uniform 1..6 from SecureRandom.
 *
 * LUCKY ([lucky] = true): rolls twice and keeps the higher face, applied
 * identically to every player. Speeds the game up; favours nobody.
 */
class DiceRoller(
    private val random: SecureRandom = SecureRandom(),
    private val lucky: Boolean = false,
    private val balanced: Boolean = true
) {
    private val bags = mutableMapOf<String, MutableList<Int>>()

    private fun freshBag(): MutableList<Int> =
        (1..6).toMutableList().also { it.shuffle(java.util.Random(random.nextLong())) }

    private fun drawFromBag(playerId: String): Int {
        val bag = bags.getOrPut(playerId) { freshBag() }
        if (bag.isEmpty()) bags[playerId] = freshBag()
        return bags.getValue(playerId).removeAt(0)
    }

    /**
     * [playerId] keeps each player's fairness bag separate.
     *
     * LUCKY used to be max(two draws), which is why a 1 almost never showed up
     * and a piece needing exactly 1 could sit there forever. It now simply
     * makes SIXES more frequent and leaves every other face reachable.
     */
    fun roll(playerId: String = "solo"): Int {
        if (lucky && random.nextInt(100) < LUCKY_SIX_PERCENT) return 6
        if (!balanced) return 1 + random.nextInt(6)
        return drawFromBag(playerId)
    }

    private companion object {
        /** Roughly doubles how often a six lands, without starving low numbers. */
        const val LUCKY_SIX_PERCENT = 20
    }
}
