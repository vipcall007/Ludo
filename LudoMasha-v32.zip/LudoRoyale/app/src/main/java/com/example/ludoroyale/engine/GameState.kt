package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player

enum class TurnPhase { AWAITING_ROLL, AWAITING_MOVE, GAME_OVER }

/**
 * Full authoritative state of one match.
 *
 * [pendingRolls] is the queue of dice values the current player has banked
 * but not spent yet. A six banks a value AND forces another roll; the player
 * then chooses, for each banked value, which piece to move it with.
 */
data class GameState(
    val gameId: String,
    val players: MutableList<Player>,
    var currentPlayerIndex: Int = 0,
    var lastDiceRoll: Int? = null,
    var consecutiveSixes: Int = 0,
    val pendingRolls: MutableList<Int> = mutableListOf(),
    var phase: TurnPhase = TurnPhase.AWAITING_ROLL,
    var rankings: MutableList<String> = mutableListOf()
) {
    val currentPlayer: Player get() = players[currentPlayerIndex]

    fun findTokenOwner(tokenId: String): Player? =
        players.firstOrNull { p -> p.tokens.any { it.id == tokenId } }
}
