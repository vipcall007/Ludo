package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Token

/** One legal choice: move [token] using the banked dice value [usedRoll]. */
data class Move(
    val token: Token,
    val usedRoll: Int,
    val fromSteps: Int,
    val toSteps: Int,
    val capturesTokenIds: List<String> = emptyList(),
    val leavesBase: Boolean = false,
    val entersHomeStretch: Boolean = false,
    val finishesToken: Boolean = false,
    /**
     * QUICK MODE, LOCKED: this piece reached the door without its player having
     * cut anybody, so it is sent back to its starting square to run the circuit
     * again rather than being allowed home.
     */
    val restartsLap: Boolean = false
)

/** What happened after a roll. */
data class RollOutcome(
    val value: Int,
    /** A six was rolled — the same player must roll again before moving. */
    val mustRollAgain: Boolean,
    /** Three sixes in a row — the whole turn (and every banked value) is lost. */
    val turnLostToThreeSixes: Boolean
)

/** What happened after a move. */
data class MoveResult(
    val move: Move,
    val capturedTokens: List<Token>,
    val extraTurn: Boolean,
    val gameWon: Boolean,
    val winnerPlayerId: String?,
    /** QUICK MODE: this move is the capture that unlocked HOME. */
    val unlockedHome: Boolean = false,
    /** QUICK MODE: the piece was turned back out for another lap. */
    val restartedLap: Boolean = false,
    /**
     * TEAM MODE: this move was played by a player who has already finished, on
     * behalf of their partner. The board uses it to say whose hand is moving.
     */
    val playedForPartner: Boolean = false,
    /** LUDO SNAKE MODE: the snake or ladder this move triggered, if any. */
    val special: Special? = null,
    /** Step the piece was standing on when the shortcut fired. */
    val specialFromSteps: Int? = null,
    /** Step the shortcut carried it to. */
    val specialToSteps: Int? = null,
    /** ARROW MODE: the arrow this move triggered, if any. */
    val arrow: BoardArrow? = null,
    /** Step the piece was standing on when the arrow fired. */
    val arrowFromSteps: Int? = null,
    /** Step the arrow carried it to. */
    val arrowToSteps: Int? = null,
    /** Values still banked and waiting to be spent by this player. */
    val rollsLeft: List<Int> = emptyList()
)
