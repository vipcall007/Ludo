package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * WHEN THE GAME MOVES FOR YOU
 *
 * Tapping a piece when there is only one piece to tap is a waste of the
 * player's time, so the game plays it. The line it must not cross is playing a
 * move the player might have made differently: two pieces to choose from, or
 * two banked numbers that piece could spend, is a decision and the game waits.
 */
class ForcedMoveTest {

    private fun state(): GameState {
        val red = Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN)
        val yellow = Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        return GameState(gameId = "forced", players = mutableListOf(red, yellow))
    }

    private fun bank(s: GameState, vararg values: Int) {
        s.pendingRolls.clear()
        s.pendingRolls.addAll(values.toList())
        s.phase = TurnPhase.AWAITING_MOVE
        s.lastDiceRoll = values.lastOrNull()
    }

    private fun out(s: GameState, playerIndex: Int, tokenIndex: Int, steps: Int) {
        s.players[playerIndex].tokens[tokenIndex].state = TokenState.ACTIVE
        s.players[playerIndex].tokens[tokenIndex].steps = steps
    }

    // ------------------------------------------------------- it plays itself

    @Test
    fun `one piece out and one number means the game just moves it`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        bank(s, 3)

        val forced = engine.forcedMove()
        assertNotNull("the only move was not taken automatically", forced)
        assertEquals(s.players[0].tokens[0].id, forced!!.token.id)
        assertEquals(3, forced.usedRoll)
    }

    @Test
    fun `a four with every piece in base is not a move at all`() {
        val s = state()
        val engine = LudoEngine(s)
        bank(s, 4)
        assertNull("there is nothing to move", engine.forcedMove())
        assertTrue(engine.legalMoves().isEmpty())
    }

    @Test
    fun `a six with one piece out and three in base is a real choice`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        bank(s, 6)
        // bring a piece out, or walk the one already out
        assertNull("the game chose for the player", engine.forcedMove())
        assertTrue(engine.legalMoves().size > 1)
    }

    @Test
    fun `two pieces out means the player decides`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        out(s, 0, 1, 20)
        bank(s, 3)
        assertNull(engine.forcedMove())
    }

    // ------------------------------------------- two numbers is always a choice

    @Test
    fun `one piece but two different numbers is a choice, not a forced move`() {
        // This is the "6 4" case: which number is spent first changes where the
        // piece ends up on the way, and what is left afterwards.
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        bank(s, 6, 4)
        assertNull("the game spent a number for the player", engine.forcedMove())
        assertEquals(listOf(4, 6), engine.rollsPlayableBy(s.players[0].tokens[0]))
    }

    @Test
    fun `a banked number nothing can spend does not turn the other into a choice`() {
        // Three from home with a 3 and a 6 banked: the 6 would overshoot, so
        // there is still only one thing to do and the game should just do it.
        val s = state()
        val engine = LudoEngine(s)
        val token = s.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3
        // the rest are already home, so the six has nobody to bring out
        for (i in 1..3) {
            s.players[0].tokens[i].state = TokenState.FINISHED
            s.players[0].tokens[i].steps = LudoEngine.FINISH_STEPS
        }
        bank(s, 3, 6)

        val forced = engine.forcedMove()
        assertNotNull("the only playable number was not played", forced)
        assertEquals(3, forced!!.usedRoll)
    }

    @Test
    fun `a six is a choice when it could bring a piece out instead`() {
        // The same shape as above, but with pieces still in base: now the six
        // CAN be spent, so the player must be allowed to decide.
        val s = state()
        val engine = LudoEngine(s)
        val token = s.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3
        bank(s, 3, 6)

        assertNull("finishing was chosen over bringing a piece out",
                   engine.forcedMove())
    }

    @Test
    fun `the same number twice with one piece is still automatic`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        bank(s, 3, 3)
        assertNotNull("both numbers are identical, so there is nothing to decide",
                      engine.forcedMove())
    }

    // ------------------------------------------ what a tapped piece is offered

    @Test
    fun `tapping a piece offers only the numbers it can actually use`() {
        val s = state()
        val engine = LudoEngine(s)
        val token = s.players[0].tokens[0]
        // three steps short of finishing: a 3 lands home, a 6 overshoots
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3
        bank(s, 3, 6)

        assertEquals(listOf(3), engine.rollsPlayableBy(token))
        assertEquals(1, engine.movesFor(token).size)
        assertTrue(engine.movesFor(token).first().finishesToken)
    }

    @Test
    fun `a piece in base is offered the six and nothing else`() {
        val s = state()
        val engine = LudoEngine(s)
        bank(s, 6, 2)
        val base = s.players[0].tokens[0]
        assertEquals(listOf(6), engine.rollsPlayableBy(base))
    }

    @Test
    fun `the offered numbers come back in a settled order`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 5)
        bank(s, 6, 2, 4)
        assertEquals(listOf(2, 4, 6), engine.rollsPlayableBy(s.players[0].tokens[0]))
    }

    @Test
    fun `nothing is forced while the player still owes a roll`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        s.pendingRolls.add(6)
        s.phase = TurnPhase.AWAITING_ROLL
        assertNull("a move was offered before the mandatory roll", engine.forcedMove())
    }

    @Test
    fun `nothing is forced once the game is over`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 10)
        bank(s, 3)
        s.phase = TurnPhase.GAME_OVER
        assertNull(engine.forcedMove())
    }

    // ---------------------------------------------------- it really is legal

    @Test
    fun `a forced move is always one the engine will accept`() {
        val s = state()
        val engine = LudoEngine(s)
        out(s, 0, 0, 44)
        bank(s, 5)
        val forced = engine.forcedMove()
        assertNotNull(forced)
        engine.applyMove(forced!!)      // would throw if it were not legal
        assertEquals(49, s.players[0].tokens[0].steps)
    }
}
