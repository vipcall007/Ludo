package com.example.ludoroyale.snl

import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialSize
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Rules of the standalone 1..100 SNAKE & LADDER board.
 *
 * These are the promises a player relies on: the numbering runs the way the
 * printed board does, a shortcut only fires on its own square and never chains
 * into another, square 100 always needs an exact roll, and a game always ends.
 */
class SnlEngineTest {

    private fun players(n: Int) = (1..n).map {
        SnlPlayer("p$it", "P$it", PlayerColor.entries[it - 1], PlayerKind.HUMAN)
    }.toMutableList()

    private fun engine(
        n: Int = 2,
        difficulty: SnakeDifficulty = SnakeDifficulty.EASY
    ) = SnlEngine(players(n), SnlRules(difficulty = difficulty))

    // ------------------------------------------------------------- numbering

    @Test
    fun `board is numbered the way the printed game is`() {
        assertEquals(9 to 0, SnlConfig.cellToGrid(1))     // bottom-left
        assertEquals(9 to 9, SnlConfig.cellToGrid(10))    // first row runs right
        assertEquals(8 to 9, SnlConfig.cellToGrid(11))    // then straight up
        assertEquals(8 to 0, SnlConfig.cellToGrid(20))    // second row runs back left
        assertEquals(0 to 9, SnlConfig.cellToGrid(91))
        assertEquals(0 to 0, SnlConfig.cellToGrid(100))   // top-left
    }

    @Test
    fun `every square has its own place on the grid`() {
        val used = (1..SnlConfig.LAST_CELL).map { SnlConfig.cellToGrid(it) }
        assertEquals(SnlConfig.LAST_CELL, used.toSet().size)
    }

    // ------------------------------------------------------- board contents

    @Test
    fun `easy board matches the specified mix`() {
        val list = SnlConfig.specialsFor(SnakeDifficulty.EASY)
        val snakes = list.filter { it.type == SpecialType.SNAKE }
        val ladders = list.filter { it.type == SpecialType.LADDER }
        assertEquals(3, snakes.size)
        assertEquals(6, ladders.size)
        assertEquals(2, snakes.count { it.size == SpecialSize.SMALL })
        assertEquals(1, snakes.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(1, ladders.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(2, ladders.count { it.size == SpecialSize.MEDIUM })
        assertEquals(3, ladders.count { it.size == SpecialSize.SMALL })

        // the showpiece snake belongs high up the board
        val big = snakes.first { it.size == SpecialSize.VERY_LARGE }
        assertTrue(SnlConfig.cellToGrid(big.entryCell).first <= 3)
    }

    @Test
    fun `medium board is six small snakes and six small ladders`() {
        val list = SnlConfig.specialsFor(SnakeDifficulty.MEDIUM)
        val snakes = list.filter { it.type == SpecialType.SNAKE }
        val ladders = list.filter { it.type == SpecialType.LADDER }
        assertEquals(6, snakes.size)
        assertEquals(6, ladders.size)
        assertTrue(list.all { it.size == SpecialSize.SMALL })
    }

    @Test
    fun `hard board is eight mixed snakes and five ladders`() {
        val list = SnlConfig.specialsFor(SnakeDifficulty.HARD)
        val snakes = list.filter { it.type == SpecialType.SNAKE }
        val ladders = list.filter { it.type == SpecialType.LADDER }
        assertEquals(8, snakes.size)
        assertEquals(5, ladders.size)
        assertTrue(snakes.map { it.size }.toSet().size >= 3)
        assertEquals(1, ladders.count { it.size == SpecialSize.VERY_LARGE })
        assertEquals(2, ladders.count { it.size == SpecialSize.MEDIUM })
        assertEquals(2, ladders.count { it.size == SpecialSize.SMALL })
    }

    @Test
    fun `no board can chain two shortcuts or hand out square 100`() {
        for (d in SnakeDifficulty.entries) {
            assertTrue("$d should be sane", SnlConfig.isSane(d))
            val list = SnlConfig.specialsFor(d)
            for (sp in list) {
                assertNull(
                    "$d: ${sp.id} exits onto another trigger",
                    SnlConfig.specialAt(d, sp.exitCell)
                )
                assertTrue("$d: ${sp.id} touches 100", sp.entryCell != 100 && sp.exitCell != 100)
            }
        }
    }

    // --------------------------------------------------------------- moving

    /**
     * A special far enough up the board that a piece can stand a few squares
     * below it. Starting at square 0 would run into the entry rule instead,
     * which is a different test.
     */
    private fun specialWithRoomBelow(type: SpecialType) =
        SnlConfig.specialsFor(SnakeDifficulty.EASY)
            .first { it.type == type && it.entryCell > 4 }

    @Test
    fun `a shortcut fires only when the piece lands exactly on it`() {
        val e = engine()
        val ladder = specialWithRoomBelow(SpecialType.LADDER)

        // stop one square short and roll past it — nothing should happen
        e.players[0].cell = ladder.entryCell - 2
        val passing = e.resolve(3)
        assertNull(passing.special)
        assertEquals(ladder.entryCell + 1, e.players[0].cell)
    }

    @Test
    fun `landing on a ladder carries the piece up`() {
        val e = engine()
        val ladder = specialWithRoomBelow(SpecialType.LADDER)
        e.players[0].cell = ladder.entryCell - 3
        val result = e.resolve(3)
        assertNotNull(result.special)
        assertEquals(ladder.exitCell, result.finalCell)
        assertEquals(ladder.exitCell, e.players[0].cell)
    }

    @Test
    fun `landing on a snake carries the piece down`() {
        val e = engine()
        val snake = specialWithRoomBelow(SpecialType.SNAKE)
        e.players[0].cell = snake.entryCell - 2
        val result = e.resolve(2)
        assertNotNull(result.special)
        assertEquals(snake.exitCell, result.finalCell)
    }

    @Test
    fun `square 100 needs an exact roll`() {
        val e = engine()
        e.players[0].cell = 98
        val over = e.resolve(5)
        assertTrue(over.blocked)
        assertEquals(98, e.players[0].cell)
        assertTrue("a wasted roll still ends the turn", e.current.id == "p2")
    }

    @Test
    fun `reaching 100 exactly wins the game`() {
        val e = engine()
        e.players[0].cell = 97
        val result = e.resolve(3)
        assertTrue(result.won)
        assertEquals(100, e.players[0].cell)
        assertEquals(SnlPhase.GAME_OVER, e.phase)
        assertEquals("p1", e.winnerId)
    }

    @Test
    fun `landing on an opponent does nothing at all`() {
        val e = engine()
        // a quiet square with no shortcut on it
        val target = (2..90).first { SnlConfig.specialAt(SnakeDifficulty.EASY, it) == null }
        e.players[1].cell = target
        e.players[0].cell = target - 2
        val result = e.resolve(2)
        assertTrue("nothing may be knocked back", result.cutPlayerIds.isEmpty())
        assertEquals("the other counter must not move", target, e.players[1].cell)
        assertEquals("and both share the square", target, e.players[0].cell)
    }

    @Test
    fun `a whole game never knocks anybody back`() {
        for (game in 0 until 60) {
            val e = engine(n = 4, difficulty = SnakeDifficulty.entries[game % 3])
            var turns = 0
            while (e.phase != SnlPhase.GAME_OVER && turns < 6000) {
                turns++
                val roll = e.rollDice()
                if (roll.turnLostToThreeSixes) continue
                assertTrue("a counter was cut", e.resolve(roll.value).cutPlayerIds.isEmpty())
            }
        }
    }

    // ----------------------------------------------------------- getting out

    @Test
    fun `a counter waits on the start pad until it rolls a six or a one`() {
        for (value in 2..5) {
            val e = engine()
            val result = e.resolve(value)
            assertTrue("a $value should not start a counter", result.needsEntryRoll)
            assertTrue(result.blocked)
            assertEquals(0, e.players[0].cell)
        }
    }

    @Test
    fun `a six or a one puts the counter on that very square`() {
        for (value in intArrayOf(1, 6)) {
            val e = engine()
            val result = e.resolve(value)
            assertTrue("a $value should start a counter", !result.needsEntryRoll)
            assertEquals(value, result.landedCell)
        }
    }

    @Test
    fun `a wasted entry roll still hands the turn on, unless it was a six`() {
        val e = engine()
        e.resolve(3)
        assertEquals("an ordinary failed entry passes the turn", "p2", e.current.id)

        val f = engine()
        // a six gets you out, so test the other half: three sixes still burn
        f.players[0].cell = 0
        val six = f.resolve(6)
        assertTrue("a six is an entry roll", !six.needsEntryRoll)
        assertTrue("and it earns another roll", six.extraTurn)
    }

    @Test
    fun `waiting on the pad cannot be dodged by a shortcut`() {
        // square 1 is never a snake head or ladder foot, so entering on a 1 is
        // never instantly undone
        for (d in SnakeDifficulty.entries) {
            assertNull(SnlConfig.specialAt(d, 1))
        }
    }

    @Test
    fun `a six keeps the turn and an ordinary roll passes it`() {
        val e = engine()
        assertTrue(e.resolve(6).extraTurn)
        assertEquals("p1", e.current.id)
        assertTrue(!e.resolve(3).extraTurn)
        assertEquals("p2", e.current.id)
    }

    // ---------------------------------------------------------- whole games

    @Test
    fun `random games always finish with an exact landing on 100`() {
        for (game in 0 until 300) {
            val difficulty = SnakeDifficulty.entries[game % 3]
            val e = engine(n = 4, difficulty = difficulty)
            var turns = 0
            while (e.phase != SnlPhase.GAME_OVER && turns < 6000) {
                turns++
                val roll = e.rollDice()
                if (roll.turnLostToThreeSixes) continue
                val result = e.resolve(roll.value)

                assertTrue("a piece left the board", e.players.all { it.cell in 0..100 })
                if (result.special != null) {
                    assertEquals(result.special!!.entryCell, result.landedCell)
                    assertEquals(result.special!!.exitCell, result.finalCell)
                    assertNull(
                        "one dice move fired two shortcuts",
                        SnlConfig.specialAt(difficulty, result.finalCell)
                    )
                }
                if (result.won) assertEquals(100, result.finalCell)
            }
            assertEquals("a game never ended", SnlPhase.GAME_OVER, e.phase)
            assertNotNull(e.winnerId)
        }
    }
}
