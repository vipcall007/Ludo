package com.example.ludoroyale.progression

import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.CosmeticType
import com.example.ludoroyale.cosmetics.UnlockMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * The daily cycle, the chest and the cosmetic catalog.
 *
 * The daily reward is the easiest thing in a game to get wrong in the player's
 * favour by accident — reopen the screen, collect again — so most of this file
 * is about the claim never being available twice on the same day.
 */
class RewardsTest {

    // ------------------------------------------------------ the daily cycle

    @Test
    fun `the cycle is seven days and day seven is the chest`() {
        assertEquals(7, DailyRewards.CYCLE.size)
        assertEquals(DailyRewards.CYCLE_LENGTH, DailyRewards.CYCLE.size)
        DailyRewards.CYCLE.forEachIndexed { i, reward ->
            assertEquals("day numbering", i + 1, reward.day)
        }
        assertEquals(RewardKind.CHEST, DailyRewards.rewardFor(7).kind)
    }

    @Test
    fun `day seven is worth clearly more than day one`() {
        val one = DailyRewards.rewardFor(1)
        val seven = DailyRewards.rewardFor(7)
        assertTrue("the big day must feel big", seven.coins > one.coins * 2)
    }

    @Test
    fun `every cosmetic the cycle hands out actually exists`() {
        for (reward in DailyRewards.CYCLE) {
            val id = reward.cosmeticId ?: continue
            assertNotNull("day ${reward.day} gives a cosmetic that is not in the catalog", Cosmetics.byId(id))
        }
    }

    @Test
    fun `a day can only be claimed once`() {
        val today = 19000
        assertTrue(DailyRewards.canClaim(lastClaimDay = 18999, today = today))
        assertFalse("claiming twice on one day", DailyRewards.canClaim(lastClaimDay = today, today = today))
    }

    @Test
    fun `claiming yesterday carries the run forward`() {
        assertEquals(4, DailyRewards.dayOnOffer(lastClaimDay = 18999, today = 19000, claimedDay = 3))
    }

    @Test
    fun `missing a day sends the run back to day one`() {
        assertEquals(1, DailyRewards.dayOnOffer(lastClaimDay = 18990, today = 19000, claimedDay = 5))
    }

    @Test
    fun `after day seven the cycle starts again`() {
        assertEquals(1, DailyRewards.dayOnOffer(lastClaimDay = 18999, today = 19000, claimedDay = 7))
    }

    @Test
    fun `a brand new player is offered day one`() {
        assertEquals(1, DailyRewards.dayOnOffer(lastClaimDay = -1, today = 19000, claimedDay = 0))
    }

    @Test
    fun `once today is taken the day already collected is what is shown`() {
        assertEquals(3, DailyRewards.dayOnOffer(lastClaimDay = 19000, today = 19000, claimedDay = 3))
    }

    @Test
    fun `the offered day is always inside the cycle`() {
        for (last in 18990..19000) {
            for (claimed in 0..7) {
                val day = DailyRewards.dayOnOffer(last, 19000, claimed)
                assertTrue("day $day is outside the cycle", day in 1..DailyRewards.CYCLE_LENGTH)
            }
        }
    }

    // -------------------------------------------------------------- chest

    @Test
    fun `the chest pool is sane`() {
        assertTrue(MysteryChest.isSane())
    }

    @Test
    fun `the published odds are the real odds and add up to a hundred`() {
        val odds = MysteryChest.odds()
        assertEquals(MysteryChest.POOL.size, odds.size)
        val total = odds.sumOf { it.second.toDouble() }
        assertEquals("the odds must add up", 100.0, total, 0.01)
        assertTrue("no entry may be impossible", odds.all { it.second > 0f })
    }

    @Test
    fun `the chest always hands over something`() {
        val rnd = Random(7)
        repeat(400) {
            val grant = MysteryChest.open(rnd, emptySet())
            assertTrue(
                "a chest gave nothing at all",
                grant.coins > 0 || grant.cosmeticId != null
            )
        }
    }

    @Test
    fun `a duplicate pays coins instead of nothing`() {
        val everything = Cosmetics.ALL.map { it.id }.toSet()
        val rnd = Random(11)
        repeat(300) {
            val grant = MysteryChest.open(rnd, everything)
            assertTrue("a duplicate paid nothing", grant.coins > 0)
            assertFalse("a duplicate was handed over again", grant.gaveCosmetic)
        }
    }

    @Test
    fun `over many opens every entry in the pool turns up`() {
        val rnd = Random(3)
        val seen = mutableSetOf<String>()
        repeat(40000) {
            val grant = MysteryChest.open(rnd, emptySet())
            seen += grant.cosmeticId ?: if (grant.coins == MysteryChest.COINS_BIG) "COINS_BIG" else "COINS_SMALL"
        }
        for ((id, _) in MysteryChest.POOL) {
            assertTrue("'$id' is in the pool but never came out", id in seen)
        }
    }

    // ------------------------------------------------------------- catalog

    @Test
    fun `the cosmetic catalog is sane`() {
        assertTrue(Cosmetics.isSane())
    }

    @Test
    fun `every type has a default a new player already owns`() {
        for (type in CosmeticType.entries) {
            val id = Cosmetics.defaultFor(type)
            val item = Cosmetics.byId(id)
            assertNotNull("no default for $type", item)
            assertEquals(type, item!!.type)
            assertTrue("the default for $type is not free", id in Cosmetics.free())
        }
    }

    @Test
    fun `nothing in the catalog costs real money or affects play`() {
        // there is only one way to pay for anything, and it is coins
        for (item in Cosmetics.ALL) {
            if (item.price > 0) {
                assertEquals(
                    "${item.id} is priced but not bought with coins",
                    UnlockMethod.COINS, item.unlock
                )
            }
        }
    }

    @Test
    fun `level unlocks arrive exactly once, on the level they name`() {
        for (item in Cosmetics.ALL.filter { it.unlock == UnlockMethod.LEVEL }) {
            val onTheLevel = Cosmetics.unlockedOnReaching(item.requiredLevel)
            assertTrue("${item.id} is not given at level ${item.requiredLevel}", item in onTheLevel)
            assertTrue(
                "${item.id} is given again a level later",
                item !in Cosmetics.unlockedOnReaching(item.requiredLevel + 1)
            )
        }
    }

    @Test
    fun `everything owed at a level is owed at every level above it`() {
        for (level in 1..100) {
            val here = Cosmetics.unlockedAtLevel(level).toSet()
            val above = Cosmetics.unlockedAtLevel(level + 1).toSet()
            assertTrue("level $level unlocks are lost by level ${level + 1}", above.containsAll(here))
        }
    }

    @Test
    fun `a rarer item is worth more as a duplicate`() {
        val common = Cosmetics.ALL.first { it.rarity == com.example.ludoroyale.cosmetics.Rarity.COMMON }
        val legendary = Cosmetics.ALL.first { it.rarity == com.example.ludoroyale.cosmetics.Rarity.LEGENDARY }
        assertTrue(legendary.dustValue > common.dustValue)
    }

    @Test
    fun `no two cosmetics share an id`() {
        val ids = Cosmetics.ALL.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }
}
