package com.example.ludoroyale.progression

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * XP, levels and what a match pays.
 *
 * These are the numbers a player's whole sense of progress rests on, so the
 * curve is pinned down here: it never goes backwards, a level is exactly as
 * far away as the table says, and the milestones land on the levels the brief
 * names.
 */
class ProgressionTest {

    @Test
    fun `a new player is level one`() {
        assertEquals(1, Progression.levelForXp(0))
        assertEquals(1, Progression.levelForXp(-50))
    }

    @Test
    fun `the level for an XP total matches the cost of getting there`() {
        for (level in 1..Progression.MAX_LEVEL) {
            val need = Progression.totalXpForLevel(level)
            assertEquals("level $level", level, Progression.levelForXp(need))
            if (level > 1) {
                assertEquals(
                    "one XP short of $level",
                    level - 1, Progression.levelForXp(need - 1)
                )
            }
        }
    }

    @Test
    fun `the curve never goes backwards and never stalls`() {
        var last = 0
        for (level in 1 until Progression.MAX_LEVEL) {
            val cost = Progression.xpForLevel(level)
            assertTrue("level $level costs nothing", cost > 0)
            assertTrue("level $level got cheaper", cost >= last)
            last = cost
        }
    }

    @Test
    fun `XP stops being asked for at the cap`() {
        assertEquals(0, Progression.xpForLevel(Progression.MAX_LEVEL))
        assertEquals(1f, Progression.progress(Progression.totalXpForLevel(Progression.MAX_LEVEL)), 0.001f)
        // and a great deal more XP still cannot push past the cap
        assertEquals(
            Progression.MAX_LEVEL,
            Progression.levelForXp(Progression.totalXpForLevel(Progression.MAX_LEVEL) * 5)
        )
    }

    @Test
    fun `progress within a level runs from zero to one`() {
        for (level in 1 until Progression.MAX_LEVEL) {
            val floor = Progression.totalXpForLevel(level)
            assertEquals("start of $level", 0f, Progression.progress(floor), 0.0001f)
            val nearlyThere = floor + Progression.xpForLevel(level) - 1
            assertTrue("end of $level", Progression.progress(nearlyThere) > 0.9f)
        }
    }

    @Test
    fun `the milestone titles land exactly where the brief says`() {
        assertEquals("BEGINNER", Progression.titleFor(1))
        assertEquals("BEGINNER", Progression.titleFor(4))
        assertEquals("BRONZE", Progression.titleFor(5))
        assertEquals("BRONZE", Progression.titleFor(9))
        assertEquals("SILVER", Progression.titleFor(10))
        assertEquals("GOLD", Progression.titleFor(20))
        assertEquals("PLATINUM", Progression.titleFor(30))
        assertEquals("DIAMOND", Progression.titleFor(50))
        assertEquals("DIAMOND", Progression.titleFor(99))
        assertEquals("LUDO MASHA KING", Progression.titleFor(100))
    }

    @Test
    fun `levels between milestones still carry the title below them`() {
        for (level in 1..Progression.MAX_LEVEL) {
            val title = Progression.titleFor(level)
            assertTrue("level $level has no title", title.isNotBlank())
        }
        assertEquals("SILVER", Progression.titleFor(15))
        assertEquals("GOLD", Progression.titleFor(25))
    }

    @Test
    fun `the next milestone is the next one up, and nothing follows the last`() {
        assertEquals(5, Progression.nextTitle(1)?.first)
        assertEquals(10, Progression.nextTitle(5)?.first)
        assertEquals(100, Progression.nextTitle(50)?.first)
        assertNull(Progression.nextTitle(100))
    }

    // ------------------------------------------------------- match rewards

    @Test
    fun `finishing a match always pays something`() {
        assertTrue(MatchRewards.xpFor(won = false, captures = 0, tokensHome = 0) > 0)
        assertTrue(MatchRewards.coinsFor(won = false, streak = 0) > 0)
    }

    @Test
    fun `winning pays more than losing, all else equal`() {
        val lost = MatchRewards.xpFor(false, 3, 2)
        val won = MatchRewards.xpFor(true, 3, 2)
        assertTrue("a win should be worth more", won > lost)
    }

    @Test
    fun `captures pay, but not without limit`() {
        val few = MatchRewards.xpFor(true, 2, 0)
        val many = MatchRewards.xpFor(true, 40, 0)
        assertTrue(many > few)
        assertEquals(
            MatchRewards.XP_COMPLETE + MatchRewards.XP_WIN + MatchRewards.XP_CAPTURE_CAP,
            many
        )
    }

    @Test
    fun `the streak bonus grows but is capped`() {
        assertEquals(MatchRewards.COINS_WIN, MatchRewards.coinsFor(true, 1))
        assertEquals(
            MatchRewards.COINS_WIN + MatchRewards.COINS_STREAK_BONUS,
            MatchRewards.coinsFor(true, 2)
        )
        val atCap = MatchRewards.coinsFor(true, MatchRewards.COINS_STREAK_CAP)
        val wayPast = MatchRewards.coinsFor(true, 500)
        assertEquals("the bonus must stop somewhere", atCap, wayPast)
    }

    @Test
    fun `a loss never pays the win rate`() {
        assertNotEquals(
            MatchRewards.coinsFor(won = true, streak = 1),
            MatchRewards.coinsFor(won = false, streak = 0)
        )
    }
}
