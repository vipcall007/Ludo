package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Daily missions.
 *
 * The two promises that matter: the same day always produces the same
 * missions, so closing the game cannot reroll a hard set into an easy one; and
 * a finished mission pays exactly once however many times it is asked.
 */
class MissionTest {

    private fun event(
        type: GameEventType, local: Boolean = true, count: Int = 1,
        value: Int = 0, mode: GameMode = GameMode.CLASSIC
    ) = GameEvent(type, "p1", local, count, value, mode)

    @Test
    fun `the same day always gives the same missions`() {
        for (day in 19000..19010) {
            val first = MissionCatalog.generate(day)
            val second = MissionCatalog.generate(day)
            assertEquals(first.map { it.id }, second.map { it.id })
            assertEquals(first.map { it.type }, second.map { it.type })
            assertEquals(first.map { it.target }, second.map { it.target })
        }
    }

    @Test
    fun `different days give different work`() {
        val a = MissionCatalog.generate(19000).map { it.type to it.target }
        var differs = false
        for (day in 19001..19020) {
            if (MissionCatalog.generate(day).map { it.type to it.target } != a) differs = true
        }
        assertTrue("every day produced the same set", differs)
    }

    @Test
    fun `a day never repeats a mission type`() {
        for (day in 19000..19060) {
            val types = MissionCatalog.generate(day).map { it.type }
            assertEquals("day $day repeats a type", types.size, types.toSet().size)
        }
    }

    @Test
    fun `every day has at least one mission any mode can finish`() {
        for (day in 19000..19060) {
            val ok = MissionCatalog.generate(day).any {
                it.type == MissionType.PLAY_MATCHES || it.type == MissionType.WIN_MATCHES
            }
            assertTrue("day $day is a dead end for a Classic-only player", ok)
        }
    }

    @Test
    fun `missions carry a reward worth having`() {
        for (def in MissionCatalog.POOL) {
            assertTrue("${def.type} pays no XP", def.xp > 0)
            assertTrue("${def.type} pays no coins", def.coins > 0)
            assertTrue("${def.type} asks for nothing", def.target > 0)
        }
    }

    // ------------------------------------------------------------ progress

    @Test
    fun `a capture mission counts captures and stops at its target`() {
        val book = MissionBook(listOf(Mission("m", MissionType.CAPTURE_TOKENS, target = 3)))
        book.onGameEvent(event(GameEventType.TOKEN_CAPTURED, count = 2))
        assertEquals(2, book.missions[0].progress)
        book.onGameEvent(event(GameEventType.TOKEN_CAPTURED, count = 5))
        assertEquals("progress must not run past the target", 3, book.missions[0].progress)
        assertTrue(book.missions[0].completed)
    }

    @Test
    fun `a computer's capture is not your capture`() {
        val book = MissionBook(listOf(Mission("m", MissionType.CAPTURE_TOKENS, target = 3)))
        book.onGameEvent(event(GameEventType.TOKEN_CAPTURED, local = false, count = 3))
        assertEquals(0, book.missions[0].progress)
    }

    @Test
    fun `a six mission counts only sixes`() {
        val book = MissionBook(listOf(Mission("m", MissionType.ROLL_SIXES, target = 3)))
        book.onGameEvent(event(GameEventType.DICE_ROLLED, value = 4))
        book.onGameEvent(event(GameEventType.DICE_ROLLED, value = 6))
        book.onGameEvent(event(GameEventType.DICE_ROLLED, value = 6))
        assertEquals(2, book.missions[0].progress)
    }

    @Test
    fun `a mode mission only counts that mode`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_SNAKE_MATCH, target = 1)))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED, mode = GameMode.CLASSIC))
        assertEquals(0, book.missions[0].progress)
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED, mode = GameMode.SNAKES))
        assertEquals(1, book.missions[0].progress)
    }

    @Test
    fun `playing counts whoever won`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_MATCHES, target = 2)))
        // a completed match counts even when the local player lost it
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED, local = false))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED, local = false))
        assertTrue(book.missions[0].completed)
    }

    @Test
    fun `winning counts only your own wins`() {
        val book = MissionBook(listOf(Mission("m", MissionType.WIN_MATCHES, target = 1)))
        book.onGameEvent(event(GameEventType.MATCH_WON, local = false))
        assertEquals(0, book.missions[0].progress)
        book.onGameEvent(event(GameEventType.MATCH_WON, local = true))
        assertEquals(1, book.missions[0].progress)
    }

    // -------------------------------------------------------------- claims

    @Test
    fun `a mission pays once and only once`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_MATCHES, 1, xp = 30, coins = 40)))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED))
        assertEquals(30 to 40, book.claim("m"))
        assertNull("a second claim must pay nothing", book.claim("m"))
        assertNull("and a third", book.claim("m"))
    }

    @Test
    fun `an unfinished mission cannot be claimed`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_MATCHES, 3, xp = 30, coins = 40)))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED))
        assertNull(book.claim("m"))
        assertEquals(0, book.claimableCount())
    }

    @Test
    fun `a claimed mission stops taking progress`() {
        val mission = Mission("m", MissionType.CAPTURE_TOKENS, 1, xp = 1, coins = 1)
        val book = MissionBook(listOf(mission))
        book.onGameEvent(event(GameEventType.TOKEN_CAPTURED))
        assertNotNull(book.claim("m"))
        book.onGameEvent(event(GameEventType.TOKEN_CAPTURED, count = 9))
        assertEquals(1, mission.progress)
    }

    @Test
    fun `a mission that does not exist cannot be claimed`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_MATCHES, 1)))
        assertNull(book.claim("not-a-mission"))
    }

    @Test
    fun `newly completed missions are reported once`() {
        val book = MissionBook(listOf(Mission("m", MissionType.PLAY_MATCHES, 1)))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED))
        assertEquals(1, book.takeNewlyCompleted().size)
        assertEquals("the same completion must not be reported twice", 0, book.takeNewlyCompleted().size)
    }

    // ------------------------------------------------------------- storage

    @Test
    fun `missions survive being written down and read back`() {
        val original = MissionCatalog.generate(19123)
        // advance rather than assign, so the saved state is one the game could
        // actually reach — progress past a target is not a thing that happens
        original[0].advance(2)
        original[1].advance(original[1].target)
        original[1].claimed = true
        val restored = MissionCodec.decode(MissionCodec.encode(original))
        assertEquals(original.size, restored.size)
        original.forEachIndexed { i, m ->
            assertEquals(m.id, restored[i].id)
            assertEquals(m.type, restored[i].type)
            assertEquals(m.target, restored[i].target)
            assertEquals(m.progress, restored[i].progress)
            assertEquals(m.claimed, restored[i].claimed)
            assertEquals(m.xp, restored[i].xp)
            assertEquals(m.coins, restored[i].coins)
            assertEquals(m.day, restored[i].day)
        }
    }

    @Test
    fun `a corrupt saved line is treated as nothing saved, never as a crash`() {
        assertEquals(0, MissionCodec.decode("").size)
        assertEquals(0, MissionCodec.decode("rubbish").size)
        assertEquals(0, MissionCodec.decode("a,b,c").size)
        assertEquals(0, MissionCodec.decode("m,NOT_A_TYPE,3,0,0,10,10,1").size)
        // one good entry among the rubbish still comes back
        val mixed = MissionCodec.decode("broken|m,PLAY_MATCHES,3,1,0,30,40,19000")
        assertEquals(1, mixed.size)
        assertEquals(MissionType.PLAY_MATCHES, mixed[0].type)
    }

    @Test
    fun `saved progress can never exceed the target`() {
        val restored = MissionCodec.decode("m,PLAY_MATCHES,3,99,0,30,40,19000")
        assertEquals(3, restored[0].progress)
    }

    @Test
    fun `replacing the day's missions clears yesterday's entirely`() {
        val book = MissionBook(MissionCatalog.generate(19000))
        book.onGameEvent(event(GameEventType.MATCH_COMPLETED))
        book.replaceWith(MissionCatalog.generate(19001))
        assertEquals(19001, book.day)
        assertTrue(book.missions.none { it.progress > 0 })
        assertEquals(0, book.takeNewlyCompleted().size)
    }

    @Test
    fun `a mission reads properly in the singular`() {
        assertFalse(MissionType.PLAY_MATCHES.describe(1).contains("matches"))
        assertTrue(MissionType.PLAY_MATCHES.describe(3).contains("matches"))
    }
}
