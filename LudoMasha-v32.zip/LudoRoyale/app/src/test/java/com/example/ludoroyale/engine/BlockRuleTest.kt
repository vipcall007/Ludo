package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * THE BLOCK RULE
 *
 * Two of your own pieces standing on one square guard each other. Somebody can
 * still land there — they just cut nothing. It is the one way in this game to
 * make a piece safe on a square that is not a marked safe square, so it needs
 * to be exactly right: two is protection, one is not, and it protects only the
 * pair that is standing there.
 */
class BlockRuleTest {

    private fun state(): GameState {
        val red = Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN)
        val yellow = Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        return GameState(gameId = "block", players = mutableListOf(red, yellow))
    }

    private fun bank(state: GameState, vararg values: Int) {
        state.pendingRolls.clear()
        state.pendingRolls.addAll(values.toList())
        state.phase = TurnPhase.AWAITING_MOVE
        state.lastDiceRoll = values.lastOrNull()
    }

    private fun place(token: Token, steps: Int) {
        token.state = TokenState.ACTIVE
        token.steps = steps
    }

    /**
     * Find a square RED can reach with [roll] that is NOT a marked safe square,
     * so the only thing that can protect a piece there is the block rule.
     */
    private fun plainSquare(): Triple<Int, Int, Int> {
        for (redSteps in 1..40) {
            val roll = 3
            val target = redSteps + roll
            val global = LudoBoard.toGlobalIndex(PlayerColor.RED, target - 1)
            if (LudoBoard.isSafeCell(global)) continue
            // the matching YELLOW step count that stands on the same square
            for (yellowSteps in 1..51) {
                if (LudoBoard.toGlobalIndex(PlayerColor.YELLOW, yellowSteps - 1) == global) {
                    return Triple(redSteps, roll, yellowSteps)
                }
            }
        }
        throw AssertionError("no ordinary square found to test on")
    }

    // ------------------------------------------------------------ one is cut

    @Test
    fun `a lone piece on an ordinary square is still cut`() {
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s)
        place(s.players[0].tokens[0], redSteps)
        place(s.players[1].tokens[0], yellowSteps)
        bank(s, roll)

        val move = engine.legalMovesFor(roll).first { it.token.id == s.players[0].tokens[0].id }
        val result = engine.applyMove(move)

        assertEquals("a single piece should have been cut", 1, result.capturedTokens.size)
        assertEquals(TokenState.BASE, s.players[1].tokens[0].state)
    }

    // ----------------------------------------------------------- two are safe

    @Test
    fun `two pieces together cannot be cut`() {
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s)
        place(s.players[0].tokens[0], redSteps)
        place(s.players[1].tokens[0], yellowSteps)
        place(s.players[1].tokens[1], yellowSteps)   // the block
        bank(s, roll)

        val move = engine.legalMovesFor(roll).first { it.token.id == s.players[0].tokens[0].id }
        assertTrue("the move should not even claim a capture", move.capturesTokenIds.isEmpty())

        val result = engine.applyMove(move)
        assertTrue("a block was cut", result.capturedTokens.isEmpty())
        assertEquals(TokenState.ACTIVE, s.players[1].tokens[0].state)
        assertEquals(TokenState.ACTIVE, s.players[1].tokens[1].state)
    }

    @Test
    fun `landing on a block is still a legal move`() {
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s)
        val red = s.players[0].tokens[0]
        place(red, redSteps)
        place(s.players[1].tokens[0], yellowSteps)
        place(s.players[1].tokens[1], yellowSteps)
        bank(s, roll)

        assertTrue("the square became unreachable instead of merely uncuttable",
                   engine.legalMovesFor(roll).any { it.token.id == red.id })
        engine.applyMove(engine.legalMovesFor(roll).first { it.token.id == red.id })
        assertEquals(redSteps + roll, red.steps)
    }

    @Test
    fun `three together are protected too`() {
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s)
        place(s.players[0].tokens[0], redSteps)
        repeat(3) { place(s.players[1].tokens[it], yellowSteps) }
        bank(s, roll)

        val move = engine.legalMovesFor(roll).first { it.token.id == s.players[0].tokens[0].id }
        assertTrue(engine.applyMove(move).capturedTokens.isEmpty())
    }

    // ------------------------------------------------- it protects only itself

    @Test
    fun `my own pair does not protect an opponent sharing the square`() {
        // RED has a pair on the target square, and a lone YELLOW is there too.
        // RED's pair is not YELLOW's business: the lone YELLOW is still cut.
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s)
        val mover = s.players[0].tokens[0]
        place(mover, redSteps)
        place(s.players[0].tokens[1], redSteps + roll)   // RED already sitting there
        place(s.players[0].tokens[2], redSteps + roll)   // and a second RED: a pair
        place(s.players[1].tokens[0], yellowSteps)       // one lone YELLOW on it
        bank(s, roll)

        val move = engine.legalMovesFor(roll).first { it.token.id == mover.id }
        val result = engine.applyMove(move)
        assertEquals("the lone opponent should still have been cut",
                     1, result.capturedTokens.size)
    }

    @Test
    fun `a block only counts pieces on the shared track`() {
        // Pieces in the home column or in base are nowhere near the square.
        val s = state()
        val engine = LudoEngine(s)
        val yellow = s.players[1]
        place(yellow.tokens[0], 20)
        yellow.tokens[1].state = TokenState.HOME_STRETCH
        yellow.tokens[1].steps = 54
        val global = LudoBoard.toGlobalIndex(PlayerColor.YELLOW, 19)
        assertFalse("a home-column piece was counted as part of a block",
                    engine.isBlockedSquare(yellow, global))
    }

    // ------------------------------------------------- what the board is told

    @Test
    fun `the board is told which squares are blocked`() {
        val s = state()
        val engine = LudoEngine(s)
        val yellow = s.players[1]
        place(yellow.tokens[0], 20)
        place(yellow.tokens[1], 20)
        place(yellow.tokens[2], 31)      // alone: not a block

        val global = LudoBoard.toGlobalIndex(PlayerColor.YELLOW, 19)
        val lone = LudoBoard.toGlobalIndex(PlayerColor.YELLOW, 30)

        assertTrue(engine.isBlockedSquare(yellow, global))
        assertFalse(engine.isBlockedSquare(yellow, lone))
        assertEquals(setOf(global), engine.blockedSquares())
    }

    @Test
    fun `no blocks on an empty board`() {
        val s = state()
        assertTrue(LudoEngine(s).blockedSquares().isEmpty())
    }

    // ---------------------------------------------------- the rule can be off

    @Test
    fun `turning the rule off restores plain cutting`() {
        val (redSteps, roll, yellowSteps) = plainSquare()
        val s = state()
        val engine = LudoEngine(s, RuleConfig(pairBlocksCapture = false))
        place(s.players[0].tokens[0], redSteps)
        place(s.players[1].tokens[0], yellowSteps)
        place(s.players[1].tokens[1], yellowSteps)
        bank(s, roll)

        val move = engine.legalMovesFor(roll).first { it.token.id == s.players[0].tokens[0].id }
        assertEquals("both pieces of the pair should go home",
                     2, engine.applyMove(move).capturedTokens.size)
        assertTrue(engine.blockedSquares().isEmpty())
    }
}
