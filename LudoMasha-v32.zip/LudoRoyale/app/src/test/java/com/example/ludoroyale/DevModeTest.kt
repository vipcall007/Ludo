package com.example.ludoroyale

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The lock on the owner's test panel.
 *
 * This is the one feature in the game that must NOT work for everybody, so
 * the way in is worth pinning down: the wrong code never opens it, a stray tap
 * never opens it, and seven deliberate taps do.
 */
class DevModeTest {

    private var clock = 0L
    private fun counter() = DevMode.TapCounter { clock }

    // ------------------------------------------------------------- the code

    @Test
    fun `the right code opens it and nothing else does`() {
        assertTrue(DevMode.accepts(DevMode.PASSCODE))
        assertFalse(DevMode.accepts(""))
        assertFalse(DevMode.accepts("0"))
        assertFalse(DevMode.accepts("000000"))
        assertFalse(DevMode.accepts(DevMode.PASSCODE + "0"))
        assertFalse(DevMode.accepts(DevMode.PASSCODE.dropLast(1)))
    }

    @Test
    fun `stray spaces around the code are forgiven`() {
        assertTrue(DevMode.accepts("  ${DevMode.PASSCODE}  "))
    }

    @Test
    fun `the code is not something anybody would try first`() {
        val obvious = setOf(
            "", "0", "1", "12", "123", "1234", "0000", "00000", "000000",
            "111111", "123456", "654321", "999999", "1111", "1234567890"
        )
        assertFalse("the owner code is a guess anybody would make",
                    DevMode.PASSCODE in obvious)
        assertTrue("the code is too short to be worth anything",
                   DevMode.PASSCODE.length >= 6)
    }

    // ------------------------------------------------------------- the taps

    @Test
    fun `a few taps do nothing at all`() {
        val taps = counter()
        repeat(DevMode.TAPS - 1) {
            clock += 100
            assertFalse("it opened too early", taps.tap())
        }
    }

    @Test
    fun `the full run opens it`() {
        val taps = counter()
        var opened = false
        repeat(DevMode.TAPS) {
            clock += 100
            if (taps.tap()) opened = true
        }
        assertTrue(opened)
    }

    @Test
    fun `a pause in the middle starts the count again`() {
        val taps = counter()
        repeat(DevMode.TAPS - 1) {
            clock += 100
            taps.tap()
        }
        // a long gap — the run is abandoned
        clock += DevMode.TAP_WINDOW_MS + 500
        assertFalse("a stale run should not finish", taps.tap())

        // and from there it takes a whole fresh run
        var opened = false
        repeat(DevMode.TAPS - 1) {
            clock += 100
            if (taps.tap()) opened = true
        }
        assertTrue(opened)
    }

    @Test
    fun `idle tapping over a long time never opens it`() {
        val taps = counter()
        repeat(200) {
            // one tap every couple of seconds, the way somebody fiddles
            clock += DevMode.TAP_WINDOW_MS + 1200
            assertFalse("idle tapping opened the panel", taps.tap())
        }
    }

    @Test
    fun `it opens once per run, not on every tap after`() {
        val taps = counter()
        var opens = 0
        repeat(DevMode.TAPS * 2) {
            clock += 100
            if (taps.tap()) opens++
        }
        assertEquals("a held run should open it exactly twice", 2, opens)
    }

    @Test
    fun `resetting clears a run in progress`() {
        val taps = counter()
        repeat(DevMode.TAPS - 1) {
            clock += 100
            taps.tap()
        }
        taps.reset()
        clock += 100
        assertFalse("the run survived a reset", taps.tap())
    }

    @Test
    fun `the remaining count never goes negative`() {
        val taps = counter()
        repeat(DevMode.TAPS * 3) {
            clock += 100
            taps.tap()
            assertTrue(taps.remaining() >= 0)
        }
    }

    // --------------------------------------------------------- what it gives

    @Test
    fun `every grant actually hands something over`() {
        for (grant in DevMode.Grant.entries) {
            assertTrue("${grant.name} gives nothing", grant.coins > 0 || grant.xp > 0)
            assertTrue("${grant.name} has no label", grant.label.isNotBlank())
        }
    }

    @Test
    fun `the level jumps are real levels, in order`() {
        var last = 0
        for (level in DevMode.LEVEL_JUMPS) {
            assertTrue("level $level is out of range",
                       level in 1..com.example.ludoroyale.progression.Progression.MAX_LEVEL)
            assertTrue("the jumps are not in order", level > last)
            last = level
        }
    }
}
