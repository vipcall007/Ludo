package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The event bus, the statistics tracker and the Epic Moment detector.
 *
 * What is really being checked here is that the phone's own record only ever
 * counts what the person holding it actually did — the whole point of the
 * byLocalPlayer flag — and that one match cannot be counted twice.
 */
class MatchSummaryTest {

    private var clock = 0L
    private fun tracker() = MatchStatsTracker { clock }

    private fun ev(
        type: GameEventType, local: Boolean = true, count: Int = 1,
        value: Int = 0, mode: GameMode = GameMode.CLASSIC
    ) = GameEvent(type, "p1", local, count, value, mode)

    // ----------------------------------------------------------------- bus

    @Test
    fun `the bus reaches everyone listening`() {
        val bus = GameEventBus()
        var a = 0
        var b = 0
        bus.register { a++ }
        bus.register { b++ }
        bus.post(GameEventType.TOKEN_MOVED)
        assertEquals(1, a)
        assertEquals(1, b)
    }

    @Test
    fun `registering the same listener twice still delivers once`() {
        val bus = GameEventBus()
        var hits = 0
        val listener = GameEventListener { hits++ }
        bus.register(listener)
        bus.register(listener)
        bus.post(GameEventType.TOKEN_MOVED)
        assertEquals(1, hits)
    }

    @Test
    fun `a listener may unregister while an event is being delivered`() {
        val bus = GameEventBus()
        var hits = 0
        lateinit var listener: GameEventListener
        listener = GameEventListener {
            hits++
            bus.unregister(listener)
        }
        bus.register(listener)
        bus.post(GameEventType.TOKEN_MOVED)
        bus.post(GameEventType.TOKEN_MOVED)
        assertEquals("it should have heard exactly one event", 1, hits)
    }

    @Test
    fun `clearing the bus drops everyone`() {
        val bus = GameEventBus()
        bus.register { }
        bus.register { }
        assertEquals(2, bus.listenerCount)
        bus.clear()
        assertEquals(0, bus.listenerCount)
    }

    // ------------------------------------------------------------- tracker

    @Test
    fun `the tracker counts what the local player did`() {
        val t = tracker()
        t.onGameEvent(ev(GameEventType.MATCH_STARTED, mode = GameMode.QUICK))
        t.onGameEvent(ev(GameEventType.DICE_ROLLED, value = 6))
        t.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 2))
        t.onGameEvent(ev(GameEventType.TOKEN_HOME))
        t.onGameEvent(ev(GameEventType.LADDER_TRIGGERED, value = 30))
        t.onGameEvent(ev(GameEventType.SNAKE_TRIGGERED, value = 12))
        t.onGameEvent(ev(GameEventType.ARROW_TRIGGERED))
        assertEquals(1, t.diceRolls)
        assertEquals(2, t.captures)
        assertEquals(1, t.tokensHome)
        assertEquals(1, t.ladderTriggers)
        assertEquals(1, t.snakeTriggers)
        assertEquals(1, t.arrowTriggers)
        assertEquals(GameMode.QUICK, t.mode)
    }

    @Test
    fun `the tracker ignores what everybody else did`() {
        val t = tracker()
        t.onGameEvent(ev(GameEventType.MATCH_STARTED))
        t.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, local = false, count = 4))
        t.onGameEvent(ev(GameEventType.TOKEN_HOME, local = false))
        t.onGameEvent(ev(GameEventType.DICE_ROLLED, local = false))
        assertEquals(0, t.captures)
        assertEquals(0, t.tokensHome)
        assertEquals(0, t.diceRolls)
    }

    @Test
    fun `starting a match clears the last one`() {
        val t = tracker()
        t.onGameEvent(ev(GameEventType.MATCH_STARTED))
        t.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 3))
        t.onGameEvent(ev(GameEventType.MATCH_COMPLETED))
        t.onGameEvent(ev(GameEventType.MATCH_STARTED))
        assertEquals(0, t.captures)
        assertFalse(t.completed)
    }

    @Test
    fun `a match is only completed once`() {
        val t = tracker()
        clock = 1_000L
        t.onGameEvent(ev(GameEventType.MATCH_STARTED))
        clock = 5_000L
        t.onGameEvent(ev(GameEventType.MATCH_COMPLETED))
        val first = t.durationMs
        clock = 90_000L
        t.onGameEvent(ev(GameEventType.MATCH_COMPLETED))
        assertEquals("a second completion must not stretch the match", first, t.durationMs)
        assertEquals(4_000L, first)
    }

    @Test
    fun `duration is never negative, even before a match starts`() {
        val t = tracker()
        assertEquals(0L, t.durationMs)
    }

    // -------------------------------------------------------- epic moments

    @Test
    fun `a double capture is an epic moment`() {
        val epic = EpicMomentDetector()
        epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 2))
        assertTrue(epic.moments.any { it.type == EpicMomentType.DOUBLE_CAPTURE })
    }

    @Test
    fun `a single capture is not`() {
        val epic = EpicMomentDetector()
        epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 1))
        assertTrue(epic.moments.isEmpty())
    }

    @Test
    fun `the third piece home is an epic moment, counted across moves`() {
        val epic = EpicMomentDetector()
        repeat(2) { epic.onGameEvent(ev(GameEventType.TOKEN_HOME)) }
        assertTrue(epic.moments.isEmpty())
        epic.onGameEvent(ev(GameEventType.TOKEN_HOME))
        assertTrue(epic.moments.any { it.type == EpicMomentType.THREE_TOKENS_HOME })
    }

    @Test
    fun `each moment fires at most once in a match`() {
        val epic = EpicMomentDetector()
        repeat(5) { epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 3)) }
        assertEquals(1, epic.moments.count { it.type == EpicMomentType.DOUBLE_CAPTURE })
    }

    @Test
    fun `a big ladder is a moment and a small one is not`() {
        val small = EpicMomentDetector()
        small.onGameEvent(ev(GameEventType.LADDER_TRIGGERED, value = 6))
        assertTrue(small.moments.isEmpty())

        val big = EpicMomentDetector()
        big.onGameEvent(ev(GameEventType.LADDER_TRIGGERED, value = 34))
        assertTrue(big.moments.any { it.type == EpicMomentType.LADDER_CLIMB })
    }

    @Test
    fun `winning on the last roll in hand is a last-move win`() {
        val epic = EpicMomentDetector()
        epic.noteRollsLeftOnWin(0)
        epic.onGameEvent(ev(GameEventType.MATCH_WON))
        assertTrue(epic.moments.any { it.type == EpicMomentType.LAST_MOVE_WIN })
    }

    @Test
    fun `winning with rolls still in hand is not`() {
        val epic = EpicMomentDetector()
        epic.noteRollsLeftOnWin(2)
        epic.onGameEvent(ev(GameEventType.MATCH_WON))
        assertTrue(epic.moments.none { it.type == EpicMomentType.LAST_MOVE_WIN })
    }

    @Test
    fun `being bitten by a snake and winning anyway is a snake save`() {
        val epic = EpicMomentDetector()
        epic.noteRollsLeftOnWin(1)
        epic.onGameEvent(ev(GameEventType.SNAKE_TRIGGERED, value = 20))
        epic.onGameEvent(ev(GameEventType.MATCH_WON))
        assertTrue(epic.moments.any { it.type == EpicMomentType.SNAKE_SAVE })
    }

    @Test
    fun `a snake with no win is not a save`() {
        val epic = EpicMomentDetector()
        epic.onGameEvent(ev(GameEventType.SNAKE_TRIGGERED, value = 20))
        assertTrue(epic.moments.none { it.type == EpicMomentType.SNAKE_SAVE })
    }

    @Test
    fun `a fifth win in a row is an epic moment`() {
        val epic = EpicMomentDetector()
        epic.streakIfWon = 5
        epic.noteRollsLeftOnWin(1)
        epic.onGameEvent(ev(GameEventType.MATCH_WON))
        assertTrue(epic.moments.any { it.type == EpicMomentType.FIVE_WIN_STREAK })
    }

    @Test
    fun `a computer's brilliance is not your epic moment`() {
        val epic = EpicMomentDetector()
        epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, local = false, count = 3))
        epic.onGameEvent(ev(GameEventType.LADDER_TRIGGERED, local = false, value = 40))
        assertTrue(epic.moments.isEmpty())
    }

    @Test
    fun `resetting clears the match`() {
        val epic = EpicMomentDetector()
        epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 2))
        assertTrue(epic.moments.isNotEmpty())
        epic.reset()
        assertTrue(epic.moments.isEmpty())
        epic.onGameEvent(ev(GameEventType.TOKEN_CAPTURED, count = 2))
        assertEquals(1, epic.moments.size)
    }

    // ------------------------------------------------------------- summary

    @Test
    fun `the match length reads as minutes and seconds`() {
        assertEquals("4:12", summaryOf(252_000L).durationText())
        assertEquals("0:07", summaryOf(7_000L).durationText())
        assertEquals("12:00", summaryOf(720_000L).durationText())
    }

    private fun summaryOf(durationMs: Long) = MatchSummary(
        matchId = "m", mode = GameMode.CLASSIC, players = 2, teamMode = false,
        winnerName = "You", winnerIsLocal = true, durationMs = durationMs,
        captures = 0, tokensHome = 0, diceRolls = 0,
        snakeTriggers = 0, ladderTriggers = 0, arrowTriggers = 0,
        xpEarned = 0, coinsEarned = 0, xpBefore = 0, xpAfter = 0,
        levelBefore = 1, levelAfter = 1, winStreak = 0, bestStreak = 0,
        leaguePointsBefore = 0, leaguePointsAfter = 0,
        leagueBefore = League.BRONZE, leagueAfter = League.BRONZE,
        epicMoments = emptyList(), missionsCompleted = emptyList(), unlocked = emptyList()
    )

    @Test
    fun `a level up and a promotion are reported when they happen`() {
        val plain = summaryOf(1000L)
        assertFalse(plain.leveledUp)
        assertFalse(plain.promoted)
        assertTrue(plain.copy(levelAfter = 2).leveledUp)
        assertTrue(plain.copy(leagueAfter = League.SILVER).promoted)
    }
}
