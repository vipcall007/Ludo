package com.example.ludoroyale.progression

import com.example.ludoroyale.model.GameMode
import com.example.ludoroyale.online.LeaderboardScope
import com.example.ludoroyale.online.NotConnected
import com.example.ludoroyale.online.PrivateRoom
import com.example.ludoroyale.online.Reaction
import com.example.ludoroyale.online.ReactionService
import com.example.ludoroyale.online.ReactionThrottle
import com.example.ludoroyale.online.RematchState
import com.example.ludoroyale.online.ServiceState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Leagues, seasons, and the parts that need a server.
 *
 * The league tests are about a promise to the player: one bad evening should
 * not undo a month. The online tests are about a promise to myself — that
 * nothing in this build quietly pretends to be connected.
 */
class LeagueTest {

    @Test
    fun `a new player starts in bronze`() {
        assertEquals(League.BRONZE, LeagueRules.leagueFor(0))
    }

    @Test
    fun `each league begins exactly at its own threshold`() {
        for (league in League.entries) {
            assertEquals(league, LeagueRules.leagueFor(league.minPoints))
            if (league.minPoints > 0) {
                val below = LeagueRules.leagueFor(league.minPoints - 1)
                assertTrue("${league.display} starts too early", below.ordinal < league.ordinal)
            }
        }
    }

    @Test
    fun `the thresholds climb`() {
        var last = -1
        for (league in League.entries) {
            assertTrue("${league.display} does not climb", league.minPoints > last)
            last = league.minPoints
        }
    }

    @Test
    fun `winning gains points and losing costs them`() {
        val start = 500
        assertTrue(LeagueRules.pointsAfter(start, won = true, playerCount = 2) > start)
        assertTrue(LeagueRules.pointsAfter(start, won = false, playerCount = 2) < start)
    }

    @Test
    fun `a bigger table is worth more`() {
        val two = LeagueRules.pointsAfter(500, won = true, playerCount = 2)
        val four = LeagueRules.pointsAfter(500, won = true, playerCount = 4)
        assertTrue("beating three people should be worth more than beating one", four > two)
    }

    @Test
    fun `losing never drops you out of the league you reached`() {
        for (league in League.entries) {
            var points = league.minPoints
            repeat(40) { points = LeagueRules.pointsAfter(points, won = false, playerCount = 4) }
            assertEquals(
                "a losing run dropped a player out of ${league.display}",
                league, LeagueRules.leagueFor(points)
            )
        }
    }

    @Test
    fun `points never go negative`() {
        var points = 0
        repeat(50) { points = LeagueRules.pointsAfter(points, won = false, playerCount = 2) }
        assertTrue(points >= 0)
    }

    @Test
    fun `progress through a league runs from zero to one`() {
        for (league in League.entries) {
            // the top league has nothing above it, so it reads as full
            val next = league.next ?: continue
            assertEquals("${league.display} start", 0f, LeagueRules.progress(league.minPoints), 0.001f)
            assertTrue(LeagueRules.progress(next.minPoints - 1) > 0.9f)
        }
        assertEquals("the top league is full", 1f, LeagueRules.progress(League.GRAND_MASTER.minPoints), 0.001f)
        assertEquals(1f, LeagueRules.progress(99999), 0.001f)
    }

    @Test
    fun `enough wins eventually reach grand master`() {
        var points = 0
        repeat(500) { points = LeagueRules.pointsAfter(points, won = true, playerCount = 4) }
        assertEquals(League.GRAND_MASTER, LeagueRules.leagueFor(points))
    }

    // -------------------------------------------------------------- season

    @Test
    fun `seasons run back to back from the first launch`() {
        val epoch = 19000
        val first = Season.forDay(epoch, epoch)
        assertEquals(1, first.id)
        assertEquals(epoch, first.startDay)

        val second = Season.forDay(epoch + Season.LENGTH_DAYS, epoch)
        assertEquals(2, second.id)
        assertEquals("seasons must not overlap or leave a gap", first.endDay + 1, second.startDay)
    }

    @Test
    fun `a season knows whether it is running`() {
        val epoch = 19000
        val season = Season.forDay(epoch, epoch)
        assertEquals(SeasonStatus.ACTIVE, season.statusOn(epoch))
        assertEquals(SeasonStatus.ACTIVE, season.statusOn(season.endDay))
        assertEquals(SeasonStatus.ENDED, season.statusOn(season.endDay + 1))
        assertEquals(SeasonStatus.UPCOMING, season.statusOn(epoch - 1))
    }

    @Test
    fun `days left never goes negative`() {
        val season = Season.forDay(19000, 19000)
        assertEquals(0, season.daysLeftOn(season.endDay + 99))
    }

    @Test
    fun `a season reset eases points back without wiping them`() {
        val before = 3000
        val after = Season.softReset(before)
        assertTrue("a strong season should still count for something", after > 0)
        assertTrue("a season should not carry over in full", after < before)
        assertEquals(0, Season.softReset(0))
    }

    // -------------------------------------------- what needs a server

    @Test
    fun `nothing in this build claims to be connected`() {
        assertEquals(ServiceState.NEEDS_BACKEND, NotConnected.state)
    }

    @Test
    fun `no invented players are ever handed out`() {
        assertTrue(NotConnected.friends().isEmpty())
        assertTrue(NotConnected.pending().isEmpty())
        assertTrue(NotConnected.rows(LeaderboardScope.GLOBAL, 20).isEmpty())
        assertTrue(NotConnected.rows(LeaderboardScope.FRIENDS, 20).isEmpty())
        assertNull(NotConnected.myRank(LeaderboardScope.GLOBAL))
        assertNull(NotConnected.currentTournament())
    }

    @Test
    fun `a room cannot be created or joined without a server`() {
        assertTrue(NotConnected.create(GameMode.CLASSIC, 4).isFailure)
        assertTrue(NotConnected.join("123456").isFailure)
    }

    @Test
    fun `every unavailable action explains itself`() {
        val reasons = listOf(
            NotConnected.send(com.example.ludoroyale.online.AccountId("x")),
            NotConnected.setReady(true),
            NotConnected.leave(),
            NotConnected.request(),
            NotConnected.respond(true),
            NotConnected.send(Reaction.FIRE),
            NotConnected.sendText("Nice!"),
            NotConnected.join()
        )
        for (r in reasons) {
            assertNotNull(r)
            assertEquals(ServiceState.NEEDS_BACKEND, r!!.state)
            assertTrue("a reason that says nothing", r.reason.isNotBlank())
        }
    }

    @Test
    fun `no rematch is ever in flight`() {
        assertEquals(RematchState.NONE, NotConnected.rematchState())
    }

    @Test
    fun `a room code has a shape, so a bad one can be rejected early`() {
        assertTrue(PrivateRoom.isWellFormed("827491"))
        assertFalse(PrivateRoom.isWellFormed("82749"))
        assertFalse(PrivateRoom.isWellFormed("8274911"))
        assertFalse(PrivateRoom.isWellFormed("82a491"))
        assertFalse(PrivateRoom.isWellFormed(""))
    }

    // ------------------------------------------------------ reaction spam

    @Test
    fun `a reaction cannot be sent twice in a moment`() {
        var now = 0L
        val throttle = ReactionThrottle { now }
        assertTrue(throttle.maySend())
        throttle.record()
        assertFalse("a reaction button must not be holdable", throttle.maySend())
        now += ReactionService.COOLDOWN_MS
        assertTrue(throttle.maySend())
    }

    @Test
    fun `a match has a ceiling on reactions`() {
        var now = 0L
        val throttle = ReactionThrottle { now }
        repeat(ReactionService.MAX_PER_MATCH) {
            now += ReactionService.COOLDOWN_MS
            assertTrue(throttle.maySend())
            throttle.record()
        }
        now += ReactionService.COOLDOWN_MS * 100
        assertFalse("the per-match limit did not hold", throttle.maySend())
        throttle.reset()
        assertTrue("a new match should start clean", throttle.maySend())
    }

    @Test
    fun `there is a reaction for every one the brief lists`() {
        assertEquals(8, Reaction.entries.size)
        assertEquals(4, Reaction.PRESET_TEXT.size)
        assertTrue(Reaction.entries.all { it.glyph.isNotBlank() })
    }
}
