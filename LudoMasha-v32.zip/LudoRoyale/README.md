## v32 — the nine points, and one correction to v31

A NOTE ON THE VERSION NUMBER. This is versionCode 10, versionName 1.0.0. The
keystore committed in v29 is unchanged, so this one installs over v29, v30 and
v31 without uninstalling anything.

THE CLOCK IS FIFTEEN SECONDS, EVERYWHERE
It already was, in both Ludo and Snakes and Ladders, and it is already drawn
the way it was asked for: a shadow that sweeps round the player's own portrait
like the hand of a watch, with a bright edge leading it. Nothing needed
changing here; it is listed so the list is complete.

EACH MODE HAS ITS OWN BOARD (point 15)
One board picture, seven lights. The alternative was seven board pictures, and
seven board pictures means seven sets of measurements: every cell position,
every yard circle, every resting slot, measured seven times and kept in step
forever. The first one to drift would put pieces in the wrong place in one mode
only, which is the kind of fault that takes a week to find. So the board and
its measurements stay single, and each mode is played under its own colour —
blue for four players, hot orange for Quick, jungle green for Snakes, purple
for Team Up, cold cyan for the computer, amber for a custom game. Two players
keeps the board exactly as painted.

Every one of those colours was laid over the real board picture and looked at
before it was written down. They are all at the same low strength, about a
seventh, because the board has to stay readable above everything else: a player
must be able to tell a green square from a yellow one at a glance, and no
amount of atmosphere is worth taking that away.

THE NUMBER CHOOSER IS SMALL, AND CLOSE IN (point 16)
It used to be chips two-thirds of a square across sitting a whole square above
the piece — a popup in all but name, covering the board at the moment the
player is trying to read it. It is now a little strip of buttons just over the
piece's head. The part you can HIT is still large: the drawn chip is 0.21 of a
square, the touch target is 0.36, because a button you can see and cannot press
is worse than a big one.

YOU CANNOT TOUCH THE BOARD OUT OF TURN (point 17)
This turned out to be a real fault rather than a tidying-up. The check that was
there asked the engine for the tapped piece's moves and got nothing back unless
the piece belonged to the player on turn. True — but while a computer is
thinking, the game is still waiting for a move, so the COMPUTER's pieces were
lit up and tappable and a person could reach in and play the computer's move
for it. The turn itself is the gate now, for lighting pieces up and for taps
alike.

A SIX AND A PIECE IN THE YARD IS NOT A QUESTION (point 18)
Tap it and it comes out. There is only one door out of the yard, so asking
"with which number?" was a popup for the sake of a popup.

BACK GOES BACK, AND ONLY THE LAST BACK CLOSES ANYTHING (point 19)
A sheet closes. A finished match goes to the lobby. A match in progress asks
first, then goes to the lobby. The setup screen goes to the lobby. Only at the
lobby itself, with nothing left to back out of, does back mean leaving — and
that asks too, because losing a lobby to a stray thumb is a poor way to end.

THE PADLOCK IS ON THE DOOR (point 20)
It used to sit inside the home column. Under the wrap rule a locked piece never
reaches the home column, so the padlock was hanging on a door nobody was
standing at. It is now on the entry square — the last square on the shared ring
before a colour turns off into its own home column, which is the square where a
locked piece is actually stopped. A locked piece does not stop there and does
not go in: it carries straight on round the ring for another lap.

SIX SECONDS BEFORE THE LOBBY (point 21)
Four counters fly in out of a starfield, the name builds itself a letter at a
time, a light runs across the gold, a crown comes down over the lot of it, and
it clears into the lobby.

It is drawn, not played. A video would have to be made at one size and then
stretched to fit every phone, it would weigh several megabytes in an app that
is mostly pictures already, and it would look soft on a tall screen. Drawn, it
is one file, it is sharp at any size, and every number in it can be changed
without re-rendering anything.

Nothing in it is a 3D engine. The counters arrive small and grow, which is
distance; they arrive squashed flat and open out, which is a disc turning to
face you; the letters swing in on their own vertical axis, narrow to wide,
which is a card being turned over; and the name has ten copies of itself
stacked behind it going down and to the right, which is thickness. Four cheap
tricks, and together they are enough.

It runs on a COLD START only — not after the phone is turned sideways, and not
every time the lobby comes back — and a tap anywhere skips it. Six seconds are
a welcome the first time and a toll the twentieth.

EVERY PIECE IS DEAD CENTRE, AND THE YARDS ARE FULL (point 22)
Two faults, and the first of them was mine.

V31 SAID the counters were three-dimensional pieces standing at an angle, with
the flat top face sitting high in the picture, and pushed every one of them
down by nine hundredths of a square to compensate. That was wrong. The sprites
were measured properly this time — centre of mass, per colour — and they are
flat discs seen straight down, with their middle at 0.497 of the image. Dead
centre, to within a third of a percent. The nudge was not correcting anything.
It was the reason nothing on the board looked quite square in its cell, and it
was the reason a crescent of grey showed above every waiting piece.

The second fault was size. Each resting circle in a yard is 0.582 of a square
across the radius; a piece was being drawn at 0.488 visible. That left a tenth
of a square of grey showing right round it — four of them, in every yard, all
the time. A waiting piece is now drawn a fifth larger than a travelling one,
because the circle it is waiting in is larger than a square.

And the four slot positions in each of the four yards were measured again, by
machine rather than by eye: take the white plate in a yard, fill it, and ask
where the holes in it are. Every one of the old hand-read numbers was about
three hundredths of a square low — not enough to name, quite enough to see once
four pieces sat side by side.

THE SEVEN LOBBY CARDS ARE PICTURES
Gold frame, artwork and title plate, all drawn into one image. Nothing is laid
on top of them, because anything laid on top would cover part of a picture that
was drawn to be complete. The seventh card gets an empty half-row beside it so
it stays the same size as the other six instead of stretching to twice their
width.

WHAT IS NOT IN THIS BUILD
Point 23 — an owner's build with a live connection and unlimited credits handed
to a player by user ID — is not here, by your own instruction to leave it and
carry on with the rest. It needs a server; there is no honest way to fake it,
and a version that pretended to work would be worse than none.

STILL OUTSTANDING, AND IT IS YOURS TO DO
The developer passcode is still 741963 and it is still sitting in a public
repository, which means it is not a secret. Change it.


## v31 — the eight fixes from the screenshot

THE COUNTERS SIT ON THEIR CIRCLES NOW (point 1)
The measured slot positions were right; the COUNTER was wrong. It is drawn as a
solid disc seen at a slight angle, so its 3D base hangs below and the flat top
face — the part that should sit on the square — is above the middle of the
picture. Centring the picture on the square parked every piece high, with the
grey circle showing underneath. Measured off the sprite and fixed: the piece is
nudged down a quarter of its radius and drawn a little larger, so it covers the
circle instead of leaving a crescent.

THE AVATAR IS HALF AS BIG AGAIN (point 2)
50dp to 72dp on the board. The frame fills the view and the face sits in the
frame's opening, so both grow together — which is what "the frame should size
itself to the avatar" asks for.

And a seat with NO frame now fills its whole box instead of showing a small
face floating in an empty square. That is every opponent, so their faces are
the bigger of the two and the player's framed one is the one that looks earned.

THE DICE TURNS IN THE AIR (point 3)
It flicks through the faces as before, but it also spins: the face narrows as
it turns away and widens as it comes back, and the gaps between flicks grow so
it slows into its answer rather than stopping dead on it. The spin is wound
down to nothing on the last step, so the number the player has to read is
always square to the screen and still.

THE BORDER ROUND THE DICE IS GONE (point 4)
It was a ring in the seat's colour. Whose dice it is was already obvious from
which seat it is sitting in, so the ring was a second answer to a question
nobody was asking.

The number stamped in the corner has gone with it. That existed because the
OLD dice were photographed at an angle and were hard to count. These faces are
drawn flat and face the player, so the stamp was covering artwork to solve a
problem that no longer exists.

"HOME LOCKED - KILL 0/1" IS GONE (point 5)
The board already carries a padlock on each player's own door, which says the
same thing in the place the rule actually applies.

ROYAL GALAXY BEHIND EVERYTHING (point 6)
The old backdrop was deep blue water with bubbles in it — against a gold and
purple game it read as a fish tank. It is now a violet-to-midnight sky with a
purple nebula and a blue one, a field of 150 stars with nine bright ones, and a
gold-lipped vignette that ties it to the frames, the dice and the counters.

There were dust lanes across the middle for a while. Thin, they read as
scratches on the screen; wide, they read as soft grey bars. The two nebulae
already do that job, so they are gone — the honest fix there was to draw less,
not to draw it better.

ONLY THE PERSON PLAYING GETS THE GOOD DICE (point 7)
Every other seat rolls a plain white one. A computer rolling a Dragon Fire dice
makes the thing a player spent weeks of hard missions on look like something
anybody gets. The plain dice comes out of the RETIRED list — a real, finished
design that simply is not collectable, which is exactly what it should be.

THE ROYAL LOOK (point 8)
Every lobby card now wears the gold frame from the reference, with a pale inner
hairline; the top bar and the bottom bar are royal violet framed in the same
gold. With the galaxy behind it, the screen reads as one thing rather than as a
set of coloured buttons on blue.

  BE CLEAR ABOUT WHAT THIS IS NOT. The reference has marble pillars, hanging
  banners and burning torches. Those are painted artwork and there is no image
  generator in this session, so they are not there. What is there is the
  structure and the palette — gold frames, royal violet, a galaxy sky. If you
  want the pillars and banners, send that background as a picture the way you
  sent the board and it goes straight in.

VERIFIED
- verify.py passes.
- Every Kotlin source compiles clean against android.jar (API 33).
- 205 unit tests pass.
- The galaxy backdrop and the board with its counters were rendered and looked
  at before packaging; the counter fit was checked against four different sizes
  and offsets before one was chosen.
- The Gradle build and the APK were NOT run here: no Android SDK in this
  sandbox. GitHub Actions does that part.

## v30 — the fourteen-point list, and all the new artwork

THE ARTWORK IS IN. Forty-eight dice faces, six frames, fifteen portraits, four
counters and the board itself, all cut from the supplied sheets by scripts kept
in tools/ (extract_dice_v2.py and extract_art.py).

  THE ORIGINAL SHEETS ARE NOT IN THIS ZIP. They are twenty-three megabytes, and
  a zip that size has to be uploaded from a phone every single version. The cut
  sprites in app/src/main/res/drawable-nodpi are what the game actually uses and
  they are all here, so the build works without them. KEEP THE ORIGINAL IMAGES
  SOMEWHERE SAFE: drop them back into tools/source_art under the names the two
  scripts expect and the whole set can be cut again — different sizes, a
  different crop, a fixed face — instead of being stuck with what is here.

THE DICE PROBLEM IS ACTUALLY FIXED (points 6 and 1)
The last set were photographed as CUBES standing at an angle, so the number was
tilted away from the player. These are drawn FLAT, straight on. The number
faces you. Nothing has to be stamped on top of it any more, and the whole of
the old collection is gone.

Eight dice. One free, the other seven earned from HARD missions and nowhere
else — a new tier, offered one a day alongside the ordinary set, with targets
several times bigger. Win 6 matches. 25 captures. 40 sixes.

THE BOARD (points 8 and 14)
The supplied picture IS the board now. It is placed by its PLAY AREA rather
than by its edges: measured off the file, its 15x15 grid starts at pixel 27.5
and runs 969 pixels, and the picture is scaled and offset so that grid lands
exactly on the engine's cells. Stretching it edge to edge would have put every
piece slightly off its square.

Two things were measured rather than assumed, and both mattered:
  - The picture's layout already matched the engine exactly — green top left,
    yellow top right, red bottom left, blue bottom right, and the stars on the
    same safe cells. Nothing in the rules had to move.
  - The four resting circles inside each yard are NOT centred on the yard. A
    painted dice in one corner pushes each yard's white circle, by a different
    amount in each. The four tidy symmetrical numbers that were there before
    put every waiting piece up and to the left of its place, so all sixteen
    slots were measured off the picture one yard at a time.

The counters are the supplied crown pieces, one per colour.

A DECISION I MADE, SO IT IS NOT A SURPRISE
The nine old token SKINS changed a rim and an ornament on a piece the game no
longer draws. Keeping them would have meant a shop full of items that change
nothing. There is now one token design — the crown that is actually on the
board — and the other eight are gone.

QUICK MODE'S LOCKED LAP (points 1 and 4)
A piece that goes all the way round while its player's door is still shut is
now sent back to its own STARTING SQUARE to run the lap again. Not to base: it
does not wait for another six. The point is to send the player out to cut
somebody, not to sit them in the corner.

The padlock is on the BOARD, on the first square of each player's home column,
where the rule actually applies — not as a message somewhere else. It comes
apart when that player cuts: a flash, the shackle springing open, and sparks.
Each player has their own and opening one leaves the others shut.

A piece turned back can cut somebody on the way in, which opens its own lock.
That is covered by a test, because it is the kind of case that gets missed.

TEAM UP (points 12 and 13)
A partner who gets all four pieces home no longer drops out. They keep their
turn, and the numbers they roll move the partner's pieces. That is a real
change to the engine, which was written throughout assuming the piece being
moved belongs to whoever's turn it is — so every rule now asks the PIECE who
owns it, and there are tests pinning down that a partner's piece goes to the
partner's home and not the mover's.

And winning ends the turn at once: the banked numbers die with it, so a won
match cannot carry on being played out with what was left over.

THE SMALL FACE (point 3)
The big face in the middle of the screen is gone. A small one now pops out of
the AVATAR of whoever cut, won or opened their lock, rises and fades. It says
who did it — which in a four-handed match is most of the information — and it
never covers the board.

They are drawn, not emoji. The emoji a phone draws is the phone's, not the
game's: the same laugh is yellow and round on one handset, flat and grey on
another, and an empty box on an old one.

NO POPUPS (point 5)
Every notify() in the game ended up in one banner across the middle of the
screen. It no longer shows during a match at all. A match says what it has to
say where it happens — the lock on the door, the face from the avatar, the
numbers under the dice — and the banner is left for the menus, where a "Saved"
is useful and nothing is covered.

FRAMES AND FACES BY LEVEL (points 7, 9, 10)
Six frames, spread across the hundred levels: the plain gold band at the start,
then a crown at 5, wings at 15, and on to the laurel crown at 75. Fifteen
portraits from level 1 to level 90.

Two things had to be handled rather than just dropped in:
  - The frames' centres were solid black on the sheet, walled in by the gold so
    the background keying could not reach them. Left alone, every frame would
    have had a black square where the face goes.
  - The six frames do not have the same opening. Fitting each face to its own
    frame's window would mean earning a better frame SHRINKS your face. So one
    window is used for all six — the largest square that fits inside every one
    of them — and a better frame is showier and never smaller.

The frame sits in its own box beside the dice, so it cannot cover it (point 7).

REMOVED (points 2 and 11)
Undo is gone. Ludo Snake mode — snakes laid over the Ludo track — is gone; the
standalone 1-100 board is a different thing and stays. Its lobby card is now
CUSTOM GAME, which opens the setup screen.

SOMETHING WORTH DECIDING ON
Nothing costs coins any more: dice come from hard missions, frames and faces
from levels. Coins are now just a score. Say the word if you want something to
spend them on.

THREE NEW PRE-BUILD CHECKS
  - check_picture_files_exist: a drawable named in Kotlin but missing as a FILE
    still compiles here and only fails on a phone. Proved by deleting a
    portrait and watching it fail. It also reports art that ships but nothing
    draws, which is dead weight in an APK handed round by file.
  - check_avatar_and_frame_art now reads PictureArt instead of the old drawing
    code.
  - check_dice_pictures follows the new ids.

STILL YOURS TO DO
DevMode.PASSCODE is still 741963 and still in a public repository.

VERIFIED
- verify.py passes.
- Every Kotlin source compiles clean against android.jar (API 33).
- 205 unit tests pass, including eleven new ones for the locked lap, the team
  hand-over and the turn ending on a win. The count is down from 239 because
  the Undo, Ludo Snake and Arrow Mode tests were deleted with their features.
- The board, the yards, the dice faces, the frames, the portraits and the
  counters were rendered and looked at before packaging.
- The Gradle build and the APK were NOT run here: this sandbox has no Android
  SDK. GitHub Actions does that part.

## v29 — the seventeen-point list

THE ONE THAT MATTERS MOST: UPDATES NOW INSTALL (point 17)

This was never a versionCode problem — the versionCode was already climbing.
`gradle assembleDebug` makes a throwaway signing key in the home directory of
whatever machine it runs on, and every GitHub Actions run is a brand-new
machine. So every APK came out signed by a different key, and Android refused
each one as though it were a different app by a different developer.

There is now one fixed key, committed at app/keystore/ludomasha.jks and used by
both debug and release builds. From this build onwards a new APK installs
straight over the old one.

  YOU MUST UNINSTALL ONCE MORE FIRST. Everything you have now was signed with
  a random key, so this build cannot go over it. Remove the old Ludo Masha,
  install this one, and that is the last time you will have to do it.

  The key's password is in build.gradle.kts in plain sight, exactly as
  Android's own debug key is. That means anyone who can read the repository
  could sign an APK this phone would accept as an update. For a game passed
  round by file that is the right trade — the alternative is never being able
  to update. Before Play Store, make a fresh key and keep it off the repo.

THE DICE (points 1 and 3)
The nineteen drawn dice are gone. The twelve picture dice are the whole
collection. Their drawing code is kept in DiceSkins.RETIRED so bringing one
back is a two-line change rather than redrawing it.

On the number being hard to read: these dice are photographed as cubes standing
at an angle, so the face carrying the number is tilted away from you. Turning
the artwork to face the screen would mean drawing all seventy-two faces again
from the front, which cannot be done here. Instead the number is now STAMPED on
the dice — drawn in code, square to the screen, gold on near-black, in the
corner that is always in shadow. It is countable at a glance at any size. In
the collection the stamp is off so the artwork shows whole.

Send flat front-facing dice pictures and the pipeline in tools/extract_dice.py
will take them; that is the only real fix for the artwork itself.

THE RULES (points 2, 4, 5, 8)
- BLOCK (new): two of your own pieces on one square guard each other. An
  opponent may still land there; they simply cut nothing. Covered by ten tests,
  including that one piece alone is still cut and that your pair does not
  protect somebody else's lone piece standing on the same square.
- Extra turns and the roll-before-you-move rule were already right.
- "If only one thing can be done, do it" now lives in the engine as
  LudoEngine.forcedMove() with its own tests, instead of being worked out in
  the Activity. It used to spend a number for you when you were holding a 6 and
  a 4 and only one piece could move; now anything with two possible moves waits
  for your tap.
- Quick mode's lock was already per player. There is now a padlock that springs
  open on screen, in the colour of the player who earned it, with a metal snap
  and a rise. Two new tests pin down that one player's lock opening leaves
  everybody else's shut, and that a second cut does not replay it.

THE SEAT (points 6, 7, 16)
The avatar is square. The fifteen-second clock is drawn round the inside of
that player's OWN frame — every seat shows its own — with the number appearing
for the last five seconds. The AUTO chip now sits beside each player's dice
instead of one chip on one seat; it is hidden on computer seats, which have
nothing to hand over.

The clock's calm colour was gold, which is the colour of the Gold frame most
players wear, so a clock with plenty of time left was invisible. It is cool
white-blue now, then amber, then red.

THE COLLECTION IS EARNED, NOT BOUGHT (points 11, 12, 15)
Nothing has a price any more. There is a MISSION TRACK: the count of missions
you have ever finished only ever goes up, and twenty-seven rungs hand over
twenty-seven items — 1, 2, 3, 4, 5, 6, 8, 10 and on to 80. Your profile shows
the count, the next item and how far off it is; the collection screen shows
which rung earns each locked item instead of a bare padlock.

New frames: Emerald, Magic (which cycles its colours round the band), Flame,
Peacock, Obsidian. New faces: Sultan, Wizard, Pharaoh, Court Jester.

YOUR OWN FACE AND NAME (points 12, 14)
"My Photo" opens the phone's picture chooser, then a crop step: drag to move,
pinch to zoom, and a fixed square window so what you see is what you get. The
picture is decoded subsampled — a modern phone photograph is tens of megapixels
and decoding one whole to make a 50dp avatar is how an app dies on a cheap
handset. It is kept in this app's own private storage and never sent anywhere.

Until you pick a name you are Guest####, drawn once and then kept so your name
does not change under you between matches. Change it from your profile.

THE CUT (point 9)
A face pops up and jeers. The faces are DRAWN, not emoji: an emoji is the
phone's, not the game's, and on an older handset it comes out as an empty box.
Five of them, chosen at random.

THE ICON (point 13)
Redrawn: a gold crown over a white dice on deep royal purple, with a proper
adaptive icon for Android 8 and up so the launcher can mask it to whatever
shape it likes without cutting anything off. tools/make_icon.py draws every
size from one set of numbers, so the fourteen files can never drift apart.

WHAT I COULD NOT DO (points 10 and 13's "with AI help")
There is no image generator in this session. The royal Ludo BOARD pictures
(point 10) and AI-made token artwork (point 11) were not made. The boards and
tokens stay drawn in code. Send pictures the way you sent the dice and they
will be cut out and wired in.

TWO NEW PRE-BUILD CHECKS
- check_avatar_and_frame_art: an avatar or frame in the catalog that
  AvatarFrameView never draws is a silent fault — it comes out as the default
  face or the bronze band and nobody notices until a player asks why their
  Pharaoh looks like everyone else. Proved by adding a frame and watching it
  fail.
- check_cosmetic_art now understands a RETIRED list, and was proved to still
  catch a live design that has no catalog entry.
- check_imports no longer reads class names out of comments.

STILL YOURS TO DO
DevMode.PASSCODE is still 741963 and still in a public repository.

VERIFIED
- verify.py passes.
- Every Kotlin source compiles clean against android.jar (API 33).
- 227 unit tests pass, up from 182.
- The Gradle build and the APK were NOT run here: this sandbox cannot reach
  dl.google.com, so there is no Android SDK. GitHub Actions does that part.

## v28 — three ways into the test panel, not one

The hidden seven-tap gesture did not work in practice, so guessing at why was
the wrong move. There are now three separate ways in, and the build number is
shown in the app so "it is not working" can be told apart from "the new APK
did not install".

WAY 1 — A PLAIN BUTTON (use this one)
    MORE  ->  TEST PANEL (owner)  ->  enter the code
No gesture, no timing, nothing to get right. It still asks for the code, so a
player who taps it gets nowhere.

WAY 2 — THE HIDDEN TAPS, now actually hittable
The target used to be the level line alone: an 11sp strip of text, which is a
hard thing to hit seven times in a row. It is now the WHOLE block — your name,
the level line and the XP bar together. It also counts out loud: from the
fourth tap it says "4 more", "3 more" and so on, so a tap that registered can
be told from one that missed.

WAY 3 — THE NAME BOX
If everything else somehow fails, the name box definitely works.
    SETTINGS  ->  Your name  ->  type the code  ->  SAVE
The panel opens and the code is NOT saved as your name.

CHECK WHICH BUILD YOU ARE ON
    MORE  ->  ABOUT  ->  Build
It reads the version straight out of the installed package. If it does not say
0.6.0 (6), the new APK has not installed and nothing else in this list will
work yet.

THE CODE IS STILL 741963 AND STILL NEEDS CHANGING
DevMode.kt, one line. It is in a public repository.

VERIFIED
- verify.py passes; every Kotlin source compiles clean; 182 tests pass.

## v27 — the owner's test panel

A hidden panel that only the owner can reach, for testing the parts of the
game that would otherwise take several hundred matches to see.

HOW TO GET IN
Tap the level line in the lobby (the "Level 1 · BEGINNER · BRONZE" text under
your name) SEVEN times quickly, then enter the code. After that it opens on a
single tap of the same line until you lock it again.

THE CODE IS IN DevMode.kt AND MUST BE CHANGED
    const val PASSCODE = "741963"
That value is sitting in a public repository, so treat it as already known
until you replace it. One line, one file.

WHAT THE PANEL DOES
- +10,000 / +100,000 coins, +5,000 / +50,000 XP, or set coins to 999,999
- jump straight to level 5, 10, 20, 30, 50 or 100
- unlock every cosmetic in the catalog at once
- make today's daily chest collectable again, as often as needed
- finish today's missions so they are ready to collect
- set the league to any tier, or set the streak to 4 so the next win shows
  the five-win banner
- WIPE THE SAVE — the only way to test what a brand-new player sees is to be
  one. It clears everything and rebuilds the file, but leaves the panel
  unlocked so you are not shut out of the thing that caused it.
- lock the panel again

WHAT IT DELIBERATELY CANNOT DO
Nothing in it touches the dice, the rules or the board. It can give coins, XP,
levels and cosmetics, and it can wipe the save. That is the whole list. There
is no switch anywhere in this game that changes how the dice falls, and this
was not the place to add the first one.

BEING STRAIGHT ABOUT THE LOCK
A passcode compiled into an APK is not a secret from a determined person:
anyone who unpacks the file can read it. It is enough to stop an ordinary
player stumbling in, which is what it is for, but it is not security. The only
way to make it genuinely unavailable in a published build is to not ship it:
    const val ENABLED = false
in DevMode.kt. It is a compile-time constant, so the code behind it is dropped
from the build entirely — no taps, no prompt, no way in.

VERIFIED
- verify.py passes.
- Every Kotlin source compiles clean against android.jar (API 33).
- 182 unit tests pass — twelve new ones on the lock itself: the wrong code
  never opens it, idle tapping over two hundred taps never opens it, a pause
  mid-run abandons the run, and the code is not one anybody would guess first.

## v26 — twelve picture dice

Twelve new dice, built from the artwork supplied: Gift Box, Burning Heart,
Ghost Charm, Robo, Alien, Starburst, Cosmos, Eight Ball, Wyrm, Ruby Crown,
The King, King & Queen. The collection is now 31 dice.

A DIFFERENT KIND OF DICE
Every dice before these was drawn in code from a handful of colours. These are
rendered isometric cubes, so they are pictures. That is a real change of
approach and it is worth being clear about the trade:

  drawn      costs nothing to ship, razor sharp at any size, re-coloured by
             editing one line — but it can only ever be gradients and pips
  picture    can show a dragon, a face, real metal — but it ships as files and
             is only as sharp as the file

Neither is better, so the game keeps both. [DiceView] decides which path to
take from the id alone, and nothing else in the game knows or cares which kind
of dice is in play.

HOW THE SPRITES WERE MADE
tools/extract_dice.py, kept in the repo so this is repeatable. Each sheet is a
3x2 grid of cubes showing 1..6. For every cube it:
  - drops the black backdrop by flooding inwards FROM THE BORDER. Keying out
    "everything dark" would have punched holes through the dice that genuinely
    have black faces.
  - trims the mirrored reflection off the four that were rendered on a polished
    floor. Over the game's background that reflection read as the dice leaking,
    and it pushed the cube off centre.
  - crops to what is left, pads back to a square so all six faces line up, and
    writes a 220px WebP.

All 72 sprites together come to 1.8 MB.

VERIFIED
- verify.py passes, with a new check that every picture dice has an id in the
  catalog, six entries in the face table and six files on disk. Confirmed it
  catches a deleted face — that is the kind of fault that shows up as a blank
  square for exactly one number and survives a whole game unnoticed.
- Fixed the R stub generator, which only scanned two drawable folders and so
  could not see the new one. It now globs drawable* the way aapt does.
- Every Kotlin source compiles clean against android.jar (API 33).
- 170 unit tests pass.
- The dice were rendered at the size the customize screen shows them.

FAIRNESS, unchanged
A dice skin is a picture. It is not visible to DiceRoller, so every one of
these rolls from exactly the same distribution as the free one.

WHERE THE ARTWORK CAME FROM
These images were supplied rather than made here, and I have no way to check
their origin. They carry no logo, brand or recognisable character, so nothing
about them looks like anyone else's property — but if they came from a stock
pack or a marketplace rather than being generated, the licence needs to allow
shipping them in an app before this is published.

## v25 — Arrow out, the Snakes board reworked, menus in the game's own skin

ARROW MODE
Gone from the lobby. The rules, the board markings and the eleven tests that
cover them are all still in the code and still pass — the mode simply has no
card any more, so nothing can start one. Deleting working, tested code to hide
a menu entry would have been the wrong trade. Its daily mission went too, since
it had become impossible to finish.

THE 1-100 BOARD
- Snakes are much slimmer (0.22 of a square at the thickest, down from 0.30)
  and far calmer: one or two long curves instead of a concertina. That zigzag
  was most of what made the old ones read as worms rather than animals.
- Ladders are slimmer to match, with the timber scaled down with them.
- Counters are smaller, sit dead centre of their square, and wear a gold
  crown collar — eight small points around a lit ring.
- The number moved into the corner of the square and shrank, so the counter
  has the middle to itself.
- NOTHING TOUCHES ANYTHING. The tables were regenerated by a search
  (scratchpad/layout2.py) that rebuilds the actual drawn outline of every
  snake and ladder and measures the real clearance between every pair. Worst
  case: Easy 0.82, Medium 0.65, Hard 0.50 of a square. verify.py now repeats
  that measurement on every build, so a hand edit or a width change cannot
  quietly put two shapes back on top of each other.

NEW RULES ON THAT BOARD
- A counter needs a 6 or a 1 to leave the start pad, and the number rolled is
  the square it starts on.
- Landing on another counter does nothing. They share the square. The printed
  game has no capture rule, and adding one punishes whoever is in front.
- A snake bites the instant the counter lands — the strike sound plays with no
  pause first — and then the counter is carried down the snake's own painted
  body to the tail. A ladder climbs straight away. Both are under a second now;
  the slide used to take nearly four.

MENUS
Every dialog in the game is now built from the same SheetPanel as the rest of
the screens: the three-line menu, HOW TO PLAY, ABOUT, and the "this needs a
server" notices. They wear the same gold-on-navy and the same close button.
They used to be Android system dialogs, which looked borrowed from another app.

NO MORE POPUPS
There is not a single Android toast left in the app. The three-sixes message is
gone entirely — the sound and the turn moving on say it. Everything else worth
saying goes through the game's own ribbon, which is part of the board, fades on
its own and never blocks a tap. The "roll a 6 or a 1" hint sits on the status
line under the board, where the player is already looking.

CLOCK AND AUTO
The turn clock is fifteen seconds. AUTO is now a small chip tucked under your
own avatar rather than a large button at the top of the board — it is about
your turns, so that is where it belongs, and it leaves the board clear.

SOUNDS
- New dice roll. A dice thrown on a board is one hard first strike, then a few
  bounces that get closer together and quieter as it loses energy, then it
  stops. The gap between bounces now shrinks by a fixed factor each time, which
  is what makes it sound thrown rather than shaken.
- New turn-change sound: two low notes, slow and soft, played only when the
  turn actually moves to a different player. Rolling again on a six is the same
  player's turn and stays silent.
- New snake bite: a rising hiss into the strike, then the weight of it landing.

VERIFIED
- verify.py passes, with a new check that proves no two shapes on the 1-100
  board touch. Confirmed it catches a deliberately overlapping snake.
- Every Kotlin source compiles clean against android.jar (API 33).
- 170 unit tests pass, including new ones for the entry roll and for a whole
  game never knocking anybody back.
- The three boards were rendered and looked at.

STILL NOT POSSIBLE
Online play. It needs a server, an account system and networking code, none of
which can be built from here. The models and screens are ready for it.

## v24 — progression, rewards, customization and the social boundary

Built in the order the brief sets out, stage by stage, with the compiler and
the tests run after each one. Nothing from the earlier phases was removed: the
three modes, the ten-second clock, Auto Play, Undo, the arrow board and the
1-100 board all work exactly as they did.

ONE CONFLICT, RESOLVED BY KEEPING BOTH
The brief says LUDO SNAKE must NOT be a standalone Snake & Ladder game. An
earlier instruction in this project said the opposite, and the standalone
1-100 board was built and reviewed on that basis. Rather than delete work that
was asked for, both now exist as separate modes: SNAKES & LADDERS is the
standalone 1-100 board, and LUDO SNAKE is the Ludo track with snakes and
ladders laid over it, on the original 3/6, 6/6, 8/5 tables, which were still
in the code and still passing their tests.

STAGE A — PROGRESSION CORE
`progression/Progression.kt` holds the whole curve: 100 levels, a cost per
level that rises steadily, and the seven milestone titles at exactly the
levels the brief names. `MatchRewards` holds every number a match can pay.
Both are plain Kotlin with no Android in them, which is what lets them be
unit-tested properly.

STAGE B — EVENTS AND THE MATCH SUMMARY
`GameEventBus` carries eleven event types. `MatchStatsTracker`, `MissionBook`
and `EpicMomentDetector` all listen; none of them reads the engine, so none of
them can disagree with it. `MatchSummary` is produced once per match and is
the single thing the victory screen, the share card and the statistics quote.

The engine itself was NOT changed. It already returns a full result for every
move; the activity translates that into events. That keeps the rules code
free of any knowledge of rewards, which is the point.

STAGE C — MISSIONS AND THE DAILY CYCLE
Four missions a day, drawn from a pool by a generator seeded on the day, so
the same day always produces the same four — closing the game cannot reroll a
hard set into an easy one. The seven-day login cycle gives coins, a dice, a
token, a frame, coins, a victory effect, and a chest on day seven. Claiming
writes the claim down BEFORE it pays, so an interrupted claim cannot become a
free second one.

STAGE D — WIN STREAK AND EPIC MOMENTS
The streak is persistent, resets on a loss, and is counted from the one place
a match can be banked. Six Epic Moments, each a checkable fact rather than a
judgement, each firing at most once a match.

STAGE E/F — COSMETICS
One catalog holds every collectable: 9 token skins, 19 dice, 6 avatars, 7
frames, 4 victory effects. It owns ids, rarity, prices and unlock method; the
drawing files hold only colours. A CUSTOMIZE screen shows all five types with
live previews drawn by the same code the game uses.

STAGE G — THE THREE SNAKE WORLDS
ROYAL GARDEN, DARK JUNGLE and DANGEROUS ROYAL TEMPLE, in `snl/SnlTheme.kt`.
A theme is paint and nothing else: same squares, same snakes, same odds. Hard
looks dangerous because it HAS eight snakes, not because its paint is darker.

STAGE H/I — VICTORY AND SHARING
The win screen now shows XP, coins, the level and league bars moving, the
match's own statistics, Epic Moments, missions finished and anything unlocked.
SHARE builds a card from the summary and hands it to the system share sheet
through a FileProvider limited to one folder in the app's own cache.

STAGE J — WHAT NEEDS A SERVER
`online/Online.kt` models friends, leaderboards, private rooms, rematch,
reactions and tournaments — and implements all of them once, as `NotConnected`,
which reports NEEDS_BACKEND and returns nothing. The screens are built and say
plainly what is missing. No invented players appear anywhere.

FAIRNESS, MADE MECHANICAL
`verify.py` now fails the build if anything in `engine/`, `ai/` or `model/`
imports the progression or cosmetics packages. A level cannot reach the dice
because the compiler will not let it.

VERIFIED
- `verify.py` passes, including three new checks: engine purity, catalog-versus-
  artwork agreement, and theme readability (tile contrast and number contrast).
- Every Kotlin source compiles clean against android.jar (API 33).
- 165 unit tests pass, up from 64.
- The three snake worlds were rendered and looked at.

NOT DONE, AND WHY
Real friends, a global leaderboard, private rooms, matchmaking, synchronised
reactions, authoritative seasons and tournaments all need an account system and
a server. None of them is faked.

## v23 — Undo and the daily chest

Two things from the screenshots that can be built without a server, plus the
checker fix that fell out of building them.

UNDO
A new UNDO button on the table, next to AUTO. It takes back the last move you
played by hand, and with it anything the computer did afterwards — those moves
only happened because of yours. Up to twelve moves back.

What it deliberately does NOT do is re-roll. The board is photographed AFTER
the dice has been rolled and its value is already on the table, so undo lets
you change WHICH piece you moved; it can never buy anyone a better number.
Undoing a capture also un-counts the kill.

The button is hidden in SNAKES & LADDERS. On the 1-100 board the dice decides
the whole move, so there is no choice to take back — an undo there would just
be a second roll wearing a disguise. It is also off once someone has won.

How it works: `engine/GameSnapshot.kt`. The engine mutates the game state in
place, which is fast but means a move cannot be reversed by arithmetic — a
capture, a home entry and a turn change all land at once. So instead of trying
to invert a move, the game keeps a full frozen copy of the state from just
before the piece was committed and puts that copy back.

DAILY CHEST
A chest in the lobby top bar, glowing with a red dot while today's is still
waiting. Opening it pays coins: 50 on day one, then 60, 75, 90, 110, 140 and
200 on day seven, after which the run starts again. Miss a day and it goes
back to day one. The panel shows all seven days with today lit up.

All of it is local — the phone's own clock and its own saved file. There is no
account, no server and nothing to buy. The chest art is drawn in code like the
rest of the game (`ChestView.kt`), so it adds no files to the APK.

ALSO
- Two new sounds, synthesised like all the others: a short step-back for undo,
  and a lid-and-coins sound for the chest. Still no background music.
- HOW TO PLAY now explains undo and the chest.
- `verify.py`: the duplicate-declaration check was reading a data class's
  constructor parameters as class members, so two small data classes in one
  file that each carried a `val id` looked like a clash. It now tracks bracket
  and brace depth and only counts real body members. Confirmed it still catches
  a genuine duplicate.

VERIFIED
- `verify.py` — all pre-build checks pass.
- Every Kotlin source compiles clean against android.jar (API 33).
- 64 unit tests pass, including six new ones in `UndoTest` that check a
  snapshot copies rather than aliases, that restoring puts an ordinary move,
  a capture and the quick-mode home unlock back exactly, and that a stack of
  twenty-five snapshots rewinds a whole run of play move by move.

## Phase 2A fix — duplicate string resource

BUILD FAILURE: `mergeDebugResources` — "Found item String/mode_snakes more
than one time". `strings.xml` defined `mode_snakes` twice: once for the mode
card, and again inside the block of strings I had added for the standalone
Snakes game before that game was removed. Kept the first, removed the second.

Also removed ten strings left orphaned when the standalone game was deleted
(`snakes_tap_dice`, `snakes_turn`, `snakes_ladder`, `snakes_snake`,
`snakes_six`, `snakes_overshoot`, `snakes_won`, `snakes_winner`, `opt_music`,
`rolls_label`) — each verified unreferenced before deletion.

WHY IT SLIPPED THROUGH: my pre-build sweep checked for resources that were
MISSING, never for resources defined TWICE, so a duplicate looked fine.
Added `verify.py` at the project root — a single script that checks every
class of error that has actually broken this project's builds:

  - duplicate resource names (this bug)
  - duplicate Kotlin declarations (the previous bug)
  - missing strings / colors / drawables / mipmaps
  - R.id used in code but absent from every layout
  - missing Android imports
  - unbalanced braces
  - custom views in XML with no matching class
  - manifest activities with no matching class
  - malformed XML

Verified the script by re-introducing the duplicate: it fails with exit code 1
and names the offending resource, then passes again once removed. Run
`python3 verify.py` before packaging.

## Phase 2A — build fix + Ludo Snake Mode completed

PART 1 — BUILD FIX: `MainActivity` had `cardSnakes` and `labelSnakes` declared
and assigned twice (my own error from the previous round), which Kotlin
rejects as conflicting declarations. Removed only the accidental second copy
of each; all Snake Mode functionality kept.

PART 2-4 — LUDO SNAKE MODE stays what it should be: the normal Ludo board,
route, tokens, dice and turn system, with snakes and ladders as shortcuts on
that route. Counts verified against the spec by parsing the config:
EASY 3 snakes (2 small, 1 very large) / 6 ladders (1 VL, 2 M, 3 S);
MEDIUM 6 small / 6 small; HARD 8 mixed / 5 ladders (1 VL, 2 M, 2 S).
Triggers are exact-landing only: the engine tests the square a dice move
FINISHED on, so passing over a head or foot can never fire it.

PART 5/8/9 — ANIMATION, WITHOUT DUPLICATING LOGIC: the engine now reports
`specialFromSteps` / `specialToSteps` alongside `special`, so the UI animates
what the engine already decided instead of re-deriving shortcut rules.
Sequence: hop to the trigger -> 220ms pause -> pulsing halo on the head/foot
-> the piece rides the shape (ladders climb with a slight rise, snakes follow
the drawn wave) -> captures resolve -> normal turn flow. Added `snakeSlide()`
(falling swoop) and `ladderClimb()` (rising run) to SoundFx.

PART 10 — the stale "race to square 100" hint is gone; it now reads
"Classic Ludo with special Snakes & Ladders shortcuts on the route!".
A project-wide grep confirms no 1-100 wording remains.

PART 11 — the snake difficulty selector is now its own control, visible only
when LUDO SNAKE is selected, instead of borrowing the bot-difficulty radios.

PART 14 — new `LudoSnakeModeTest` (17 tests): the six count assertions, size
composition, board safety, snakes-go-back/ladders-go-forward, exact-landing
for both, passing-over for both, no shortcut in Classic, and Snake Mode still
needing a six to leave base and four tokens home to win.

## Round 16 — Snakes & Ladders added, music wired, duplicates cleaned

SNAKES & LADDERS as a third mode, in its own screen:
- `snakes/SnakesEngine.kt` — classic 100-square board with the standard ladder
  and snake map, must land on 100 exactly (an overshoot doesn't move), a six
  earns another roll, first to 100 wins.
- `snakes/SnakesBoardView.kt` — 10x10 boustrophedon grid with numbers, drawn
  ladders (two rails + rungs) and drawn snakes (wavy body, head with eyes),
  shaded 3D pieces that fan out when they share a square, and animation that
  walks the piece square by square then glides it up a ladder or down a snake.
- `snakes/SnakesActivity.kt` — tap-to-roll, computer players take their own
  turns, menu, and the same confetti win screen as Ludo.
- Reached from a third SNAKES card on the setup screen; it carries over the
  player count, typed names, bot setting and difficulty.

MUSIC: there was already a synthesised looping background bed inside SoundFx
from an earlier round — I had started writing a second one. Deleted my
duplicate and wired the new music button to the existing implementation, with
a ♫ / ♫̸ toggle beside the sound button.

TWO CLEANUPS FOUND BY VERIFICATION, BOTH MY OWN MISTAKES:
- An earlier round had already created a Snakes attempt in the root and engine
  packages whose layout ids no longer existed, so it was dead code that would
  have failed to compile against the new layout. Deleted those four files;
  a grep confirms nothing references them.
- My own edit to insert the SNAKES card had removed the mode-hint line and the
  2/3/4 player pills from the layout, which would have crashed `findViewById`
  at startup. Restored them.

## Round 15 — Arrow Mode replaced by Quick Mode

ARROW MODE FULLY REMOVED: `ArrowConfig.kt`, `ArrowModeTest.kt`, the arrow
fields on `Move`/`MoveResult`, the arrow branch in `applyMove`, every arrow
renderer, the glow/slide animation, the `arrowMode` flag, the arrow icon, the
arrow strings and the arrow card. Verified by a project-wide grep — nothing
arrow-related is left except the board's own centre arrowheads, which are
part of the artwork.

QUICK MODE, built from the supplied spec:
- Two pieces per player start ACTIVE on their own starting square, no six
  needed; the other two wait in base and still need a six (sections 2, 10, 11).
- HOME starts LOCKED. The finishing move is simply never offered while
  `hasCapturedOpponent` is false, which is the cleanest way to satisfy
  sections 5 and 14 — a piece may travel and may sit in its home lane, it just
  cannot complete.
- A legal capture sets `hasCapturedOpponent = true` permanently (section 6),
  and being captured later never resets it (section 20).
- A safe square captures nothing, so it unlocks nothing (section 7).
- Win is 1 kill + 1 token home, checked after every move and ending the match
  at once (sections 3, 12, 18). Classic still needs all four home.
- Status strip shows "HOME LOCKED · KILL 0/1" then "HOME UNLOCKED · KILL 1/1",
  with a brief "HOME UNLOCKED!" pulse (~1.3s) on the unlocking capture
  (sections 15, 16), and the win banner gains "Quick Mode Victory" (section 17).
- AI (section 22): while HOME is locked a capture is worth more than twice its
  normal score, so the computer actively hunts the kill it needs. It still
  only ever picks from the same legal-move list a human sees.

TESTS: new `QuickModeTest` covering the locked/unlocked finishing move, the
capture unlocking HOME, the unlock surviving a later capture, safe squares not
unlocking, 1-kill-plus-1-home winning immediately, classic still needing four,
the 2-active/2-base start, and base pieces still needing a six.

STILL OUTSTANDING: Snakes & Ladders as a separate mode, and background music
(needs a real audio file).

## Round 14 — Arrow Mode built to the written specification

Implemented the supplied Arrow Mode spec exactly, replacing the previous
guesswork (and the 12-arrow version from the round before).

EXACTLY 8 GAMEPLAY ARROWS — one STRAIGHT and one HOME per colour. New
`engine/ArrowConfig.kt` holds every position in one place, with nothing
hard-coded into UI or engine code, so entries/exits can be retuned freely.

COLOUR OWNERSHIP IS STRUCTURAL: arrow positions are expressed in the owning
colour's OWN step numbers, so a red token's step 22 is a physically different
square from a green token's step 22. Red literally cannot reach green's arrow
— it is not a check that can be forgotten, it falls out of the addressing.
On top of that, `acceptsToken` also requires the right token state:
STRAIGHT needs ACTIVE, HOME needs HOME_LANE.

MOVEMENT ORDER per section 7: dice move first, THEN the arrow check on the
square the move ended on, THEN captures at the FINAL destination, then home,
then turn rules. Captures were previously resolved before the arrow, which
was wrong.

LANDING IS EXACT: the arrow is only ever tested against the square a move
finished on, so passing over an entry can never fire it.

NO CHAINING: at most one activation per move, and a test asserts no arrow's
exit is another arrow's entry for the same colour.

SIX RULE: the arrow no longer grants a roll of its own and no longer cancels
the extra roll a six earned — it is part of the same move, per section 9.
(This reverses the "arrow forces an immediate re-roll" behaviour from the
earlier round, because the written spec overrides it.)

ANIMATION per section 12: token settles, 200ms pause, the arrow glows, then a
single smooth ~500ms slide to the exit.

VISUALS per section 13: glow pass, drop shadow, metallic body, bright core and
an entry knob, all tinted to the owning colour.

TESTS per section 16: new `ArrowModeTest` covering all eight arrows existing,
colour ownership both ways, state requirements, passing-vs-landing, no extra
dice cost, no chaining, capture judged at the arrow exit, the six keeping its
extra roll, and arrows never pushing a token off its valid path. The
configuration was also simulated independently before writing the tests.

STILL OUTSTANDING: Snakes & Ladders as a separate mode, and background music
(needs a real audio file).

## Round 13 — real arrow rule, 3D pieces, new dice sound, avatars

ARROW MODE REBUILT TO THE ACTUAL RULE (researched rather than guessed):
the standard board carries 12 arrows, 3 in each colour zone; landing on an
arrow's TAIL sends the piece straight to its HEAD and grants another chance.
Implemented exactly that — 12 tails computed to sit on straight runs of the
track, none on a safe star or a colour's start square. Every tail and head is
on the SHARED outer track, so an arrow can never drop a piece into another
colour's home column (the rule the user kept stressing). Deleted the old
per-colour arrow scheme and the decorative direction marks — Classic is now a
completely clean board.

DICE SOUND: replaced again, this time plainly realistic — a few dry wooden
taps as the cube tumbles, spacing out as it slows, then one settling knock.
Noise-based knocks rather than tones, so it reads as a die rather than a beep.

3D LOOK: pieces are now lit domes — flattened contact shadow on the board, a
dark rim, a radial body gradient shaded from a top-left light, white inset
with the star, and a specular highlight. Arrows are drawn with a shadow pass
underneath so they sit above the board.

AVATARS: computer players get a robot face (visor, antenna, grille); human
players get four distinct faces with different skin, hair and shirt colours.

Palette remains red -> dark blue throughout.

STILL OUTSTANDING (not dropped): Snakes & Ladders as a separate mode, and
background music (needs a real audio file — effects are synthesised, a music
loop is not something worth synthesising).

## Round 12 — the turn rule, fair dice, cut animation, real AI difficulty

THE IMPORTANT RULE (rewritten): a cut, an arrow, or sending a piece home now
forces the SAME player to roll again IMMEDIATELY. Anything already banked
stays banked and can only be spent after that roll. Sixes keep banking and
re-rolling; on three in a row only THOSE THREE SIXES are wasted — any other
banked numbers survive and are still playable. Removed the old `bonusRolls`
mechanism, which deferred the extra roll instead of forcing it.

LUCKY DICE BUG (this is why a piece needing a 1 could sit forever): lucky mode
was max(two draws), which makes low faces nearly unreachable. It now just
raises the chance of a six. Verified by simulation — normal: every face ~16%;
lucky: six 33%, every other face still ~13%.

CUT ANIMATION: a cut piece now races back along its own path to its base slot
(fast, reversed) with the comic sound, instead of vanishing.

BOARD JUMPING: the banked-dice strips were `wrap_content`, so the board slid
up and down as dice appeared. Fixed at 34dp.

ARROWS: direction marks restored at exactly the circled positions — a U-turn
curling into each colour's home column, a diagonal arrow pointing in toward
the centre, and triple chevrons before the home turn.

AI: rewritten with genuinely different levels. Easy plays mostly at random
like a child; Medium is sensible but slips; Hard evaluates danger both ways —
it runs threatened pieces out of reach, refuses to park in front of an enemy,
prefers safe squares and pushes for home. It still only ever picks from the
same legal-move list a human sees.

WIN SCREEN: replaced the plain dialog with a full celebration — falling
confetti, the winner's name, and PLAY AGAIN / GO TO HOME.

SOUND: on/off button on the game screen.

Palette moved to red -> dark blue as asked.

STILL TO DO (told the user, not dropped): Snakes & Ladders as a separate game
mode, and real background music (needs an actual audio file — the current
effects are synthesised, but a music loop is not something to synthesise).

## Round 11 — bot actually plays, arrows cut back, dice rattle rewritten

1+5. ARROWS: `drawDirectionMarks` was drawing U-turns, chevrons and home-entry
   arrows on EVERY board including Classic, and arrow mode added ten shortcuts
   per colour on top — the board was unreadable. Deleted the decorative marks
   entirely (Classic now has zero arrows) and cut arrow mode to TWO shortcuts
   per colour plus the home-run arrow.
2. DICE SOUND: the old one played after the die had already landed. Rewritten
   as a tumble across a hard surface — many sharp clicks that start fast and
   thin out as the die slows, ending in a settling knock — and it now starts
   AT the roll, with the reveal animation lengthened to 700ms to match.
3. BOT BUG (the real one): `maybeRunBot()` was defined but NEVER CALLED — an
   earlier patch targeted a version of `render()` that no longer existed, so it
   silently did nothing and the computer just sat there. Now called at the end
   of every render, and `maybeAutoPlay` hands straight over to the bot on a
   bot's turn so the "let the human choose" guard can't stall it.
4. ARROW RE-ROLL: riding an arrow now forces the SAME player to roll again
   immediately, and anything already banked stays banked to be spent after.
   (Cuts and finishes still bank their bonus for after the current values.)
6. Palette moved off the flat blue to deep plum/near-black with warm gold
   edges and a warm pool of light behind the board.

## Round 10 — build fix (missing imports)

BUILD FIX: `MainActivity.kt:58` — "Unresolved reference: RadioGroup", and the
knock-on "Not enough information to infer type variable T" at line 93 (the
`findViewById` whose target type couldn't be resolved). When the mode radio
buttons were replaced with cards and pills a few rounds back, the
`android.widget.RadioGroup` import was dropped — then the bot-difficulty radio
group reintroduced the type without the import coming back. Added it, plus
`android.widget.Toast` (which was being used fully-qualified).

Added an import checker that walks every Kotlin file, finds Android
widget/graphics/media types used in the body, and reports any that are neither
imported, fully qualified, nor declared in the project. Only false positive
was a ToneGenerator mention inside a comment.

## Round 9 — build fix + classic arrow styling

BUILD FIX: `LudoBoard.kt:51` — "Variable 'HOME_RUN_ARROW_END' must be
initialized". `ARROW_PAIRS`' initializer referenced `HOME_RUN_ARROW_START/END`
that were declared *below* it in the same object, and Kotlin initialises
object properties in declaration order. Moved both constants above their
first use. Also added a scan over every object/class for the same
forward-reference pattern; nothing else hits it.

ARROW STYLING (matching the reference board): direction marks are now drawn
in the classic thin grey style instead of bold shapes —
- a rounded U-turn curve at each of the four outer tips of the track,
- triple chevrons along the straights,
- a slim arrow turning into each colour's home column.
These are always visible (they explain how the board flows), and the
ARROW-MODE shortcuts reuse the same thin chevron style, just tinted in each
colour so it stays obvious that an arrow belongs to one colour only.
Removed the old per-cell travel-arrow renderer and its paint.

## Round 8 — computer opponent, fair dice, colour-locked arrows

1. COMPUTER OPPONENT: setup now has "Play against the computer" plus
   Easy / Medium / Hard. Player 1 stays you; the rest are driven by the
   existing LudoAI, which only ever picks from the same legal-move list a
   human would see. `maybeRunBot()` takes the bot's turn after a short pause
   so it reads naturally.
2. DICE SOUND: the roll is now a real rattle — bursts of low-passed noise
   spaced further apart as the die loses energy, ending in a landing knock —
   instead of a beep.
4. FAIR DICE (default on): each player draws from their OWN shuffled bag of
   1..6; a face leaves the bag when drawn and the bag reshuffles when empty.
   Over each set of six rolls every player gets exactly the same faces, so
   nobody sits there getting nothing while someone else keeps rolling sixes —
   but the order stays random, so a roll still feels like a roll. It balances
   luck between players; it does not favour anyone.
5. Movement was already a continuous glide; removed the per-square tick sound
   that still made it *feel* step-by-step.
7. ARROWS REBUILT, COLOUR-LOCKED: arrows are now defined in each colour's OWN
   step numbers rather than on the shared ring. That structurally guarantees
   the rule that was emphasised — a red piece can only ever be carried along
   red's route, never into green's or anyone else's home. Drawn per colour in
   that colour's tint.
   Layout implemented from the description: an arrow runs 4->5, then the next
   starts 4 after the previous ended (9->10, 14->15 ... 44->45), and a final
   arrow at 48 carries the piece into its own home column landing on 52, so a
   5 finishes it. THIS GEOMETRY IS A BEST-GUESS FROM THE DESCRIPTION and was
   flagged to the user for correction.

## Round 7 — thin arrows, smooth glide, bonus rolls, drawn golden dice

ARROWS: redrawn as a thin pencil-line stroke with a small open arrowhead and
a tail tick, instead of the heavy orange band.

BONUS ROLLS (the real fix): cutting a piece, riding an arrow, or getting a
piece home now all earn ANOTHER roll — but the bonus is STORED, not taken
immediately. Any values already banked are spent first; only when nothing is
left to play does the same player roll again. GameState gained `bonusRolls`
and the engine a `takeBonusOrAdvance()` step. Previously the extra turn was
only granted when the bank happened to be empty, so banked values could be
silently thrown away.

MOVEMENT: pieces now glide continuously along the real path (turning corners
correctly) instead of teleporting square to square. `glide()` interpolates
between cell centres at ~110ms per square, with a soft tick as each square is
crossed.

DICE: reverted to a drawn face — the cropped photo parts looked wrong at
small sizes. Same clean shape as before, but golden: warm gold gradient body,
bright inner bevel, deep gold border, glossy sheen, and black pips with a
specular dot. Crisp at any size, no bitmaps.

BACKGROUND: the XML layer-list wasn't rendering, so the backdrop is now a
custom `GameBackgroundView` drawn in code — blue-violet gradient, a warm pool
of light behind the board, faint scattered pips, corner vignette. Added to
both the game and splash screens.

SOUND: notes can now slide in pitch. A cut plays a comic falling
"wah-wah-wahhh"; a win plays a longer rising celebration fanfare.

## Round 6 — golden dice, fixed arrows, on-board number chips, game background

1. DICE: replaced the drawn dice with the golden artwork the user supplied.
   Sliced the 3x2 sheet into six faces (dice_1..dice_6 at 192px), and DiceView
   now renders the matching image, desaturating it off-turn and drawing a thin
   ring in the owner's colour.
2. ARROWS FIXED: the real bug was WHERE they sat, not how they were drawn.
   The old indices (4, 17, 30, 43) fall on corners of the track, so a straight
   shaft from start to landing cell cut diagonally across the board. Checked
   every ring index for a straight 3-cell run and moved the arrows to
   1, 12, 20, 32 (landing on 4, 15, 23, 35) — all straight, and none landing
   on a safe star or a colour's start cell.
3/5. BACKGROUND: game and splash now use layered gradients (night-blue base,
   warm radial glow behind the board, corner vignette) instead of a flat
   colour. Board frame reworked too: drop shadow, two-tone wood, thin gold
   inner edge, softer off-white playfield.
4. "Give how many?" dialog is gone. Tapping a piece now floats small gold
   number chips directly over that piece; tapping a chip plays that value.
   Chips flip below the piece when it sits near the top edge, and clear
   themselves whenever the turn moves on.

## Round 5 — build fix + real artwork icon

BUILD FIX: `LudoBoardView.onTouchEvent` failed to compile —
"Smart cast to 'Token' is impossible, because 'best' is a local variable
captured by a changing closure". The `var best` was written inside a
`forEachIndexed` lambda and then dereferenced afterwards, which Kotlin will
not smart-cast. Copied it into a local `val chosen` before use.

ICON: replaced the hand-drawn vector logo with the artwork the user supplied.
Generated proper launcher PNGs at every density (mdpi 48 -> xxxhdpi 192,
plus round variants) and a 512px copy used on the splash and setup screens.
Deleted the old adaptive-icon XML and vector foreground/background, which
would otherwise have overridden the PNG on Android 8+.

## Round 4 — arrows, sound, per-player rolls, pick-your-points

1. Arrow markers redrawn as a real arrow that spans the cells it covers:
   shaft starts on the arrow's own cell, head sits on the exact cell the piece
   lands on. No more guessing where it goes.
8. Arrow jump shortened from 6 cells to 3 — the piece stops on the arrow's
   TIP instead of skipping a whole side of the board.
2. Sound rewritten from scratch: ToneGenerator was silent on some phones, so
   SoundFx now synthesises sine tones into an AudioTrack (still no audio files
   bundled, nothing copied). Game-start flourish now actually plays, along
   with dice, step, cut, magic, three-six buzzer and win fanfare.
3. Banked rolls now appear UNDER each player's own avatar, not in a shared
   tray in the middle.
4. Tapping a piece asks "Give how many?" and lists the banked values that can
   move it, each labelled with what it would do (cuts / comes out / goes home).
5. It auto-plays only when there is genuinely nothing to decide (one piece and
   one value). As soon as a six is banked next to another number, or several
   pieces are out, the choice comes back to the player.
6. The current player's movable pieces gently pulse (grow/shrink) so it is
   obvious which pieces are theirs and which can actually move.
7. Stacked pieces are fanned out and shrunk to fit instead of being replaced
   by a number badge — you can literally count the pieces on the square.

## Round 3 — banked rolls, magic arrows, team turn order

1. Setup screen restyled to match the reference: selectable Classic / Arrow
   mode cards with icons, player-count pills, name fields, teams + lucky
   toggles, big gold START.
2. ARROW MODE redesigned: bolder orange arrow markers, and landing on one now
   makes the piece VANISH and REAPPEAR at the arrow's end (fade out / fade in)
   with a sparkle sound, instead of walking the gap. Same player rolls again.
3. Game-start flourish sound added. Logo and launcher icon redrawn (crown +
   gold ring + four-quadrant board + big dice).
4. Team mode now uses the SAME clockwise turn order as classic
   (Red -> Green -> Yellow -> Blue), which naturally alternates A, B, A, B.
   Team is shown as a separate label, not jammed into the name.
5+6. Rolls are now BANKED, not spent immediately:
   - a six banks the value and forces another roll (the six is not used yet)
   - three sixes in a row burn the turn and every banked value
   - when rolling stops, banked values appear in a tray under the board; the
     player taps WHICH value to spend, then which piece to spend it on, and
     repeats until all values are used. Works with a single piece too.
7. Home pieces sit closer together (tight 2x2 in each yard circle).
8. Piles are now unmistakable: stacked pieces are drawn stepped behind the
   front one AND carry a numbered badge; two colours on one safe cell sit
   side by side.

Engine note: GameState now carries `pendingRolls`, and Move carries the
`usedRoll` it spends, so the same rules drive UI, future AI and any future
server without special-casing.

## Round 2 — "Ludo Masha" rebrand + modes (14 of the 20 requests)
Done this round:
1. Animated splash: logo scales/spins in, title + tagline fade up, then the
   game opens (view animation, not a video file — costs no APK size).
2. New premium app icon + logo (gold badge, four ludo quadrants, dice, crown).
3. Home pieces now sit as a neat centred 2x2 in each yard (the old slots were
   off-centre, which is why they looked scattered).
4. Player name entry for each seat on the setup screen.
6. Board vertically centred in the game screen.
7. Premium dice: gradient body, gloss highlight, player-coloured rim,
   recessed pips.
8/19. ARROW MODE as a separate mode — landing on an arrow carries the piece
   to where the arrow ends and the same player rolls again. Arrows are drawn
   on the board only in that mode.
9. TEAM MODE (2v2): Red+Yellow vs Green+Blue, partners sit opposite, you
   cannot cut your own partner, and a team wins only when both partners are
   home.
10. Active player's arrow pulses (blinks) so the turn is unmissable.
12. Removed the "tap your dice" hint line.
13. Capture now plays a comic descending slide.
14. Win plays a rising celebration fanfare + a winner dialog.
15. Menu button (top-right): Restart / New game / Close.
17. "Lucky Dice" is an explicit, labelled setting (rolls twice, keeps the
    higher face) applied identically to every player — deliberately NOT a
    hidden tilt toward anyone, so the game stays fair.

Also: single-legal-move turns now auto-play instead of forcing a pointless tap.

Deferred to the next round (told the user, not silently dropped):
- 5/11: accumulating rolls after a six and letting the player choose which
  value to use.
- 16: removing a player mid-game (and clearing their pieces).
- 18: Easy/Medium/Hard — these only mean something against AI opponents, and
  pass-n-play is all humans; needs a decision on adding AI players first.

# Ludo Royale — Phase 1 (Offline Rule Engine)

## What's actually working right now
A complete, UI-independent Ludo **rules engine** in Kotlin — the piece every other
phase (AI, local multiplayer, online sync) depends on:

- `model/` — `PlayerColor`, `Token`, `Player` (pure data, no Android deps)
- `engine/` — `LudoBoard` (52-cell track + safe cells + home stretch geometry),
  `RuleConfig` (toggleable rules: extra turn on six, 3-six forfeit, capture
  extra turn, exact-roll-to-finish, safe-cell capture blocking...),
  `DiceRoller` (SecureRandom, unbiased, never favors anyone),
  `LudoEngine` (roll → legalMoves → applyMove → turn advance / win detection)
- `ai/LudoAI.kt` — Easy (random legal move), Medium/Hard (heuristic scoring:
  captures > finishing > home-stretch entry > leaving base). The AI is only
  ever given the same `List<Move>` a human would see — it cannot cheat.
- `MainActivity.kt` — a bare, text-only screen that plays a full human-vs-AI
  game end to end through the real engine (roll, move, capture, win). This is
  **not** the premium UI from the spec — it exists to prove the engine is
  actually wired to something runnable, per "don't stop at a mockup."
- `LudoEngineTest.kt` — 6 JUnit tests covering: can't leave base without a six,
  leaving base on six, capture + extra turn, exact-roll-to-finish (overshoot
  rejected), three-consecutive-sixes forfeit, normal turn advancement.

## Getting an actual APK on your phone (no coding needed)
A `.github/workflows/build-apk.yml` file is included — it builds the APK
automatically in the cloud when you upload this project to GitHub. Steps are
in the chat reply.

## Phase 1b update — real visible board
Added: `BoardGeometry.kt` (classic 15x15 cross-board coordinate mapping),
`LudoBoardView.kt` (Canvas-drawn board: 4 colored home squares, 52-cell ring,
safe-cell markers, colored home stretches, center pinwheel, circular tokens,
tap-to-move with yellow highlight on legal tokens). `MainActivity.kt` now
wires taps on the real board to the engine instead of auto-picking moves.
Still original artwork — nothing copied from any reference app.
Not yet done: dice-roll animation, token-slide animation, sound.

## Phase 1c update — local pass-and-play (2-4 players, one phone)
Added a setup screen: pick 2, 3, or 4 players, then everyone takes turns
passing the same phone. No AI needed for this mode — Ludo has no hidden
information, so this is fair and simple. `MainActivity.kt` now creates
that many `PlayerKind.HUMAN` players and the real board drives it.
Not yet done: dice-roll animation, token-slide animation, sound,
"pass to next player" confirmation screen (optional nicety, not required).

## Phase 1d update — animation + sound
Tokens now slide (animated, ~260ms) between positions instead of jumping.
Dice shows a quick random-cycling animation before landing on the real
(already-decided) result. Added `SoundFx.kt` — short original beep tones
via Android's built-in ToneGenerator for dice/move/capture/win (no external
audio files needed, nothing copied).

## Phase 1e update — closer to a "real board" look
Added `DiceView.kt` — dice now shows real pip dots (like a physical die),
not a plain digit. Safe cells now draw as a yellow star instead of a plain
gray dot. Compared against reference screenshots the person shared —
matched the dice-face and star-cell look; didn't copy any art files
(everything above is drawn in code).

## Bugfix — MainActivity out of sync with new box-by-box board API
LudoBoardView was upgraded to move tokens box-by-box (snapToState / hopToken)
but MainActivity.kt still tried the old direct `boardView.state = ...`
assignment, which no longer compiles (state's setter is now private by
design). Rewrote MainActivity to use snapToState (initial/instant sync) and
hopToken (animated box-by-box move, then snap to the true post-move state —
this is also what naturally resets a captured token back to its base).

## Visual overhaul — matching the reference screenshots more closely
Compared my build's screenshot against the reference game's screenshots the
person shared, and closed the gaps that were actually closable in code:
- Board: wooden/orange rounded frame, white playfield, circular home yards
  (were plain white squares), gray star safe cells, white travel-direction
  chevrons on each color's entry cell.
- Tokens: styled piece (colored disc + white ring + colored star + drop
  shadow) instead of a flat circle. Stacked pieces now show a numbered
  badge, and two colors sharing a safe cell are drawn offset — so you can
  always tell how many pieces are on a square.
- Players: each player now sits at their own corner of the board with an
  avatar (color-tinted ring) + name + their OWN dice, top players rotated
  180° so they face the board — replaces the single status-text line.
- Rolling: tap your own dice to roll (no separate button); the dice shakes
  and spins through random faces before landing on the real result, with a
  green arrow marking whose turn it is and inactive dice dimmed.
- Movement: a soft step tick on each box as the piece walks.
All drawn in code; no artwork, sound, or code copied from the reference app.
Still not matched (would need an artist / real asset pipeline): painted
3D artwork, gradient backgrounds, character illustrations, animated
victory sequences, and the reference's globe/decorative path icons.

## Honest caveats
- **This was not compiled.** The sandbox that wrote this code has no network
  access, so it can't download the Android Gradle Plugin, Kotlin compiler, or
  Gradle wrapper jar to actually build/run it. Open it in Android Studio and
  hit Sync — that's the first real build/test pass. I re-read every file by
  hand for syntax/logic errors, but treat that as "should compile," not "did compile."
- **No launcher icon** — `AndroidManifest.xml` points at `@mipmap/ic_launcher`,
  which doesn't exist yet. Use Android Studio's Image Asset tool (right-click
  `res` → New → Image Asset) before your first build or it'll fail on that.
- **No gradlew wrapper jar** — Android Studio will offer to generate one on
  first open; let it.
- 4-player and 3-player games, team mode pairing, and the online-sync layer
  (server, matchmaking, reconnect) aren't built yet — the engine's `GameState`
  is already the exact object a server would serialize/broadcast, so that
  layer plugs in without changing engine logic.

## Suggested next slices (small, testable, in order)
1. Real board rendering (Canvas/Compose) + tap-to-select tokens, replacing
   the text placeholder screen — sections 7-9 of the spec.
2. Local multiplayer (3-4 players, same device, pass-and-play).
3. Coins/XP/profile persistence (Room database) + daily reward + missions.
4. Server-authoritative online play: this is the point where I'd need you to
   provide a backend target (Firebase project, or a server you control) —
   see spec section 45/46. I won't pretend one is already configured.

## Scope note on the original master prompt
The uploaded spec asks for a full commercial-grade game (online multiplayer,
matchmaking, private rooms, chat, monetization architecture, Play Store
release) — that's realistically weeks of work, not one response. I built the
foundation everything else stacks on and I'm stopping here to check in before
going further, per the spec's own "build in phases, don't dump everything
at once" instruction (section 40/45).
