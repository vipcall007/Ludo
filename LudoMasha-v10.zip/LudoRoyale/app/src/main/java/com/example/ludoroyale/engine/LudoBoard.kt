package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor

/**
 * Pure geometry of a classic Ludo board — no rendering, no Android
 * dependencies. UI layers map these indices onto screen coordinates.
 */
object LudoBoard {
    const val TRACK_LENGTH = 52          // shared outer ring, indices 0..51
    const val HOME_STRETCH_LENGTH = 6    // private final path per color, 0..5
    const val FINAL_INDEX = HOME_STRETCH_LENGTH - 1

    /** Global (0..51) cells that are safe — no captures allowed there. */
    val SAFE_CELLS: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    fun isSafeCell(globalIndex: Int): Boolean = globalIndex in SAFE_CELLS

    /** Converts a token's own relative track position to the shared global index. */
    fun toGlobalIndex(color: PlayerColor, relativeIndex: Int): Int =
        (color.startOffset + relativeIndex) % TRACK_LENGTH

    /** Steps remaining on the shared track before this color enters its home stretch. */
    fun stepsToHomeEntry(color: PlayerColor, relativeIndex: Int): Int {
        val entryRelative = ((color.homeEntryOffset - color.startOffset) + TRACK_LENGTH) % TRACK_LENGTH
        return entryRelative - relativeIndex
    }

    /**
     * ARROW MODE shortcuts, defined per colour in that colour's OWN step
     * numbers (1..57). Being relative to each colour's own route is what
     * guarantees the important rule: a red piece can only ever be carried
     * along red's path, never into another colour's home.
     */

    /** The final arrow: off the shared track and into this colour's home column. */
    const val HOME_RUN_ARROW_START = 48
    const val HOME_RUN_ARROW_END = 52     // 5 more finishes (57)

    private val ARROW_STARTS = listOf(4, 9, 14, 19, 24, 29, 34, 39, 44)

    /** Step the piece is carried to, or null if there is no arrow on [step]. */
    fun arrowTargetForStep(step: Int): Int? = when (step) {
        in ARROW_STARTS -> step + 1
        HOME_RUN_ARROW_START -> HOME_RUN_ARROW_END
        else -> null
    }

    /** All (from, to) arrows, for drawing. */
    val ARROW_PAIRS: List<Pair<Int, Int>> =
        ARROW_STARTS.map { it to it + 1 } + listOf(HOME_RUN_ARROW_START to HOME_RUN_ARROW_END)
}
