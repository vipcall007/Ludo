package com.example.ludoroyale.snl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.model.PlayerColor
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * The standalone SNAKE & LADDER board — a royal-gold 10x10 grid numbered 1..100
 * the way the printed game is, with hand-drawn 3D snakes and wooden ladders.
 *
 * The view only DRAWS and ANIMATES. Every rule lives in [SnlEngine]; this class
 * is handed a result that has already been decided and plays it back.
 */
class SnlBoardView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** One piece as the board needs to see it. */
    class Piece(val id: String, val color: PlayerColor, var cell: Int)

    var difficulty: SnakeDifficulty = SnakeDifficulty.EASY
        set(value) { field = value; rebuildSpecials(); invalidate() }

    private var pieces: List<Piece> = emptyList()

    /** Live drawing position of every piece, in (row, col) board units. */
    private val displayed = HashMap<String, Pair<Float, Float>>()

    private var glowCell: Int? = null
    private var glowPhase = 0f

    // ------------------------------------------------------------- lifecycle

    private val glowTicker = object : Runnable {
        override fun run() {
            if (glowCell == null) return
            glowPhase += 0.22f
            invalidate()
            postDelayed(this, 40)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(glowTicker)
        for (t in tickers.values) removeCallbacks(t)
        tickers.clear()
    }

    // ------------------------------------------------------------------ API

    fun setPieces(list: List<Piece>) {
        pieces = list
        for (p in list) displayed[p.id] = centerOf(p.cell)
        invalidate()
    }

    fun snapTo(list: List<Piece>) {
        pieces = list
        for (p in list) displayed[p.id] = centerOf(p.cell)
        invalidate()
    }

    fun setGlow(cell: Int?) {
        glowCell = cell
        removeCallbacks(glowTicker)
        if (cell != null) { glowPhase = 0f; post(glowTicker) }
        invalidate()
    }

    /** Walks a piece square by square, the way a hand moves a counter. */
    fun hopAlong(pieceId: String, cells: List<Int>, onComplete: () -> Unit) {
        if (cells.isEmpty()) { onComplete(); return }
        glide(pieceId, cells.map { centerOf(it) }, perLegMs = 115L, arc = 0.22f, onComplete = onComplete)
    }

    /** Slides down a snake, or climbs a ladder, in one smooth run. */
    fun rideSpecial(pieceId: String, special: SnlSpecial, onComplete: () -> Unit) {
        val drawn = drawnSpecials.firstOrNull { it.spec.id == special.id }
        val path = if (drawn != null && drawn.spec.type == SpecialType.SNAKE) {
            // follow the snake's own curve, so the piece really slides along it
            drawn.spine.map { (x, y) -> ((y - frame) / cell) to ((x - frame) / cell) }
        } else {
            listOf(centerOf(special.entryCell), centerOf(special.exitCell))
        }
        val legMs = if (special.type == SpecialType.LADDER) 70L else 34L
        glide(pieceId, path, perLegMs = legMs, arc = 0f, onComplete = onComplete)
    }

    /** Knocked back to the start pad. */
    fun sendToStart(pieceId: String, fromCell: Int, onComplete: () -> Unit) {
        glide(pieceId, listOf(centerOf(fromCell), centerOf(0)), perLegMs = 320L, arc = 0.9f, onComplete = onComplete)
    }

    // -------------------------------------------------------------- animation

    /** One ticker per piece, so two pieces can move at the same time. */
    private val tickers = HashMap<String, Runnable>()

    private fun glide(
        pieceId: String,
        path: List<Pair<Float, Float>>,
        perLegMs: Long,
        arc: Float,
        onComplete: () -> Unit
    ) {
        if (path.size < 2) {
            val only = path.lastOrNull()
            if (only != null) displayed[pieceId] = only
            invalidate(); onComplete(); return
        }
        val start = System.currentTimeMillis()
        val total = perLegMs * (path.size - 1)
        tickers.remove(pieceId)?.let { removeCallbacks(it) }
        val run = object : Runnable {
            override fun run() {
                val t = ((System.currentTimeMillis() - start).toFloat() / total).coerceIn(0f, 1f)
                val pos = t * (path.size - 1)
                val leg = pos.toInt().coerceAtMost(path.size - 2)
                val f = pos - leg
                val a = path[leg]
                val b = path[leg + 1]
                val lift = if (arc > 0f) -arc * sin(f * Math.PI).toFloat() else 0f
                displayed[pieceId] =
                    (a.first + (b.first - a.first) * f + lift) to (a.second + (b.second - a.second) * f)
                invalidate()
                if (t >= 1f) {
                    displayed[pieceId] = path.last()
                    tickers.remove(pieceId)
                    invalidate()
                    onComplete()
                } else postDelayed(this, 16)
            }
        }
        tickers[pieceId] = run
        post(run)
    }

    // -------------------------------------------------------------- geometry

    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell

    /** (row, col) centre in board units. Cell 0 is the start pad under square 1. */
    private fun centerOf(cellNo: Int): Pair<Float, Float> {
        if (cellNo <= 0) return (SnlConfig.ROWS - 0.48f) to 0.5f
        val (r, c) = SnlConfig.cellToGrid(cellNo)
        return (r + 0.5f) to (c + 0.5f)
    }

    private fun screenOf(cellNo: Int): Pair<Float, Float> {
        val (r, c) = centerOf(cellNo)
        return px(c) to py(r)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.045f
        cell = (size - 2 * frame) / SnlConfig.COLUMNS
        numberPaint.textSize = cell * 0.30f
        rebuildSpecials()
        for (p in pieces) displayed[p.id] = centerOf(p.cell)
    }

    // ---------------------------------------------------------------- paints

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun lighten(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    // ------------------------------------------------------------------ draw

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawFrame(canvas)
        drawSquares(canvas)
        drawLadders(canvas)
        drawSnakes(canvas)
        drawGlow(canvas)
        drawPieces(canvas)
    }

    /** Deep royal panel inside a polished metallic-gold border. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.05f

        shadow.alpha = 90
        canvas.drawRoundRect(RectF(3f, 7f, size, size + 4f), r, r, shadow)

        // gold border with a brushed sheen running corner to corner
        shade.shader = LinearGradient(
            0f, 0f, size, size,
            intArrayOf(
                Color.rgb(0x7A, 0x52, 0x10), Color.rgb(0xF6, 0xD9, 0x7A),
                Color.rgb(0xC9, 0x9A, 0x2E), Color.rgb(0xFF, 0xF0, 0xB8),
                Color.rgb(0x8A, 0x5F, 0x16)
            ),
            floatArrayOf(0f, 0.26f, 0.52f, 0.78f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, shade)
        shade.shader = null

        // inner bevel
        stroke.color = Color.argb(120, 0x3A, 0x26, 0x05)
        stroke.strokeWidth = frame * 0.16f
        canvas.drawRoundRect(
            RectF(frame * 0.62f, frame * 0.62f, size - frame * 0.62f, size - frame * 0.62f),
            r * 0.5f, r * 0.5f, stroke
        )

        // playfield backing
        fill.color = Color.rgb(0x16, 0x1E, 0x3E)
        canvas.drawRect(RectF(px(0f), py(0f), px(10f), py(10f)), fill)
    }

    /**
     * The 100 squares. Alternating cream and royal indigo keeps the numbers
     * readable, and each tile gets a soft bevel so the board sits raised.
     */
    private fun drawSquares(canvas: Canvas) {
        stroke.strokeCap = Paint.Cap.BUTT
        for (n in 1..SnlConfig.LAST_CELL) {
            val (row, col) = SnlConfig.cellToGrid(n)
            val left = px(col.toFloat())
            val top = py(row.toFloat())
            val rect = RectF(left, top, left + cell, top + cell)

            val cream = (row + col) % 2 == 0
            val base = if (cream) Color.rgb(0xF3, 0xE4, 0xC2) else Color.rgb(0x25, 0x31, 0x68)

            shade.shader = LinearGradient(
                left, top, left, top + cell,
                lighten(base, 0.16f), darken(base, 0.12f), Shader.TileMode.CLAMP
            )
            canvas.drawRect(rect, shade)
            shade.shader = null

            // top/left light edge, bottom/right dark edge = raised tile
            stroke.strokeWidth = cell * 0.045f
            stroke.color = Color.argb(70, 255, 255, 255)
            canvas.drawLine(left, top + stroke.strokeWidth / 2, left + cell, top + stroke.strokeWidth / 2, stroke)
            canvas.drawLine(left + stroke.strokeWidth / 2, top, left + stroke.strokeWidth / 2, top + cell, stroke)
            stroke.color = Color.argb(60, 0, 0, 0)
            canvas.drawLine(left, top + cell - stroke.strokeWidth / 2, left + cell, top + cell - stroke.strokeWidth / 2, stroke)
            canvas.drawLine(left + cell - stroke.strokeWidth / 2, top, left + cell - stroke.strokeWidth / 2, top + cell, stroke)

            // thin gold grid line
            stroke.strokeWidth = cell * 0.018f
            stroke.color = Color.argb(90, 0xD8, 0xB0, 0x55)
            canvas.drawRect(rect, stroke)

            // the number, tucked into the top-left of its square
            numberPaint.color = if (cream) Color.rgb(0x4A, 0x31, 0x0C) else Color.rgb(0xF0, 0xD2, 0x87)
            canvas.drawText(
                n.toString(),
                left + cell * 0.30f,
                top + cell * 0.32f,
                numberPaint
            )

            if (n == SnlConfig.LAST_CELL) drawCrown(canvas, left + cell * 0.62f, top + cell * 0.66f, cell * 0.26f)
            if (n == 1) drawStartArrow(canvas, left + cell * 0.66f, top + cell * 0.70f, cell * 0.20f)
        }
    }

    /** Gold crown marking square 100. */
    private fun drawCrown(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Path()
        p.moveTo(cx - r, cy + r * 0.6f)
        p.lineTo(cx - r * 0.78f, cy - r * 0.7f)
        p.lineTo(cx - r * 0.34f, cy + r * 0.05f)
        p.lineTo(cx, cy - r * 0.95f)
        p.lineTo(cx + r * 0.34f, cy + r * 0.05f)
        p.lineTo(cx + r * 0.78f, cy - r * 0.7f)
        p.lineTo(cx + r, cy + r * 0.6f)
        p.close()
        shade.shader = LinearGradient(
            cx, cy - r, cx, cy + r,
            Color.rgb(0xFF, 0xF1, 0xB4), Color.rgb(0xC8, 0x93, 0x21), Shader.TileMode.CLAMP
        )
        canvas.drawPath(p, shade)
        shade.shader = null
        stroke.strokeWidth = r * 0.14f
        stroke.color = Color.rgb(0x6B, 0x47, 0x0A)
        canvas.drawPath(p, stroke)
    }

    /** Small gold arrow on square 1 showing which way play runs. */
    private fun drawStartArrow(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Path()
        p.moveTo(cx - r, cy - r * 0.45f)
        p.lineTo(cx + r * 0.25f, cy - r * 0.45f)
        p.lineTo(cx + r * 0.25f, cy - r)
        p.lineTo(cx + r, cy)
        p.lineTo(cx + r * 0.25f, cy + r)
        p.lineTo(cx + r * 0.25f, cy + r * 0.45f)
        p.lineTo(cx - r, cy + r * 0.45f)
        p.close()
        fill.color = Color.rgb(0xE8, 0xBB, 0x4A)
        canvas.drawPath(p, fill)
    }

    // ---------------------------------------------------- snakes and ladders

    /** A special with its screen geometry worked out once per layout. */
    private class Drawn(
        val spec: SnlSpecial,
        val spine: List<Pair<Float, Float>>,
        val body: Path
    )

    private var drawnSpecials: List<Drawn> = emptyList()

    private fun rebuildSpecials() {
        if (cell <= 0f) { drawnSpecials = emptyList(); return }
        drawnSpecials = SnlConfig.specialsFor(difficulty).map { spec ->
            if (spec.type == SpecialType.SNAKE) buildSnake(spec) else buildLadder(spec)
        }
    }

    /**
     * A snake's spine: a wave running head to tail whose swing grows with the
     * snake's length, so a very large snake really coils across the board while
     * a small one is barely a kink.
     */
    private fun buildSnake(spec: SnlSpecial): Drawn {
        val (hx, hy) = screenOf(spec.entryCell)
        val (tx, ty) = screenOf(spec.exitCell)
        val dx = tx - hx
        val dy = ty - hy
        val len = hypot(dx, dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len

        val span = abs(spec.entryCell - spec.exitCell)
        val waves = when {
            span >= 40 -> 3.0f
            span >= 20 -> 2.0f
            else -> 1.5f
        }
        val amp = cell * when {
            span >= 40 -> 0.90f
            span >= 20 -> 0.72f
            else -> 0.52f
        }

        val steps = 90
        val spine = ArrayList<Pair<Float, Float>>(steps + 1)
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            // the swing fades out at both ends so head and tail sit on their squares
            val envelope = sin(t * Math.PI).toFloat()
            val off = amp * envelope * sin(t * waves * 2f * Math.PI.toFloat())
            // kept inside the playfield so no snake ever crawls onto the gold frame
            val sx = (hx + dx * t + nx * off).coerceIn(px(0.22f), px(SnlConfig.COLUMNS - 0.22f))
            val sy = (hy + dy * t + ny * off).coerceIn(py(0.22f), py(SnlConfig.ROWS - 0.22f))
            spine += sx to sy
        }
        return Drawn(spec, spine, bodyOutline(spine, cell * 0.30f, cell * 0.10f))
    }

    private fun buildLadder(spec: SnlSpecial): Drawn {
        val (fx, fy) = screenOf(spec.entryCell)
        val (tx, ty) = screenOf(spec.exitCell)
        return Drawn(spec, listOf(fx to fy, tx to ty), Path())
    }

    /** Turns a centre line into a closed outline that tapers head to tail. */
    private fun bodyOutline(spine: List<Pair<Float, Float>>, headWidth: Float, tailWidth: Float): Path {
        val left = ArrayList<Pair<Float, Float>>(spine.size)
        val right = ArrayList<Pair<Float, Float>>(spine.size)
        for (i in spine.indices) {
            val prev = spine[if (i == 0) 0 else i - 1]
            val next = spine[if (i == spine.lastIndex) i else i + 1]
            val tx = next.first - prev.first
            val ty = next.second - prev.second
            val tl = hypot(tx, ty).coerceAtLeast(0.0001f)
            val nx = -ty / tl
            val ny = tx / tl
            val t = i.toFloat() / spine.lastIndex
            val w = (headWidth + (tailWidth - headWidth) * t) / 2f
            val (x, y) = spine[i]
            left += (x + nx * w) to (y + ny * w)
            right += (x - nx * w) to (y - ny * w)
        }
        val p = Path()
        p.moveTo(left[0].first, left[0].second)
        for (i in 1 until left.size) p.lineTo(left[i].first, left[i].second)
        for (i in right.indices.reversed()) p.lineTo(right[i].first, right[i].second)
        p.close()
        return p
    }

    /** Six distinct snake skins — nothing on the board looks like its neighbour. */
    private fun snakeSkin(skin: Int): IntArray = when (skin % 6) {
        0 -> intArrayOf(Color.rgb(0x1B, 0x7A, 0x38), Color.rgb(0x7E, 0xD9, 0x56), Color.rgb(0x0C, 0x40, 0x1C)) // emerald
        1 -> intArrayOf(Color.rgb(0x9E, 0x1B, 0x20), Color.rgb(0xF2, 0x6A, 0x5C), Color.rgb(0x54, 0x0C, 0x0E)) // ruby
        2 -> intArrayOf(Color.rgb(0x4A, 0x27, 0x7E), Color.rgb(0xB3, 0x8B, 0xE8), Color.rgb(0x27, 0x12, 0x45)) // amethyst
        3 -> intArrayOf(Color.rgb(0xB8, 0x86, 0x14), Color.rgb(0xFF, 0xDE, 0x6B), Color.rgb(0x5E, 0x42, 0x05)) // gold
        4 -> intArrayOf(Color.rgb(0x0E, 0x6E, 0x7A), Color.rgb(0x5F, 0xD5, 0xE2), Color.rgb(0x06, 0x3A, 0x42)) // turquoise
        else -> intArrayOf(Color.rgb(0x2B, 0x2F, 0x38), Color.rgb(0x8A, 0x93, 0xA6), Color.rgb(0x12, 0x14, 0x19)) // charcoal
    }

    private fun drawSnakes(canvas: Canvas) {
        for (d in drawnSpecials) {
            if (d.spec.type != SpecialType.SNAKE) continue
            drawSnake(canvas, d)
        }
    }

    private fun drawSnake(canvas: Canvas, d: Drawn) {
        val skin = snakeSkin(d.spec.skin)
        val dark = skin[0]
        val light = skin[1]
        val outline = skin[2]

        // cast shadow on the board
        canvas.save()
        canvas.translate(cell * 0.09f, cell * 0.12f)
        fill.color = Color.argb(55, 0, 0, 0)
        canvas.drawPath(d.body, fill)
        canvas.restore()

        // body, lit from the top-left
        val head = d.spine.first()
        val tail = d.spine.last()
        shade.shader = LinearGradient(
            head.first, head.second, tail.first, tail.second,
            intArrayOf(light, dark, light), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(d.body, shade)
        shade.shader = null

        // scales and belly, kept inside the body
        canvas.save()
        canvas.clipPath(d.body)

        // belly highlight along the spine
        stroke.color = Color.argb(70, 255, 255, 255)
        stroke.strokeWidth = cell * 0.07f
        stroke.strokeCap = Paint.Cap.ROUND
        val belly = Path()
        belly.moveTo(d.spine[0].first, d.spine[0].second)
        for (i in 1 until d.spine.size) belly.lineTo(d.spine[i].first, d.spine[i].second)
        canvas.drawPath(belly, stroke)

        // scale bands
        stroke.color = Color.argb(95, Color.red(outline), Color.green(outline), Color.blue(outline))
        stroke.strokeWidth = cell * 0.045f
        var i = 4
        while (i < d.spine.size - 3) {
            val (x, y) = d.spine[i]
            val t = i.toFloat() / d.spine.lastIndex
            val r = cell * (0.16f - 0.06f * t)
            val a = atan2(
                d.spine[i + 1].second - d.spine[i - 1].second,
                d.spine[i + 1].first - d.spine[i - 1].first
            )
            canvas.save()
            canvas.rotate(Math.toDegrees(a.toDouble()).toFloat(), x, y)
            canvas.drawArc(RectF(x - r, y - r, x + r, y + r), -70f, 140f, false, stroke)
            canvas.restore()
            i += 5
        }
        canvas.restore()

        // crisp outline
        stroke.color = outline
        stroke.strokeWidth = cell * 0.035f
        canvas.drawPath(d.body, stroke)

        drawSnakeHead(canvas, d, dark, light, outline)
        drawSnakeTail(canvas, d, outline)
    }

    private fun drawSnakeHead(canvas: Canvas, d: Drawn, dark: Int, light: Int, outline: Int) {
        val (hx, hy) = d.spine[0]
        val (nx, ny) = d.spine[3]
        // the head points AWAY from the body, back over its own square
        val angle = Math.toDegrees(atan2((hy - ny).toDouble(), (hx - nx).toDouble())).toFloat()

        canvas.save()
        canvas.rotate(angle, hx, hy)

        val hw = cell * 0.40f   // head length
        val hh = cell * 0.31f   // head width

        // tongue, flicking out in front
        stroke.color = Color.rgb(0xD4, 0x2A, 0x3A)
        stroke.strokeWidth = cell * 0.045f
        stroke.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(hx + hw * 0.42f, hy, hx + hw * 0.92f, hy, stroke)
        canvas.drawLine(hx + hw * 0.92f, hy, hx + hw * 1.14f, hy - cell * 0.09f, stroke)
        canvas.drawLine(hx + hw * 0.92f, hy, hx + hw * 1.14f, hy + cell * 0.09f, stroke)

        // skull
        val head = RectF(hx - hw * 0.62f, hy - hh, hx + hw * 0.55f, hy + hh)
        shade.shader = RadialGradient(
            hx - hw * 0.1f, hy - hh * 0.5f, hw * 1.3f,
            intArrayOf(light, dark), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawOval(head, shade)
        shade.shader = null
        stroke.color = outline
        stroke.strokeWidth = cell * 0.035f
        canvas.drawOval(head, stroke)

        // eyes — white, gold ring, slit pupil
        val ex = hx + hw * 0.10f
        val ey = hh * 0.46f
        for (s in intArrayOf(-1, 1)) {
            val cy = hy + s * ey
            fill.color = Color.WHITE
            canvas.drawCircle(ex, cy, cell * 0.088f, fill)
            fill.color = Color.rgb(0xE8, 0xBB, 0x3A)
            canvas.drawCircle(ex, cy, cell * 0.060f, fill)
            fill.color = Color.BLACK
            canvas.drawOval(
                RectF(ex - cell * 0.016f, cy - cell * 0.050f, ex + cell * 0.016f, cy + cell * 0.050f),
                fill
            )
            fill.color = Color.argb(200, 255, 255, 255)
            canvas.drawCircle(ex - cell * 0.026f, cy - cell * 0.026f, cell * 0.018f, fill)
        }

        // nostrils
        fill.color = Color.argb(150, 0, 0, 0)
        canvas.drawCircle(hx + hw * 0.42f, hy - hh * 0.30f, cell * 0.018f, fill)
        canvas.drawCircle(hx + hw * 0.42f, hy + hh * 0.30f, cell * 0.018f, fill)

        canvas.restore()
    }

    private fun drawSnakeTail(canvas: Canvas, d: Drawn, outline: Int) {
        val (tx, ty) = d.spine.last()
        fill.color = outline
        canvas.drawCircle(tx, ty, cell * 0.048f, fill)
    }

    // ------------------------------------------------------------- ladders

    private fun drawLadders(canvas: Canvas) {
        for (d in drawnSpecials) {
            if (d.spec.type != SpecialType.LADDER) continue
            val (x0, y0) = d.spine[0]
            val (x1, y1) = d.spine[1]
            drawLadder(canvas, x0, y0, x1, y1, d.spec.skin)
        }
    }

    /**
     * A wooden ladder with round rails and rope-bound rungs. The rails carry a
     * light and a dark edge so they read as poles rather than flat lines.
     */
    private fun drawLadder(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, skin: Int) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = hypot(dx, dy).coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len
        val half = cell * 0.30f

        val wood = when (skin % 3) {
            0 -> intArrayOf(Color.rgb(0xC4, 0x8A, 0x45), Color.rgb(0xF0, 0xC5, 0x83), Color.rgb(0x6E, 0x42, 0x15))
            1 -> intArrayOf(Color.rgb(0xA9, 0x6B, 0x33), Color.rgb(0xDD, 0xAA, 0x66), Color.rgb(0x5A, 0x33, 0x0E))
            else -> intArrayOf(Color.rgb(0xD1, 0x9C, 0x55), Color.rgb(0xFA, 0xDB, 0x9C), Color.rgb(0x7C, 0x50, 0x1C))
        }

        // shadow
        canvas.save()
        canvas.translate(cell * 0.08f, cell * 0.11f)
        stroke.color = Color.argb(60, 0, 0, 0)
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeWidth = cell * 0.13f
        canvas.drawLine(x0 + nx * half, y0 + ny * half, x1 + nx * half, y1 + ny * half, stroke)
        canvas.drawLine(x0 - nx * half, y0 - ny * half, x1 - nx * half, y1 - ny * half, stroke)
        canvas.restore()

        // rungs first, so the rails sit over their ends
        val rungs = (len / (cell * 0.62f)).toInt().coerceAtLeast(3)
        for (i in 1 until rungs) {
            val t = i.toFloat() / rungs
            val rx = x0 + dx * t
            val ry = y0 + dy * t
            stroke.color = wood[2]
            stroke.strokeWidth = cell * 0.105f
            canvas.drawLine(rx + nx * half, ry + ny * half, rx - nx * half, ry - ny * half, stroke)
            stroke.color = wood[0]
            stroke.strokeWidth = cell * 0.072f
            canvas.drawLine(rx + nx * half, ry + ny * half, rx - nx * half, ry - ny * half, stroke)
            stroke.color = Color.argb(150, Color.red(wood[1]), Color.green(wood[1]), Color.blue(wood[1]))
            stroke.strokeWidth = cell * 0.026f
            canvas.drawLine(
                rx + nx * half * 0.86f, ry + ny * half * 0.86f - cell * 0.020f,
                rx - nx * half * 0.86f, ry - ny * half * 0.86f - cell * 0.020f, stroke
            )
        }

        // the two rails
        for (s in intArrayOf(-1, 1)) {
            val ax = x0 + nx * half * s
            val ay = y0 + ny * half * s
            val bx = x1 + nx * half * s
            val by = y1 + ny * half * s
            stroke.color = wood[2]
            stroke.strokeWidth = cell * 0.145f
            canvas.drawLine(ax, ay, bx, by, stroke)
            stroke.color = wood[0]
            stroke.strokeWidth = cell * 0.105f
            canvas.drawLine(ax, ay, bx, by, stroke)
            stroke.color = wood[1]
            stroke.strokeWidth = cell * 0.036f
            canvas.drawLine(
                ax - nx * cell * 0.022f, ay - ny * cell * 0.022f,
                bx - nx * cell * 0.022f, by - ny * cell * 0.022f, stroke
            )
        }
    }

    // ---------------------------------------------------------------- pieces

    private fun drawGlow(canvas: Canvas) {
        val c = glowCell ?: return
        val (cx, cy) = screenOf(c)
        val p = 0.5f + 0.5f * sin(glowPhase)
        val r = cell * (0.45f + 0.22f * p)
        fill.color = Color.argb((95 + 90 * p).toInt().coerceIn(0, 255), 0xFF, 0xE0, 0x7A)
        canvas.drawCircle(cx, cy, r, fill)
        fill.color = Color.argb((140 + 80 * p).toInt().coerceIn(0, 255), 0xFF, 0xF6, 0xD2)
        canvas.drawCircle(cx, cy, r * 0.52f, fill)
    }

    private fun drawPieces(canvas: Canvas) {
        // group pieces sharing a square so they fan out instead of hiding
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Piece>>()
        for (p in pieces) {
            val pos = displayed[p.id] ?: continue
            val key = Math.round(pos.first * 3) to Math.round(pos.second * 3)
            byCell.getOrPut(key) { mutableListOf() }.add(p)
        }
        for ((key, group) in byCell) {
            val row = key.first / 3f
            val col = key.second / 3f
            val offsets = fanOffsets(group.size)
            val shrink = when (group.size) {
                0, 1 -> 1f
                2 -> 0.82f
                3 -> 0.72f
                else -> 0.64f
            }
            group.forEachIndexed { i, piece ->
                val (ox, oy) = offsets[i]
                drawPiece(canvas, px(col) + ox * cell, py(row) + oy * cell, piece.color, shrink)
            }
        }
    }

    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.17f to 0f, 0.17f to 0f)
        3 -> listOf(0f to -0.18f, -0.18f to 0.14f, 0.18f to 0.14f)
        else -> listOf(-0.17f to -0.17f, 0.17f to -0.17f, -0.17f to 0.17f, 0.17f to 0.17f)
    }

    /** The same lit dome used on the Ludo board, so both boards feel like one game. */
    private fun drawPiece(canvas: Canvas, cx: Float, cy: Float, color: PlayerColor, scale: Float) {
        val radius = cell * 0.34f * scale
        val base = colorOf(color)

        shadow.alpha = 80
        canvas.drawOval(
            RectF(cx - radius * 0.95f, cy + radius * 0.34f, cx + radius * 0.95f, cy + radius * 1.0f),
            shadow
        )

        // gold collar keeps the piece readable on both tile colours
        fill.color = Color.rgb(0xE2, 0xB8, 0x51)
        canvas.drawCircle(cx, cy + radius * 0.05f, radius * 1.14f, fill)
        fill.color = darken(base, 0.55f)
        canvas.drawCircle(cx, cy + radius * 0.04f, radius * 1.04f, fill)

        shade.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.40f, radius * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, shade)
        shade.shader = null

        fill.color = Color.WHITE
        canvas.drawCircle(cx, cy, radius * 0.60f, fill)
        fill.color = base
        drawStar(canvas, cx, cy, radius * 0.50f)

        gloss.shader = RadialGradient(
            cx - radius * 0.34f, cy - radius * 0.46f, radius * 0.75f,
            Color.argb(140, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, gloss)
        gloss.shader = null
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val path = Path()
        val innerR = outerR * 0.45f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outerR else innerR
            val a = Math.PI / 2 * -1 + i * Math.PI / 5
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, fill)
    }
}
