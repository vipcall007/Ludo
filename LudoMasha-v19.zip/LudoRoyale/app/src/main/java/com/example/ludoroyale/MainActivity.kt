package com.example.ludoroyale

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Toast
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.engine.DiceRoller
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState
import com.example.ludoroyale.snl.SnlBoardView
import com.example.ludoroyale.snl.SnlConfig
import com.example.ludoroyale.snl.SnlEngine
import com.example.ludoroyale.snl.SnlPhase
import com.example.ludoroyale.snl.SnlPlayer
import com.example.ludoroyale.snl.SnlRules

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 *
 * Three modes share this screen:
 *  CLASSIC and QUICK play on the Ludo board,
 *  SNAKE & LADDER plays on its own 1..100 board.
 *
 * Whichever board is up, the seats, dice, ten-second turn clock and Auto Play
 * all behave the same, so the game feels like one product rather than two.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val avatar: ImageView,
        val dice: DiceView,
        val arrow: View,
        val rolls: LinearLayout,
        val timer: TurnTimerRing
    )

    private lateinit var boardView: LudoBoardView
    private lateinit var snlBoard: SnlBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var btnMenu: View
    private lateinit var btnSound: TextView
    private lateinit var btnAuto: TextView
    private lateinit var winOverlay: View
    private lateinit var winTitle: TextView
    private lateinit var quickStatus: TextView
    private lateinit var confetti: ConfettiView

    private lateinit var cardClassic: View
    private lateinit var cardQuick: View
    private lateinit var cardSnakes: View
    private lateinit var labelClassic: TextView
    private lateinit var labelQuick: TextView
    private lateinit var labelSnakes: TextView
    private lateinit var btnMusic: TextView
    private lateinit var snakeDiffRow: View
    private lateinit var snakeDiffGroup: RadioGroup
    private lateinit var modeHint: TextView
    private lateinit var pills: List<TextView>
    private lateinit var optTeams: CheckBox
    private lateinit var optLucky: CheckBox
    private lateinit var optBots: CheckBox
    private lateinit var nameFields: List<EditText>

    private var engine: LudoEngine? = null
    private var snl: SnlEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()
    private enum class Mode { CLASSIC, QUICK, SNAKES }
    private var mode = Mode.CLASSIC
    private var playerCount = 2
    private var rolling = false
    private var choiceTokenId: String? = null
    private var busy = false

    /** Auto Play: once on, it stays on until the player takes control back. */
    private var autoPlay = false
    private var turnDeadline = 0L
    private var timerKey = ""
    private var timerRunning = false

    /** Classic clockwise seating order — team mode keeps exactly this order. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
        else -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        snlBoard = findViewById(R.id.snlBoard)
        btnMenu = findViewById(R.id.btnMenu)
        btnSound = findViewById(R.id.btnSound)
        btnAuto = findViewById(R.id.btnAuto)
        winOverlay = findViewById(R.id.winOverlay)
        winTitle = findViewById(R.id.winTitle)
        quickStatus = findViewById(R.id.quickStatus)
        confetti = findViewById(R.id.confetti)

        cardClassic = findViewById(R.id.cardClassic)
        cardQuick = findViewById(R.id.cardQuick)
        cardSnakes = findViewById(R.id.cardSnakes)
        labelClassic = findViewById(R.id.labelClassic)
        labelQuick = findViewById(R.id.labelQuick)
        labelSnakes = findViewById(R.id.labelSnakes)
        btnMusic = findViewById(R.id.btnMusic)
        snakeDiffRow = findViewById(R.id.snakeDiffRow)
        snakeDiffGroup = findViewById(R.id.snakeDiffGroup)
        modeHint = findViewById(R.id.modeHint)
        optTeams = findViewById(R.id.optTeams)
        optLucky = findViewById(R.id.optLucky)
        optBots = findViewById(R.id.optBots)
        pills = listOf(findViewById(R.id.pill2), findViewById(R.id.pill3), findViewById(R.id.pill4))
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.avatarTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft), findViewById(R.id.rollsTopLeft), findViewById(R.id.timerTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.avatarTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight), findViewById(R.id.rollsTopRight), findViewById(R.id.timerTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.avatarBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft), findViewById(R.id.rollsBottomLeft), findViewById(R.id.timerBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.avatarBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight), findViewById(R.id.rollsBottomRight), findViewById(R.id.timerBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        cardClassic.setOnClickListener { selectMode(Mode.CLASSIC) }
        cardQuick.setOnClickListener { selectMode(Mode.QUICK) }
        cardSnakes.setOnClickListener { selectMode(Mode.SNAKES) }
        pills.forEachIndexed { i, pill -> pill.setOnClickListener { selectCount(i + 2) } }
        findViewById<View>(R.id.btnStart).setOnClickListener { onStartPressed() }
        btnMenu.setOnClickListener { showMenu() }
        btnSound.setOnClickListener { toggleSound() }
        btnMusic.setOnClickListener { toggleMusic() }
        btnAuto.setOnClickListener { toggleAuto() }
        findViewById<View>(R.id.btnPlayAgain).setOnClickListener { hideWin(); startGame() }
        findViewById<View>(R.id.btnGoHome).setOnClickListener { hideWin(); backToSetup() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        boardView.onChoicePicked = { value -> handleChoicePicked(value) }

        selectMode(Mode.CLASSIC)
        selectCount(2)
    }

    // ---------- setup screen ----------

    private fun selectMode(picked: Mode) {
        mode = picked
        fun style(card: View, label: TextView, on: Boolean) {
            card.setBackgroundResource(if (on) R.drawable.card_selected else R.drawable.card_normal)
            label.setTextColor(if (on) Color.rgb(0x1B, 0x25, 0x51) else Color.WHITE)
        }
        style(cardClassic, labelClassic, picked == Mode.CLASSIC)
        style(cardQuick, labelQuick, picked == Mode.QUICK)
        style(cardSnakes, labelSnakes, picked == Mode.SNAKES)

        modeHint.text = when (picked) {
            Mode.CLASSIC -> "Classic: normal Ludo rules."
            Mode.QUICK -> "Quick: one piece starts out. Cut one opponent to unlock HOME, then get one piece home to win."
            Mode.SNAKES -> "Snake & Ladder: the full 1-100 board. Climb the ladders, dodge the snakes, land exactly on 100 to win."
        }

        snakeDiffRow.visibility = if (picked == Mode.SNAKES) View.VISIBLE else View.GONE
        // teams and lucky dice belong to the Ludo modes
        optTeams.isEnabled = picked != Mode.SNAKES && playerCount == 4
        if (picked == Mode.SNAKES) optTeams.isChecked = false
    }

    private fun selectCount(count: Int) {
        playerCount = count
        pills.forEachIndexed { i, pill ->
            val on = i + 2 == count
            pill.setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
            pill.setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
        }
        val seats = seatColors(count)
        val hints = listOf("Red", "Green", "Yellow", "Blue")
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
            if (i < count) {
                val colorName = hints[PlayerColor.entries.indexOf(seats[i]).coerceIn(0, 3)]
                field.hint = "Player ${i + 1} ($colorName)"
            }
        }
        optTeams.isEnabled = mode != Mode.SNAKES && count == 4
        if (count != 4) optTeams.isChecked = false
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun chosenDifficulty(): SnakeDifficulty = when (snakeDiffGroup.checkedRadioButtonId) {
        R.id.snakeEasy -> SnakeDifficulty.EASY
        R.id.snakeHard -> SnakeDifficulty.HARD
        else -> SnakeDifficulty.MEDIUM
    }

    /** Names typed on the setup screen, falling back to sensible defaults. */
    private fun playerNames(botsOn: Boolean): List<String> =
        (0 until playerCount).map { i ->
            val typed = nameFields[i].text.toString().trim()
            when {
                typed.isNotEmpty() -> typed
                botsOn && i > 0 -> "Computer $i"
                else -> "Player ${i + 1}"
            }
        }

    // ---------- game ----------

    private fun onStartPressed() {
        startGame()
    }

    private fun startGame() {
        autoPlay = false
        stopTurnTimer()
        updateAutoButton()
        if (mode == Mode.SNAKES) startSnakeGame() else startLudoGame()
    }

    /** Everything both boards share: seats, avatars, dice colours, panels. */
    private fun showGameChrome(colors: List<PlayerColor>, names: List<String>, kinds: List<PlayerKind>, teams: List<Int>) {
        for ((color, slot) in slots) {
            val index = colors.indexOf(color)
            if (index < 0) {
                slot.root.visibility = View.INVISIBLE
                slot.timer.secondsLeft = null
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teams[index] != 0) {
                    "${names[index]}  •  Team ${if (teams[index] == 1) "A" else "B"}"
                } else names[index]
                slot.avatar.setImageResource(
                    if (kinds[index] != PlayerKind.HUMAN) R.drawable.ic_avatar_bot
                    else when (index) {
                        0 -> R.drawable.ic_avatar_p1
                        1 -> R.drawable.ic_avatar_p2
                        2 -> R.drawable.ic_avatar_p3
                        else -> R.drawable.ic_avatar_p4
                    }
                )
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.value = 1
                slot.timer.secondsLeft = null
            }
        }

        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        btnSound.visibility = View.VISIBLE
        btnMusic.visibility = View.VISIBLE
        btnAuto.visibility = View.VISIBLE
        hideWin()
        SoundFx.gameStart()
        SoundFx.startMusic()
    }

    private fun startLudoGame() {
        snl = null
        val colors = seatColors(playerCount)
        val teamsOn = optTeams.isChecked && playerCount == 4
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)

        val players = colors.mapIndexed { i, color ->
            // partners sit opposite: Red+Yellow vs Green+Blue
            val team = if (!teamsOn) 0
                       else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            // one NORMAL computer strength, as specified
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            Player.create("p${i + 1}", names[i], color, kind, team)
        }.toMutableList()

        val rules = RuleConfig(
            quickMode = mode == Mode.QUICK,
            snakeMode = false,
            teamMode = teamsOn,
            luckyDice = optLucky.isChecked
        )

        if (rules.quickMode) {
            // Spec: exactly ONE token starts on the board, no six needed for it.
            // The other three wait in base and come out on a six as normal.
            for (p in players) {
                p.tokens[0].state = TokenState.ACTIVE
                p.tokens[0].steps = 1
            }
        }

        val newEngine = LudoEngine(GameState(gameId = "pass-n-play", players = players), rules)
        engine = newEngine
        boardView.snakeDifficulty = null
        boardView.snapToState(newEngine.state)
        rolling = false
        busy = false

        boardView.visibility = View.VISIBLE
        snlBoard.visibility = View.GONE

        showGameChrome(colors, names, players.map { it.kind }, players.map { it.team })
        quickStatus.visibility = if (rules.quickMode) View.VISIBLE else View.GONE
        render()
    }

    private fun startSnakeGame() {
        engine = null
        val colors = seatColors(playerCount)
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)

        val players = colors.mapIndexed { i, color ->
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            SnlPlayer("p${i + 1}", names[i], color, kind)
        }.toMutableList()

        val difficulty = chosenDifficulty()
        val newEngine = SnlEngine(
            players,
            SnlRules(difficulty = difficulty),
            DiceRoller(lucky = optLucky.isChecked)
        )
        snl = newEngine
        rolling = false
        busy = false

        snlBoard.difficulty = difficulty
        snlBoard.setPieces(players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
        boardView.visibility = View.GONE
        snlBoard.visibility = View.VISIBLE

        showGameChrome(colors, names, players.map { it.kind }, players.map { 0 })
        quickStatus.visibility = View.VISIBLE
        quickStatus.text = getString(R.string.snl_status)
        renderSnake()
    }

    private fun toggleSound() {
        SoundFx.enabled = !SoundFx.enabled
        btnSound.text = getString(if (SoundFx.enabled) R.string.sound_on else R.string.sound_off)
        btnSound.alpha = if (SoundFx.enabled) 1f else 0.5f
    }

    override fun onResume() {
        super.onResume()
        SoundFx.resumeMusic()
    }

    override fun onPause() {
        super.onPause()
        SoundFx.pauseMusic()
        stopTurnTimer()
    }

    private var musicOn = true

    private fun toggleMusic() {
        musicOn = !musicOn
        if (musicOn) SoundFx.startMusic() else SoundFx.stopMusic()
        btnMusic.text = getString(if (musicOn) R.string.music_on else R.string.music_off)
        btnMusic.alpha = if (musicOn) 1f else 0.5f
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_new),
                    getString(R.string.menu_close),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> startGame()
                    1 -> backToSetup()
                    2 -> finish()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun backToSetup() {
        engine = null
        snl = null
        rolling = false
        busy = false
        autoPlay = false
        stopTurnTimer()
        for ((_, slot) in slots) { stopBlink(slot.arrow); slot.timer.secondsLeft = null }
        gamePanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        btnSound.visibility = View.GONE
        btnMusic.visibility = View.GONE
        btnAuto.visibility = View.GONE
        hideWin()
        setupPanel.visibility = View.VISIBLE
    }

    // ---------- the ten-second turn clock ----------

    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            val left = (turnDeadline - System.currentTimeMillis()) / 1000f
            paintTimer(left.coerceAtLeast(0f))
            if (left <= 0f) {
                timerRunning = false
                paintTimer(null)
                onTurnTimedOut()
            } else {
                boardHost().postDelayed(this, 80)
            }
        }
    }

    private fun boardHost(): View = if (mode == Mode.SNAKES) snlBoard else boardView

    /** Whose ring is lit, and how much of the ten seconds is left on it. */
    private fun paintTimer(secondsLeft: Float?) {
        val active = activeColor()
        for ((color, slot) in slots) {
            slot.timer.secondsLeft = if (secondsLeft != null && color == active) secondsLeft else null
        }
    }

    private fun stopTurnTimer() {
        timerRunning = false
        timerKey = ""
        boardHost().removeCallbacks(timerTick)
        paintTimer(null)
    }

    /**
     * Restarts the clock whenever the decision in front of the player changes —
     * a new turn, a fresh roll, one more banked value to spend.
     */
    private fun refreshTurnTimer() {
        if (!humanMustDecide()) {
            if (timerRunning || timerKey.isNotEmpty()) stopTurnTimer()
            return
        }
        val key = decisionKey()
        if (key != timerKey) {
            timerKey = key
            turnDeadline = System.currentTimeMillis() + TURN_MS
        }
        if (!timerRunning) {
            timerRunning = true
            boardHost().removeCallbacks(timerTick)
            boardHost().post(timerTick)
        }
    }

    private fun decisionKey(): String {
        val e = engine
        if (e != null) return "L${e.state.currentPlayerIndex}|${e.state.phase}|${e.state.pendingRolls.size}"
        val s = snl ?: return ""
        return "S${s.currentIndex}|${s.phase}|${s.lastRoll}"
    }

    /** True when a human, not a computer, owes the game a decision right now. */
    private fun humanMustDecide(): Boolean {
        if (busy || rolling || autoPlay) return false
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind == PlayerKind.HUMAN
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind == PlayerKind.HUMAN
    }

    private fun activeColor(): PlayerColor? {
        val e = engine
        if (e != null) return if (e.state.phase == TurnPhase.GAME_OVER) null else e.state.currentPlayer.color
        val s = snl ?: return null
        return if (s.phase == SnlPhase.GAME_OVER) null else s.current.color
    }

    /** Ten seconds gone: Auto Play takes over and stays on until TAKE CONTROL. */
    private fun onTurnTimedOut() {
        if (autoPlay) return
        autoPlay = true
        updateAutoButton()
        toast("Time up — Auto Play is on. Tap TAKE CONTROL to play yourself.")
        if (mode == Mode.SNAKES) renderSnake() else render()
    }

    private fun toggleAuto() {
        autoPlay = !autoPlay
        updateAutoButton()
        if (autoPlay) {
            stopTurnTimer()
        } else {
            // handing control back restarts the clock on the decision in hand
            timerKey = ""
        }
        if (mode == Mode.SNAKES) renderSnake() else render()
    }

    private fun updateAutoButton() {
        btnAuto.text = getString(if (autoPlay) R.string.take_control else R.string.auto_off)
        btnAuto.alpha = if (autoPlay) 1f else 0.75f
    }

    /** The seat is played for you when it is a computer, or Auto Play is on. */
    private fun automaticTurn(): Boolean {
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind != PlayerKind.HUMAN || autoPlay
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind != PlayerKind.HUMAN || autoPlay
    }

    // ---------- rolling ----------

    private fun handleRoll() {
        if (mode == Mode.SNAKES) handleSnakeRoll() else handleLudoRoll()
    }

    private fun handleLudoRoll() {
        val e = engine ?: return
        if (rolling || busy || e.state.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[e.state.currentPlayer.color] ?: return

        rolling = true
        stopTurnTimer()
        clearChoice()
        val outcome = e.rollDice()
        SoundFx.diceRoll()          // starts WITH the roll, runs under the animation
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            when {
                outcome.turnLostToThreeSixes -> {
                    SoundFx.turnLost()
                    toast("Three sixes — turn lost, all rolls wasted!")
                    render()
                }
                outcome.mustRollAgain -> {
                    // six banked; the same player must roll again
                    render()
                }
                else -> onRollingFinished()
            }
        }
    }

    /** Shake + spin so rolling actually feels like rolling. */
    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.22f).scaleY(1.22f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    /**
     * Flickers random faces, then settles on the value the engine already
     * decided. The animation only reveals the result — it never changes it.
     */
    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int, onDone: () -> Unit) {
        if (remaining <= 0) {
            dice.value = finalValue
            onDone()
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue, onDone) }, 50)
    }

    private fun onRollingFinished() {
        val e = engine ?: return
        val moves = e.legalMoves()
        if (moves.isEmpty()) {
            e.passTurn()
            render()
            return
        }
        render()
        maybeAutoPlay()
    }

    /**
     * Plays by itself only when there is genuinely nothing to decide: one
     * piece, one value. The moment there is a real choice (a six banked next
     * to another number, or several pieces out) it hands control back.
     */
    private fun maybeAutoPlay() {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return
        if (automaticTurn()) { maybeRunAutomatic(); return }
        val moves = e.legalMoves()
        val distinctValues = e.state.pendingRolls.distinct()
        val distinctTokens = moves.map { it.token.id }.distinct()
        if (moves.size == 1 || (distinctTokens.size == 1 && distinctValues.size == 1)) {
            val only = moves.first()
            boardView.postDelayed({ playMove(only) }, 260)
        }
    }

    private fun handleTokenTap(token: Token) {
        val e = engine ?: return
        if (busy || rolling || autoPlay || e.state.phase != TurnPhase.AWAITING_MOVE) return

        // which banked values can move THIS piece?
        val options = e.state.pendingRolls.distinct()
            .mapNotNull { value -> e.legalMovesFor(value).firstOrNull { it.token.id == token.id } }

        when {
            options.isEmpty() -> return
            options.size == 1 -> {
                clearChoice()
                playMove(options.first())
            }
            else -> {
                // little number chips float over the piece itself
                choiceTokenId = token.id
                boardView.showChoices(token.id, options.map { it.usedRoll })
            }
        }
    }

    /** Player tapped one of the number chips over a piece. */
    private fun handleChoicePicked(value: Int) {
        val e = engine ?: return
        val tokenId = choiceTokenId ?: return
        val move = e.legalMovesFor(value).firstOrNull { it.token.id == tokenId } ?: return
        clearChoice()
        playMove(move)
    }

    private fun clearChoice() {
        choiceTokenId = null
        boardView.clearChoices()
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        if (busy) return
        clearChoice()
        stopTurnTimer()
        busy = true
        boardView.tappableTokenIds = emptySet()

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            // remember where the victims were standing — applyMove resets them
            val victimsBefore = move.capturesTokenIds.mapNotNull { id ->
                e.state.players.flatMap { p -> p.tokens.map { p to it } }
                    .firstOrNull { it.second.id == id }
                    ?.let { (owner, tok) -> Triple(tok.id, tok.color, tok.steps to owner.tokens.indexOf(tok)) }
            }

            val result = e.applyMove(move)

            val settle = {
                boardView.snapToState(e.state)
                when {
                    result.gameWon -> SoundFx.win()
                    else -> SoundFx.tokenMove()
                }
                busy = false
                render()
                maybeAutoPlay()
            }

            val afterCaptures = {
                if (victimsBefore.isNotEmpty()) {
                    SoundFx.capture()
                    var pending = victimsBefore.size
                    for ((id, color, info) in victimsBefore) {
                        val (steps, slot) = info
                        boardView.flyHome(id, color, steps, slot) {
                            pending--
                            if (pending == 0) settle()
                        }
                    }
                } else settle()
            }

            if (result.unlockedHome) {
                SoundFx.magic()
                showUnlockBanner()
            }

            afterCaptures()
        }
    }

    /** "HOME UNLOCKED!" — brief, doesn't hold the game up. */
    private fun showUnlockBanner() {
        quickStatus.text = getString(R.string.quick_unlock_toast)
        quickStatus.scaleX = 0.8f
        quickStatus.scaleY = 0.8f
        quickStatus.animate().scaleX(1.12f).scaleY(1.12f).setDuration(220)
            .withEndAction { quickStatus.animate().scaleX(1f).scaleY(1f).setDuration(200).start() }
            .start()
        quickStatus.postDelayed({ refreshQuickStatus() }, 1300)
    }

    /** Lock/unlock line for the player whose turn it is. */
    private fun refreshQuickStatus() {
        val e = engine ?: return
        if (quickStatus.visibility != View.VISIBLE) return
        val p = if (e.state.phase == TurnPhase.GAME_OVER) e.state.players.firstOrNull()
                else e.state.currentPlayer
        quickStatus.text = getString(
            if (p?.hasCapturedOpponent == true) R.string.quick_unlocked else R.string.quick_locked
        )
    }

    // ---------- computer players and Auto Play ----------

    /** Let the computer — or Auto Play — take the turn, with a readable pause. */
    private fun maybeRunAutomatic() {
        if (!automaticTurn() || busy || rolling) return
        val e = engine ?: return

        when (e.state.phase) {
            TurnPhase.AWAITING_ROLL -> boardView.postDelayed({
                if (automaticTurn() && !busy && !rolling) handleLudoRoll()
            }, 650)

            TurnPhase.AWAITING_MOVE -> boardView.postDelayed({
                if (!automaticTurn() || busy || rolling) return@postDelayed
                val moves = e.legalMoves()
                if (moves.isEmpty()) {
                    e.passTurn()
                    render()
                } else {
                    // Auto Play uses the very same decision logic as the computer,
                    // and only ever sees information a player could see.
                    playMove(
                        LudoAI.chooseMove(
                            PlayerKind.AI_MEDIUM, moves, e.state,
                            needsKill = e.rules.quickMode && !e.state.currentPlayer.hasCapturedOpponent
                        )
                    )
                }
            }, 600)

            TurnPhase.GAME_OVER -> Unit
        }
    }

    private fun render() {
        val e = engine ?: return
        val s = e.state
        val gameOver = s.phase == TurnPhase.GAME_OVER
        val active = if (gameOver) null else s.currentPlayer.color

        // every piece any banked value can move is tappable (and pulses)
        boardView.tappableTokenIds =
            if (!busy && !rolling && !autoPlay && s.phase == TurnPhase.AWAITING_MOVE)
                e.legalMoves().map { it.token.id }.toSet()
            else emptySet()

        paintSeats(active, s.phase == TurnPhase.AWAITING_ROLL)
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            renderRollsFor(color, slot, color == active)
        }

        val last = s.lastDiceRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        refreshQuickStatus()
        refreshTurnTimer()
        if (gameOver) {
            val champion = s.players.firstOrNull { it.id == s.rankings.firstOrNull() }
            announceWinner(
                champion?.let { it.displayName to it.team },
                showSubtitle = e.rules.quickMode
            )
        } else {
            maybeRunAutomatic()
        }
    }

    /** Highlight, dim and enable seats — identical on both boards. */
    private fun paintSeats(active: PlayerColor?, canRoll: Boolean) {
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == active
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable = isActive && !busy && !rolling && canRoll && !autoPlay

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }
        }
    }

    /** Banked values shown as small dice right under that player's own avatar. */
    private fun renderRollsFor(color: PlayerColor, slot: Slot, isActive: Boolean) {
        slot.rolls.removeAllViews()
        val e = engine ?: return
        if (!isActive) return
        val rolls = e.state.pendingRolls
        if (rolls.isEmpty()) return

        val size = (30 * resources.displayMetrics.density).toInt()
        val gap = (3 * resources.displayMetrics.density).toInt()
        rolls.forEach { value ->
            val chip = DiceView(this)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginStart = gap
            lp.marginEnd = gap
            chip.layoutParams = lp
            chip.value = value
            chip.accent = uiColor(color)
            chip.isClickable = false
            slot.rolls.addView(chip)
        }
    }

    // ---------- SNAKE & LADDER ----------

    private fun handleSnakeRoll() {
        val s = snl ?: return
        if (rolling || busy || s.phase != SnlPhase.AWAITING_ROLL) return
        val slot = slots[s.current.color] ?: return

        rolling = true
        stopTurnTimer()
        val outcome = s.rollDice()
        SoundFx.diceRoll()
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            if (outcome.turnLostToThreeSixes) {
                SoundFx.turnLost()
                toast("Three sixes — turn lost!")
                renderSnake()
            } else {
                playSnakeMove(outcome.value)
            }
        }
    }

    /**
     * Plays back one dice move on the 1..100 board. The engine has already
     * decided everything — walk, shortcut, knock-back, win — so this only
     * animates the result in the order the rules call for.
     */
    private fun playSnakeMove(value: Int) {
        val s = snl ?: return
        if (busy) return
        busy = true

        val from = s.current.cell
        val result = s.resolve(value)

        val settle = {
            snlBoard.snapTo(s.players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
            busy = false
            renderSnake()
        }

        val afterCuts = {
            if (result.cutPlayerIds.isEmpty()) {
                if (result.won) SoundFx.win() else SoundFx.tokenMove()
                settle()
            } else {
                SoundFx.capture()
                toast(getString(R.string.snl_cut))
                var pending = result.cutPlayerIds.size
                for (id in result.cutPlayerIds) {
                    snlBoard.sendToStart(id, result.finalCell) {
                        pending--
                        if (pending == 0) settle()
                    }
                }
            }
        }

        if (result.blocked) {
            toast(getString(R.string.snl_blocked))
            settle()
            return
        }

        snlBoard.hopAlong(result.playerId, s.walkPath(from, result.landedCell)) {
            val special = result.special
            if (special != null) {
                val isLadder = special.type == SpecialType.LADDER
                snlBoard.setGlow(special.entryCell)
                snlBoard.postDelayed({
                    if (isLadder) SoundFx.ladderClimb() else SoundFx.snakeSlide()
                    snlBoard.rideSpecial(result.playerId, special) {
                        snlBoard.setGlow(null)
                        afterCuts()
                    }
                }, SPECIAL_PAUSE_MS)
            } else {
                afterCuts()
            }
        }
    }

    private fun renderSnake() {
        val s = snl ?: return
        val gameOver = s.phase == SnlPhase.GAME_OVER
        val active = if (gameOver) null else s.current.color

        paintSeats(active, s.phase == SnlPhase.AWAITING_ROLL)
        for ((_, slot) in slots) slot.rolls.removeAllViews()

        val last = s.lastRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        if (!gameOver) {
            val p = s.current
            quickStatus.text = if (p.cell == 0) getString(R.string.snl_status)
                               else "${p.displayName} · ${p.cell} / ${SnlConfig.LAST_CELL}"
        }

        refreshTurnTimer()
        if (gameOver) {
            val winner = s.players.firstOrNull { it.id == s.winnerId }
            announceWinner(winner?.let { it.displayName to 0 }, showSubtitle = true, snake = true)
        } else {
            maybeRunAutomaticSnake()
        }
    }

    private fun maybeRunAutomaticSnake() {
        if (!automaticTurn() || busy || rolling) return
        val s = snl ?: return
        if (s.phase != SnlPhase.AWAITING_ROLL) return
        snlBoard.postDelayed({
            if (automaticTurn() && !busy && !rolling) handleSnakeRoll()
        }, 650)
    }

    // ---------- shared chrome ----------

    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun announceWinner(winner: Pair<String, Int>?, showSubtitle: Boolean, snake: Boolean = false) {
        if (winOverlay.visibility == View.VISIBLE) return
        if (winner == null) return
        stopTurnTimer()
        val (name, team) = winner
        winTitle.text = if (team != 0) "Team ${if (team == 1) "A" else "B"} wins!" else "$name wins!"
        if (showSubtitle) {
            val subtitle = getString(if (snake) R.string.snl_victory else R.string.quick_victory)
            winTitle.text = "${winTitle.text}\n$subtitle"
        }
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.animate().alpha(1f).setDuration(320).start()
        confetti.start()
    }

    private fun hideWin() {
        confetti.stop()
        winOverlay.visibility = View.GONE
    }

    private companion object {
        /** Beat before a snake or ladder fires, so the landing reads first. */
        const val SPECIAL_PAUSE_MS = 220L
        const val BLINKING = "blinking"
        /** Every human decision is on a ten-second clock. */
        const val TURN_MS = 10_000L
    }
}
