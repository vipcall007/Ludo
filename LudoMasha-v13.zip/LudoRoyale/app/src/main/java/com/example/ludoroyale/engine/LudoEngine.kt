package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState

/**
 * Deterministic, UI-independent Ludo rules engine.
 *
 * Turn shape (matches how people actually play):
 *  - Tap dice. A six banks the value and you MUST roll again — the six is not
 *    spent yet.
 *  - Three sixes in a row loses the whole turn and every banked value.
 *  - A non-six ends the rolling phase. You then spend the banked values one at
 *    a time, choosing for EACH value which piece moves it.
 *  - Cutting an opponent (or riding an arrow) earns another roll.
 */
class LudoEngine(
    val state: GameState,
    val rules: RuleConfig = RuleConfig(),
    private val dice: DiceRoller = DiceRoller(lucky = rules.luckyDice)
) {

    /** Rolls for the current player and banks the value. */
    fun rollDice(): RollOutcome {
        check(state.phase == TurnPhase.AWAITING_ROLL) { "Not awaiting a roll." }
        val value = dice.roll(state.currentPlayer.id)
        state.lastDiceRoll = value

        if (value == 6) {
            state.consecutiveSixes++
            if (rules.threeSixCancelsTurn && state.consecutiveSixes >= 3) {
                // Only the three sixes are wasted. Anything else already banked
                // stays and can still be played this turn.
                var toDrop = 3
                val it = state.pendingRolls.iterator()
                while (it.hasNext() && toDrop > 0) {
                    if (it.next() == 6) { it.remove(); toDrop-- }
                }
                state.consecutiveSixes = 0
                return if (state.pendingRolls.isNotEmpty() && legalMoves().isNotEmpty()) {
                    state.phase = TurnPhase.AWAITING_MOVE
                    RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = true)
                } else {
                    state.pendingRolls.clear()
                    advanceTurn(keepSamePlayer = false)
                    RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = true)
                }
            }
            state.pendingRolls.add(value)
            if (rules.extraTurnOnSix) {
                state.phase = TurnPhase.AWAITING_ROLL   // a six always means roll again
                return RollOutcome(value, mustRollAgain = true, turnLostToThreeSixes = false)
            }
        } else {
            state.consecutiveSixes = 0
            state.pendingRolls.add(value)
        }

        state.phase = TurnPhase.AWAITING_MOVE
        return RollOutcome(value, mustRollAgain = false, turnLostToThreeSixes = false)
    }

    /** Every legal move across all banked values. Empty = nothing can be played. */
    fun legalMoves(): List<Move> =
        state.pendingRolls.distinct().flatMap { legalMovesFor(it) }

    /** Legal moves that spend exactly the banked value [roll]. */
    fun legalMovesFor(roll: Int): List<Move> {
        val player = state.currentPlayer
        val moves = mutableListOf<Move>()
        for (token in player.tokens) {
            when (token.state) {
                TokenState.BASE -> {
                    if (!rules.sixRequiredToLeaveBase || roll == 6) {
                        moves += Move(token, roll, fromSteps = 0, toSteps = 1, leavesBase = true)
                    }
                }
                TokenState.ACTIVE, TokenState.HOME_STRETCH -> {
                    val target = token.steps + roll
                    if (target > FINISH_STEPS) continue
                    if (target == FINISH_STEPS) {
                        moves += Move(token, roll, token.steps, target, finishesToken = true)
                        continue
                    }
                    val entersHome = token.steps <= LudoBoard.TRACK_LENGTH - 1 &&
                        target > LudoBoard.TRACK_LENGTH - 1
                    val captured =
                        if (target <= LudoBoard.TRACK_LENGTH - 1) capturablesAt(player, target) else emptyList()
                    moves += Move(
                        token = token,
                        usedRoll = roll,
                        fromSteps = token.steps,
                        toSteps = target,
                        capturesTokenIds = captured.map { it.id },
                        entersHomeStretch = entersHome
                    )
                }
                TokenState.FINISHED -> Unit
            }
        }
        return moves
    }

    /** Plays [move], spending its banked value. */
    fun applyMove(move: Move): MoveResult {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        val player = state.currentPlayer

        val capturedTokens = mutableListOf<Token>()
        for (id in move.capturesTokenIds) {
            state.players.flatMap { it.tokens }.firstOrNull { it.id == id }?.let { victim ->
                victim.resetToBase()
                capturedTokens += victim
            }
        }

        move.token.steps = move.toSteps
        move.token.state = when {
            move.finishesToken -> TokenState.FINISHED
            move.toSteps > LudoBoard.TRACK_LENGTH - 1 -> TokenState.HOME_STRETCH
            else -> TokenState.ACTIVE
        }

        // ARROW MODE: landing on an arrow's tail carries the piece straight to
        // its head. Tails and heads are both on the shared track, so this can
        // never drop a piece into another colour's home column.
        var tookArrow = false
        var arrowLandedSteps: Int? = null
        if (rules.arrowMode && move.token.state == TokenState.ACTIVE) {
            val here = LudoBoard.toGlobalIndex(move.token.color, move.token.steps - 1)
            if (LudoBoard.isArrowTail(here)) {
                val landed = move.token.steps + LudoBoard.ARROW_HOP
                if (landed <= LudoBoard.TRACK_LENGTH - 1) {
                    move.token.steps = landed
                    arrowLandedSteps = landed
                    tookArrow = true
                }
            }
        }

        state.pendingRolls.remove(move.usedRoll)   // spend exactly this value

        var gameWon = false
        if (move.finishesToken) {
            player.finishedCount++
            if (player.finishedCount >= Player.TOKENS_PER_PLAYER) {
                player.hasWon = true
                state.rankings += player.id
                gameWon = if (rules.teamMode && player.team != 0) {
                    state.players.filter { it.team == player.team }.all { it.hasWon }
                } else {
                    state.rankings.size >= state.players.size - 1
                }
            }
        }

        // A cut, an arrow, or sending a piece home all force the SAME player to
        // roll again straight away. Whatever is still banked stays banked and
        // can only be spent after that roll.
        val forcesReRoll = tookArrow ||
            (rules.captureGrantsExtraTurn && capturedTokens.isNotEmpty()) ||
            (rules.finishGrantsExtraTurn && move.finishesToken)

        when {
            gameWon -> state.phase = TurnPhase.GAME_OVER

            forcesReRoll -> {
                state.consecutiveSixes = 0
                state.lastDiceRoll = null
                state.phase = TurnPhase.AWAITING_ROLL    // must roll before moving again
            }

            state.pendingRolls.isNotEmpty() -> {
                state.phase = TurnPhase.AWAITING_MOVE
                if (legalMoves().isEmpty()) {
                    state.pendingRolls.clear()
                    advanceTurn(keepSamePlayer = false)
                }
            }

            else -> advanceTurn(keepSamePlayer = false)
        }

        return MoveResult(
            move = move,
            capturedTokens = capturedTokens,
            extraTurn = forcesReRoll && !gameWon,
            gameWon = gameWon,
            winnerPlayerId = if (gameWon) player.id else null,
            arrowLandedSteps = arrowLandedSteps,
            rollsLeft = state.pendingRolls.toList()
        )
    }

    /** Nothing playable — drop every banked value and hand over. */
    fun passTurn() {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        state.pendingRolls.clear()
        advanceTurn(keepSamePlayer = false)
    }

    private fun advanceTurn(keepSamePlayer: Boolean) {
        state.pendingRolls.clear()
        if (!keepSamePlayer) {
            var next = (state.currentPlayerIndex + 1) % state.players.size
            var guard = 0
            while (state.players[next].hasWon && guard < state.players.size) {
                next = (next + 1) % state.players.size
                guard++
            }
            state.currentPlayerIndex = next
            state.consecutiveSixes = 0
        }
        state.lastDiceRoll = null
        state.phase = TurnPhase.AWAITING_ROLL
    }

    private fun capturablesAt(mover: Player, targetSteps: Int): List<Token> {
        val globalIndex = LudoBoard.toGlobalIndex(mover.color, targetSteps - 1)
        if (rules.safeCellsBlockCapture && LudoBoard.isSafeCell(globalIndex)) return emptyList()
        return state.players
            .filter { it.id != mover.id }
            // team mode: never cut your own partner
            .filter { !(rules.teamMode && it.team != 0 && it.team == mover.team) }
            .flatMap { it.tokens }
            .filter { it.state == TokenState.ACTIVE }
            .filter { LudoBoard.toGlobalIndex(it.color, it.steps - 1) == globalIndex }
    }

    companion object {
        /** 51 shared-track steps + 6 home-column steps. */
        const val FINISH_STEPS = 57
    }
}
