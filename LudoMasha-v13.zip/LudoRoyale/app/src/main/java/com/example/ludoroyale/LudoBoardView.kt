package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import kotlin.math.min

/**
 * Draws the classic Ludo cross board (wooden frame, circular home yards,
 * arrow-shaped home stretches, star safe cells, direction arrows) plus
 * styled tokens with stack counts, and moves tokens box-by-box.
 * Everything is drawn in code — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    var tappableTokenIds: Set<String> = emptySet()
        set(value) {
            field = value
            if (value.isEmpty()) stopPulse() else startPulse()
            invalidate()
        }

    // Movable pieces breathe in and out so the player can spot them instantly.
    private var pulse = 1f
    private var pulseUp = true
    private var pulsing = false

    private val pulseTick = object : Runnable {
        override fun run() {
            if (!pulsing) return
            pulse += if (pulseUp) 0.022f else -0.022f
            if (pulse >= 1.18f) { pulse = 1.18f; pulseUp = false }
            if (pulse <= 1.0f) { pulse = 1.0f; pulseUp = true }
            invalidate()
            postDelayed(this, 32)
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        pulse = 1f
        pulseUp = true
        post(pulseTick)
    }

    private fun stopPulse() {
        pulsing = false
        pulse = 1f
        removeCallbacks(pulseTick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopPulse()   // don't keep ticking after the view is gone
    }

    var onTokenTapped: ((Token) -> Unit)? = null

    /** Picked one of the little number chips floating over a piece. */
    var onChoicePicked: ((Int) -> Unit)? = null

    // Small number chips shown right above a piece, so the player never
    // leaves the board to say how many points to give it.
    private var choiceTokenId: String? = null
    private var choiceValues: List<Int> = emptyList()
    private val chipRects = mutableListOf<Pair<Int, RectF>>()

    fun showChoices(tokenId: String, values: List<Int>) {
        choiceTokenId = tokenId
        choiceValues = values
        invalidate()
    }

    fun clearChoices() {
        choiceTokenId = null
        choiceValues = emptyList()
        chipRects.clear()
        invalidate()
    }

    /** Draw ARROW-MODE shortcut arrows on the track. */
    var arrowMode: Boolean = false
        set(value) { field = value; invalidate() }

    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Token currently vanishing/reappearing for an ARROW-MODE magic jump. */
    private var fadingTokenId: String? = null
    private var fadeAlpha: Float = 1f

    /**
     * ARROW MODE magic move: the piece puffs out at the arrow's start and
     * reappears where the arrow ends, instead of walking the gap.
     */
    fun magicTeleport(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit) {
        fadingTokenId = tokenId
        fadeOut(tokenId, color, toSteps, onComplete, 1f)
    }

    private fun fadeOut(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit, a: Float) {
        if (a <= 0.05f) {
            // reappear at the arrow's end
            displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, toSteps)
            fadeIn(tokenId, onComplete, 0f)
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeOut(tokenId, color, toSteps, onComplete, a - 0.16f) }, 34)
    }

    private fun fadeIn(tokenId: String, onComplete: () -> Unit, a: Float) {
        if (a >= 1f) {
            fadeAlpha = 1f
            fadingTokenId = null
            invalidate()
            onComplete()
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeIn(tokenId, onComplete, a + 0.16f) }, 34)
    }

    /** Instantly syncs the board to [newState] (game start, or after a hop lands). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /** Moves one token cell-by-cell from [fromSteps] to [toSteps], then calls [onComplete]. */
    /**
     * Slides one piece smoothly along the squares from [fromSteps] to
     * [toSteps] — it walks the real path (so it turns the corners correctly)
     * but glides continuously instead of jumping square to square.
     */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        if (fromSteps <= 0) {
            path += BoardGeometry.centerForSteps(color, toSteps)
        } else {
            for (step in (fromSteps + 1)..toSteps) path += BoardGeometry.centerForSteps(color, step)
        }
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete)
    }

    /**
     * A cut piece races back the way it came — its path reversed, faster than a
     * normal move — instead of blinking straight to its base.
     */
    fun flyHome(tokenId: String, color: PlayerColor, fromSteps: Int, baseSlot: Int, onComplete: () -> Unit) {
        val path = mutableListOf<Pair<Float, Float>>()
        displayedCenters[tokenId]?.let { path += it }
        var step = fromSteps
        while (step > 1) {                       // retrace the lap backwards
            step -= maxOf(1, fromSteps / 8)      // skip a little so it stays quick
            path += BoardGeometry.centerForSteps(color, maxOf(step, 1))
        }
        path += BoardGeometry.BASE_SLOTS.getValue(color)[baseSlot.coerceIn(0, 3)]
        if (path.size < 2) { onComplete(); return }
        glide(tokenId, path, onComplete, perLegMs = 34L)
    }

    private fun glide(tokenId: String, path: List<Pair<Float, Float>>, onComplete: () -> Unit, perLegMs: Long = 110L) {
        val legs = path.size - 1
        val perLeg = perLegMs                   // ms per square
        val total = (legs * perLeg).coerceAtLeast(160L)
        val startAt = System.currentTimeMillis()
        var lastLeg = -1

        val ticker = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - startAt
                val t = (elapsed.toFloat() / total).coerceIn(0f, 1f)
                val pos = t * legs
                val leg = pos.toInt().coerceAtMost(legs - 1)
                val f = pos - leg

                val a = path[leg]
                val b = path[leg + 1]
                displayedCenters[tokenId] =
                    (a.first + (b.first - a.first) * f) to (a.second + (b.second - a.second) * f)

                lastLeg = leg
                invalidate()

                if (t >= 1f) {
                    displayedCenters[tokenId] = path.last()
                    invalidate()
                    onComplete()
                } else {
                    postDelayed(this, 16)
                }
            }
        }
        post(ticker)
    }

    // ---- geometry ----
    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell
    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(px(c0), py(r0), px(c1), py(r1))

    // ---- paints ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xBD, 0xBD, 0xBD)
        strokeWidth = 1.5f
    }
    private val bodyShade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xFF, 0xEB, 0x3B)
        strokeWidth = 6f
    }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0x21, 0x21, 0x21)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    /** Thin pencil-like stroke used for the arrow-mode markers. */
    private val arrowLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.028f
        cell = (size - 2 * frame) / BoardGeometry.GRID_SIZE
        badgeText.textSize = cell * 0.46f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawFrame(canvas)
        drawHomeYards(canvas)
        drawTrack(canvas)
        drawHomeStretches(canvas)
        drawCenterArrows(canvas)
        drawBoardArrows(canvas)
        drawTokens(canvas)
        drawChoiceChips(canvas)
    }

    /** Wooden outer frame, gold inner edge, soft off-white playfield. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.055f

        // outer shadow
        fill.color = Color.argb(90, 0, 0, 0)
        canvas.drawRoundRect(RectF(2f, 5f, size, size + 3f), r, r, fill)

        // dark wood edge
        fill.color = Color.rgb(0xA8, 0x63, 0x24)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, fill)

        // warm wood face
        fill.color = Color.rgb(0xD9, 0x93, 0x4A)
        canvas.drawRoundRect(RectF(frame * 0.28f, frame * 0.28f, size - frame * 0.28f, size - frame * 0.28f), r, r, fill)

        // thin gold inner edge framing the play area
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawRect(
            RectF(px(0f) - frame * 0.22f, py(0f) - frame * 0.22f,
                  px(15f) + frame * 0.22f, py(15f) + frame * 0.22f), fill
        )

        // playfield
        fill.color = Color.rgb(0xFA, 0xFA, 0xF5)
        canvas.drawRect(RectF(px(0f), py(0f), px(15f), py(15f)), fill)
    }

    /** The four colored corner yards, each with a white circle holding the 4 base slots. */
    private fun drawHomeYards(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0].toFloat(); val c0 = box[1].toFloat()
            val r1 = (box[2] + 1).toFloat(); val c1 = (box[3] + 1).toFloat()

            fill.color = colorOf(color)
            canvas.drawRect(rect(r0, c0, r1, c1), fill)

            // white circle in the middle of the yard
            val cx = px((c0 + c1) / 2f)
            val cy = py((r0 + r1) / 2f)
            val radius = cell * 2.1f
            canvas.drawCircle(cx + cell * 0.06f, cy + cell * 0.09f, radius, shadow)
            fill.color = Color.WHITE
            canvas.drawCircle(cx, cy, radius, fill)
        }
    }

    /** The 52-cell outer ring: white cells, colored start cells, star safe cells, direction arrows. */
    private fun drawTrack(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val r = rc.first.toFloat(); val c = rc.second.toFloat()
            var startColor: PlayerColor? = null
            for (color in PlayerColor.entries) if (color.startOffset == idx) startColor = color

            fill.color = if (startColor != null) colorOf(startColor) else Color.WHITE
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), fill)
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), gridLine)

            if (LudoBoard.isSafeCell(idx)) {
                val starColor = if (startColor != null) Color.WHITE else Color.rgb(0x9E, 0x9E, 0x9E)
                drawStar(canvas, px(c + 0.5f), py(r + 0.5f), cell * 0.3f, starColor)
            }
        }
    }

    /** A chevron on a start cell showing which way tokens travel from there. */
    /**
     * The 12 board arrows (3 per colour zone). Each is drawn from its tail to
     * its head along the track, so it is obvious where a piece will be carried.
     * Only shown in ARROW MODE — Classic has a clean board.
     */
    private fun drawBoardArrows(canvas: Canvas) {
        if (!arrowMode) return
        val ring = BoardGeometry.RING

        for (tail in LudoBoard.ARROW_TAILS) {
            val head = LudoBoard.arrowHead(tail)
            val a = ring[tail]
            val b = ring[head]
            val ax = px(a.second + 0.5f); val ay = py(a.first + 0.5f)
            val bx = px(b.second + 0.5f); val by = py(b.first + 0.5f)

            val vx = bx - ax; val vy = by - ay
            val len = kotlin.math.sqrt(vx * vx + vy * vy).coerceAtLeast(1f)
            val ux = vx / len; val uy = vy / len

            val sx = ax + ux * cell * 0.26f
            val sy = ay + uy * cell * 0.26f
            val ex = bx - ux * cell * 0.24f
            val ey = by - uy * cell * 0.24f

            // soft shadow under the arrow, then the arrow itself — reads as raised
            arrowLine.strokeWidth = maxOf(2.5f, cell * 0.085f)
            arrowLine.color = Color.argb(70, 0, 0, 0)
            canvas.drawLine(sx + 2f, sy + 3f, ex + 2f, ey + 3f, arrowLine)
            headAt(canvas, ex + 2f, ey + 3f, ux, uy)

            arrowLine.strokeWidth = maxOf(2f, cell * 0.07f)
            arrowLine.color = Color.rgb(0xE8, 0x5D, 0x1F)
            canvas.drawLine(sx, sy, ex, ey, arrowLine)
            headAt(canvas, ex, ey, ux, uy)

            // small knob marking the tail you must land on
            fill.color = Color.rgb(0xE8, 0x5D, 0x1F)
            canvas.drawCircle(ax, ay, cell * 0.16f, fill)
            fill.color = Color.rgb(0xFF, 0xD9, 0x8A)
            canvas.drawCircle(ax, ay, cell * 0.09f, fill)
        }
    }

    /** A small open chevron head at (x,y) pointing along (dx,dy). */
    private fun headAt(canvas: Canvas, x: Float, y: Float, dx: Float, dy: Float, scale: Float = 1f) {
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.0001f)
        val ux = dx / len
        val uy = dy / len
        val h = cell * 0.19f * scale
        val pxv = -uy
        val pyv = ux
        canvas.drawLine(x, y, x - ux * h + pxv * h * 0.62f, y - uy * h + pyv * h * 0.62f, arrowLine)
        canvas.drawLine(x, y, x - ux * h - pxv * h * 0.62f, y - uy * h - pyv * h * 0.62f, arrowLine)
    }

    /** Star path using whatever colour/alpha is already set on [fill]. */
    private fun drawStarPath(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            path.let { p ->
                val x = cx + (rr * Math.cos(angle)).toFloat()
                val y = cy + (rr * Math.sin(angle)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            val x = cx + (rr * Math.cos(angle)).toFloat()
            val y = cy + (rr * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    /** Each color's private path to home, drawn as one solid colored lane. */
    private fun drawHomeStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            fill.color = colorOf(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), fill)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), gridLine)
            }
        }
    }

    /** The four big arrowheads meeting at the center — the "win" zone. */
    private fun drawCenterArrows(canvas: Canvas) {
        val cx = px(7.5f); val cy = py(7.5f)
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(px(p1c), py(p1r))
            path.lineTo(px(p2c), py(p2r))
            path.lineTo(cx, cy)
            path.close()
            fill.color = colorOf(color)
            canvas.drawPath(path, fill)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    /**
     * Tokens, grouped so stacked pieces are obvious: one styled piece per
     * (cell, color) with a numbered badge when more than one sits there,
     * and a slight offset when two different colors share a safe cell.
     */
    /**
     * Every piece is drawn as its own piece — a pile of three shows three
     * discs fanned out, not one disc with a number on it. Movable pieces
     * gently grow and shrink so the player can see what they can play.
     */
    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return

        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            val shrink = when {
                tokens.size >= 4 -> 0.62f
                tokens.size == 3 -> 0.70f
                tokens.size == 2 -> 0.80f
                else -> 1f
            }
            tokens.forEachIndexed { i, token ->
                val (ox, oy) = offsets[i]
                val faded = token.id == fadingTokenId
                val alpha = if (faded) fadeAlpha else 1f
                val tappable = token.id in tappableTokenIds
                val scale = shrink * if (tappable) pulse else 1f
                drawToken(
                    canvas,
                    px(col) + ox * cell,
                    py(row) + oy * cell,
                    token.color, alpha, tappable, scale
                )
            }
        }
    }

    /** Where each piece sits when several share one square. */
    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.16f to 0f, 0.16f to 0f)
        3 -> listOf(0f to -0.17f, -0.17f to 0.13f, 0.17f to 0.13f)
        4 -> listOf(-0.16f to -0.16f, 0.16f to -0.16f, -0.16f to 0.16f, 0.16f to 0.16f)
        else -> {
            // 5+ : ring them around the cell centre
            val list = mutableListOf<Pair<Float, Float>>()
            for (i in 0 until count) {
                val angle = 2.0 * Math.PI * i / count
                list += (0.19f * Math.cos(angle).toFloat()) to (0.19f * Math.sin(angle).toFloat())
            }
            list
        }
    }

    /** A piece drawn as a lit dome: contact shadow, dark rim, shaded body, highlight. */
    private fun drawToken(
        canvas: Canvas, cx: Float, cy: Float,
        color: PlayerColor, alpha: Float, tappable: Boolean, scale: Float
    ) {
        if (alpha <= 0.02f) return
        val radius = cell * 0.36f * scale
        val a = (alpha * 255).toInt().coerceIn(0, 255)
        val base = colorOf(color)

        // contact shadow flattened on the board
        shadow.alpha = (75 * alpha).toInt().coerceIn(0, 255)
        canvas.drawOval(
            RectF(cx - radius * 0.95f, cy + radius * 0.34f, cx + radius * 0.95f, cy + radius * 0.98f),
            shadow
        )
        shadow.alpha = 60

        // dark rim keeps overlapping pieces readable
        fill.color = darken(base, 0.55f)
        fill.alpha = a
        canvas.drawCircle(cx, cy + radius * 0.05f, radius * 1.06f, fill)

        // body shaded from a top-left light source
        bodyShade.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.40f, radius * 1.6f,
            intArrayOf(lighten(base, 0.50f), base, darken(base, 0.32f)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        bodyShade.alpha = a
        canvas.drawCircle(cx, cy, radius, bodyShade)
        bodyShade.shader = null
        bodyShade.alpha = 255

        // white inset + star
        fill.color = Color.WHITE
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 0.62f, fill)
        fill.color = base
        fill.alpha = a
        drawStarPath(canvas, cx, cy, radius * 0.52f)
        fill.alpha = 255

        // specular highlight
        gloss.shader = RadialGradient(
            cx - radius * 0.34f, cy - radius * 0.46f, radius * 0.75f,
            Color.argb((140 * alpha).toInt().coerceIn(0, 255), 255, 255, 255),
            Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, gloss)
        gloss.shader = null

        if (tappable) canvas.drawCircle(cx, cy, radius + 5f, highlight)
    }

    private fun lighten(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    /** Number chips floating just above the chosen piece. */
    private fun drawChoiceChips(canvas: Canvas) {
        chipRects.clear()
        val tokenId = choiceTokenId ?: return
        if (choiceValues.isEmpty()) return
        val pos = displayedCenters[tokenId] ?: return

        val r = cell * 0.34f
        val gap = cell * 0.12f
        val totalW = choiceValues.size * (r * 2) + (choiceValues.size - 1) * gap
        var x = px(pos.second) - totalW / 2f + r
        // sit above the piece, but flip below if it would fall off the top
        var y = py(pos.first) - cell * 0.95f
        if (y - r < 0f) y = py(pos.first) + cell * 0.95f

        for (value in choiceValues) {
            // shadow + gold chip
            canvas.drawCircle(x + r * 0.10f, y + r * 0.16f, r, shadow)
            fill.color = Color.rgb(0x1E, 0x28, 0x32)
            canvas.drawCircle(x, y, r, fill)
            fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
            canvas.drawCircle(x, y, r * 0.86f, fill)

            badgeText.color = Color.rgb(0x1E, 0x14, 0x00)
            badgeText.textSize = r * 1.15f
            canvas.drawText(value.toString(), x, y + r * 0.42f, badgeText)

            chipRects += value to RectF(x - r, y - r, x + r, y + r)
            x += r * 2 + gap
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell <= 0f) return true

        // a visible number chip wins the tap
        for ((value, rect) in chipRects) {
            if (rect.contains(event.x, event.y)) {
                onChoicePicked?.invoke(value)
                return true
            }
        }

        // rebuild the same layout used for drawing, so taps hit what you see
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            tokens.forEachIndexed { i, token ->
                if (token.id !in tappableTokenIds) return@forEachIndexed
                val (ox, oy) = offsets[i]
                val dx = event.x - (px(col) + ox * cell)
                val dy = event.y - (py(row) + oy * cell)
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }

        // copy to a local val: Kotlin cannot smart-cast a var written inside a lambda
        val chosen = best
        val touchRadius = cell * 0.8f
        if (chosen != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(chosen)
        }
        return true
    }
}
