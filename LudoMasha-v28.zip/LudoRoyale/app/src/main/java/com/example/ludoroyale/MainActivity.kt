package com.example.ludoroyale

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.cosmetics.Cosmetics
import com.example.ludoroyale.cosmetics.CosmeticItem
import com.example.ludoroyale.cosmetics.CosmeticType
import com.example.ludoroyale.cosmetics.Rarity
import com.example.ludoroyale.cosmetics.TokenArts
import com.example.ludoroyale.cosmetics.UnlockMethod
import com.example.ludoroyale.engine.DiceRoller
import com.example.ludoroyale.engine.GameSnapshot
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.GameMode
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.online.LeaderboardScope
import com.example.ludoroyale.online.NotConnected
import com.example.ludoroyale.online.PrivateRoom
import com.example.ludoroyale.online.Reaction
import com.example.ludoroyale.progression.DailyRewards
import com.example.ludoroyale.progression.EpicMoment
import com.example.ludoroyale.progression.EpicMomentDetector
import com.example.ludoroyale.progression.GameEventBus
import com.example.ludoroyale.progression.GameEventType
import com.example.ludoroyale.progression.League
import com.example.ludoroyale.progression.LeagueRules
import com.example.ludoroyale.progression.MatchRewards
import com.example.ludoroyale.progression.MatchStatsTracker
import com.example.ludoroyale.progression.MatchSummary
import com.example.ludoroyale.progression.Mission
import com.example.ludoroyale.progression.MissionBook
import com.example.ludoroyale.progression.MysteryChest
import com.example.ludoroyale.progression.Progression
import com.example.ludoroyale.progression.SeasonStatus
import com.example.ludoroyale.snl.SnlBoardView
import com.example.ludoroyale.snl.SnlConfig
import com.example.ludoroyale.snl.SnlEngine
import com.example.ludoroyale.snl.SnlPhase
import com.example.ludoroyale.snl.SnlPlayer
import com.example.ludoroyale.snl.SnlRules
import com.example.ludoroyale.snl.SnlTheme

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 *
 * The lobby leads to a short match setup and then the table. CLASSIC, QUICK,
 * TEAM and LUDO SNAKE play on the Ludo board; SNAKES & LADDERS plays on its
 * own 1..100 board. Seats, dice, the ten-second turn clock, Auto Play and
 * Undo work the same on all of them.
 *
 * Everything a player earns — XP, coins, cosmetics, missions, the daily chest,
 * the local league standing — is kept on this phone by [Stats] and is handed
 * out from the one [MatchSummary] each match produces. None of it is ever read
 * by the rules engine, so nothing anybody owns or has reached can change how
 * the dice falls or where a piece may go.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val avatar: AvatarFrameView,
        val dice: DiceView,
        val arrow: View,
        val rolls: LinearLayout,
        val timer: TurnTimerRing
    )

    private lateinit var stats: Stats

    private lateinit var boardView: LudoBoardView
    private lateinit var snlBoard: SnlBoardView
    private lateinit var lobbyPanel: View
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var overlayHost: FrameLayout
    private lateinit var btnMenu: View
    private lateinit var btnSound: TextView
    private lateinit var btnAuto: TextView
    private lateinit var btnUndo: TextView
    private lateinit var winOverlay: View
    private lateinit var winTitle: TextView
    private lateinit var winSubtitle: TextView
    private lateinit var winBody: LinearLayout
    private lateinit var btnShare: TextView
    private lateinit var btnRematch: TextView
    private lateinit var quickStatus: TextView
    private lateinit var confetti: ConfettiView
    private lateinit var banner: TextView

    private lateinit var snakeDiffRow: View
    private lateinit var snakeDiffGroup: RadioGroup
    private lateinit var matchTitle: TextView
    private lateinit var modeHint: TextView
    private lateinit var countRow: View
    private lateinit var pills: List<TextView>
    private lateinit var optLucky: CheckBox
    private lateinit var optBots: CheckBox
    private lateinit var nameFields: List<EditText>

    private lateinit var lobbyCoins: TextView
    private lateinit var lobbyLevel: TextView
    private lateinit var lobbyXp: XpBarView
    private lateinit var lobbyAvatar: AvatarFrameView
    private lateinit var lobbyChestArt: ChestView
    private lateinit var chestBadge: TextView
    private lateinit var panelQuit: View

    private var engine: LudoEngine? = null
    private var snl: SnlEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()

    private var mode = GameMode.CLASSIC
    private var playerCount = 2
    private var teamsOn = false
    private var rolling = false
    private var choiceTokenId: String? = null
    private var busy = false

    /** Auto Play: once on, it stays on until the player takes control back. */
    private var autoPlay = false
    private var turnDeadline = 0L
    private var timerKey = ""
    private var timerRunning = false

    // ---------------------------------------------------- progression wiring

    /**
     * The one place a match reports what happened. Missions, the statistics
     * tracker and the Epic Moment detector all listen here; none of them
     * inspects the engine, so none of them can disagree with it.
     */
    private val bus = GameEventBus()
    private val tracker = MatchStatsTracker()
    private lateinit var missions: MissionBook
    private val epic = EpicMomentDetector { moment -> onEpicMoment(moment) }

    /** The match being played, used to make sure it can only ever pay once. */
    /**
     * Whose turn it was last time the board was drawn.
     *
     * The hand-over sound is played from here rather than from the engine: the
     * engine changes the current player in several places (a pass, a lost
     * turn, a finished move) and chasing every one of them would mean the
     * sound eventually gets missed. Noticing the change in one place cannot.
     */
    private var lastTurnOwner: String = ""

    private var matchId: String = ""
    private var lastSummary: MatchSummary? = null
    private var rollsLeftOnWinningMove = 0

    /** Counts the secret taps that lead to the owner's test panel. */
    private val devTaps = DevMode.TapCounter()

    private class UndoPoint(val board: GameSnapshot, val kills: Int)
    private val undoStack = mutableListOf<UndoPoint>()

    /** Classic clockwise seating order — team mode keeps exactly this order. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
        else -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        stats = Stats(this)
        stats.rolloverSeasonIfNeeded()
        missions = MissionBook(stats.missionsForToday())

        bus.register(tracker)
        bus.register(missions)
        bus.register(epic)

        lobbyPanel = findViewById(R.id.lobbyPanel)
        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        overlayHost = findViewById(R.id.overlayHost)
        boardView = findViewById(R.id.boardView)
        snlBoard = findViewById(R.id.snlBoard)
        btnMenu = findViewById(R.id.btnMenu)
        btnSound = findViewById(R.id.btnSound)
        btnAuto = findViewById(R.id.btnAuto)
        btnUndo = findViewById(R.id.btnUndo)
        winOverlay = findViewById(R.id.winOverlay)
        winTitle = findViewById(R.id.winTitle)
        winSubtitle = findViewById(R.id.winSubtitle)
        winBody = findViewById(R.id.winBody)
        btnShare = findViewById(R.id.btnShare)
        btnRematch = findViewById(R.id.btnRematch)
        quickStatus = findViewById(R.id.quickStatus)
        confetti = findViewById(R.id.confetti)
        banner = findViewById(R.id.banner)
        panelQuit = findViewById(R.id.panelQuit)

        matchTitle = findViewById(R.id.matchTitle)
        modeHint = findViewById(R.id.modeHint)
        countRow = findViewById(R.id.countRow)
        snakeDiffRow = findViewById(R.id.snakeDiffRow)
        snakeDiffGroup = findViewById(R.id.snakeDiffGroup)
        optLucky = findViewById(R.id.optLucky)
        optBots = findViewById(R.id.optBots)
        lobbyCoins = findViewById(R.id.lobbyCoins)
        lobbyLevel = findViewById(R.id.lobbyLevel)
        lobbyXp = findViewById(R.id.lobbyXp)
        lobbyAvatar = findViewById(R.id.lobbyAvatar)
        lobbyChestArt = findViewById(R.id.lobbyChestArt)
        chestBadge = findViewById(R.id.chestBadge)
        pills = listOf(findViewById(R.id.pill2), findViewById(R.id.pill3), findViewById(R.id.pill4))
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.avatarTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft), findViewById(R.id.rollsTopLeft), findViewById(R.id.timerTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.avatarTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight), findViewById(R.id.rollsTopRight), findViewById(R.id.timerTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.avatarBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft), findViewById(R.id.rollsBottomLeft), findViewById(R.id.timerBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.avatarBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight), findViewById(R.id.rollsBottomRight), findViewById(R.id.timerBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        // ---- lobby cards
        findViewById<CardArtView>(R.id.artTwo).kind = CardArt.TWO_PLAYERS
        findViewById<CardArtView>(R.id.artFour).kind = CardArt.FOUR_PLAYERS
        findViewById<CardArtView>(R.id.artQuick).kind = CardArt.QUICK
        findViewById<CardArtView>(R.id.artSnake).kind = CardArt.SNAKE
        findViewById<CardArtView>(R.id.artTeam).kind = CardArt.TEAM
        findViewById<CardArtView>(R.id.artComputer).kind = CardArt.COMPUTER
        findViewById<CardArtView>(R.id.artLudoSnake).kind = CardArt.LUDO_SNAKE

        findViewById<View>(R.id.cardTwo).setOnClickListener {
            openMatch(GameMode.CLASSIC, 2, teams = false, bots = false, R.string.card_two)
        }
        findViewById<View>(R.id.cardFour).setOnClickListener {
            openMatch(GameMode.CLASSIC, 4, teams = false, bots = false, R.string.card_four)
        }
        findViewById<View>(R.id.cardQuick).setOnClickListener {
            openMatch(GameMode.QUICK, 2, teams = false, bots = false, R.string.card_quick)
        }
        findViewById<View>(R.id.cardSnake).setOnClickListener {
            openMatch(GameMode.SNAKES, 2, teams = false, bots = false, R.string.card_snake)
        }
        findViewById<View>(R.id.cardTeam).setOnClickListener {
            openMatch(GameMode.CLASSIC, 4, teams = true, bots = false, R.string.card_team)
        }
        findViewById<View>(R.id.cardComputer).setOnClickListener {
            openMatch(GameMode.CLASSIC, 2, teams = false, bots = true, R.string.card_computer)
        }
        findViewById<View>(R.id.cardLudoSnake).setOnClickListener {
            openMatch(GameMode.LUDO_SNAKE, 2, teams = false, bots = false, R.string.card_ludo_snake)
        }

        // ---- lobby chrome and the bottom bar
        // The hidden way in. The tap target is the WHOLE name-and-level block
        // rather than the thin level line: an 11sp strip of text is a hard
        // thing to hit seven times in a row, which is most of why this did not
        // work the first time.
        val identityBlock = lobbyLevel.parent as? View
        (identityBlock ?: lobbyLevel).apply {
            isClickable = true
            setOnClickListener { onLevelLineTapped() }
        }

        findViewById<View>(R.id.lobbySettings).setOnClickListener { showSettings() }
        lobbyAvatar.setOnClickListener { showProfile() }
        findViewById<View>(R.id.lobbyChest).setOnClickListener { showDaily() }
        findViewById<View>(R.id.navMissions).setOnClickListener { showMissions() }
        findViewById<View>(R.id.navDaily).setOnClickListener { showDaily() }
        findViewById<View>(R.id.navCustomize).setOnClickListener { showCustomize() }
        findViewById<View>(R.id.navProfile).setOnClickListener { showProfile() }
        findViewById<View>(R.id.navMore).setOnClickListener { showMore() }

        findViewById<View>(R.id.btnQuitYes).setOnClickListener {
            panelQuit.visibility = View.GONE; backToLobby()
        }
        findViewById<View>(R.id.btnQuitNo).setOnClickListener { panelQuit.visibility = View.GONE }

        pills.forEachIndexed { i, pill -> pill.setOnClickListener { selectCount(i + 2) } }
        findViewById<View>(R.id.btnStart).setOnClickListener { startGame() }
        findViewById<View>(R.id.btnBack).setOnClickListener { backToLobby() }
        btnMenu.setOnClickListener { showMenu() }
        btnSound.setOnClickListener { setSound(!stats.soundOn) }
        btnAuto.setOnClickListener { toggleAuto() }
        btnUndo.setOnClickListener { undoMove() }
        findViewById<View>(R.id.btnPlayAgain).setOnClickListener { hideWin(); startGame() }
        findViewById<View>(R.id.btnGoHome).setOnClickListener { hideWin(); backToLobby() }
        btnShare.setOnClickListener { shareVictory() }
        btnRematch.setOnClickListener { explainNeedsServer(getString(R.string.online_rematch)) }
        boardView.onStep = { SoundFx.step() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        boardView.onChoicePicked = { value -> handleChoicePicked(value) }

        SoundFx.enabled = stats.soundOn
        applyCosmetics()
        showWallet()
        selectCount(2)
    }

    override fun onDestroy() {
        super.onDestroy()
        bus.clear()
    }

    // ---------- wallet, level and cosmetics ----------

    private fun coinText(n: Int): String =
        if (n >= 1000) "%.1fK".format(n / 1000f) else n.toString()

    private fun showWallet() {
        lobbyCoins.text = coinText(stats.coins)
        lobbyLevel.text = "Level ${stats.level()} · ${stats.rankName()} · ${stats.league().display}"
        lobbyXp.progress = stats.levelProgress()
        lobbyAvatar.avatarId = stats.selected(CosmeticType.AVATAR)
        lobbyAvatar.frameId = stats.selected(CosmeticType.AVATAR_FRAME)
        val ready = stats.chestReady()
        lobbyChestArt.ready = ready
        chestBadge.visibility = if (ready) View.VISIBLE else View.GONE
    }

    /** Puts every chosen cosmetic into use across the whole screen. */
    private fun applyCosmetics() {
        val dice = DiceSkins.resolve(stats.selected(CosmeticType.DICE_SKIN))
        for ((_, slot) in slots) slot.dice.skin = dice
        boardView.tokenArt = TokenArts.byId(stats.selected(CosmeticType.TOKEN_SKIN))
        snlBoard.tokenArtId = stats.selected(CosmeticType.TOKEN_SKIN)
    }

    private fun buzz(ms: Long) {
        if (!stats.vibration) return
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vib.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(ms)
        }
    }

    private fun hidePanels() {
        overlayHost.removeAllViews()
        overlayHost.visibility = View.GONE
    }

    private fun anyPanelOpen(): Boolean =
        overlayHost.visibility == View.VISIBLE || panelQuit.visibility == View.VISIBLE

    // ---------- the owner's test panel ----------

    /**
     * Seven taps on the level line open the way in — or, once the passcode
     * has been accepted on this install, go straight to the panel.
     *
     * Nothing happens on the first few taps. A player who taps their own level
     * twice out of idleness gets no hint that anything is there.
     */
    private fun onLevelLineTapped() {
        if (!DevMode.ENABLED) return
        if (stats.devUnlocked) {
            showDevPanel()
            return
        }
        if (devTaps.tap()) {
            askDevPasscode()
            return
        }
        // Once the run is clearly deliberate, say how many are left. Without
        // this there is no way to tell a tap that registered from one that
        // missed, which makes a failed attempt impossible to diagnose.
        val left = devTaps.remaining()
        if (left in 1..DevMode.TAPS - 3) notify(getString(R.string.dev_more_taps, left))
    }

    private fun askDevPasscode() {
        val d = resources.displayMetrics.density
        SheetPanel.open(this, overlayHost, getString(R.string.dev_locked)) {
            body(getString(R.string.dev_locked_note), "#8FB0E4", 12f)
            val field = EditText(this@MainActivity).apply {
                hint = getString(R.string.dev_code)
                setBackgroundResource(R.drawable.bg_field)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.rgb(0x7C, 0x93, 0xBE))
                textSize = 18f
                gravity = Gravity.CENTER
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
                val pad = (14 * d).toInt()
                setPadding(pad, pad, pad, pad)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            add(field)
            primaryButton(getString(R.string.dev_unlock)) {
                if (DevMode.accepts(field.text.toString())) {
                    stats.devUnlocked = true
                    devTaps.reset()
                    SoundFx.magic()
                    showDevPanel()
                } else {
                    SoundFx.turnLost()
                    notify(getString(R.string.dev_wrong))
                }
            }
            secondaryButton(getString(R.string.menu_cancel)) { hidePanels() }
            gap(24f)
        }
    }

    /**
     * Everything needed to test the game without playing three hundred
     * matches to reach the far end of it.
     *
     * Every button says exactly what it does and takes effect at once. There
     * is nothing here that touches the dice or the rules.
     */
    private fun showDevPanel() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.dev_title),
            getString(R.string.dev_subtitle)
        ) {
            section(getString(R.string.dev_now))
            row(getString(R.string.coins), stats.coins.toString(), "#FFE9A8")
            row(getString(R.string.stat_level), "${stats.level()}  ·  ${stats.rankName()}")
            row(getString(R.string.dev_xp), stats.xp.toString())
            row(getString(R.string.stat_league), "${stats.league().display} (${stats.leaguePoints})")
            row(getString(R.string.stat_streak), stats.streak.toString())
            row(getString(R.string.dev_owned), "${stats.owned().size} / ${Cosmetics.ALL.size}")

            section(getString(R.string.dev_give))
            for (grant in DevMode.Grant.entries) {
                secondaryButton(grant.label) {
                    stats.addCoins(grant.coins)
                    if (grant.xp > 0) stats.addXp(grant.xp)
                    SoundFx.magic()
                    showWallet()
                    showDevPanel()
                }
            }
            secondaryButton(getString(R.string.dev_max_coins)) {
                stats.coins = 999_999
                SoundFx.magic()
                showWallet()
                showDevPanel()
            }

            section(getString(R.string.dev_level))
            val jumps = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            val d = resources.displayMetrics.density
            for (level in DevMode.LEVEL_JUMPS) {
                jumps.addView(TextView(this@MainActivity).apply {
                    text = level.toString()
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundResource(R.drawable.pill_normal)
                    setTextColor(Color.WHITE)
                    val pad = (8 * d).toInt()
                    setPadding(pad, pad + pad / 2, pad, pad + pad / 2)
                    layoutParams = LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    ).apply { setMargins(pad / 2, pad, pad / 2, 0) }
                    isClickable = true
                    setOnClickListener {
                        stats.devSetLevel(level)
                        SoundFx.win()
                        showWallet()
                        showDevPanel()
                    }
                })
            }
            add(jumps)

            section(getString(R.string.dev_unlocks))
            secondaryButton(getString(R.string.dev_unlock_all)) {
                val added = stats.devUnlockEverything()
                SoundFx.magic()
                notify(getString(R.string.dev_unlocked_count, added))
                applyCosmetics()
                showDevPanel()
            }

            section(getString(R.string.dev_daily))
            secondaryButton(getString(R.string.dev_reset_chest)) {
                stats.devResetDaily()
                showWallet()
                notify(getString(R.string.dev_chest_ready))
                showDevPanel()
            }
            secondaryButton(getString(R.string.dev_finish_missions)) {
                stats.devCompleteMissions()
                missions.replaceWith(stats.missionsForToday())
                notify(getString(R.string.dev_missions_done))
                showDevPanel()
            }

            section(getString(R.string.dev_competitive))
            val tiers = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            add(tiers)
            for (tier in League.entries) {
                tiers.addView(TextView(this@MainActivity).apply {
                    text = tier.display
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundResource(
                        if (stats.league() == tier) R.drawable.pill_selected else R.drawable.pill_normal
                    )
                    setTextColor(
                        if (stats.league() == tier) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE
                    )
                    val pad = (10 * d).toInt()
                    setPadding(pad, pad, pad, pad)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (6 * d).toInt() }
                    isClickable = true
                    setOnClickListener {
                        stats.leaguePoints = tier.minPoints
                        showWallet()
                        showDevPanel()
                    }
                })
            }
            secondaryButton(getString(R.string.dev_streak_five)) {
                stats.streak = 4
                if (stats.bestStreak < 4) stats.bestStreak = 4
                notify(getString(R.string.dev_streak_note))
                showDevPanel()
            }

            section(getString(R.string.dev_danger))
            body(getString(R.string.dev_wipe_note), "#8FB0E4", 11f)
            secondaryButton(getString(R.string.dev_wipe)) { confirmDevWipe() }
            secondaryButton(getString(R.string.dev_lock)) {
                stats.devUnlocked = false
                devTaps.reset()
                hidePanels()
                notify(getString(R.string.dev_locked_again))
            }
            gap(24f)
        }
    }

    private fun confirmDevWipe() {
        SheetPanel.open(this, overlayHost, getString(R.string.dev_wipe)) {
            body(getString(R.string.dev_wipe_confirm), "#FFFFFF", 14f)
            primaryButton(getString(R.string.dev_wipe_yes)) {
                val wasUnlocked = stats.devUnlocked
                stats.devWipe()
                // a wipe should test the new-player experience, not lock the
                // owner out of the panel that caused it
                stats.devUnlocked = wasUnlocked
                missions.replaceWith(stats.missionsForToday())
                applyCosmetics()
                showWallet()
                SoundFx.turnLost()
                notify(getString(R.string.dev_wiped))
                hidePanels()
            }
            secondaryButton(getString(R.string.menu_cancel)) { showDevPanel() }
            gap(24f)
        }
    }

    // ---------- PROFILE ----------

    private fun showProfile() {
        val level = stats.level()
        val next = Progression.nextTitle(level)
        SheetPanel.open(
            this, overlayHost,
            stats.playerName.ifBlank { getString(R.string.nav_profile) },
            "Level $level · ${stats.rankName()}"
        ) {
            val portrait = AvatarFrameView(this@MainActivity).apply {
                avatarId = stats.selected(CosmeticType.AVATAR)
                frameId = stats.selected(CosmeticType.AVATAR_FRAME)
                accent = Color.rgb(0x2B, 0x3A, 0x63)
                val size = (110 * resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    topMargin = (8 * resources.displayMetrics.density).toInt()
                }
            }
            add(portrait)

            section(getString(R.string.sec_progress))
            row(getString(R.string.stat_level), "$level  ·  ${stats.rankName()}")
            val bar = XpBarView(this@MainActivity).apply {
                progress = stats.levelProgress()
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (10 * resources.displayMetrics.density).toInt()
                ).apply { topMargin = (6 * resources.displayMetrics.density).toInt() }
            }
            add(bar)
            val span = stats.xpSpan()
            body(
                if (span <= 0) getString(R.string.xp_maxed)
                else getString(R.string.xp_progress, stats.xpIntoLevel(), span),
                "#8FB0E4", 12f
            )
            if (next != null) body(getString(R.string.next_title, next.second, next.first), "#8FB0E4", 12f)

            section(getString(R.string.sec_league))
            row(getString(R.string.stat_league), stats.league().display, "#FFE9A8")
            row(getString(R.string.stat_points), stats.leaguePoints.toString())
            val lb = XpBarView(this@MainActivity).apply {
                progress = stats.leagueProgress()
                fillFrom = Color.rgb(0x9A, 0xE0, 0xFF)
                fillTo = Color.rgb(0x2E, 0x9A, 0xE8)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (10 * resources.displayMetrics.density).toInt()
                ).apply { topMargin = (6 * resources.displayMetrics.density).toInt() }
            }
            add(lb)
            body(getString(R.string.league_local_note), "#8FB0E4", 11f)

            section(getString(R.string.sec_record))
            row(getString(R.string.stat_won), "${stats.gamesWon} of ${stats.gamesPlayed}")
            row(getString(R.string.stat_rate), "%.0f%%".format(stats.winRate()))
            row(getString(R.string.stat_streak), streakText(stats.streak))
            row(getString(R.string.stat_best), stats.bestStreak.toString())
            row(getString(R.string.stat_kills), stats.kills.toString())
            row(getString(R.string.stat_home), stats.tokensHome.toString())
            row(getString(R.string.stat_2p), stats.wins2p.toString())
            row(getString(R.string.stat_4p), stats.wins4p.toString())
            row(getString(R.string.stat_team), stats.winsTeam.toString())
            row(getString(R.string.stat_quick), stats.winsQuick.toString())
            row(getString(R.string.stat_snake), stats.winsSnake.toString())

            val season = stats.season()
            section(getString(R.string.sec_season))
            row(getString(R.string.season_name), "#${season.id}")
            row(
                getString(R.string.season_state),
                when (season.statusOn(stats.today())) {
                    SeasonStatus.ACTIVE -> getString(R.string.season_days, season.daysLeftOn(stats.today()))
                    SeasonStatus.ENDED -> getString(R.string.season_ended)
                    SeasonStatus.UPCOMING -> getString(R.string.season_soon)
                }
            )
            body(getString(R.string.season_note), "#8FB0E4", 11f)

            primaryButton(getString(R.string.nav_customize)) { showCustomize() }
            secondaryButton(getString(R.string.edit_name)) { showSettings() }
            gap(24f)
        }
    }

    private fun streakText(streak: Int): String = when {
        streak >= 5 -> "$streak 👑"
        streak >= 3 -> "$streak 🔥"
        else -> streak.toString()
    }

    // ---------- CUSTOMIZE ----------

    private var customizeTab = CosmeticType.TOKEN_SKIN

    private fun showCustomize() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.nav_customize),
            getString(R.string.customize_note)
        ) {
            // tabs
            val tabs = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            for (type in CosmeticType.entries) {
                tabs.addView(TextView(this@MainActivity).apply {
                    text = type.display
                    textSize = 10f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    val on = type == customizeTab
                    setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
                    setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
                    val pad = (6 * resources.displayMetrics.density).toInt()
                    setPadding(pad, pad + pad / 2, pad, pad + pad / 2)
                    layoutParams = LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    ).apply { setMargins(pad / 2, pad, pad / 2, pad) }
                    isClickable = true
                    setOnClickListener { customizeTab = type; showCustomize() }
                })
            }
            add(tabs)

            row(getString(R.string.coins), coinText(stats.coins), "#FFE9A8")

            val grid = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            add(grid)
            buildCosmeticGrid(grid, customizeTab)
            gap(24f)
        }
    }

    private fun buildCosmeticGrid(host: LinearLayout, type: CosmeticType) {
        host.removeAllViews()
        val d = resources.displayMetrics.density
        val perRow = if (type == CosmeticType.VICTORY_EFFECT) 2 else 3
        var row: LinearLayout? = null
        val items = Cosmetics.byType(type)

        items.forEachIndexed { i, item ->
            if (i % perRow == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                host.addView(row)
            }

            val owned = stats.owns(item.id)
            val active = stats.selected(type) == item.id

            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundResource(
                    when {
                        active -> R.drawable.bg_dice_active
                        owned -> R.drawable.bg_dice_item
                        else -> R.drawable.bg_dice_locked
                    }
                )
                val pad = (8 * d).toInt()
                setPadding(pad, pad, pad, pad)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt()) }
                isClickable = true
                setOnClickListener { pickCosmetic(item) }
            }

            cell.addView(previewFor(item, owned, (52 * d).toInt()))

            cell.addView(TextView(this).apply {
                text = item.name
                setTextColor(if (owned) Color.WHITE else Color.rgb(0x7C, 0x93, 0xBE))
                textSize = 11f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (4 * d).toInt() }
            })

            cell.addView(TextView(this).apply {
                text = rarityText(item.rarity)
                setTextColor(rarityColor(item.rarity))
                textSize = 9f
                gravity = Gravity.CENTER
                letterSpacing = 0.08f
            })

            cell.addView(TextView(this).apply {
                text = statusText(item, owned, active)
                setTextColor(
                    when {
                        active -> Color.rgb(0xFF, 0xE9, 0xA8)
                        owned -> Color.rgb(0x9F, 0xB6, 0xDE)
                        else -> Color.rgb(0xF2, 0xC1, 0x4E)
                    }
                )
                textSize = 10f
                gravity = Gravity.CENTER
            })

            row?.addView(cell)
        }

        // keep the last row's cells the same width as the others
        val last = host.getChildAt(host.childCount - 1) as? LinearLayout ?: return
        while (last.childCount < perRow) {
            last.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            })
        }
    }

    /** A live preview of the item, drawn with the same code the game uses. */
    private fun previewFor(item: CosmeticItem, owned: Boolean, size: Int): View = when (item.type) {
        CosmeticType.DICE_SKIN -> DiceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            skin = DiceSkins.resolve(item.id)
            value = 6
            dimmed = !owned
            isClickable = false
        }
        CosmeticType.TOKEN_SKIN -> TokenPreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            artId = item.id
            dimmed = !owned
        }
        CosmeticType.AVATAR -> AvatarFrameView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            avatarId = item.id
            frameId = Cosmetics.FRAME_NONE
            alpha = if (owned) 1f else 0.45f
        }
        CosmeticType.AVATAR_FRAME -> AvatarFrameView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            avatarId = stats.selected(CosmeticType.AVATAR)
            frameId = item.id
            alpha = if (owned) 1f else 0.45f
        }
        CosmeticType.VICTORY_EFFECT -> VictoryEffectPreview(this).apply {
            layoutParams = LinearLayout.LayoutParams(size * 2, size)
            effectId = item.id
            alpha = if (owned) 1f else 0.45f
        }
    }

    private fun rarityText(r: Rarity) = r.display

    private fun rarityColor(r: Rarity): Int = when (r) {
        Rarity.COMMON -> Color.rgb(0x9F, 0xB6, 0xDE)
        Rarity.RARE -> Color.rgb(0x6B, 0xC8, 0xFF)
        Rarity.EPIC -> Color.rgb(0xC0, 0x8A, 0xFF)
        Rarity.LEGENDARY -> Color.rgb(0xFF, 0xC1, 0x4E)
    }

    private fun statusText(item: CosmeticItem, owned: Boolean, active: Boolean): String = when {
        active -> getString(R.string.dice_in_use)
        owned -> getString(R.string.dice_use)
        item.unlock == UnlockMethod.COINS -> "🔒 ${item.price}"
        item.unlock == UnlockMethod.LEVEL -> getString(R.string.unlock_level, item.requiredLevel)
        item.unlock == UnlockMethod.DAILY -> getString(R.string.unlock_daily)
        item.unlock == UnlockMethod.CHEST -> getString(R.string.unlock_chest)
        else -> getString(R.string.unlock_mission)
    }

    private fun pickCosmetic(item: CosmeticItem) {
        if (stats.owns(item.id)) {
            stats.select(item.id)
            applyCosmetics()
            buzz(20)
            showWallet()
            showCustomize()
            return
        }
        when (item.unlock) {
            UnlockMethod.COINS -> {
                if (stats.buy(item.id)) {
                    stats.select(item.id)
                    SoundFx.magic()
                    notify(getString(R.string.unlocked, item.name))
                    applyCosmetics()
                    showWallet()
                    showCustomize()
                } else {
                    notify(getString(R.string.not_enough_coins))
                }
            }
            UnlockMethod.LEVEL ->
                notify(getString(R.string.needs_level, item.requiredLevel))
            UnlockMethod.DAILY ->
                notify(getString(R.string.needs_daily))
            UnlockMethod.CHEST ->
                notify(getString(R.string.needs_chest))
            else ->
                notify(getString(R.string.needs_mission))
        }
    }

    // ---------- MISSIONS ----------

    private fun showMissions() {
        refreshMissionDay()
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.nav_missions),
            getString(R.string.missions_note)
        ) {
            val d = resources.displayMetrics.density
            for (mission in missions.missions) {
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundResource(
                        if (mission.claimed) R.drawable.bg_dice_item else R.drawable.bg_stat
                    )
                    val pad = (12 * d).toInt()
                    setPadding(pad, pad, pad, pad)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (8 * d).toInt() }
                }

                card.addView(TextView(this@MainActivity).apply {
                    text = mission.describe()
                    setTextColor(if (mission.claimed) Color.rgb(0x8F, 0xB0, 0xE4) else Color.WHITE)
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                })

                card.addView(TextView(this@MainActivity).apply {
                    text = getString(R.string.mission_reward, mission.xp, mission.coins)
                    setTextColor(Color.rgb(0xFF, 0xE9, 0xA8))
                    textSize = 11f
                })

                val bar = XpBarView(this@MainActivity).apply {
                    progress = mission.progress.toFloat() / mission.target.coerceAtLeast(1)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, (10 * d).toInt()
                    ).apply { topMargin = (8 * d).toInt() }
                }
                card.addView(bar)

                card.addView(TextView(this@MainActivity).apply {
                    text = mission.progressText()
                    setTextColor(Color.rgb(0x9F, 0xB6, 0xDE))
                    textSize = 11f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (4 * d).toInt() }
                })

                if (mission.claimable) {
                    card.addView(TextView(this@MainActivity).apply {
                        text = getString(R.string.chest_collect)
                        setBackgroundResource(R.drawable.bg_button_gold)
                        setTextColor(Color.rgb(0x2A, 0x1A, 0x00))
                        textSize = 13f
                        setTypeface(typeface, Typeface.BOLD)
                        gravity = Gravity.CENTER
                        setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = (8 * d).toInt() }
                        isClickable = true
                        setOnClickListener { claimMission(mission) }
                    })
                } else if (mission.claimed) {
                    card.addView(TextView(this@MainActivity).apply {
                        text = getString(R.string.mission_claimed)
                        setTextColor(Color.rgb(0x6B, 0xD3, 0x8A))
                        textSize = 12f
                        setTypeface(typeface, Typeface.BOLD)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = (6 * d).toInt() }
                    })
                }

                add(card)
            }
            body(getString(R.string.missions_reset), "#8FB0E4", 11f)
            gap(24f)
        }
    }

    /** Swaps yesterday's missions for today's, once the day has turned over. */
    private fun refreshMissionDay() {
        val today = stats.today()
        if (missions.day != today) {
            missions.replaceWith(stats.missionsForToday())
        }
    }

    private fun claimMission(mission: Mission) {
        val paid = missions.claim(mission.id) ?: return
        val (xp, coins) = paid
        stats.saveMissions(missions.missions)
        val (before, after) = stats.addXp(xp)
        stats.addCoins(coins)
        SoundFx.magic()
        buzz(35)
        notify(getString(R.string.mission_paid, xp, coins))
        if (after > before) celebrateLevelUp(before, after)
        showWallet()
        showMissions()
    }

    // ---------- DAILY REWARD ----------

    private fun showDaily() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.chest_title),
            getString(R.string.chest_hint)
        ) {
            val d = resources.displayMetrics.density
            val ready = stats.chestReady()
            val dayOnOffer = stats.chestDayOnOffer()

            val art = ChestView(this@MainActivity).apply {
                this.ready = ready
                val size = (150 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                }
            }
            add(art)

            body(
                if (ready) getString(R.string.chest_day_offer, dayOnOffer)
                else getString(R.string.chest_done),
                "#FFFFFF", 17f
            ).apply { gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD) }

            // the seven days, four then three
            var row: LinearLayout? = null
            for (day in 1..DailyRewards.CYCLE_LENGTH) {
                if ((day - 1) % 4 == 0) {
                    row = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    }
                    add(row!!)
                }
                val collected = day < dayOnOffer || (day == dayOnOffer && !ready)
                val isToday = day == dayOnOffer && ready
                val reward = DailyRewards.rewardFor(day)

                val tile = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setBackgroundResource(
                        when {
                            isToday -> R.drawable.bg_dice_active
                            collected -> R.drawable.bg_dice_item
                            else -> R.drawable.bg_dice_locked
                        }
                    )
                    val pad = (7 * d).toInt()
                    setPadding(pad, pad, pad, pad)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { setMargins((3 * d).toInt(), (6 * d).toInt(), (3 * d).toInt(), 0) }
                }
                tile.addView(TextView(this@MainActivity).apply {
                    text = getString(R.string.chest_day, day)
                    setTextColor(if (isToday) Color.rgb(0xFF, 0xE9, 0xA8) else Color.rgb(0x9F, 0xB6, 0xDE))
                    textSize = 10f
                    gravity = Gravity.CENTER
                })
                tile.addView(TextView(this@MainActivity).apply {
                    text = if (collected) "✓" else reward.label()
                    setTextColor(
                        when {
                            isToday -> Color.WHITE
                            collected -> Color.rgb(0x6B, 0xD3, 0x8A)
                            day == 7 -> Color.rgb(0xFF, 0xC1, 0x4E)
                            else -> Color.rgb(0xF2, 0xC1, 0x4E)
                        }
                    )
                    textSize = if (day == 7) 13f else 11f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                })
                if (day == 7) {
                    tile.addView(TextView(this@MainActivity).apply {
                        text = "👑"
                        textSize = 12f
                        gravity = Gravity.CENTER
                    })
                }
                row?.addView(tile)
            }
            // pad the short row so the tiles line up
            val lastRow = content.getChildAt(content.childCount - 1) as? LinearLayout
            if (lastRow != null) {
                while (lastRow.childCount in 1 until 4) {
                    lastRow.addView(View(this@MainActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                    })
                }
            }

            if (ready) {
                primaryButton(getString(R.string.chest_collect)) { collectDaily(art) }
            } else {
                body(getString(R.string.chest_tomorrow), "#8FB0E4", 12f)
            }

            section(getString(R.string.chest_odds_title))
            body(getString(R.string.chest_odds_note), "#8FB0E4", 11f)
            for ((id, pct) in MysteryChest.odds()) {
                val label = when (id) {
                    "COINS_SMALL" -> getString(R.string.chest_coins, MysteryChest.COINS_SMALL)
                    "COINS_BIG" -> getString(R.string.chest_coins, MysteryChest.COINS_BIG)
                    else -> Cosmetics.byId(id)?.name ?: id
                }
                row(label, "%.1f%%".format(pct))
            }
            body(getString(R.string.chest_duplicate_note), "#8FB0E4", 11f)
            gap(24f)
        }
    }

    private fun collectDaily(art: ChestView) {
        val grant = stats.claimDaily() ?: return
        SoundFx.chest()
        buzz(55)
        art.ready = false
        art.animate().cancel()
        art.scaleX = 0.82f
        art.scaleY = 0.82f
        art.animate().scaleX(1.08f).scaleY(1.08f).setDuration(240)
            .withEndAction { art.animate().scaleX(1f).scaleY(1f).setDuration(200).start() }
            .start()

        val name = grant.cosmeticId?.let { Cosmetics.byId(it)?.name }
        val message = when {
            grant.gaveCosmetic && name != null -> getString(R.string.chest_got_item, name)
            grant.wasDuplicate && name != null -> getString(R.string.chest_duplicate, name, grant.coins)
            else -> getString(R.string.chest_reward, grant.coins)
        }
        notify(message)
        showBanner(message)
        applyCosmetics()
        showWallet()
        showDaily()
    }

    // ---------- MORE: settings, rules, online ----------

    private fun showMore() {
        SheetPanel.open(this, overlayHost, getString(R.string.nav_more)) {
            secondaryButton(getString(R.string.nav_settings)) { showSettings() }
            secondaryButton(getString(R.string.rules_title)) { showRules() }
            secondaryButton(getString(R.string.nav_leaderboard)) { showLeaderboard() }
            secondaryButton(getString(R.string.nav_friends)) { showFriends() }
            secondaryButton(getString(R.string.nav_rooms)) { showRooms() }
            secondaryButton(getString(R.string.nav_about)) { showAbout() }

            // The owner's way in, in plain sight but behind the code. The
            // hidden tap still works; this is here because a hidden gesture
            // that will not open is worse than no gesture at all.
            if (DevMode.ENABLED) {
                secondaryButton(getString(R.string.dev_entry)) {
                    if (stats.devUnlocked) showDevPanel() else askDevPasscode()
                }
            }
            gap(24f)
        }
    }

    private fun showSettings() {
        SheetPanel.open(this, overlayHost, getString(R.string.nav_settings)) {
            val d = resources.displayMetrics.density

            section(getString(R.string.set_name))
            val field = EditText(this@MainActivity).apply {
                setText(stats.playerName)
                hint = getString(R.string.set_name)
                setBackgroundResource(R.drawable.bg_field)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.rgb(0x7C, 0x93, 0xBE))
                textSize = 15f
                val pad = (12 * d).toInt()
                setPadding(pad, pad, pad, pad)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            add(field)
            secondaryButton(getString(R.string.save)) {
                val typed = field.text.toString()
                // The last resort. If every button and gesture somehow fails,
                // the name box still works — so typing the code here and
                // saving opens the panel, and the code is NOT kept as a name.
                if (DevMode.accepts(typed)) {
                    stats.devUnlocked = true
                    SoundFx.magic()
                    showDevPanel()
                    return@secondaryButton
                }
                stats.playerName = typed
                notify(getString(R.string.saved))
                showWallet()
            }

            section(getString(R.string.sec_sound))
            toggleRow(this, getString(R.string.set_sound), stats.soundOn) {
                setSound(!stats.soundOn); showSettings()
            }
            toggleRow(this, getString(R.string.set_vibration), stats.vibration) {
                stats.vibration = !stats.vibration
                if (stats.vibration) buzz(30)
                showSettings()
            }
            body(getString(R.string.no_music_note), "#8FB0E4", 11f)
            gap(24f)
        }
    }

    private fun toggleRow(panel: SheetPanel, label: String, on: Boolean, onTap: () -> Unit) {
        val d = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(this).apply {
            text = getString(if (on) R.string.on else R.string.off)
            setBackgroundResource(if (on) R.drawable.bg_toggle_on else R.drawable.bg_toggle_off)
            setTextColor(if (on) Color.rgb(0x2A, 0x1A, 0x00) else Color.rgb(0x8F, 0xB0, 0xE4))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            val padX = (18 * d).toInt()
            val padY = (8 * d).toInt()
            setPadding(padX, padY, padX, padY)
            isClickable = true
            setOnClickListener { onTap() }
        })
        panel.add(row)
    }

    /**
     * The screens that need a server.
     *
     * They are built, and they say exactly what is missing. What they do NOT
     * do is invent a list of players: a leaderboard full of made-up names would
     * look finished and be a lie, and the first person who asked a friend where
     * they ranked would catch it.
     */
    private fun showLeaderboard() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.nav_leaderboard),
            getString(R.string.online_needs_account)
        ) {
            val rows = NotConnected.rows(LeaderboardScope.GLOBAL, 20)
            section(getString(R.string.lb_global))
            if (rows.isEmpty()) body(NotConnected.reason, "#C8D8F4", 13f)
            section(getString(R.string.lb_you))
            row(getString(R.string.stat_league), stats.league().display, "#FFE9A8")
            row(getString(R.string.stat_points), stats.leaguePoints.toString())
            row(getString(R.string.stat_won), "${stats.gamesWon} of ${stats.gamesPlayed}")
            body(getString(R.string.lb_local_only), "#8FB0E4", 11f)
            gap(24f)
        }
    }

    private fun showFriends() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.nav_friends),
            getString(R.string.online_needs_account)
        ) {
            body(NotConnected.reason, "#C8D8F4", 13f)
            section(getString(R.string.friends_planned))
            body(getString(R.string.friends_list), "#8FB0E4", 12f)
            section(getString(R.string.reactions_title))
            body(
                Reaction.entries.joinToString("   ") { it.glyph } + "\n" +
                    Reaction.PRESET_TEXT.joinToString("   ·   "),
                "#C8D8F4", 15f
            )
            body(getString(R.string.reactions_note), "#8FB0E4", 11f)
            gap(24f)
        }
    }

    private fun showRooms() {
        SheetPanel.open(
            this, overlayHost,
            getString(R.string.nav_rooms),
            getString(R.string.online_needs_account)
        ) {
            body(NotConnected.reason, "#C8D8F4", 13f)
            section(getString(R.string.rooms_flow_title))
            body(getString(R.string.rooms_flow), "#8FB0E4", 12f)
            body(
                getString(R.string.rooms_code_note, PrivateRoom.CODE_LENGTH),
                "#8FB0E4", 11f
            )
            gap(24f)
        }
    }

    private fun explainNeedsServer(what: String) {
        SheetPanel.open(this, overlayHost, what) {
            body(NotConnected.reason, "#C8D8F4", 14f)
            primaryButton(getString(R.string.menu_cancel)) { hidePanels() }
            gap(24f)
        }
    }

    private fun showAbout() {
        SheetPanel.open(this, overlayHost, getString(R.string.about_title)) {
            // Which build this is. Without it there is no way to tell whether
            // a new APK actually installed, which turns every "it is not
            // working" into a guess.
            row(getString(R.string.about_version), buildLabel(), "#FFE9A8")
            body(
                "Ludo Masha — offline pass-n-play.\n\n" +
                "Everything you see is drawn in code and every sound is made on the " +
                "spot, so the app carries no artwork or audio from anywhere else.\n\n" +
                "Coins are a number on this phone. They cannot be bought, sold or " +
                "cashed out, and nothing you own or unlock changes the dice, the " +
                "rules or your chances. A Level 1 player and a Level 100 player play " +
                "exactly the same game.",
                "#C8D8F4", 13f
            )
            primaryButton(getString(R.string.menu_cancel)) { hidePanels() }
            gap(24f)
        }
    }

    /** The version name and code, straight out of the built package. */
    private fun buildLabel(): String = try {
        val info = packageManager.getPackageInfo(packageName, 0)
        @Suppress("DEPRECATION")
        "${info.versionName} (${info.versionCode})"
    } catch (e: Exception) {
        "?"
    }

    private fun showRules() {
        SheetPanel.open(this, overlayHost, getString(R.string.rules_title)) {
            body(
                "LUDO\n" +
                "Roll a six to bring a piece out. Land on an opponent to send it home. " +
                "A six, a capture or a piece reaching home all earn another roll, and three " +
                "sixes in a row burn the turn. Starred squares are safe.\n\n" +
                "QUICK MODE\n" +
                "One piece starts on the board. Home stays locked until you cut an opponent; " +
                "after that, one piece home wins the match.\n\n" +
                "LUDO SNAKE\n" +
                "Ordinary Ludo, with snakes and ladders laid over the track. They fire only " +
                "when you land exactly on them, and only one can fire per move.\n\n" +
                "SNAKES & LADDERS\n" +
                "One counter each on the 1-100 board. You need a 6 or a 1 to get out of the " +
                "start pad, and the number you roll is the square you start on. Land on a " +
                "ladder foot to climb, on a snake head to be carried back down its body to " +
                "the tail — passing over either does nothing. Two counters can share a " +
                "square: nobody is knocked back on this board. Square 100 needs an exact " +
                "roll.\n\n" +
                "TURN CLOCK\n" +
                "Every turn has fifteen seconds, shown as a ring around the avatar. If it " +
                "runs out, Auto Play takes over — tap the AUTO chip under your own avatar " +
                "to take the wheel back.\n\n" +
                "UNDO\n" +
                "UNDO takes back the last move you played by hand, and anything the computer " +
                "did after it. The dice is not rolled again — you get the same numbers back " +
                "and may spend them on a different piece. It is off on the 1-100 board, where " +
                "the dice leaves no choice to change.\n\n" +
                "XP, LEVELS AND COINS\n" +
                "Finishing a match pays 20 XP, winning pays 50 more, each capture 3 and each " +
                "piece home 5. A win pays 100 coins plus 25 for each win in a row; finishing " +
                "a match you lost still pays 20. Missions and the daily chest pay too.\n\n" +
                "FAIR PLAY\n" +
                "Skins, levels and leagues change how the game looks and what you have to aim " +
                "for. They never change the dice, the rules or your chances of winning.",
                "#C8D8F4", 13f
            )
            primaryButton(getString(R.string.menu_cancel)) { hidePanels() }
            gap(24f)
        }
    }

    // ---------- match setup ----------

    private fun openMatch(picked: GameMode, count: Int, teams: Boolean, bots: Boolean, titleRes: Int) {
        mode = picked
        teamsOn = teams
        optBots.isChecked = bots
        matchTitle.setText(titleRes)

        modeHint.text = when {
            teams -> getString(R.string.hint_team)
            picked == GameMode.QUICK -> getString(R.string.hint_quick)
            picked == GameMode.SNAKES -> getString(R.string.hint_snakes)
            picked == GameMode.LUDO_SNAKE -> getString(R.string.hint_ludo_snake)
            else -> getString(R.string.hint_classic)
        }

        // both snake modes get to pick how many snakes there are
        snakeDiffRow.visibility =
            if (picked == GameMode.SNAKES || picked == GameMode.LUDO_SNAKE) View.VISIBLE else View.GONE
        countRow.visibility = if (teams) View.GONE else View.VISIBLE
        selectCount(count)

        hidePanels()
        lobbyPanel.visibility = View.GONE
        setupPanel.visibility = View.VISIBLE
    }

    private fun selectCount(count: Int) {
        playerCount = count
        pills.forEachIndexed { i, pill ->
            val on = i + 2 == count
            pill.setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
            pill.setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
        }
        val seats = seatColors(count)
        val hints = listOf("Red", "Green", "Yellow", "Blue")
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
            if (i < count) {
                val colorName = hints[PlayerColor.entries.indexOf(seats[i]).coerceIn(0, 3)]
                field.hint = "Player ${i + 1} ($colorName)"
            }
        }
        if (nameFields[0].text.isNullOrBlank() && stats.playerName.isNotBlank()) {
            nameFields[0].setText(stats.playerName)
        }
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun chosenDifficulty(): SnakeDifficulty = when (snakeDiffGroup.checkedRadioButtonId) {
        R.id.snakeEasy -> SnakeDifficulty.EASY
        R.id.snakeHard -> SnakeDifficulty.HARD
        else -> SnakeDifficulty.MEDIUM
    }

    private fun playerNames(botsOn: Boolean): List<String> =
        (0 until playerCount).map { i ->
            val typed = nameFields[i].text.toString().trim()
            when {
                typed.isNotEmpty() -> typed
                i == 0 && stats.playerName.isNotBlank() -> stats.playerName
                botsOn && i > 0 -> "Computer $i"
                else -> "Player ${i + 1}"
            }
        }

    // ---------- the match ----------

    private fun startGame() {
        autoPlay = false
        undoStack.clear()
        lastSummary = null
        rollsLeftOnWinningMove = 0
        stopTurnTimer()
        updateAutoButton()
        refreshMissionDay()
        applyCosmetics()

        // a fresh id, so this match's rewards can be paid exactly once
        lastTurnOwner = ""
        matchId = "m${System.currentTimeMillis()}-${(1000..9999).random()}"
        epic.reset()
        epic.streakIfWon = stats.streak + 1
        bus.post(GameEventType.MATCH_STARTED, mode = mode)

        if (mode == GameMode.SNAKES) startSnakeGame() else startLudoGame()
    }

    /** Everything both boards share: seats, avatars, dice colours, panels. */
    private fun showGameChrome(
        colors: List<PlayerColor>,
        names: List<String>,
        kinds: List<PlayerKind>,
        teams: List<Int>
    ) {
        val dice = DiceSkins.resolve(stats.selected(CosmeticType.DICE_SKIN))
        val myAvatar = stats.selected(CosmeticType.AVATAR)
        val myFrame = stats.selected(CosmeticType.AVATAR_FRAME)
        for ((color, slot) in slots) {
            val index = colors.indexOf(color)
            if (index < 0) {
                slot.root.visibility = View.INVISIBLE
                slot.timer.secondsLeft = null
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teams[index] != 0) {
                    "${names[index]}  •  Team ${if (teams[index] == 1) "A" else "B"}"
                } else names[index]
                slot.avatar.isBot = kinds[index] != PlayerKind.HUMAN
                slot.avatar.accent = uiColor(color)
                // seat one is the person holding the phone, so it wears their
                // chosen face and frame; the others get the seat's own look
                if (index == 0) {
                    slot.avatar.avatarId = myAvatar
                    slot.avatar.frameId = myFrame
                } else {
                    slot.avatar.avatarId = when (index) {
                        1 -> Cosmetics.AVATAR_P2
                        2 -> Cosmetics.AVATAR_P3
                        else -> Cosmetics.AVATAR_P4
                    }
                    slot.avatar.frameId = Cosmetics.FRAME_NONE
                }
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.skin = dice
                slot.dice.value = 1
                slot.timer.secondsLeft = null
            }
        }

        hidePanels()
        lobbyPanel.visibility = View.GONE
        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        btnSound.visibility = View.VISIBLE
        btnAuto.visibility = View.VISIBLE
        // there is nothing to take back on the 1..100 board: the dice decides
        // the whole move, so undo would only be a second roll in disguise
        btnUndo.visibility = if (mode == GameMode.SNAKES) View.GONE else View.VISIBLE
        updateUndoButton()
        hideWin()
        SoundFx.gameStart()
    }

    private fun startLudoGame() {
        snl = null
        val colors = seatColors(playerCount)
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)
        val teams = teamsOn && playerCount == 4

        val players = colors.mapIndexed { i, color ->
            val team = if (!teams) 0
                       else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            Player.create("p${i + 1}", names[i], color, kind, team)
        }.toMutableList()

        val difficulty = chosenDifficulty()
        val rules = RuleConfig(
            quickMode = mode == GameMode.QUICK,
            snakeMode = mode == GameMode.LUDO_SNAKE,
            // ARROW MODE is off. The rules, the board markings and their
            // tests are all still here and still pass — the mode simply has no
            // card in the lobby, so nothing can start one. Deleting working,
            // tested code to hide a menu entry would be the wrong trade.
            arrowMode = false,
            snakeDifficulty = difficulty,
            teamMode = teams,
            luckyDice = optLucky.isChecked
        )

        if (rules.quickMode) {
            for (p in players) {
                p.tokens[0].state = com.example.ludoroyale.model.TokenState.ACTIVE
                p.tokens[0].steps = 1
            }
        }

        val newEngine = LudoEngine(GameState(gameId = matchId, players = players), rules)
        engine = newEngine
        boardView.snakeDifficulty = if (rules.snakeMode) difficulty else null
        boardView.arrowMode = rules.arrowMode
        boardView.snapToState(newEngine.state)
        rolling = false
        busy = false

        boardView.visibility = View.VISIBLE
        snlBoard.visibility = View.GONE

        showGameChrome(colors, names, players.map { it.kind }, players.map { it.team })
        quickStatus.visibility =
            if (rules.quickMode || rules.snakeMode) View.VISIBLE else View.GONE
        if (rules.snakeMode) {
            quickStatus.text = getString(R.string.ludo_snake_status, SnlTheme.of(difficulty).title)
        }
        render()
    }

    private fun startSnakeGame() {
        engine = null
        val colors = seatColors(playerCount)
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)

        val players = colors.mapIndexed { i, color ->
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            SnlPlayer("p${i + 1}", names[i], color, kind)
        }.toMutableList()

        val difficulty = chosenDifficulty()
        val newEngine = SnlEngine(
            players,
            SnlRules(difficulty = difficulty),
            DiceRoller(lucky = optLucky.isChecked)
        )
        snl = newEngine
        rolling = false
        busy = false

        snlBoard.onStep = { SoundFx.step() }
        snlBoard.difficulty = difficulty
        snlBoard.tokenArtId = stats.selected(CosmeticType.TOKEN_SKIN)
        snlBoard.setPieces(players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
        boardView.visibility = View.GONE
        snlBoard.visibility = View.VISIBLE

        showGameChrome(colors, names, players.map { it.kind }, players.map { 0 })
        quickStatus.visibility = View.VISIBLE
        quickStatus.text = SnlTheme.of(difficulty).title
        renderSnake()
    }

    override fun onPause() {
        super.onPause()
        stopTurnTimer()
    }

    /**
     * The in-game menu behind the three lines.
     *
     * Built from the same [SheetPanel] as every other screen in the game, so
     * it wears the same gold-on-navy and the same close button. It used to be
     * an Android list dialog, which looked like it had been borrowed from a
     * different app — and on a board like this that reads as unfinished.
     */
    private fun showMenu() {
        SheetPanel.open(this, overlayHost, getString(R.string.menu_title)) {
            primaryButton(getString(R.string.menu_resume)) { hidePanels() }
            secondaryButton(getString(R.string.menu_restart)) { hidePanels(); startGame() }
            secondaryButton(getString(R.string.rules_title)) { showRules() }
            secondaryButton(getString(R.string.nav_settings)) { showSettings() }
            secondaryButton(getString(R.string.set_sound)) {
                setSound(!stats.soundOn)
                notify(getString(if (stats.soundOn) R.string.sound_is_on else R.string.sound_is_off))
                showMenu()
            }
            secondaryButton(getString(R.string.menu_new)) {
                hidePanels()
                panelQuit.visibility = View.VISIBLE
            }
            gap(24f)
        }
    }

    private fun backToLobby() {
        engine = null
        snl = null
        rolling = false
        busy = false
        autoPlay = false
        undoStack.clear()
        stopTurnTimer()
        for ((_, slot) in slots) { stopBlink(slot.arrow); slot.timer.secondsLeft = null }
        gamePanel.visibility = View.GONE
        setupPanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        btnSound.visibility = View.GONE
        btnAuto.visibility = View.GONE
        btnUndo.visibility = View.GONE
        hideWin()
        hidePanels()
        lobbyPanel.visibility = View.VISIBLE
        showWallet()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            anyPanelOpen() -> { hidePanels(); panelQuit.visibility = View.GONE }
            winOverlay.visibility == View.VISIBLE -> { hideWin(); backToLobby() }
            gamePanel.visibility == View.VISIBLE -> panelQuit.visibility = View.VISIBLE
            setupPanel.visibility == View.VISIBLE -> backToLobby()
            else -> super.onBackPressed()
        }
    }

    // ---------- the ten-second turn clock ----------

    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            val left = (turnDeadline - System.currentTimeMillis()) / 1000f
            paintTimer(left.coerceAtLeast(0f))
            if (left <= 0f) {
                timerRunning = false
                paintTimer(null)
                onTurnTimedOut()
            } else {
                boardHost().postDelayed(this, 80)
            }
        }
    }

    private fun boardHost(): View = if (mode == GameMode.SNAKES) snlBoard else boardView

    private fun paintTimer(secondsLeft: Float?) {
        val active = activeColor()
        for ((color, slot) in slots) {
            slot.timer.secondsLeft = if (secondsLeft != null && color == active) secondsLeft else null
        }
    }

    private fun stopTurnTimer() {
        timerRunning = false
        timerKey = ""
        boardHost().removeCallbacks(timerTick)
        paintTimer(null)
    }

    private fun refreshTurnTimer() {
        if (!humanMustDecide()) {
            if (timerRunning || timerKey.isNotEmpty()) stopTurnTimer()
            return
        }
        val key = decisionKey()
        if (key != timerKey) {
            timerKey = key
            turnDeadline = System.currentTimeMillis() + TURN_MS
        }
        if (!timerRunning) {
            timerRunning = true
            boardHost().removeCallbacks(timerTick)
            boardHost().post(timerTick)
        }
    }

    private fun decisionKey(): String {
        val e = engine
        if (e != null) return "L${e.state.currentPlayerIndex}|${e.state.phase}|${e.state.pendingRolls.size}"
        val s = snl ?: return ""
        return "S${s.currentIndex}|${s.phase}|${s.lastRoll}"
    }

    private fun humanMustDecide(): Boolean {
        if (busy || rolling || autoPlay) return false
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind == PlayerKind.HUMAN
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind == PlayerKind.HUMAN
    }

    private fun activeColor(): PlayerColor? {
        val e = engine
        if (e != null) return if (e.state.phase == TurnPhase.GAME_OVER) null else e.state.currentPlayer.color
        val s = snl ?: return null
        return if (s.phase == SnlPhase.GAME_OVER) null else s.current.color
    }

    private fun onTurnTimedOut() {
        if (autoPlay) return
        autoPlay = true
        updateAutoButton()
        notify(getString(R.string.auto_took_over))
        if (mode == GameMode.SNAKES) renderSnake() else render()
    }

    private fun toggleAuto() {
        autoPlay = !autoPlay
        updateAutoButton()
        if (autoPlay) stopTurnTimer() else timerKey = ""
        if (mode == GameMode.SNAKES) renderSnake() else render()
    }

    /**
     * The little AUTO chip under the player's own avatar.
     *
     * Small and quiet when it is off, lit gold when Auto Play has the wheel —
     * which is the one moment it needs to be obvious, because that is when the
     * player will want to take it back.
     */
    private fun updateAutoButton() {
        btnAuto.setText(if (autoPlay) R.string.auto_on_short else R.string.auto_short)
        btnAuto.setTextColor(
            if (autoPlay) Color.rgb(0x2A, 0x1A, 0x00) else Color.rgb(0x8F, 0xB0, 0xE4)
        )
        btnAuto.setBackgroundResource(
            if (autoPlay) R.drawable.bg_toggle_on else R.drawable.bg_pill_dark
        )
        btnAuto.alpha = if (autoPlay) 1f else 0.8f
    }

    private fun automaticTurn(): Boolean {
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind != PlayerKind.HUMAN || autoPlay
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind != PlayerKind.HUMAN || autoPlay
    }

    /**
     * Whether something counts towards THIS phone's record.
     *
     * Seat one is the person whose profile this is. A computer's capture is not
     * their capture, and neither is one Auto Play made while they were away
     * from the phone — so neither feeds their missions or statistics.
     */
    private fun isLocal(playerId: String): Boolean = playerId == LOCAL_ID && !autoPlay

    // ---------- rolling ----------

    private fun handleRoll() {
        if (mode == GameMode.SNAKES) handleSnakeRoll() else handleLudoRoll()
    }

    private fun handleLudoRoll() {
        val e = engine ?: return
        if (rolling || busy || e.state.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[e.state.currentPlayer.color] ?: return
        val roller = e.state.currentPlayer.id

        rolling = true
        stopTurnTimer()
        clearChoice()
        val outcome = e.rollDice()
        bus.post(
            GameEventType.DICE_ROLLED, roller, isLocal(roller),
            value = outcome.value, mode = mode
        )
        SoundFx.diceRoll()
        buzz(28)
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            when {
                outcome.turnLostToThreeSixes -> {
                    // no message: the sound and the turn moving on say it
                    SoundFx.turnLost()
                    render()
                }
                outcome.mustRollAgain -> render()
                else -> onRollingFinished()
            }
        }
    }

    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.22f).scaleY(1.22f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    /**
     * Flickers random faces, then settles on the value the engine already
     * decided. The animation only reveals the result — it never changes it.
     */
    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int, onDone: () -> Unit) {
        if (remaining <= 0) {
            dice.value = finalValue
            onDone()
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue, onDone) }, 50)
    }

    private fun onRollingFinished() {
        val e = engine ?: return
        val moves = e.legalMoves()
        if (moves.isEmpty()) {
            e.passTurn()
            render()
            return
        }
        render()
        maybeAutoPlay()
    }

    private fun maybeAutoPlay() {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return
        if (automaticTurn()) { maybeRunAutomatic(); return }
        val moves = e.legalMoves()
        val distinctValues = e.state.pendingRolls.distinct()
        val distinctTokens = moves.map { it.token.id }.distinct()
        if (moves.size == 1 || (distinctTokens.size == 1 && distinctValues.size == 1)) {
            val only = moves.first()
            boardView.postDelayed({ playMove(only) }, 260)
        }
    }

    private fun handleTokenTap(token: Token) {
        val e = engine ?: return
        if (busy || rolling || autoPlay || e.state.phase != TurnPhase.AWAITING_MOVE) return

        val options = e.state.pendingRolls.distinct()
            .mapNotNull { value -> e.legalMovesFor(value).firstOrNull { it.token.id == token.id } }

        when {
            options.isEmpty() -> return
            options.size == 1 -> {
                clearChoice()
                playMove(options.first())
            }
            else -> {
                choiceTokenId = token.id
                boardView.showChoices(token.id, options.map { it.usedRoll })
            }
        }
    }

    private fun handleChoicePicked(value: Int) {
        val e = engine ?: return
        val tokenId = choiceTokenId ?: return
        val move = e.legalMovesFor(value).firstOrNull { it.token.id == tokenId } ?: return
        clearChoice()
        playMove(move)
    }

    private fun clearChoice() {
        choiceTokenId = null
        boardView.clearChoices()
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        if (busy) return
        clearChoice()
        stopTurnTimer()
        busy = true
        boardView.tappableTokenIds = emptySet()
        val mover = e.state.currentPlayer.id
        val moverIsHuman = e.state.currentPlayer.kind == PlayerKind.HUMAN && !autoPlay
        val local = isLocal(mover)

        // UNDO: photograph the board before the piece is committed.
        if (moverIsHuman) {
            undoStack.add(UndoPoint(GameSnapshot.of(e.state), stats.kills))
            while (undoStack.size > MAX_UNDO) undoStack.removeAt(0)
            updateUndoButton()
        }

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            val victimsBefore = move.capturesTokenIds.mapNotNull { id ->
                e.state.players.flatMap { p -> p.tokens.map { p to it } }
                    .firstOrNull { it.second.id == id }
                    ?.let { (owner, tok) -> Triple(tok.id, tok.color, tok.steps to owner.tokens.indexOf(tok)) }
            }

            val result = e.applyMove(move)

            // report what happened, once, in the order it happened
            bus.post(GameEventType.TOKEN_MOVED, mover, local, mode = mode)
            if (result.capturedTokens.isNotEmpty()) {
                bus.post(
                    GameEventType.TOKEN_CAPTURED, mover, local,
                    count = result.capturedTokens.size, mode = mode
                )
                if (local) repeat(result.capturedTokens.size) { stats.addKill() }
            }
            val reachedHome = move.finishesToken ||
                move.token.state == com.example.ludoroyale.model.TokenState.FINISHED
            if (reachedHome) {
                bus.post(GameEventType.TOKEN_HOME, mover, local, mode = mode)
                if (local) stats.tokensHome += 1
            }
            result.special?.let { sp ->
                val delta = kotlin.math.abs(sp.delta)
                bus.post(
                    if (sp.type == SpecialType.LADDER) GameEventType.LADDER_TRIGGERED
                    else GameEventType.SNAKE_TRIGGERED,
                    mover, local, value = delta, mode = mode
                )
            }
            if (result.arrow != null) {
                bus.post(GameEventType.ARROW_TRIGGERED, mover, local, mode = mode)
            }
            if (result.gameWon) {
                rollsLeftOnWinningMove = result.rollsLeft.size
                epic.noteRollsLeftOnWin(rollsLeftOnWinningMove)
            }

            val settle = {
                boardView.snapToState(e.state)
                if (result.gameWon) SoundFx.win() else SoundFx.tokenMove()
                busy = false
                render()
                maybeAutoPlay()
            }

            val afterCaptures = {
                if (victimsBefore.isNotEmpty()) {
                    SoundFx.capture()
                    buzz(45)
                    var pending = victimsBefore.size
                    for ((id, color, info) in victimsBefore) {
                        val (steps, slot) = info
                        boardView.flyHome(id, color, steps, slot) {
                            pending--
                            if (pending == 0) settle()
                        }
                    }
                } else settle()
            }

            if (result.unlockedHome) {
                SoundFx.magic()
                showUnlockBanner()
            }

            // a snake, a ladder or an arrow lights up, then carries the piece
            val special = result.special
            val specialFrom = result.specialFromSteps
            val specialTo = result.specialToSteps
            val arrow = result.arrow
            val arrowFrom = result.arrowFromSteps
            val arrowTo = result.arrowToSteps

            when {
                special != null && specialFrom != null && specialTo != null -> {
                    val isLadder = special.type == SpecialType.LADDER
                    boardView.setSpecialGlow(special.entryCell)
                    boardView.postDelayed({
                        if (isLadder) SoundFx.ladderClimb() else SoundFx.snakeSlide()
                        buzz(35)
                        boardView.rideSpecial(
                            move.token.id, move.token.color, specialFrom, specialTo, isLadder
                        ) {
                            boardView.setSpecialGlow(null)
                            afterCaptures()
                        }
                    }, SPECIAL_PAUSE_MS)
                }

                arrow != null && arrowFrom != null && arrowTo != null -> {
                    boardView.setSpecialGlow(arrow.cell)
                    boardView.postDelayed({
                        SoundFx.arrow()
                        buzz(30)
                        boardView.rideSpecial(
                            move.token.id, move.token.color, arrowFrom, arrowTo, true
                        ) {
                            boardView.setSpecialGlow(null)
                            afterCaptures()
                        }
                    }, SPECIAL_PAUSE_MS)
                }

                else -> afterCaptures()
            }
        }
    }

    private fun showUnlockBanner() {
        quickStatus.text = getString(R.string.quick_unlock_toast)
        quickStatus.scaleX = 0.8f
        quickStatus.scaleY = 0.8f
        quickStatus.animate().scaleX(1.12f).scaleY(1.12f).setDuration(220)
            .withEndAction { quickStatus.animate().scaleX(1f).scaleY(1f).setDuration(200).start() }
            .start()
        quickStatus.postDelayed({ refreshQuickStatus() }, 1300)
    }

    private fun refreshQuickStatus() {
        val e = engine ?: return
        if (quickStatus.visibility != View.VISIBLE) return
        if (mode == GameMode.LUDO_SNAKE) {
            quickStatus.text = getString(
                R.string.ludo_snake_status, SnlTheme.of(e.rules.snakeDifficulty).title
            )
            return
        }
        val p = if (e.state.phase == TurnPhase.GAME_OVER) e.state.players.firstOrNull()
                else e.state.currentPlayer
        quickStatus.text = getString(
            if (p?.hasCapturedOpponent == true) R.string.quick_unlocked else R.string.quick_locked
        )
    }

    // ---------- undo ----------

    private fun undoMove() {
        val e = engine ?: return
        if (busy || rolling) return
        if (winOverlay.visibility == View.VISIBLE || e.state.phase == TurnPhase.GAME_OVER) {
            notify(getString(R.string.undo_locked))
            return
        }
        if (undoStack.isEmpty()) {
            notify(getString(R.string.undo_none))
            return
        }

        val point = undoStack.removeAt(undoStack.size - 1)
        stopTurnTimer()
        clearChoice()
        point.board.restoreInto(e.state)
        stats.kills = point.kills

        autoPlay = false
        updateAutoButton()

        boardView.setSpecialGlow(null)
        boardView.snapToState(e.state)
        SoundFx.undo()
        buzz(25)
        notify(getString(R.string.undo_done))

        timerKey = ""
        updateUndoButton()
        render()
    }

    private fun updateUndoButton() {
        val available = mode != GameMode.SNAKES && undoStack.isNotEmpty() &&
            engine?.state?.phase != TurnPhase.GAME_OVER
        btnUndo.isClickable = available
        btnUndo.alpha = if (available) 0.95f else 0.35f
    }

    // ---------- computer players and Auto Play ----------

    private fun maybeRunAutomatic() {
        if (!automaticTurn() || busy || rolling) return
        val e = engine ?: return

        when (e.state.phase) {
            TurnPhase.AWAITING_ROLL -> boardView.postDelayed({
                if (automaticTurn() && !busy && !rolling) handleLudoRoll()
            }, 650)

            TurnPhase.AWAITING_MOVE -> boardView.postDelayed({
                if (!automaticTurn() || busy || rolling) return@postDelayed
                val moves = e.legalMoves()
                if (moves.isEmpty()) {
                    e.passTurn()
                    render()
                } else {
                    playMove(
                        LudoAI.chooseMove(
                            PlayerKind.AI_MEDIUM, moves, e.state,
                            needsKill = e.rules.quickMode && !e.state.currentPlayer.hasCapturedOpponent
                        )
                    )
                }
            }, 600)

            TurnPhase.GAME_OVER -> Unit
        }
    }

    private fun render() {
        val e = engine ?: return
        val s = e.state
        val gameOver = s.phase == TurnPhase.GAME_OVER
        val active = if (gameOver) null else s.currentPlayer.color
        markTurnOwner(if (gameOver) "" else s.currentPlayer.id)

        boardView.tappableTokenIds =
            if (!busy && !rolling && !autoPlay && s.phase == TurnPhase.AWAITING_MOVE)
                e.legalMoves().map { it.token.id }.toSet()
            else emptySet()

        paintSeats(active, s.phase == TurnPhase.AWAITING_ROLL)
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            renderRollsFor(color, slot, color == active)
        }

        val last = s.lastDiceRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        refreshQuickStatus()
        refreshTurnTimer()
        updateUndoButton()
        if (gameOver) {
            val champion = s.players.firstOrNull { it.id == s.rankings.firstOrNull() }
            finishMatch(
                winnerName = champion?.displayName ?: "",
                winnerId = champion?.id ?: "",
                winnerTeam = champion?.team ?: 0
            )
        } else {
            maybeRunAutomatic()
        }
    }

    private fun paintSeats(active: PlayerColor?, canRoll: Boolean) {
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == active
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable = isActive && !busy && !rolling && canRoll && !autoPlay

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }
        }
    }

    private fun renderRollsFor(color: PlayerColor, slot: Slot, isActive: Boolean) {
        slot.rolls.removeAllViews()
        val e = engine ?: return
        if (!isActive) return
        val rolls = e.state.pendingRolls
        if (rolls.isEmpty()) return

        val size = (30 * resources.displayMetrics.density).toInt()
        val gap = (3 * resources.displayMetrics.density).toInt()
        val skin = DiceSkins.resolve(stats.selected(CosmeticType.DICE_SKIN))
        rolls.forEach { value ->
            val chip = DiceView(this)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginStart = gap
            lp.marginEnd = gap
            chip.layoutParams = lp
            chip.skin = skin
            chip.value = value
            chip.accent = uiColor(color)
            chip.isClickable = false
            slot.rolls.addView(chip)
        }
    }

    // ---------- SNAKE & LADDER ----------

    private fun handleSnakeRoll() {
        val s = snl ?: return
        if (rolling || busy || s.phase != SnlPhase.AWAITING_ROLL) return
        val slot = slots[s.current.color] ?: return
        val roller = s.current.id

        rolling = true
        stopTurnTimer()
        val outcome = s.rollDice()
        bus.post(
            GameEventType.DICE_ROLLED, roller, isLocal(roller),
            value = outcome.value, mode = mode
        )
        SoundFx.diceRoll()
        buzz(28)
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            if (outcome.turnLostToThreeSixes) {
                SoundFx.turnLost()
                renderSnake()
            } else {
                playSnakeMove(outcome.value)
            }
        }
    }

    private fun playSnakeMove(value: Int) {
        val s = snl ?: return
        if (busy) return
        busy = true

        val from = s.current.cell
        val mover = s.current.id
        val local = isLocal(mover)
        val result = s.resolve(value)

        bus.post(GameEventType.TOKEN_MOVED, mover, local, mode = mode)
        if (result.cutPlayerIds.isNotEmpty()) {
            bus.post(
                GameEventType.TOKEN_CAPTURED, mover, local,
                count = result.cutPlayerIds.size, mode = mode
            )
            if (local) repeat(result.cutPlayerIds.size) { stats.addKill() }
        }
        result.special?.let { sp ->
            val delta = kotlin.math.abs(sp.delta)
            bus.post(
                if (sp.type == SpecialType.LADDER) GameEventType.LADDER_TRIGGERED
                else GameEventType.SNAKE_TRIGGERED,
                mover, local, value = delta, mode = mode
            )
        }
        if (result.won) {
            rollsLeftOnWinningMove = 0
            epic.noteRollsLeftOnWin(0)
        }

        val settle = {
            snlBoard.snapTo(s.players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
            busy = false
            renderSnake()
        }

        val afterCuts = {
            if (result.won) SoundFx.win() else SoundFx.tokenMove()
            settle()
        }

        if (result.blocked) {
            // no popup: the status line under the board carries it
            settle()
            return
        }

        snlBoard.hopAlong(result.playerId, s.walkPath(from, result.landedCell)) {
            val special = result.special
            if (special != null) {
                val isLadder = special.type == SpecialType.LADDER
                // The strike lands the instant the counter arrives — no pause
                // first. Being caught by a snake should feel like being caught.
                if (isLadder) SoundFx.ladderClimb() else SoundFx.snakeBite()
                buzz(if (isLadder) 35 else 60)
                snlBoard.setGlow(special.entryCell)
                snlBoard.postDelayed({
                    if (!isLadder) SoundFx.snakeSlide()
                    snlBoard.rideSpecial(result.playerId, special) {
                        snlBoard.setGlow(null)
                        afterCuts()
                    }
                }, if (isLadder) 90L else SNAKE_BITE_MS)
            } else {
                afterCuts()
            }
        }
    }

    private fun renderSnake() {
        val s = snl ?: return
        val gameOver = s.phase == SnlPhase.GAME_OVER
        val active = if (gameOver) null else s.current.color
        markTurnOwner(if (gameOver) "" else s.current.id)

        paintSeats(active, s.phase == SnlPhase.AWAITING_ROLL)
        for ((_, slot) in slots) slot.rolls.removeAllViews()

        val last = s.lastRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        if (!gameOver) {
            val p = s.current
            quickStatus.text = when {
                // the one thing a new player will not guess, said where they
                // are already looking rather than in a box over the board
                p.cell == 0 -> getString(R.string.snl_need_entry)
                else -> "${p.displayName} · ${p.cell} / ${SnlConfig.LAST_CELL}"
            }
        }

        refreshTurnTimer()
        if (gameOver) {
            val winner = s.players.firstOrNull { it.id == s.winnerId }
            finishMatch(
                winnerName = winner?.displayName ?: "",
                winnerId = winner?.id ?: "",
                winnerTeam = 0
            )
        } else {
            maybeRunAutomaticSnake()
        }
    }

    private fun maybeRunAutomaticSnake() {
        if (!automaticTurn() || busy || rolling) return
        val s = snl ?: return
        if (s.phase != SnlPhase.AWAITING_ROLL) return
        snlBoard.postDelayed({
            if (automaticTurn() && !busy && !rolling) handleSnakeRoll()
        }, 650)
    }

    // ---------- the end of a match ----------

    /**
     * Closes the match: reports it, works out what it was worth, pays for it
     * ONCE, and shows the result.
     *
     * [Stats.claimMatchPayout] is the gate. A finished match can reach this
     * method more than once — a re-render, a stray callback — and every one of
     * those must not be worth another hundred coins.
     */
    private fun finishMatch(winnerName: String, winnerId: String, winnerTeam: Int) {
        if (winOverlay.visibility == View.VISIBLE) return
        if (winnerId.isBlank()) return
        stopTurnTimer()

        val humanWon = winnerId == LOCAL_ID
        bus.post(GameEventType.MATCH_WON, winnerId, humanWon, mode = mode)
        bus.post(GameEventType.MATCH_COMPLETED, mode = mode)

        val firstTime = stats.claimMatchPayout(matchId)

        val xpBefore = stats.xp
        val levelBefore = stats.level()
        val pointsBefore = stats.leaguePoints
        val leagueBefore = stats.league()

        var xpEarned = 0
        var coinsEarned = 0
        var unlocked = listOf<CosmeticItem>()

        if (firstTime) {
            stats.recordMatch(mode, playerCount, teamsOn && playerCount == 4, humanWon)
            xpEarned = MatchRewards.xpFor(humanWon, tracker.captures, tracker.tokensHome)
            coinsEarned = MatchRewards.coinsFor(humanWon, stats.streak)
            stats.addXp(xpEarned)
            stats.addCoins(coinsEarned)
            unlocked = stats.unlocksBetween(levelBefore, stats.level())
            for (item in unlocked) stats.grant(item.id)
            stats.saveMissions(missions.missions)
        }

        val summary = MatchSummary(
            matchId = matchId,
            mode = mode,
            players = playerCount,
            teamMode = teamsOn && playerCount == 4,
            winnerName = if (winnerTeam != 0) {
                getString(R.string.team_name, if (winnerTeam == 1) "A" else "B")
            } else winnerName,
            winnerIsLocal = humanWon,
            durationMs = tracker.durationMs,
            captures = tracker.captures,
            tokensHome = tracker.tokensHome,
            diceRolls = tracker.diceRolls,
            snakeTriggers = tracker.snakeTriggers,
            ladderTriggers = tracker.ladderTriggers,
            arrowTriggers = tracker.arrowTriggers,
            xpEarned = xpEarned,
            coinsEarned = coinsEarned,
            xpBefore = xpBefore,
            xpAfter = stats.xp,
            levelBefore = levelBefore,
            levelAfter = stats.level(),
            winStreak = stats.streak,
            bestStreak = stats.bestStreak,
            leaguePointsBefore = pointsBefore,
            leaguePointsAfter = stats.leaguePoints,
            leagueBefore = leagueBefore,
            leagueAfter = stats.league(),
            epicMoments = epic.moments,
            missionsCompleted = missions.takeNewlyCompleted().map { it.describe() },
            unlocked = unlocked.map { it.name }
        )
        lastSummary = summary
        showVictory(summary)
    }

    private fun showVictory(summary: MatchSummary) {
        val d = resources.displayMetrics.density
        winTitle.text = if (summary.winnerIsLocal) {
            getString(R.string.victory)
        } else {
            getString(R.string.winner_is, summary.winnerName)
        }
        winSubtitle.text = "${summary.mode.display}  ·  ${summary.durationText()}"

        winBody.removeAllViews()

        fun heading(text: String, color: Int, size: Float) {
            winBody.addView(TextView(this).apply {
                this.text = text
                setTextColor(color)
                textSize = size
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (8 * d).toInt() }
            })
        }

        fun card(build: LinearLayout.() -> Unit) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_stat)
                val pad = (12 * d).toInt()
                setPadding(pad, pad, pad, pad)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (10 * d).toInt() }
            }
            box.build()
            winBody.addView(box)
        }

        fun LinearLayout.line(label: String, value: String, valueColor: Int = Color.WHITE) {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            row.addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(Color.rgb(0x9F, 0xB6, 0xDE))
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this@MainActivity).apply {
                text = value
                setTextColor(valueColor)
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })
            addView(row)
        }

        // ---- the win streak, when it is worth showing
        if (summary.winnerIsLocal && summary.winStreak >= 2) {
            heading(
                getString(R.string.streak_banner, streakText(summary.winStreak)),
                Color.rgb(0xFF, 0xC1, 0x4E), 20f
            )
        }

        // ---- what the match paid
        card {
            line(getString(R.string.xp_earned), "+${summary.xpEarned}", Color.rgb(0xFF, 0xE9, 0xA8))
            line(getString(R.string.coins_earned), "+${summary.coinsEarned}", Color.rgb(0xFF, 0xE9, 0xA8))
            val bar = XpBarView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (10 * d).toInt()
                ).apply { topMargin = (6 * d).toInt() }
            }
            addView(bar)
            bar.animateTo(
                Progression.progress(summary.xpBefore),
                Progression.progress(summary.xpAfter)
            )
            line(
                getString(R.string.stat_level),
                if (summary.leveledUp) "${summary.levelBefore} → ${summary.levelAfter}"
                else summary.levelAfter.toString(),
                if (summary.leveledUp) Color.rgb(0xFF, 0xC1, 0x4E) else Color.WHITE
            )
            line(
                getString(R.string.stat_league),
                if (summary.promoted) "${summary.leagueBefore.display} → ${summary.leagueAfter.display}"
                else summary.leagueAfter.display,
                if (summary.promoted) Color.rgb(0xFF, 0xC1, 0x4E) else Color.WHITE
            )
            line(
                getString(R.string.stat_points),
                "${summary.leaguePointsBefore} → ${summary.leaguePointsAfter}"
            )
        }

        // ---- what happened in it
        card {
            line(getString(R.string.stat_kills), summary.captures.toString())
            line(getString(R.string.stat_home), summary.tokensHome.toString())
            line(getString(R.string.stat_rolls), summary.diceRolls.toString())
            if (summary.ladderTriggers > 0) line(getString(R.string.stat_ladders), summary.ladderTriggers.toString())
            if (summary.snakeTriggers > 0) line(getString(R.string.stat_snakes), summary.snakeTriggers.toString())
            if (summary.arrowTriggers > 0) line(getString(R.string.stat_arrows), summary.arrowTriggers.toString())
            line(getString(R.string.stat_time), summary.durationText())
        }

        if (summary.epicMoments.isNotEmpty()) {
            heading(getString(R.string.epic_title), Color.rgb(0xFF, 0xB4, 0x5E), 15f)
            card {
                for (moment in summary.epicMoments) {
                    line("${moment.type.glyph}  ${moment.type.label}", "", Color.WHITE)
                }
            }
        }

        if (summary.missionsCompleted.isNotEmpty()) {
            heading(getString(R.string.missions_done), Color.rgb(0x6B, 0xD3, 0x8A), 15f)
            card {
                for (m in summary.missionsCompleted) line(m, "✓", Color.rgb(0x6B, 0xD3, 0x8A))
            }
        }

        if (summary.unlocked.isNotEmpty()) {
            heading(getString(R.string.unlocked_title), Color.rgb(0xFF, 0xC1, 0x4E), 15f)
            card {
                for (name in summary.unlocked) line(name, "🎁", Color.rgb(0xFF, 0xE9, 0xA8))
            }
        }

        btnShare.visibility = if (summary.winnerIsLocal) View.VISIBLE else View.GONE

        buzz(70)
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.animate().alpha(1f).setDuration(320).start()
        confetti.start()
        applyVictoryEffect()
        showWallet()

        if (summary.leveledUp) {
            winOverlay.postDelayed({ celebrateLevelUp(summary.levelBefore, summary.levelAfter) }, 700)
        }
    }

    /** The chosen victory effect decides how the celebration looks. */
    private fun applyVictoryEffect() {
        confetti.style = when (stats.selected(CosmeticType.VICTORY_EFFECT)) {
            Cosmetics.FX_GOLD_RAIN -> ConfettiView.Style.GOLD_RAIN
            Cosmetics.FX_FIREWORKS -> ConfettiView.Style.FIREWORKS
            Cosmetics.FX_ROYAL_CROWN -> ConfettiView.Style.ROYAL_CROWN
            else -> ConfettiView.Style.CONFETTI
        }
    }

    private fun shareVictory() {
        val summary = lastSummary ?: return
        val bitmap = VictoryCard.render(summary, stats.playerName)
        val uri = VictoryCard.save(this, bitmap)
        bitmap.recycle()
        if (uri == null) {
            notify(getString(R.string.share_failed))
            return
        }
        val intent = VictoryCard.shareIntent(uri, summary, stats.playerName)
        startActivity(android.content.Intent.createChooser(intent, getString(R.string.btn_share)))
    }

    private fun hideWin() {
        confetti.stop()
        winOverlay.visibility = View.GONE
    }

    // ---------- banners ----------

    private fun onEpicMoment(moment: EpicMoment) {
        showBanner("${moment.type.glyph}  ${moment.type.label}")
        SoundFx.magic()
        buzz(35)
    }

    private fun celebrateLevelUp(before: Int, after: Int) {
        SoundFx.win()
        buzz(60)
        showBanner(getString(R.string.level_up, before, after), 2200)
    }

    /**
     * A ribbon across the top of the screen for a moment.
     *
     * It never blocks anything: the board stays live underneath, and the turn
     * clock keeps running, so a celebration can never cost somebody their turn.
     */
    private fun showBanner(text: String, holdMs: Long = 1500) {
        banner.text = text
        banner.visibility = View.VISIBLE
        banner.animate().cancel()
        banner.alpha = 0f
        banner.scaleX = 0.7f
        banner.scaleY = 0.7f
        banner.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).start()
        banner.removeCallbacks(hideBanner)
        banner.postDelayed(hideBanner, holdMs)
    }

    private val hideBanner = Runnable {
        banner.animate().alpha(0f).setDuration(260)
            .withEndAction { banner.visibility = View.GONE }.start()
    }

    // ---------- shared chrome ----------

    private fun setSound(on: Boolean) {
        stats.soundOn = on
        SoundFx.enabled = on
        btnSound.text = getString(if (on) R.string.sound_on else R.string.sound_off)
        btnSound.alpha = if (on) 1f else 0.5f
    }

    /**
     * Plays the hand-over sound when, and only when, the turn actually moves
     * to a different player. Rolling again on a six is the same player's turn
     * and must stay silent, or the sound becomes noise.
     */
    private fun markTurnOwner(id: String) {
        if (id == lastTurnOwner) return
        val hadOne = lastTurnOwner.isNotEmpty()
        lastTurnOwner = id
        if (hadOne && id.isNotEmpty()) SoundFx.turnChange()
    }

    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    /**
     * Tells the player something, in the game's own voice.
     *
     * There are no Android toasts anywhere in this app any more. A toast is a
     * grey system box that lands on top of the board looking like it belongs
     * to the phone rather than the game, and during a match it is simply in
     * the way. Everything worth saying goes through the ribbon instead: it is
     * part of the board, it fades on its own, and it never blocks a tap.
     */
    private fun notify(message: String) {
        showBanner(message)
    }

    private companion object {
        /** Beat before a snake or ladder fires on the Ludo board. */
        const val SPECIAL_PAUSE_MS = 220L

        /** How long the strike is allowed to land before the counter slides. */
        const val SNAKE_BITE_MS = 200L
        const val BLINKING = "blinking"
        /** Every human decision is on a fifteen-second clock. */
        const val TURN_MS = 15_000L
        /** How many hand-played moves can be taken back. */
        const val MAX_UNDO = 12
        /** Seat one: the person whose phone this is. */
        const val LOCAL_ID = "p1"
    }
}
