package com.example.ludoroyale

import android.content.Context
import android.content.SharedPreferences

/**
 * Everything the game remembers about this player between sessions: their
 * name, coins, record and which dice they own. It is all local — nothing is
 * sent anywhere, and nothing here costs real money.
 */
class Stats(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ludo_masha", Context.MODE_PRIVATE)

    private fun int(key: String, def: Int = 0) = prefs.getInt(key, def)
    private fun put(key: String, value: Int) = prefs.edit().putInt(key, value).apply()

    var playerName: String
        get() = prefs.getString(KEY_NAME, "") ?: ""
        set(v) = prefs.edit().putString(KEY_NAME, v.trim().take(14)).apply()

    var coins: Int
        get() = int(KEY_COINS, 0)
        set(v) = put(KEY_COINS, v.coerceAtLeast(0))

    var gamesPlayed: Int
        get() = int(KEY_PLAYED); set(v) = put(KEY_PLAYED, v)

    var gamesWon: Int
        get() = int(KEY_WON); set(v) = put(KEY_WON, v)

    var wins2p: Int
        get() = int(KEY_W2); set(v) = put(KEY_W2, v)

    var wins4p: Int
        get() = int(KEY_W4); set(v) = put(KEY_W4, v)

    var winsTeam: Int
        get() = int(KEY_WT); set(v) = put(KEY_WT, v)

    var winsQuick: Int
        get() = int(KEY_WQ); set(v) = put(KEY_WQ, v)

    var winsSnake: Int
        get() = int(KEY_WS); set(v) = put(KEY_WS, v)

    var kills: Int
        get() = int(KEY_KILLS); set(v) = put(KEY_KILLS, v)

    var streak: Int
        get() = int(KEY_STREAK); set(v) = put(KEY_STREAK, v)

    var bestStreak: Int
        get() = int(KEY_BEST); set(v) = put(KEY_BEST, v)

    var vibration: Boolean
        get() = prefs.getBoolean(KEY_VIBRATE, true)
        set(v) = prefs.edit().putBoolean(KEY_VIBRATE, v).apply()

    var soundOn: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(v) = prefs.edit().putBoolean(KEY_SOUND, v).apply()

    var musicOn: Boolean
        get() = prefs.getBoolean(KEY_MUSIC, true)
        set(v) = prefs.edit().putBoolean(KEY_MUSIC, v).apply()

    /** Id of the dice face the player is using. */
    var activeDice: String
        get() = prefs.getString(KEY_DICE, DiceSkins.DEFAULT_ID) ?: DiceSkins.DEFAULT_ID
        set(v) = prefs.edit().putString(KEY_DICE, v).apply()

    private var ownedRaw: String
        get() = prefs.getString(KEY_OWNED, "") ?: ""
        set(v) = prefs.edit().putString(KEY_OWNED, v).apply()

    /** Dice the player owns. The free ones are always in the list. */
    fun owned(): Set<String> {
        val bought = ownedRaw.split(",").filter { it.isNotBlank() }
        return (DiceSkins.free() + bought).toSet()
    }

    fun owns(id: String) = id in owned()

    /** Spends the coins and unlocks the dice. Returns false if it is too dear. */
    fun buyDice(id: String): Boolean {
        val skin = DiceSkins.byId(id) ?: return false
        if (owns(id)) return true
        if (coins < skin.price) return false
        coins -= skin.price
        ownedRaw = (ownedRaw.split(",").filter { it.isNotBlank() } + id).distinct().joinToString(",")
        return true
    }

    /** A rank that climbs steadily as the player wins. */
    fun level(): Int = 1 + gamesWon / 3

    fun rankName(): String = when (level()) {
        1, 2 -> "Beginner"
        3, 4 -> "Player"
        5, 6, 7 -> "Sharp"
        8, 9, 10 -> "Expert"
        11, 12, 13, 14 -> "Master"
        else -> "Champion"
    }

    fun winRate(): Float =
        if (gamesPlayed == 0) 0f else gamesWon * 100f / gamesPlayed

    /** Call once when a match ends. [won] is whether THIS phone's player won. */
    fun recordResult(
        won: Boolean,
        players: Int,
        team: Boolean,
        quick: Boolean,
        snake: Boolean
    ): Int {
        gamesPlayed += 1
        if (!won) {
            streak = 0
            return 0
        }
        gamesWon += 1
        when {
            snake -> winsSnake += 1
            quick -> winsQuick += 1
            team -> winsTeam += 1
            players >= 4 -> wins4p += 1
            else -> wins2p += 1
        }
        streak += 1
        if (streak > bestStreak) bestStreak = streak
        val reward = WIN_COINS + (streak - 1) * STREAK_BONUS
        coins += reward
        return reward
    }

    fun addKill() {
        kills += 1
    }

    // ---------------------------------------------------- the daily chest

    /**
     * Which day it is here, counted from the phone's own clock and time zone.
     * Everything about the chest is local — there is no server, no account and
     * nothing to buy; it simply pays a few coins the first time the game is
     * opened each day, and pays a little more for coming back day after day.
     */
    private fun today(): Int {
        val now = System.currentTimeMillis()
        val offset = java.util.TimeZone.getDefault().getOffset(now)
        return ((now + offset) / 86_400_000L).toInt()
    }

    /** The day the chest was last collected, as [today] counts days. */
    private var lastChestDay: Int
        get() = int(KEY_CHEST_DAY, -1); set(v) = put(KEY_CHEST_DAY, v)

    /** How many days in a row the chest has been collected, 1..7. */
    var chestDay: Int
        get() = int(KEY_CHEST_STREAK, 0).coerceIn(0, CHEST_REWARDS.size)
        private set(v) = put(KEY_CHEST_STREAK, v)

    /** True when today's chest has not been opened yet. */
    fun chestReady(): Boolean = lastChestDay != today()

    /**
     * Which day of the run the chest is offering right now: 1..7. After a full
     * week the run starts over, and missing a day sends it back to day one.
     */
    fun chestDayOnOffer(): Int {
        if (!chestReady()) return chestDay.coerceAtLeast(1)
        val continues = lastChestDay == today() - 1 && chestDay in 1 until CHEST_REWARDS.size
        return if (continues) chestDay + 1 else 1
    }

    fun chestReward(day: Int): Int = CHEST_REWARDS[(day - 1).coerceIn(0, CHEST_REWARDS.size - 1)]

    /**
     * Opens today's chest and pays for it. Returns the coins added, or 0 if it
     * had already been opened today.
     */
    fun openChest(): Int {
        if (!chestReady()) return 0
        val day = chestDayOnOffer()
        chestDay = day
        lastChestDay = today()
        val reward = chestReward(day)
        coins += reward
        return reward
    }

    private companion object {
        const val KEY_NAME = "player_name"
        const val KEY_COINS = "coins"
        const val KEY_PLAYED = "games_played"
        const val KEY_WON = "games_won"
        const val KEY_W2 = "wins_2p"
        const val KEY_W4 = "wins_4p"
        const val KEY_WT = "wins_team"
        const val KEY_WQ = "wins_quick"
        const val KEY_WS = "wins_snake"
        const val KEY_KILLS = "kills"
        const val KEY_STREAK = "streak"
        const val KEY_BEST = "best_streak"
        const val KEY_VIBRATE = "vibration"
        const val KEY_SOUND = "sound_on"
        const val KEY_MUSIC = "music_on"
        const val KEY_DICE = "active_dice"
        const val KEY_OWNED = "owned_dice"
        const val KEY_CHEST_DAY = "chest_last_day"
        const val KEY_CHEST_STREAK = "chest_streak"

        /** Coins for a win, plus a little more for each win in a row. */
        const val WIN_COINS = 100
        const val STREAK_BONUS = 25

        /** What the chest pays on day one through day seven of a run. */
        val CHEST_REWARDS = intArrayOf(50, 60, 75, 90, 110, 140, 200)
    }
}
