package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Which picture a lobby card shows. All of it is drawn here, in code. */
enum class CardArt { TWO_PLAYERS, FOUR_PLAYERS, QUICK, SNAKE, TEAM, COMPUTER, ARROW }

/**
 * The little illustration on each lobby card — original artwork drawn with
 * plain shapes so it stays crisp on every screen and weighs nothing.
 */
class CardArtView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var kind: CardArt = CardArt.TWO_PLAYERS
        set(value) { field = value; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        color = Color.WHITE
    }

    private val red = Color.rgb(0xE5, 0x30, 0x35)
    private val green = Color.rgb(0x22, 0xA6, 0x4B)
    private val yellow = Color.rgb(0xFA, 0xBF, 0x16)
    private val blue = Color.rgb(0x16, 0x8D, 0xE8)

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = min(w, h)
        when (kind) {
            CardArt.TWO_PLAYERS -> twoPlayers(canvas, w, h, s)
            CardArt.FOUR_PLAYERS -> fourPlayers(canvas, w, h, s)
            CardArt.QUICK -> quick(canvas, w, h, s)
            CardArt.SNAKE -> snake(canvas, w, h, s)
            CardArt.TEAM -> team(canvas, w, h, s)
            CardArt.COMPUTER -> computer(canvas, w, h, s)
            CardArt.ARROW -> arrow(canvas, w, h, s)
        }
    }

    // ------------------------------------------------------------ the pieces

    /** The same lit dome the boards use, so the cards match the game. */
    private fun token(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        shadow.alpha = 70
        canvas.drawOval(RectF(cx - r * 0.9f, cy + r * 0.45f, cx + r * 0.9f, cy + r * 1.05f), shadow)

        fill.color = Color.rgb(0xFF, 0xFF, 0xFF)
        canvas.drawCircle(cx, cy, r * 1.12f, fill)
        fill.color = darken(color, 0.45f)
        canvas.drawCircle(cx, cy, r * 1.04f, fill)

        shade.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.4f, r * 1.7f,
            intArrayOf(lighten(color, 0.55f), color, darken(color, 0.3f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null

        fill.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * 0.58f, fill)
        fill.color = color
        canvas.drawPath(star(cx, cy, r * 0.48f), fill)

        shade.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.45f, r * 0.8f,
            Color.argb(150, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, shade)
        shade.shader = null
    }

    private fun star(cx: Float, cy: Float, outer: Float): Path {
        val p = Path()
        val inner = outer * 0.45f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -Math.PI / 2 + i * Math.PI / 5
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    /** A white die showing [pips], tipped slightly so it reads as an object. */
    private fun die(canvas: Canvas, cx: Float, cy: Float, size: Float, pips: Int, tilt: Float) {
        canvas.save()
        canvas.rotate(tilt, cx, cy)
        val half = size / 2f
        val box = RectF(cx - half, cy - half, cx + half, cy + half)

        shadow.alpha = 60
        canvas.drawRoundRect(
            RectF(box.left + size * 0.08f, box.top + size * 0.12f,
                  box.right + size * 0.08f, box.bottom + size * 0.12f),
            size * 0.22f, size * 0.22f, shadow
        )

        shade.shader = LinearGradient(
            box.left, box.top, box.right, box.bottom,
            Color.WHITE, Color.rgb(0xD7, 0xDF, 0xEA), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(box, size * 0.22f, size * 0.22f, shade)
        shade.shader = null
        stroke.color = Color.rgb(0x9A, 0xA8, 0xBD)
        stroke.strokeWidth = size * 0.05f
        canvas.drawRoundRect(box, size * 0.22f, size * 0.22f, stroke)

        fill.color = Color.rgb(0x22, 0x2C, 0x45)
        val r = size * 0.10f
        val o = size * 0.24f
        fun pip(dx: Float, dy: Float) = canvas.drawCircle(cx + dx, cy + dy, r, fill)
        when (pips) {
            1 -> pip(0f, 0f)
            2 -> { pip(-o, -o); pip(o, o) }
            3 -> { pip(-o, -o); pip(0f, 0f); pip(o, o) }
            4 -> { pip(-o, -o); pip(o, -o); pip(-o, o); pip(o, o) }
            5 -> { pip(-o, -o); pip(o, -o); pip(0f, 0f); pip(-o, o); pip(o, o) }
            else -> { pip(-o, -o); pip(o, -o); pip(-o, 0f); pip(o, 0f); pip(-o, o); pip(o, o) }
        }
        canvas.restore()
    }

    // ------------------------------------------------------------- the cards

    private fun twoPlayers(canvas: Canvas, w: Float, h: Float, s: Float) {
        val r = s * 0.20f
        token(canvas, w * 0.34f, h * 0.42f, r, red)
        token(canvas, w * 0.66f, h * 0.42f, r, blue)
        die(canvas, w * 0.5f, h * 0.76f, s * 0.30f, 5, -12f)
    }

    private fun fourPlayers(canvas: Canvas, w: Float, h: Float, s: Float) {
        val r = s * 0.155f
        token(canvas, w * 0.5f, h * 0.24f, r, green)
        token(canvas, w * 0.28f, h * 0.48f, r, red)
        token(canvas, w * 0.72f, h * 0.48f, r, yellow)
        token(canvas, w * 0.5f, h * 0.72f, r, blue)
    }

    private fun quick(canvas: Canvas, w: Float, h: Float, s: Float) {
        token(canvas, w * 0.38f, h * 0.55f, s * 0.20f, red)
        // a bolt, for the fast game
        val p = Path()
        val bx = w * 0.68f
        val by = h * 0.28f
        val u = s * 0.26f
        p.moveTo(bx, by)
        p.lineTo(bx - u * 0.55f, by + u * 1.1f)
        p.lineTo(bx - u * 0.05f, by + u * 1.1f)
        p.lineTo(bx - u * 0.45f, by + u * 2.2f)
        p.lineTo(bx + u * 0.75f, by + u * 0.85f)
        p.lineTo(bx + u * 0.18f, by + u * 0.85f)
        p.lineTo(bx + u * 0.55f, by)
        p.close()
        shade.shader = LinearGradient(
            bx, by, bx, by + u * 2.2f,
            Color.rgb(0xFF, 0xEE, 0x9C), Color.rgb(0xF5, 0xA1, 0x12), Shader.TileMode.CLAMP
        )
        canvas.drawPath(p, shade)
        shade.shader = null
        stroke.color = Color.rgb(0x8A, 0x54, 0x06)
        stroke.strokeWidth = s * 0.030f
        canvas.drawPath(p, stroke)
    }

    private fun snake(canvas: Canvas, w: Float, h: Float, s: Float) {
        // ladder on the left
        val lx = w * 0.28f
        val topY = h * 0.16f
        val bottomY = h * 0.88f
        val half = s * 0.13f
        stroke.color = Color.rgb(0x6E, 0x42, 0x15)
        stroke.strokeWidth = s * 0.075f
        canvas.drawLine(lx - half, bottomY, lx - half + s * 0.05f, topY, stroke)
        canvas.drawLine(lx + half, bottomY, lx + half + s * 0.05f, topY, stroke)
        stroke.color = Color.rgb(0xC9, 0x8E, 0x4C)
        stroke.strokeWidth = s * 0.048f
        canvas.drawLine(lx - half, bottomY, lx - half + s * 0.05f, topY, stroke)
        canvas.drawLine(lx + half, bottomY, lx + half + s * 0.05f, topY, stroke)
        for (i in 1..4) {
            val t = i / 5f
            val y = bottomY + (topY - bottomY) * t
            val dx = s * 0.05f * t
            stroke.color = Color.rgb(0x6E, 0x42, 0x15)
            stroke.strokeWidth = s * 0.055f
            canvas.drawLine(lx - half + dx, y, lx + half + dx, y, stroke)
            stroke.color = Color.rgb(0xD9, 0xA2, 0x5E)
            stroke.strokeWidth = s * 0.032f
            canvas.drawLine(lx - half + dx, y, lx + half + dx, y, stroke)
        }

        // a real snake on the right: tapered body, wedge head, forked tongue
        val spine = ArrayList<FloatArray>(41)
        val p0x = w * 0.74f; val p0y = h * 0.16f
        val c1x = w * 1.02f; val c1y = h * 0.38f
        val c2x = w * 0.50f; val c2y = h * 0.58f
        val p3x = w * 0.74f; val p3y = h * 0.78f
        for (i in 0..40) {
            val t = i / 40f
            val mt = 1f - t
            val x = mt * mt * mt * p0x + 3 * mt * mt * t * c1x + 3 * mt * t * t * c2x + t * t * t * p3x
            val y = mt * mt * mt * p0y + 3 * mt * mt * t * c1y + 3 * mt * t * t * c2y + t * t * t * p3y
            spine += floatArrayOf(x, y)
        }
        // carry on into a fine tail
        for (i in 1..14) {
            val t = i / 14f
            spine += floatArrayOf(
                p3x - s * 0.34f * t + s * 0.10f * sin(t * 3.4f),
                p3y + s * 0.42f * t
            )
        }

        val maxW = s * 0.19f
        val body = Path()
        val leftSide = ArrayList<FloatArray>(spine.size)
        val rightSide = ArrayList<FloatArray>(spine.size)
        for (i in spine.indices) {
            val a = spine[if (i == 0) 0 else i - 1]
            val b = spine[if (i == spine.lastIndex) i else i + 1]
            val tx = b[0] - a[0]
            val ty = b[1] - a[1]
            val tl = kotlin.math.hypot(tx, ty).coerceAtLeast(0.0001f)
            val nx = -ty / tl
            val ny = tx / tl
            val t = i.toFloat() / spine.lastIndex
            val halfW = maxW * (1f - t * t * 0.96f).coerceAtLeast(0f) / 2f
            leftSide += floatArrayOf(spine[i][0] + nx * halfW, spine[i][1] + ny * halfW)
            rightSide += floatArrayOf(spine[i][0] - nx * halfW, spine[i][1] - ny * halfW)
        }
        body.moveTo(leftSide[0][0], leftSide[0][1])
        for (i in 1 until leftSide.size) body.lineTo(leftSide[i][0], leftSide[i][1])
        for (i in rightSide.indices.reversed()) body.lineTo(rightSide[i][0], rightSide[i][1])
        body.close()

        val base = Color.rgb(0x2C, 0x9B, 0x46)
        val darkGreen = Color.rgb(0x0C, 0x40, 0x1C)
        fill.color = base
        canvas.drawPath(body, fill)

        canvas.save()
        canvas.clipPath(body)
        // belly highlight and dorsal shade give the body its roundness
        val bellyLine = Path()
        for (i in spine.indices) {
            if (i == 0) bellyLine.moveTo(leftSide[i][0], leftSide[i][1])
            else bellyLine.lineTo(leftSide[i][0], leftSide[i][1])
        }
        stroke.color = Color.argb(200, 0xD6, 0xE4, 0x96)
        stroke.strokeWidth = maxW * 0.34f
        canvas.drawPath(bellyLine, stroke)

        val backLine = Path()
        for (i in spine.indices) {
            if (i == 0) backLine.moveTo(rightSide[i][0], rightSide[i][1])
            else backLine.lineTo(rightSide[i][0], rightSide[i][1])
        }
        stroke.color = Color.argb(160, 0x0C, 0x40, 0x1C)
        canvas.drawPath(backLine, stroke)

        // saddle markings
        fill.color = Color.argb(210, 0x10, 0x4A, 0x20)
        var i = 4
        while (i < spine.size - 6) {
            val a = spine[i - 1]
            val b = spine[i + 1]
            val ang = Math.toDegrees(kotlin.math.atan2((b[1] - a[1]).toDouble(), (b[0] - a[0]).toDouble())).toFloat()
            val t = i.toFloat() / spine.lastIndex
            val hw = maxW * (1f - t * t * 0.96f).coerceAtLeast(0f) / 2f
            canvas.save()
            canvas.translate(spine[i][0], spine[i][1])
            canvas.rotate(ang)
            canvas.drawOval(RectF(-hw * 0.5f, -hw * 0.9f, hw * 0.5f, hw * 0.9f), fill)
            canvas.restore()
            i += 6
        }
        canvas.restore()

        stroke.color = darkGreen
        stroke.strokeWidth = s * 0.022f
        canvas.drawPath(body, stroke)

        // head
        val a0 = spine[0]
        val a1 = spine[2]
        val ang = kotlin.math.atan2((a0[1] - a1[1]), (a0[0] - a1[0]))
        val hl = maxW * 1.25f
        val hw2 = maxW * 0.70f
        val cA = cos(ang)
        val sA = sin(ang)
        fun hx(x: Float, y: Float) = a0[0] + x * cA - y * sA
        fun hy(x: Float, y: Float) = a0[1] + x * sA + y * cA

        stroke.color = Color.rgb(0xCE, 0x20, 0x30)
        stroke.strokeWidth = s * 0.020f
        canvas.drawLine(hx(hl * 0.9f, 0f), hy(hl * 0.9f, 0f), hx(hl * 1.6f, 0f), hy(hl * 1.6f, 0f), stroke)
        canvas.drawLine(hx(hl * 1.6f, 0f), hy(hl * 1.6f, 0f), hx(hl * 2.0f, -hw2 * 0.5f), hy(hl * 2.0f, -hw2 * 0.5f), stroke)
        canvas.drawLine(hx(hl * 1.6f, 0f), hy(hl * 1.6f, 0f), hx(hl * 2.0f, hw2 * 0.5f), hy(hl * 2.0f, hw2 * 0.5f), stroke)

        val head = Path()
        head.moveTo(hx(hl, 0f), hy(hl, 0f))
        head.cubicTo(
            hx(hl * 0.88f, -hw2 * 0.52f), hy(hl * 0.88f, -hw2 * 0.52f),
            hx(hl * 0.50f, -hw2 * 0.98f), hy(hl * 0.50f, -hw2 * 0.98f),
            hx(hl * 0.02f, -hw2), hy(hl * 0.02f, -hw2)
        )
        head.cubicTo(
            hx(-hl * 0.34f, -hw2 * 1.02f), hy(-hl * 0.34f, -hw2 * 1.02f),
            hx(-hl * 0.62f, -hw2 * 0.78f), hy(-hl * 0.62f, -hw2 * 0.78f),
            hx(-hl * 0.72f, -hw2 * 0.56f), hy(-hl * 0.72f, -hw2 * 0.56f)
        )
        head.lineTo(hx(-hl * 0.72f, hw2 * 0.56f), hy(-hl * 0.72f, hw2 * 0.56f))
        head.cubicTo(
            hx(-hl * 0.62f, hw2 * 0.78f), hy(-hl * 0.62f, hw2 * 0.78f),
            hx(-hl * 0.34f, hw2 * 1.02f), hy(-hl * 0.34f, hw2 * 1.02f),
            hx(hl * 0.02f, hw2), hy(hl * 0.02f, hw2)
        )
        head.cubicTo(
            hx(hl * 0.50f, hw2 * 0.98f), hy(hl * 0.50f, hw2 * 0.98f),
            hx(hl * 0.88f, hw2 * 0.52f), hy(hl * 0.88f, hw2 * 0.52f),
            hx(hl, 0f), hy(hl, 0f)
        )
        head.close()

        shade.shader = LinearGradient(
            hx(0f, -hw2), hy(0f, -hw2), hx(0f, hw2), hy(0f, hw2),
            intArrayOf(lighten(base, 0.30f), base, darken(base, 0.30f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(head, shade)
        shade.shader = null
        stroke.color = darkGreen
        stroke.strokeWidth = s * 0.022f
        canvas.drawPath(head, stroke)

        for (sg in intArrayOf(-1, 1)) {
            val ex = hx(hl * 0.24f, sg * hw2 * 0.52f)
            val ey = hy(hl * 0.24f, sg * hw2 * 0.52f)
            canvas.save()
            canvas.translate(ex, ey)
            canvas.rotate(Math.toDegrees(ang.toDouble()).toFloat())
            fill.color = Color.WHITE
            canvas.drawOval(RectF(-hw2 * 0.30f, -hw2 * 0.24f, hw2 * 0.30f, hw2 * 0.24f), fill)
            fill.color = Color.rgb(0xF4, 0xCE, 0x4A)
            canvas.drawOval(RectF(-hw2 * 0.22f, -hw2 * 0.18f, hw2 * 0.22f, hw2 * 0.18f), fill)
            fill.color = Color.BLACK
            canvas.drawOval(RectF(-hw2 * 0.055f, -hw2 * 0.15f, hw2 * 0.055f, hw2 * 0.15f), fill)
            canvas.restore()
        }
    }

    private fun team(canvas: Canvas, w: Float, h: Float, s: Float) {
        val r = s * 0.155f
        token(canvas, w * 0.20f, h * 0.38f, r, red)
        token(canvas, w * 0.34f, h * 0.58f, r, yellow)
        token(canvas, w * 0.66f, h * 0.38f, r, blue)
        token(canvas, w * 0.80f, h * 0.58f, r, green)

        text.textSize = s * 0.26f
        val cx = w * 0.5f
        val cy = h * 0.52f
        fill.color = Color.rgb(0x1B, 0x28, 0x4A)
        canvas.drawCircle(cx, cy, s * 0.19f, fill)
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawCircle(cx, cy, s * 0.16f, fill)
        text.color = Color.rgb(0x1B, 0x28, 0x4A)
        canvas.drawText("VS", cx, cy + s * 0.09f, text)
        text.color = Color.WHITE
    }

    private fun computer(canvas: Canvas, w: Float, h: Float, s: Float) {
        token(canvas, w * 0.30f, h * 0.50f, s * 0.175f, red)

        // a friendly little machine, drawn from scratch
        val bw = s * 0.42f
        val bh = s * 0.36f
        val cx = w * 0.68f
        val cy = h * 0.52f
        val body = RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)

        shadow.alpha = 65
        canvas.drawRoundRect(
            RectF(body.left + s * 0.03f, body.top + s * 0.05f, body.right + s * 0.03f, body.bottom + s * 0.05f),
            s * 0.11f, s * 0.11f, shadow
        )
        shade.shader = LinearGradient(
            body.left, body.top, body.left, body.bottom,
            Color.rgb(0xCF, 0xDC, 0xEE), Color.rgb(0x8D, 0x9F, 0xBC), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(body, s * 0.11f, s * 0.11f, shade)
        shade.shader = null
        stroke.color = Color.rgb(0x39, 0x46, 0x66)
        stroke.strokeWidth = s * 0.032f
        canvas.drawRoundRect(body, s * 0.11f, s * 0.11f, stroke)

        // screen face
        val face = RectF(cx - bw * 0.32f, cy - bh * 0.26f, cx + bw * 0.32f, cy + bh * 0.20f)
        fill.color = Color.rgb(0x16, 0x2A, 0x4C)
        canvas.drawRoundRect(face, s * 0.05f, s * 0.05f, fill)
        fill.color = Color.rgb(0x5F, 0xE2, 0xD0)
        canvas.drawCircle(face.centerX() - bw * 0.14f, face.centerY() - bh * 0.02f, s * 0.035f, fill)
        canvas.drawCircle(face.centerX() + bw * 0.14f, face.centerY() - bh * 0.02f, s * 0.035f, fill)
        stroke.color = Color.rgb(0x5F, 0xE2, 0xD0)
        stroke.strokeWidth = s * 0.022f
        canvas.drawLine(
            face.centerX() - bw * 0.12f, face.bottom - bh * 0.07f,
            face.centerX() + bw * 0.12f, face.bottom - bh * 0.07f, stroke
        )

        // antenna
        stroke.color = Color.rgb(0x39, 0x46, 0x66)
        stroke.strokeWidth = s * 0.028f
        canvas.drawLine(cx, body.top, cx, body.top - s * 0.11f, stroke)
        fill.color = Color.rgb(0xF2, 0xC1, 0x4E)
        canvas.drawCircle(cx, body.top - s * 0.14f, s * 0.045f, fill)
    }

    /** A token riding a feathered dart — the picture for ARROW MODE. */
    private fun arrow(canvas: Canvas, w: Float, h: Float, s: Float) {
        val cy = h * 0.52f
        val len = s * 0.40f
        val cx = w * 0.56f

        // the dart, drawn the same way the board draws a straight arrow
        stroke.color = Color.rgb(0x2B, 0x36, 0x4C)
        stroke.strokeWidth = s * 0.085f
        canvas.drawLine(cx - len, cy, cx + len * 0.55f, cy, stroke)
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.08f, cy - s * 0.22f, stroke)
        canvas.drawLine(cx + len * 0.55f, cy, cx + len * 0.08f, cy + s * 0.22f, stroke)
        stroke.strokeWidth = s * 0.062f
        for (i in 0 until 3) {
            val x = cx - len + i * s * 0.14f
            canvas.drawLine(x, cy - s * 0.19f, x + s * 0.12f, cy, stroke)
            canvas.drawLine(x, cy + s * 0.19f, x + s * 0.12f, cy, stroke)
        }

        // a solid home arrow above it, in the player's colour
        val hy = h * 0.24f
        val p = Path()
        val hl = s * 0.30f
        val hh = s * 0.16f
        p.moveTo(cx + hl, hy)
        p.lineTo(cx + hl - hh, hy - hh)
        p.lineTo(cx + hl - hh, hy - hh * 0.42f)
        p.lineTo(cx - hl, hy - hh * 0.42f)
        p.lineTo(cx - hl, hy + hh * 0.42f)
        p.lineTo(cx + hl - hh, hy + hh * 0.42f)
        p.lineTo(cx + hl - hh, hy + hh)
        p.close()
        fill.color = yellow
        canvas.drawPath(p, fill)
        stroke.color = darken(yellow, 0.45f)
        stroke.strokeWidth = s * 0.028f
        canvas.drawPath(p, stroke)

        token(canvas, w * 0.24f, h * 0.78f, s * 0.19f, red)
    }
}
