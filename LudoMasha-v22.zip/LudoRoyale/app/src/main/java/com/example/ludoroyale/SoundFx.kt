package com.example.ludoroyale

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Original sound effects synthesised on the fly and written straight into an
 * AudioTrack — no audio files are bundled and nothing is copied from anywhere.
 *
 * The dice is the important one: a real dice roll is not a beep, it is a run of
 * forty-odd little wooden knocks in the low-middle of the range that thin out
 * as the dice settles. That is exactly how [diceRoll] is built — short bursts
 * of band-limited noise, randomly spaced, under a decaying envelope.
 *
 * There is no background music. The game is quiet between actions on purpose.
 */
object SoundFx {

    private const val RATE = 22050
    private val exec = Executors.newSingleThreadExecutor()
    private val rnd = Random(System.nanoTime())

    var enabled: Boolean = true

    // ------------------------------------------------------------- the sounds

    /** Forty-odd wooden knocks thinning out as the dice settles. */
    fun diceRoll() {
        val ms = 520
        val buf = DoubleArray(RATE * ms / 1000)
        var at = 0.0
        while (at < ms - 30) {
            val t = at / ms
            // knocks start busy and thin out towards the end
            val level = (1.0 - t * 0.78) * (0.55 + rnd.nextDouble() * 0.45)
            val low = 190.0 + rnd.nextDouble() * 120.0
            val high = 620.0 + rnd.nextDouble() * 420.0
            knock(buf, at, 16.0 + rnd.nextDouble() * 10.0, low, high, 0.42 * level, decay = 9.0)
            at += 7.0 + rnd.nextDouble() * 11.0
        }
        // the dice comes to rest with one firmer tap
        knock(buf, (ms - 34).toDouble(), 32.0, 150.0, 720.0, 0.55, decay = 7.0)
        render(buf)
    }

    /** One crisp tick as a piece hops a square. */
    fun step() {
        val buf = DoubleArray(RATE * 40 / 1000)
        knock(buf, 0.0, 34.0, 1800.0, 7200.0, 0.30, decay = 11.0)
        render(buf)
    }

    /** The softer knock when a piece settles at the end of its move. */
    fun tokenMove() {
        val buf = DoubleArray(RATE * 70 / 1000)
        knock(buf, 0.0, 60.0, 420.0, 2300.0, 0.34, decay = 8.0)
        render(buf)
    }

    /** A hard clack, then a short drop — something just got sent home. */
    fun capture() {
        val buf = DoubleArray(RATE * 340 / 1000)
        knock(buf, 0.0, 70.0, 260.0, 4200.0, 0.52, decay = 7.0)
        tone(buf, 60.0, 190.0, 520.0, 0.30, endFreq = 190.0)
        render(buf)
    }

    /** Wind under the piece as an arrow carries it. */
    fun arrow() {
        val ms = 300
        val buf = DoubleArray(RATE * ms / 1000)
        var at = 0.0
        while (at < ms - 40) {
            val t = at / ms
            val centre = 500.0 + 3400.0 * t
            knock(buf, at, 46.0, centre * 0.55, centre * 1.7, 0.16 * (1.0 - t * 0.35), decay = 3.2)
            at += 14.0
        }
        tone(buf, 40.0, 240.0, 520.0, 0.16, endFreq = 1500.0)
        render(buf)
    }

    /** Rungs going by, one after another. */
    fun ladderClimb() {
        val buf = DoubleArray(RATE * 380 / 1000)
        for (i in 0 until 6) {
            knock(buf, i * 58.0, 46.0, 500.0 + i * 180.0, 2400.0 + i * 500.0, 0.26, decay = 7.0)
        }
        render(buf)
    }

    /** A long slide down. */
    fun snakeSlide() {
        val buf = DoubleArray(RATE * 460 / 1000)
        tone(buf, 0.0, 420.0, 900.0, 0.30, endFreq = 180.0)
        var at = 0.0
        while (at < 400) {
            knock(buf, at, 40.0, 240.0, 1500.0, 0.10, decay = 4.0)
            at += 26.0
        }
        render(buf)
    }

    /** Small sparkle for a bonus. */
    fun magic() {
        val buf = DoubleArray(RATE * 340 / 1000)
        tone(buf, 0.0, 90.0, 880.0, 0.26)
        tone(buf, 70.0, 90.0, 1175.0, 0.24)
        tone(buf, 140.0, 140.0, 1568.0, 0.22)
        render(buf)
    }

    /** Short fanfare. */
    fun win() {
        val buf = DoubleArray(RATE * 780 / 1000)
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
        notes.forEachIndexed { i, f ->
            tone(buf, i * 150.0, if (i == 3) 300.0 else 170.0, f, 0.30)
        }
        render(buf)
    }

    /** Two low taps — the turn is gone. */
    fun turnLost() {
        val buf = DoubleArray(RATE * 380 / 1000)
        tone(buf, 0.0, 150.0, 330.0, 0.28, endFreq = 247.0)
        tone(buf, 170.0, 190.0, 247.0, 0.26, endFreq = 165.0)
        render(buf)
    }

    /** A brief roll of the table as the match opens. */
    fun gameStart() {
        val buf = DoubleArray(RATE * 460 / 1000)
        tone(buf, 0.0, 130.0, 392.0, 0.26)
        tone(buf, 120.0, 130.0, 523.25, 0.26)
        tone(buf, 240.0, 200.0, 659.25, 0.28)
        render(buf)
    }

    // ------------------------------------------------------------- synthesis

    /**
     * A short burst of band-limited noise — one knock of wood on wood. The two
     * one-pole filters in series keep the energy between [lowHz] and [highHz],
     * which is what makes it read as a knock rather than a hiss.
     */
    private fun knock(
        buf: DoubleArray,
        atMs: Double,
        lenMs: Double,
        lowHz: Double,
        highHz: Double,
        vol: Double,
        decay: Double
    ) {
        val start = (atMs * RATE / 1000.0).toInt()
        val len = (lenMs * RATE / 1000.0).toInt()
        if (start >= buf.size || len <= 0) return
        val aLp = 1.0 - exp(-2.0 * PI * highHz / RATE)
        val aHp = 1.0 - exp(-2.0 * PI * lowHz / RATE)
        var lp = 0.0
        var hp = 0.0
        val end = min(buf.size, start + len)
        for (i in start until end) {
            val white = rnd.nextDouble() * 2.0 - 1.0
            lp += (white - lp) * aLp
            hp += (lp - hp) * aHp
            val band = lp - hp
            val k = (i - start).toDouble() / len
            buf[i] += band * exp(-decay * k) * vol
        }
    }

    /** A plain tone, optionally sliding to [endFreq]. */
    private fun tone(
        buf: DoubleArray,
        atMs: Double,
        lenMs: Double,
        freq: Double,
        vol: Double,
        endFreq: Double = -1.0
    ) {
        val start = (atMs * RATE / 1000.0).toInt()
        val len = (lenMs * RATE / 1000.0).toInt()
        if (start >= buf.size || len <= 0) return
        val end = min(buf.size, start + len)
        var phase = 0.0
        for (i in start until end) {
            val k = (i - start).toDouble() / len
            val f = if (endFreq > 0) freq + (endFreq - freq) * k else freq
            phase += 2.0 * PI * f / RATE
            // quick attack, smooth tail, so nothing clicks at the edges
            val env = if (k < 0.06) k / 0.06 else exp(-3.2 * (k - 0.06))
            buf[i] += sin(phase) * env * vol
        }
    }

    private fun render(buf: DoubleArray) {
        if (!enabled) return
        exec.execute {
            try {
                val pcm = ShortArray(buf.size)
                for (i in buf.indices) {
                    val v = buf[i].coerceIn(-1.0, 1.0)
                    pcm[i] = (v * 32767).toInt().toShort()
                }
                val bytes = pcm.size * 2
                if (bytes <= 0) return@execute
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(pcm, 0, pcm.size)
                track.setNotificationMarkerPosition(pcm.size)
                track.setPlaybackPositionUpdateListener(
                    object : AudioTrack.OnPlaybackPositionUpdateListener {
                        override fun onMarkerReached(t: AudioTrack?) {
                            try { t?.stop(); t?.release() } catch (_: Exception) {}
                        }
                        override fun onPeriodicNotification(t: AudioTrack?) = Unit
                    }
                )
                track.play()
            } catch (_: Exception) {
                // audio is a nicety — never let it take the game down
            }
        }
    }
}
