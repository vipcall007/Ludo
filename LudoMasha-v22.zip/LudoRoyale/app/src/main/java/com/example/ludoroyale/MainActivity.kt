package com.example.ludoroyale

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Toast
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.engine.DiceRoller
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState
import com.example.ludoroyale.snl.SnlBoardView
import com.example.ludoroyale.snl.SnlConfig
import com.example.ludoroyale.snl.SnlEngine
import com.example.ludoroyale.snl.SnlPhase
import com.example.ludoroyale.snl.SnlPlayer
import com.example.ludoroyale.snl.SnlRules

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 *
 * The lobby leads to a short match setup and then the table. CLASSIC, QUICK
 * and TEAM play on the Ludo board; SNAKES & LADDERS plays on its own 1..100
 * board. Seats, dice, the ten-second turn clock and Auto Play work the same on
 * both. Coins, record and unlocked dice are kept on the phone by [Stats].
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val avatar: ImageView,
        val dice: DiceView,
        val arrow: View,
        val rolls: LinearLayout,
        val timer: TurnTimerRing
    )

    private lateinit var stats: Stats

    private lateinit var boardView: LudoBoardView
    private lateinit var snlBoard: SnlBoardView
    private lateinit var lobbyPanel: View
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var btnMenu: View
    private lateinit var btnSound: TextView
    private lateinit var btnAuto: TextView
    private lateinit var winOverlay: View
    private lateinit var winTitle: TextView
    private lateinit var quickStatus: TextView
    private lateinit var confetti: ConfettiView

    private lateinit var snakeDiffRow: View
    private lateinit var snakeDiffGroup: RadioGroup
    private lateinit var matchTitle: TextView
    private lateinit var modeHint: TextView
    private lateinit var countRow: View
    private lateinit var pills: List<TextView>
    private lateinit var optLucky: CheckBox
    private lateinit var optBots: CheckBox
    private lateinit var nameFields: List<EditText>

    private lateinit var lobbyCoins: TextView
    private lateinit var lobbyLevel: TextView

    // overlay panels
    private lateinit var panelProfile: View
    private lateinit var panelSettings: View
    private lateinit var panelDice: View
    private lateinit var panelQuit: View
    private lateinit var statsGrid: LinearLayout
    private lateinit var profileRank: TextView
    private lateinit var profileName: TextView
    private lateinit var toggleSound: TextView
    private lateinit var toggleVibration: TextView
    private lateinit var settingsName: EditText
    private lateinit var settingsAbout: TextView
    private lateinit var diceGrid: LinearLayout
    private lateinit var diceActivePreview: DiceView
    private lateinit var diceActiveName: TextView
    private lateinit var diceCoins: TextView

    private var engine: LudoEngine? = null
    private var snl: SnlEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()
    private enum class Mode { CLASSIC, QUICK, SNAKES, ARROW }
    private var mode = Mode.CLASSIC
    private var playerCount = 2
    private var teamsOn = false
    private var rolling = false
    private var choiceTokenId: String? = null
    private var busy = false
    private var resultRecorded = false

    /** Auto Play: once on, it stays on until the player takes control back. */
    private var autoPlay = false
    private var turnDeadline = 0L
    private var timerKey = ""
    private var timerRunning = false

    /** Classic clockwise seating order — team mode keeps exactly this order. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
        else -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        stats = Stats(this)

        lobbyPanel = findViewById(R.id.lobbyPanel)
        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        snlBoard = findViewById(R.id.snlBoard)
        btnMenu = findViewById(R.id.btnMenu)
        btnSound = findViewById(R.id.btnSound)
        btnAuto = findViewById(R.id.btnAuto)
        winOverlay = findViewById(R.id.winOverlay)
        winTitle = findViewById(R.id.winTitle)
        quickStatus = findViewById(R.id.quickStatus)
        confetti = findViewById(R.id.confetti)

        matchTitle = findViewById(R.id.matchTitle)
        modeHint = findViewById(R.id.modeHint)
        countRow = findViewById(R.id.countRow)
        snakeDiffRow = findViewById(R.id.snakeDiffRow)
        snakeDiffGroup = findViewById(R.id.snakeDiffGroup)
        optLucky = findViewById(R.id.optLucky)
        optBots = findViewById(R.id.optBots)
        lobbyCoins = findViewById(R.id.lobbyCoins)
        lobbyLevel = findViewById(R.id.lobbyLevel)
        pills = listOf(findViewById(R.id.pill2), findViewById(R.id.pill3), findViewById(R.id.pill4))
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        panelProfile = findViewById(R.id.panelProfile)
        panelSettings = findViewById(R.id.panelSettings)
        panelDice = findViewById(R.id.panelDice)
        panelQuit = findViewById(R.id.panelQuit)
        statsGrid = findViewById(R.id.statsGrid)
        profileRank = findViewById(R.id.profileRank)
        profileName = findViewById(R.id.profileName)
        toggleSound = findViewById(R.id.toggleSound)
        toggleVibration = findViewById(R.id.toggleVibration)
        settingsName = findViewById(R.id.settingsName)
        settingsAbout = findViewById(R.id.settingsAbout)
        diceGrid = findViewById(R.id.diceGrid)
        diceActivePreview = findViewById(R.id.diceActivePreview)
        diceActiveName = findViewById(R.id.diceActiveName)
        diceCoins = findViewById(R.id.diceCoins)

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.avatarTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft), findViewById(R.id.rollsTopLeft), findViewById(R.id.timerTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.avatarTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight), findViewById(R.id.rollsTopRight), findViewById(R.id.timerTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.avatarBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft), findViewById(R.id.rollsBottomLeft), findViewById(R.id.timerBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.avatarBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight), findViewById(R.id.rollsBottomRight), findViewById(R.id.timerBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        // ---- lobby cards
        findViewById<CardArtView>(R.id.artTwo).kind = CardArt.TWO_PLAYERS
        findViewById<CardArtView>(R.id.artFour).kind = CardArt.FOUR_PLAYERS
        findViewById<CardArtView>(R.id.artQuick).kind = CardArt.QUICK
        findViewById<CardArtView>(R.id.artSnake).kind = CardArt.SNAKE
        findViewById<CardArtView>(R.id.artTeam).kind = CardArt.TEAM
        findViewById<CardArtView>(R.id.artComputer).kind = CardArt.COMPUTER
        findViewById<CardArtView>(R.id.artArrow).kind = CardArt.ARROW

        findViewById<View>(R.id.cardTwo).setOnClickListener {
            openMatch(Mode.CLASSIC, 2, teams = false, bots = false, R.string.card_two)
        }
        findViewById<View>(R.id.cardFour).setOnClickListener {
            openMatch(Mode.CLASSIC, 4, teams = false, bots = false, R.string.card_four)
        }
        findViewById<View>(R.id.cardQuick).setOnClickListener {
            openMatch(Mode.QUICK, 2, teams = false, bots = false, R.string.card_quick)
        }
        findViewById<View>(R.id.cardSnake).setOnClickListener {
            openMatch(Mode.SNAKES, 2, teams = false, bots = false, R.string.card_snake)
        }
        findViewById<View>(R.id.cardTeam).setOnClickListener {
            openMatch(Mode.CLASSIC, 4, teams = true, bots = false, R.string.card_team)
        }
        findViewById<View>(R.id.cardComputer).setOnClickListener {
            openMatch(Mode.CLASSIC, 2, teams = false, bots = true, R.string.card_computer)
        }
        findViewById<View>(R.id.cardArrow).setOnClickListener {
            openMatch(Mode.ARROW, 2, teams = false, bots = false, R.string.card_arrow)
        }

        // ---- lobby chrome and the bottom bar
        findViewById<View>(R.id.lobbySettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.lobbyAvatar).setOnClickListener { showProfile() }
        findViewById<View>(R.id.navRules).setOnClickListener { showRules() }
        findViewById<View>(R.id.navDice).setOnClickListener { showDice() }
        findViewById<View>(R.id.navProfile).setOnClickListener { showProfile() }
        findViewById<View>(R.id.navSettings).setOnClickListener { showSettings() }

        // ---- panels
        findViewById<View>(R.id.closeProfile).setOnClickListener { hidePanels() }
        findViewById<View>(R.id.closeSettings).setOnClickListener { hidePanels() }
        findViewById<View>(R.id.closeDice).setOnClickListener { hidePanels() }
        findViewById<View>(R.id.btnEditName).setOnClickListener { hidePanels(); showSettings() }
        findViewById<View>(R.id.btnRulesFromSettings).setOnClickListener { showRules() }
        findViewById<View>(R.id.btnSaveName).setOnClickListener { saveName() }
        toggleSound.setOnClickListener { setSound(!stats.soundOn) }
        toggleVibration.setOnClickListener {
            stats.vibration = !stats.vibration
            paintToggles()
            if (stats.vibration) buzz(30)
        }
        findViewById<View>(R.id.btnQuitYes).setOnClickListener { panelQuit.visibility = View.GONE; backToLobby() }
        findViewById<View>(R.id.btnQuitNo).setOnClickListener { panelQuit.visibility = View.GONE }

        pills.forEachIndexed { i, pill -> pill.setOnClickListener { selectCount(i + 2) } }
        findViewById<View>(R.id.btnStart).setOnClickListener { startGame() }
        findViewById<View>(R.id.btnBack).setOnClickListener { backToLobby() }
        btnMenu.setOnClickListener { showMenu() }
        btnSound.setOnClickListener { setSound(!stats.soundOn) }
        btnAuto.setOnClickListener { toggleAuto() }
        findViewById<View>(R.id.btnPlayAgain).setOnClickListener { hideWin(); startGame() }
        findViewById<View>(R.id.btnGoHome).setOnClickListener { hideWin(); backToLobby() }
        boardView.onStep = { SoundFx.step() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        boardView.onChoicePicked = { value -> handleChoicePicked(value) }

        // ---- restore saved preferences
        SoundFx.enabled = stats.soundOn
        applyDiceSkin()
        paintToggles()
        showWallet()
        selectCount(2)
    }

    // ---------- wallet, level and dice skin ----------

    private fun coinText(n: Int): String =
        if (n >= 1000) "%.1fK".format(n / 1000f) else n.toString()

    private fun showWallet() {
        lobbyCoins.text = coinText(stats.coins)
        lobbyLevel.text = "Level ${stats.level()} · ${stats.rankName()}"
        diceCoins.text = coinText(stats.coins)
    }

    private fun applyDiceSkin() {
        val skin = DiceSkins.resolve(stats.activeDice)
        for ((_, slot) in slots) slot.dice.skin = skin
        diceActivePreview.skin = skin
        diceActivePreview.value = 6
        diceActiveName.text = skin.label
    }

    private fun buzz(ms: Long) {
        if (!stats.vibration) return
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vib.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(ms)
        }
    }

    // ---------- overlay panels ----------

    private fun hidePanels() {
        panelProfile.visibility = View.GONE
        panelSettings.visibility = View.GONE
        panelDice.visibility = View.GONE
    }

    private fun anyPanelOpen(): Boolean =
        panelProfile.visibility == View.VISIBLE ||
        panelSettings.visibility == View.VISIBLE ||
        panelDice.visibility == View.VISIBLE ||
        panelQuit.visibility == View.VISIBLE

    private fun showProfile() {
        hidePanels()
        profileName.text = stats.playerName.ifBlank { getString(R.string.nav_profile) }
        profileRank.text = "Level ${stats.level()}  ·  ${stats.rankName()}  ·  ${coinText(stats.coins)} coins"
        buildStatsGrid()
        panelProfile.visibility = View.VISIBLE
    }

    private fun buildStatsGrid() {
        statsGrid.removeAllViews()
        val tiles = listOf(
            getString(R.string.stat_won) to "${stats.gamesWon} of ${stats.gamesPlayed}",
            getString(R.string.stat_rate) to "%.0f%%".format(stats.winRate()),
            getString(R.string.stat_2p) to stats.wins2p.toString(),
            getString(R.string.stat_4p) to stats.wins4p.toString(),
            getString(R.string.stat_team) to stats.winsTeam.toString(),
            getString(R.string.stat_quick) to stats.winsQuick.toString(),
            getString(R.string.stat_snake) to stats.winsSnake.toString(),
            getString(R.string.stat_kills) to stats.kills.toString(),
            getString(R.string.stat_streak) to stats.streak.toString(),
            getString(R.string.stat_best) to stats.bestStreak.toString()
        )
        val d = resources.displayMetrics.density
        var row: LinearLayout? = null
        tiles.forEachIndexed { i, (label, value) ->
            if (i % 2 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                statsGrid.addView(row)
            }
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_stat)
                val pad = (10 * d).toInt()
                setPadding(pad, pad, pad, pad)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                val m = (4 * d).toInt()
                lp.setMargins(m, m, m, m)
                layoutParams = lp
            }
            tile.addView(TextView(this).apply {
                text = label
                setTextColor(Color.rgb(0x9F, 0xB6, 0xDE))
                textSize = 11f
            })
            tile.addView(TextView(this).apply {
                text = value
                setTextColor(Color.WHITE)
                textSize = 19f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            row?.addView(tile)
        }
    }

    private fun showSettings() {
        hidePanels()
        settingsName.setText(stats.playerName)
        paintToggles()
        settingsAbout.text =
            "Ludo Masha · offline pass-n-play\nWin a match to earn coins — 100, plus 25 more for each win in a row."
        panelSettings.visibility = View.VISIBLE
    }

    private fun paintToggles() {
        fun paint(view: TextView, on: Boolean) {
            view.setBackgroundResource(if (on) R.drawable.bg_toggle_on else R.drawable.bg_toggle_off)
            view.setText(if (on) R.string.on else R.string.off)
            view.setTextColor(if (on) Color.rgb(0x2A, 0x1A, 0x00) else Color.rgb(0x8F, 0xB0, 0xE4))
        }
        paint(toggleSound, stats.soundOn)
        paint(toggleVibration, stats.vibration)
    }

    private fun saveName() {
        stats.playerName = settingsName.text.toString()
        toast("Saved")
        showWallet()
    }

    private fun setSound(on: Boolean) {
        stats.soundOn = on
        SoundFx.enabled = on
        btnSound.text = getString(if (on) R.string.sound_on else R.string.sound_off)
        btnSound.alpha = if (on) 1f else 0.5f
        paintToggles()
    }

    private fun showDice() {
        hidePanels()
        buildDiceGrid()
        applyDiceSkin()
        showWallet()
        panelDice.visibility = View.VISIBLE
    }

    private fun buildDiceGrid() {
        diceGrid.removeAllViews()
        val d = resources.displayMetrics.density
        var row: LinearLayout? = null
        DiceSkins.ALL.forEachIndexed { i, skin ->
            if (i % 3 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                diceGrid.addView(row)
            }

            val owned = stats.owns(skin.id)
            val active = stats.activeDice == skin.id

            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundResource(
                    when {
                        active -> R.drawable.bg_dice_active
                        owned -> R.drawable.bg_dice_item
                        else -> R.drawable.bg_dice_locked
                    }
                )
                val pad = (8 * d).toInt()
                setPadding(pad, pad, pad, pad)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                val m = (5 * d).toInt()
                lp.setMargins(m, m, m, m)
                layoutParams = lp
                isClickable = true
                setOnClickListener { pickDice(skin) }
            }

            item.addView(DiceView(this).apply {
                layoutParams = LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt())
                this.skin = skin
                value = 6
                dimmed = !owned
                isClickable = false
            })

            item.addView(TextView(this).apply {
                text = skin.label
                setTextColor(if (owned) Color.WHITE else Color.rgb(0x7C, 0x93, 0xBE))
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                val m = (4 * d).toInt()
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = m
                layoutParams = lp
            })

            item.addView(TextView(this).apply {
                text = when {
                    active -> getString(R.string.dice_in_use)
                    owned -> getString(R.string.dice_use)
                    else -> "🔒 ${skin.price}"
                }
                setTextColor(
                    when {
                        active -> Color.rgb(0xFF, 0xE9, 0xA8)
                        owned -> Color.rgb(0x9F, 0xB6, 0xDE)
                        else -> Color.rgb(0xF2, 0xC1, 0x4E)
                    }
                )
                textSize = 11f
                gravity = Gravity.CENTER
            })

            row?.addView(item)
        }
    }

    private fun pickDice(skin: DiceSkin) {
        if (stats.owns(skin.id)) {
            stats.activeDice = skin.id
            applyDiceSkin()
            buildDiceGrid()
            buzz(20)
            return
        }
        if (stats.buyDice(skin.id)) {
            stats.activeDice = skin.id
            SoundFx.magic()
            toast(getString(R.string.dice_unlocked))
            applyDiceSkin()
            buildDiceGrid()
            showWallet()
        } else {
            toast(getString(R.string.not_enough_coins))
        }
    }

    private fun showRules() {
        AlertDialog.Builder(this)
            .setTitle(R.string.rules_title)
            .setMessage(
                "LUDO\n" +
                "Roll a six to bring a piece out. Land on an opponent to send it home. " +
                "A six, a capture or a piece reaching home all earn another roll, and three " +
                "sixes in a row burn the turn. Starred squares are safe.\n\n" +
                "QUICK MODE\n" +
                "One piece starts on the board. Home stays locked until you cut an opponent; " +
                "after that, one piece home wins the match.\n\n" +
                "SNAKES & LADDERS\n" +
                "One counter each on the 1-100 board. Land on a ladder foot to climb, on a " +
                "snake head to slide down — passing over either does nothing. Landing on an " +
                "opponent sends it back to the start. Square 100 needs an exact roll.\n\n" +
                "TURN CLOCK\n" +
                "Every turn has ten seconds. If it runs out, Auto Play takes over and keeps " +
                "playing until you press TAKE CONTROL.\n\n" +
                "COINS\n" +
                "Every win pays 100 coins, plus 25 more for each win in a row. Spend them on " +
                "new dice in the DICE tab."
            )
            .setPositiveButton(R.string.menu_cancel, null)
            .show()
    }

    // ---------- match setup ----------

    private fun openMatch(picked: Mode, count: Int, teams: Boolean, bots: Boolean, titleRes: Int) {
        mode = picked
        teamsOn = teams
        optBots.isChecked = bots
        matchTitle.setText(titleRes)

        modeHint.text = when {
            teams -> "Partners sit opposite: Red + Yellow against Green + Blue."
            picked == Mode.QUICK -> "One piece starts out. Cut an opponent to unlock HOME, then get one piece home to win."
            picked == Mode.SNAKES -> "The full 1-100 board. Climb the ladders, dodge the snakes, land exactly on 100 to win."
            picked == Mode.ARROW -> "Ludo with arrows on the track. Land on a dart and it carries you six squares on; land on your own colour's arrow and it takes you straight to your home lane."
            else -> "Standard Ludo rules. First to bring all four pieces home wins."
        }

        snakeDiffRow.visibility = if (picked == Mode.SNAKES) View.VISIBLE else View.GONE
        countRow.visibility = if (teams) View.GONE else View.VISIBLE
        selectCount(count)

        lobbyPanel.visibility = View.GONE
        setupPanel.visibility = View.VISIBLE
    }

    private fun selectCount(count: Int) {
        playerCount = count
        pills.forEachIndexed { i, pill ->
            val on = i + 2 == count
            pill.setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
            pill.setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
        }
        val seats = seatColors(count)
        val hints = listOf("Red", "Green", "Yellow", "Blue")
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
            if (i < count) {
                val colorName = hints[PlayerColor.entries.indexOf(seats[i]).coerceIn(0, 3)]
                field.hint = "Player ${i + 1} ($colorName)"
            }
        }
        // seat one is you
        if (nameFields[0].text.isNullOrBlank() && stats.playerName.isNotBlank()) {
            nameFields[0].setText(stats.playerName)
        }
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun chosenDifficulty(): SnakeDifficulty = when (snakeDiffGroup.checkedRadioButtonId) {
        R.id.snakeEasy -> SnakeDifficulty.EASY
        R.id.snakeHard -> SnakeDifficulty.HARD
        else -> SnakeDifficulty.MEDIUM
    }

    private fun playerNames(botsOn: Boolean): List<String> =
        (0 until playerCount).map { i ->
            val typed = nameFields[i].text.toString().trim()
            when {
                typed.isNotEmpty() -> typed
                i == 0 && stats.playerName.isNotBlank() -> stats.playerName
                botsOn && i > 0 -> "Computer $i"
                else -> "Player ${i + 1}"
            }
        }

    // ---------- game ----------

    private fun startGame() {
        autoPlay = false
        resultRecorded = false
        stopTurnTimer()
        updateAutoButton()
        if (mode == Mode.SNAKES) startSnakeGame() else startLudoGame()
    }

    /** Everything both boards share: seats, avatars, dice colours, panels. */
    private fun showGameChrome(
        colors: List<PlayerColor>,
        names: List<String>,
        kinds: List<PlayerKind>,
        teams: List<Int>
    ) {
        val skin = DiceSkins.resolve(stats.activeDice)
        for ((color, slot) in slots) {
            val index = colors.indexOf(color)
            if (index < 0) {
                slot.root.visibility = View.INVISIBLE
                slot.timer.secondsLeft = null
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teams[index] != 0) {
                    "${names[index]}  •  Team ${if (teams[index] == 1) "A" else "B"}"
                } else names[index]
                slot.avatar.setImageResource(
                    if (kinds[index] != PlayerKind.HUMAN) R.drawable.ic_avatar_bot
                    else when (index) {
                        0 -> R.drawable.ic_avatar_p1
                        1 -> R.drawable.ic_avatar_p2
                        2 -> R.drawable.ic_avatar_p3
                        else -> R.drawable.ic_avatar_p4
                    }
                )
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.skin = skin
                slot.dice.value = 1
                slot.timer.secondsLeft = null
            }
        }

        lobbyPanel.visibility = View.GONE
        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        btnSound.visibility = View.VISIBLE
        btnAuto.visibility = View.VISIBLE
        hideWin()
        SoundFx.gameStart()
    }

    private fun startLudoGame() {
        snl = null
        val colors = seatColors(playerCount)
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)
        val teams = teamsOn && playerCount == 4

        val players = colors.mapIndexed { i, color ->
            // partners sit opposite: Red+Yellow vs Green+Blue
            val team = if (!teams) 0
                       else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            // one NORMAL computer strength, as specified
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            Player.create("p${i + 1}", names[i], color, kind, team)
        }.toMutableList()

        val rules = RuleConfig(
            quickMode = mode == Mode.QUICK,
            snakeMode = false,
            arrowMode = mode == Mode.ARROW,
            teamMode = teams,
            luckyDice = optLucky.isChecked
        )

        if (rules.quickMode) {
            // Spec: exactly ONE token starts on the board, no six needed for it.
            for (p in players) {
                p.tokens[0].state = TokenState.ACTIVE
                p.tokens[0].steps = 1
            }
        }

        val newEngine = LudoEngine(GameState(gameId = "pass-n-play", players = players), rules)
        engine = newEngine
        boardView.snakeDifficulty = null
        boardView.arrowMode = rules.arrowMode
        boardView.snapToState(newEngine.state)
        rolling = false
        busy = false

        boardView.visibility = View.VISIBLE
        snlBoard.visibility = View.GONE

        showGameChrome(colors, names, players.map { it.kind }, players.map { it.team })
        quickStatus.visibility = if (rules.quickMode) View.VISIBLE else View.GONE
        render()
    }

    private fun startSnakeGame() {
        engine = null
        val colors = seatColors(playerCount)
        val botsOn = optBots.isChecked
        val names = playerNames(botsOn)

        val players = colors.mapIndexed { i, color ->
            val kind = if (botsOn && i > 0) PlayerKind.AI_MEDIUM else PlayerKind.HUMAN
            SnlPlayer("p${i + 1}", names[i], color, kind)
        }.toMutableList()

        val difficulty = chosenDifficulty()
        val newEngine = SnlEngine(
            players,
            SnlRules(difficulty = difficulty),
            DiceRoller(lucky = optLucky.isChecked)
        )
        snl = newEngine
        rolling = false
        busy = false

        snlBoard.onStep = { SoundFx.step() }
        snlBoard.difficulty = difficulty
        snlBoard.setPieces(players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
        boardView.visibility = View.GONE
        snlBoard.visibility = View.VISIBLE

        showGameChrome(colors, names, players.map { it.kind }, players.map { 0 })
        quickStatus.visibility = View.VISIBLE
        quickStatus.text = getString(R.string.snl_status)
        renderSnake()
    }

    override fun onPause() {
        super.onPause()
        stopTurnTimer()
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_new),
                    getString(R.string.rules_title),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> startGame()
                    1 -> panelQuit.visibility = View.VISIBLE
                    2 -> showRules()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun backToLobby() {
        engine = null
        snl = null
        rolling = false
        busy = false
        autoPlay = false
        stopTurnTimer()
        for ((_, slot) in slots) { stopBlink(slot.arrow); slot.timer.secondsLeft = null }
        gamePanel.visibility = View.GONE
        setupPanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        btnSound.visibility = View.GONE
        btnAuto.visibility = View.GONE
        hideWin()
        hidePanels()
        lobbyPanel.visibility = View.VISIBLE
        showWallet()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            anyPanelOpen() -> { hidePanels(); panelQuit.visibility = View.GONE }
            winOverlay.visibility == View.VISIBLE -> { hideWin(); backToLobby() }
            gamePanel.visibility == View.VISIBLE -> panelQuit.visibility = View.VISIBLE
            setupPanel.visibility == View.VISIBLE -> backToLobby()
            else -> super.onBackPressed()
        }
    }

    // ---------- the ten-second turn clock ----------

    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            val left = (turnDeadline - System.currentTimeMillis()) / 1000f
            paintTimer(left.coerceAtLeast(0f))
            if (left <= 0f) {
                timerRunning = false
                paintTimer(null)
                onTurnTimedOut()
            } else {
                boardHost().postDelayed(this, 80)
            }
        }
    }

    private fun boardHost(): View = if (mode == Mode.SNAKES) snlBoard else boardView

    private fun paintTimer(secondsLeft: Float?) {
        val active = activeColor()
        for ((color, slot) in slots) {
            slot.timer.secondsLeft = if (secondsLeft != null && color == active) secondsLeft else null
        }
    }

    private fun stopTurnTimer() {
        timerRunning = false
        timerKey = ""
        boardHost().removeCallbacks(timerTick)
        paintTimer(null)
    }

    /**
     * Restarts the clock whenever the decision in front of the player changes —
     * a new turn, a fresh roll, one more banked value to spend.
     */
    private fun refreshTurnTimer() {
        if (!humanMustDecide()) {
            if (timerRunning || timerKey.isNotEmpty()) stopTurnTimer()
            return
        }
        val key = decisionKey()
        if (key != timerKey) {
            timerKey = key
            turnDeadline = System.currentTimeMillis() + TURN_MS
        }
        if (!timerRunning) {
            timerRunning = true
            boardHost().removeCallbacks(timerTick)
            boardHost().post(timerTick)
        }
    }

    private fun decisionKey(): String {
        val e = engine
        if (e != null) return "L${e.state.currentPlayerIndex}|${e.state.phase}|${e.state.pendingRolls.size}"
        val s = snl ?: return ""
        return "S${s.currentIndex}|${s.phase}|${s.lastRoll}"
    }

    private fun humanMustDecide(): Boolean {
        if (busy || rolling || autoPlay) return false
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind == PlayerKind.HUMAN
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind == PlayerKind.HUMAN
    }

    private fun activeColor(): PlayerColor? {
        val e = engine
        if (e != null) return if (e.state.phase == TurnPhase.GAME_OVER) null else e.state.currentPlayer.color
        val s = snl ?: return null
        return if (s.phase == SnlPhase.GAME_OVER) null else s.current.color
    }

    private fun onTurnTimedOut() {
        if (autoPlay) return
        autoPlay = true
        updateAutoButton()
        toast("Time up — Auto Play is on. Tap TAKE CONTROL to play yourself.")
        if (mode == Mode.SNAKES) renderSnake() else render()
    }

    private fun toggleAuto() {
        autoPlay = !autoPlay
        updateAutoButton()
        if (autoPlay) stopTurnTimer() else timerKey = ""
        if (mode == Mode.SNAKES) renderSnake() else render()
    }

    private fun updateAutoButton() {
        btnAuto.text = getString(if (autoPlay) R.string.take_control else R.string.auto_off)
        btnAuto.alpha = if (autoPlay) 1f else 0.75f
    }

    private fun automaticTurn(): Boolean {
        val e = engine
        if (e != null) {
            if (e.state.phase == TurnPhase.GAME_OVER) return false
            return e.state.currentPlayer.kind != PlayerKind.HUMAN || autoPlay
        }
        val s = snl ?: return false
        if (s.phase == SnlPhase.GAME_OVER) return false
        return s.current.kind != PlayerKind.HUMAN || autoPlay
    }

    // ---------- rolling ----------

    private fun handleRoll() {
        if (mode == Mode.SNAKES) handleSnakeRoll() else handleLudoRoll()
    }

    private fun handleLudoRoll() {
        val e = engine ?: return
        if (rolling || busy || e.state.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[e.state.currentPlayer.color] ?: return

        rolling = true
        stopTurnTimer()
        clearChoice()
        val outcome = e.rollDice()
        SoundFx.diceRoll()
        buzz(28)
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            when {
                outcome.turnLostToThreeSixes -> {
                    SoundFx.turnLost()
                    toast("Three sixes — turn lost, all rolls wasted!")
                    render()
                }
                outcome.mustRollAgain -> render()
                else -> onRollingFinished()
            }
        }
    }

    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.22f).scaleY(1.22f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    /**
     * Flickers random faces, then settles on the value the engine already
     * decided. The animation only reveals the result — it never changes it.
     */
    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int, onDone: () -> Unit) {
        if (remaining <= 0) {
            dice.value = finalValue
            onDone()
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue, onDone) }, 50)
    }

    private fun onRollingFinished() {
        val e = engine ?: return
        val moves = e.legalMoves()
        if (moves.isEmpty()) {
            e.passTurn()
            render()
            return
        }
        render()
        maybeAutoPlay()
    }

    private fun maybeAutoPlay() {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return
        if (automaticTurn()) { maybeRunAutomatic(); return }
        val moves = e.legalMoves()
        val distinctValues = e.state.pendingRolls.distinct()
        val distinctTokens = moves.map { it.token.id }.distinct()
        if (moves.size == 1 || (distinctTokens.size == 1 && distinctValues.size == 1)) {
            val only = moves.first()
            boardView.postDelayed({ playMove(only) }, 260)
        }
    }

    private fun handleTokenTap(token: Token) {
        val e = engine ?: return
        if (busy || rolling || autoPlay || e.state.phase != TurnPhase.AWAITING_MOVE) return

        val options = e.state.pendingRolls.distinct()
            .mapNotNull { value -> e.legalMovesFor(value).firstOrNull { it.token.id == token.id } }

        when {
            options.isEmpty() -> return
            options.size == 1 -> {
                clearChoice()
                playMove(options.first())
            }
            else -> {
                choiceTokenId = token.id
                boardView.showChoices(token.id, options.map { it.usedRoll })
            }
        }
    }

    private fun handleChoicePicked(value: Int) {
        val e = engine ?: return
        val tokenId = choiceTokenId ?: return
        val move = e.legalMovesFor(value).firstOrNull { it.token.id == tokenId } ?: return
        clearChoice()
        playMove(move)
    }

    private fun clearChoice() {
        choiceTokenId = null
        boardView.clearChoices()
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        if (busy) return
        clearChoice()
        stopTurnTimer()
        busy = true
        boardView.tappableTokenIds = emptySet()
        val moverIsHuman = e.state.currentPlayer.kind == PlayerKind.HUMAN && !autoPlay

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            val victimsBefore = move.capturesTokenIds.mapNotNull { id ->
                e.state.players.flatMap { p -> p.tokens.map { p to it } }
                    .firstOrNull { it.second.id == id }
                    ?.let { (owner, tok) -> Triple(tok.id, tok.color, tok.steps to owner.tokens.indexOf(tok)) }
            }

            val result = e.applyMove(move)
            if (moverIsHuman) repeat(result.capturedTokens.size) { stats.addKill() }

            val settle = {
                boardView.snapToState(e.state)
                if (result.gameWon) SoundFx.win() else SoundFx.tokenMove()
                busy = false
                render()
                maybeAutoPlay()
            }

            val afterCaptures = {
                if (victimsBefore.isNotEmpty()) {
                    SoundFx.capture()
                    buzz(45)
                    var pending = victimsBefore.size
                    for ((id, color, info) in victimsBefore) {
                        val (steps, slot) = info
                        boardView.flyHome(id, color, steps, slot) {
                            pending--
                            if (pending == 0) settle()
                        }
                    }
                } else settle()
            }

            if (result.unlockedHome) {
                SoundFx.magic()
                showUnlockBanner()
            }

            // ARROW MODE: land on an arrow, it lights up, then it carries you.
            val arrow = result.arrow
            val arrowFrom = result.arrowFromSteps
            val arrowTo = result.arrowToSteps
            if (arrow != null && arrowFrom != null && arrowTo != null) {
                boardView.setSpecialGlow(arrow.cell)
                boardView.postDelayed({
                    SoundFx.arrow()
                    buzz(30)
                    boardView.rideSpecial(
                        move.token.id, move.token.color, arrowFrom, arrowTo, true
                    ) {
                        boardView.setSpecialGlow(null)
                        afterCaptures()
                    }
                }, SPECIAL_PAUSE_MS)
            } else {
                afterCaptures()
            }
        }
    }

    private fun showUnlockBanner() {
        quickStatus.text = getString(R.string.quick_unlock_toast)
        quickStatus.scaleX = 0.8f
        quickStatus.scaleY = 0.8f
        quickStatus.animate().scaleX(1.12f).scaleY(1.12f).setDuration(220)
            .withEndAction { quickStatus.animate().scaleX(1f).scaleY(1f).setDuration(200).start() }
            .start()
        quickStatus.postDelayed({ refreshQuickStatus() }, 1300)
    }

    private fun refreshQuickStatus() {
        val e = engine ?: return
        if (quickStatus.visibility != View.VISIBLE) return
        val p = if (e.state.phase == TurnPhase.GAME_OVER) e.state.players.firstOrNull()
                else e.state.currentPlayer
        quickStatus.text = getString(
            if (p?.hasCapturedOpponent == true) R.string.quick_unlocked else R.string.quick_locked
        )
    }

    // ---------- computer players and Auto Play ----------

    private fun maybeRunAutomatic() {
        if (!automaticTurn() || busy || rolling) return
        val e = engine ?: return

        when (e.state.phase) {
            TurnPhase.AWAITING_ROLL -> boardView.postDelayed({
                if (automaticTurn() && !busy && !rolling) handleLudoRoll()
            }, 650)

            TurnPhase.AWAITING_MOVE -> boardView.postDelayed({
                if (!automaticTurn() || busy || rolling) return@postDelayed
                val moves = e.legalMoves()
                if (moves.isEmpty()) {
                    e.passTurn()
                    render()
                } else {
                    // Auto Play uses the very same decision logic as the computer,
                    // and only ever sees information a player could see.
                    playMove(
                        LudoAI.chooseMove(
                            PlayerKind.AI_MEDIUM, moves, e.state,
                            needsKill = e.rules.quickMode && !e.state.currentPlayer.hasCapturedOpponent
                        )
                    )
                }
            }, 600)

            TurnPhase.GAME_OVER -> Unit
        }
    }

    private fun render() {
        val e = engine ?: return
        val s = e.state
        val gameOver = s.phase == TurnPhase.GAME_OVER
        val active = if (gameOver) null else s.currentPlayer.color

        boardView.tappableTokenIds =
            if (!busy && !rolling && !autoPlay && s.phase == TurnPhase.AWAITING_MOVE)
                e.legalMoves().map { it.token.id }.toSet()
            else emptySet()

        paintSeats(active, s.phase == TurnPhase.AWAITING_ROLL)
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            renderRollsFor(color, slot, color == active)
        }

        val last = s.lastDiceRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        refreshQuickStatus()
        refreshTurnTimer()
        if (gameOver) {
            val champion = s.players.firstOrNull { it.id == s.rankings.firstOrNull() }
            announceWinner(
                champion?.let { it.displayName to it.team },
                showSubtitle = e.rules.quickMode,
                humanWon = champion?.kind == PlayerKind.HUMAN,
                quick = e.rules.quickMode,
                team = e.rules.teamMode
            )
        } else {
            maybeRunAutomatic()
        }
    }

    private fun paintSeats(active: PlayerColor?, canRoll: Boolean) {
        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == active
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable = isActive && !busy && !rolling && canRoll && !autoPlay

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }
        }
    }

    private fun renderRollsFor(color: PlayerColor, slot: Slot, isActive: Boolean) {
        slot.rolls.removeAllViews()
        val e = engine ?: return
        if (!isActive) return
        val rolls = e.state.pendingRolls
        if (rolls.isEmpty()) return

        val size = (30 * resources.displayMetrics.density).toInt()
        val gap = (3 * resources.displayMetrics.density).toInt()
        val skin = DiceSkins.resolve(stats.activeDice)
        rolls.forEach { value ->
            val chip = DiceView(this)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginStart = gap
            lp.marginEnd = gap
            chip.layoutParams = lp
            chip.skin = skin
            chip.value = value
            chip.accent = uiColor(color)
            chip.isClickable = false
            slot.rolls.addView(chip)
        }
    }

    // ---------- SNAKE & LADDER ----------

    private fun handleSnakeRoll() {
        val s = snl ?: return
        if (rolling || busy || s.phase != SnlPhase.AWAITING_ROLL) return
        val slot = slots[s.current.color] ?: return

        rolling = true
        stopTurnTimer()
        val outcome = s.rollDice()
        SoundFx.diceRoll()
        buzz(28)
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            if (outcome.turnLostToThreeSixes) {
                SoundFx.turnLost()
                toast("Three sixes — turn lost!")
                renderSnake()
            } else {
                playSnakeMove(outcome.value)
            }
        }
    }

    /**
     * Plays back one dice move on the 1..100 board. The engine has already
     * decided everything — walk, shortcut, knock-back, win — so this only
     * animates the result in the order the rules call for.
     */
    private fun playSnakeMove(value: Int) {
        val s = snl ?: return
        if (busy) return
        busy = true

        val from = s.current.cell
        val moverIsHuman = s.current.kind == PlayerKind.HUMAN && !autoPlay
        val result = s.resolve(value)
        if (moverIsHuman) repeat(result.cutPlayerIds.size) { stats.addKill() }

        val settle = {
            snlBoard.snapTo(s.players.map { SnlBoardView.Piece(it.id, it.color, it.cell) })
            busy = false
            renderSnake()
        }

        val afterCuts = {
            if (result.cutPlayerIds.isEmpty()) {
                if (result.won) SoundFx.win() else SoundFx.tokenMove()
                settle()
            } else {
                SoundFx.capture()
                buzz(45)
                toast(getString(R.string.snl_cut))
                var pending = result.cutPlayerIds.size
                for (id in result.cutPlayerIds) {
                    snlBoard.sendToStart(id, result.finalCell) {
                        pending--
                        if (pending == 0) settle()
                    }
                }
            }
        }

        if (result.blocked) {
            toast(getString(R.string.snl_blocked))
            settle()
            return
        }

        snlBoard.hopAlong(result.playerId, s.walkPath(from, result.landedCell)) {
            val special = result.special
            if (special != null) {
                val isLadder = special.type == SpecialType.LADDER
                snlBoard.setGlow(special.entryCell)
                snlBoard.postDelayed({
                    if (isLadder) SoundFx.ladderClimb() else SoundFx.snakeSlide()
                    buzz(35)
                    snlBoard.rideSpecial(result.playerId, special) {
                        snlBoard.setGlow(null)
                        afterCuts()
                    }
                }, SPECIAL_PAUSE_MS)
            } else {
                afterCuts()
            }
        }
    }

    private fun renderSnake() {
        val s = snl ?: return
        val gameOver = s.phase == SnlPhase.GAME_OVER
        val active = if (gameOver) null else s.current.color

        paintSeats(active, s.phase == SnlPhase.AWAITING_ROLL)
        for ((_, slot) in slots) slot.rolls.removeAllViews()

        val last = s.lastRoll
        if (last != null && active != null) slots[active]?.dice?.value = last

        if (!gameOver) {
            val p = s.current
            quickStatus.text = if (p.cell == 0) getString(R.string.snl_status)
                               else "${p.displayName} · ${p.cell} / ${SnlConfig.LAST_CELL}"
        }

        refreshTurnTimer()
        if (gameOver) {
            val winner = s.players.firstOrNull { it.id == s.winnerId }
            announceWinner(
                winner?.let { it.displayName to 0 },
                showSubtitle = true,
                humanWon = winner?.kind == PlayerKind.HUMAN,
                snake = true
            )
        } else {
            maybeRunAutomaticSnake()
        }
    }

    private fun maybeRunAutomaticSnake() {
        if (!automaticTurn() || busy || rolling) return
        val s = snl ?: return
        if (s.phase != SnlPhase.AWAITING_ROLL) return
        snlBoard.postDelayed({
            if (automaticTurn() && !busy && !rolling) handleSnakeRoll()
        }, 650)
    }

    // ---------- shared chrome ----------

    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun announceWinner(
        winner: Pair<String, Int>?,
        showSubtitle: Boolean,
        humanWon: Boolean,
        quick: Boolean = false,
        team: Boolean = false,
        snake: Boolean = false
    ) {
        if (winOverlay.visibility == View.VISIBLE) return
        if (winner == null) return
        stopTurnTimer()

        val (name, teamNo) = winner
        winTitle.text = if (teamNo != 0) "Team ${if (teamNo == 1) "A" else "B"} wins!" else "$name wins!"
        if (showSubtitle) {
            val subtitle = getString(if (snake) R.string.snl_victory else R.string.quick_victory)
            winTitle.text = "${winTitle.text}\n$subtitle"
        }

        if (!resultRecorded) {
            resultRecorded = true
            val reward = stats.recordResult(
                won = humanWon,
                players = playerCount,
                team = team,
                quick = quick,
                snake = snake
            )
            if (reward > 0) {
                winTitle.text = "${winTitle.text}\n+$reward coins"
            }
            showWallet()
        }

        buzz(70)
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.animate().alpha(1f).setDuration(320).start()
        confetti.start()
    }

    private fun hideWin() {
        confetti.stop()
        winOverlay.visibility = View.GONE
    }

    private companion object {
        /** Beat before a snake or ladder fires, so the landing reads first. */
        const val SPECIAL_PAUSE_MS = 220L
        const val BLINKING = "blinking"
        /** Every human decision is on a ten-second clock. */
        const val TURN_MS = 10_000L
    }
}
