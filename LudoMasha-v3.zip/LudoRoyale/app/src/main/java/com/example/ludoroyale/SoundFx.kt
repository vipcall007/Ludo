package com.example.ludoroyale

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/**
 * Original sound feedback built from Android's ToneGenerator — no bundled
 * or copied audio files. Captures get a comic descending "wah-wah" slide;
 * wins get a rising fanfare.
 */
object SoundFx {
    private val generator by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }
    private val handler = Handler(Looper.getMainLooper())

    fun diceRoll() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP, 60) }
    fun step() = safe { generator.startTone(ToneGenerator.TONE_DTMF_1, 32) }
    fun tokenMove() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP2, 55) }

    /** Comic "you got knocked out" slide — descending tones. */
    fun capture() {
        val slide = listOf(
            ToneGenerator.TONE_DTMF_9,
            ToneGenerator.TONE_DTMF_6,
            ToneGenerator.TONE_DTMF_3,
            ToneGenerator.TONE_DTMF_0
        )
        slide.forEachIndexed { i, tone ->
            handler.postDelayed({ safe { generator.startTone(tone, 110) } }, i * 105L)
        }
    }

    /** Rising celebration fanfare for a win. */
    fun win() {
        val fanfare = listOf(
            ToneGenerator.TONE_DTMF_1,
            ToneGenerator.TONE_DTMF_5,
            ToneGenerator.TONE_DTMF_9,
            ToneGenerator.TONE_CDMA_CONFIRM
        )
        fanfare.forEachIndexed { i, tone ->
            val dur = if (i == fanfare.lastIndex) 520 else 150
            handler.postDelayed({ safe { generator.startTone(tone, dur) } }, i * 165L)
        }
    }

    /** Sparkly rising chime for the arrow-mode magic jump. */
    fun magic() {
        val sparkle = listOf(
            ToneGenerator.TONE_DTMF_3,
            ToneGenerator.TONE_DTMF_7,
            ToneGenerator.TONE_DTMF_9,
            ToneGenerator.TONE_DTMF_D
        )
        sparkle.forEachIndexed { i, tone ->
            handler.postDelayed({ safe { generator.startTone(tone, 65) } }, i * 62L)
        }
    }

    /** Short flourish when a game starts. */
    fun gameStart() {
        val intro = listOf(ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_9, ToneGenerator.TONE_DTMF_D)
        intro.forEachIndexed { i, tone ->
            handler.postDelayed({ safe { generator.startTone(tone, 130) } }, i * 140L)
        }
    }

    /** Buzzer when three sixes burn the whole turn. */
    fun turnLost() {
        listOf(ToneGenerator.TONE_DTMF_0, ToneGenerator.TONE_DTMF_0).forEachIndexed { i, tone ->
            handler.postDelayed({ safe { generator.startTone(tone, 190) } }, i * 200L)
        }
    }

    /** Whoosh-ish blip when an arrow carries a piece forward. */
    fun arrow() {
        listOf(ToneGenerator.TONE_DTMF_2, ToneGenerator.TONE_DTMF_7).forEachIndexed { i, tone ->
            handler.postDelayed({ safe { generator.startTone(tone, 70) } }, i * 70L)
        }
    }

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (_: Exception) { /* never crash the game over a beep */ }
    }
}
