package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import kotlin.math.min

/**
 * Draws the classic Ludo cross board (wooden frame, circular home yards,
 * arrow-shaped home stretches, star safe cells, direction arrows) plus
 * styled tokens with stack counts, and moves tokens box-by-box.
 * Everything is drawn in code — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    var tappableTokenIds: Set<String> = emptySet()
        set(value) { field = value; invalidate() }

    var onTokenTapped: ((Token) -> Unit)? = null

    /** Draw ARROW-MODE shortcut arrows on the track. */
    var arrowMode: Boolean = false
        set(value) { field = value; invalidate() }

    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Token currently vanishing/reappearing for an ARROW-MODE magic jump. */
    private var fadingTokenId: String? = null
    private var fadeAlpha: Float = 1f

    /**
     * ARROW MODE magic move: the piece puffs out at the arrow's start and
     * reappears where the arrow ends, instead of walking the gap.
     */
    fun magicTeleport(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit) {
        fadingTokenId = tokenId
        fadeOut(tokenId, color, toSteps, onComplete, 1f)
    }

    private fun fadeOut(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit, a: Float) {
        if (a <= 0.05f) {
            // reappear at the arrow's end
            displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, toSteps)
            fadeIn(tokenId, onComplete, 0f)
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeOut(tokenId, color, toSteps, onComplete, a - 0.16f) }, 34)
    }

    private fun fadeIn(tokenId: String, onComplete: () -> Unit, a: Float) {
        if (a >= 1f) {
            fadeAlpha = 1f
            fadingTokenId = null
            invalidate()
            onComplete()
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeIn(tokenId, onComplete, a + 0.16f) }, 34)
    }

    /** Instantly syncs the board to [newState] (game start, or after a hop lands). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /** Moves one token cell-by-cell from [fromSteps] to [toSteps], then calls [onComplete]. */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val hops: List<Int> = if (fromSteps <= 0) listOf(toSteps) else (fromSteps + 1..toSteps).toList()
        hopSequence(tokenId, color, hops, 0, onComplete)
    }

    private fun hopSequence(tokenId: String, color: PlayerColor, hops: List<Int>, index: Int, onComplete: () -> Unit) {
        if (index >= hops.size) { onComplete(); return }
        displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, hops[index])
        invalidate()
        SoundFx.step()
        postDelayed({ hopSequence(tokenId, color, hops, index + 1, onComplete) }, 130)
    }

    // ---- geometry ----
    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell
    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(px(c0), py(r0), px(c1), py(r1))

    // ---- paints ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xBD, 0xBD, 0xBD)
        strokeWidth = 1.5f
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xFF, 0xEB, 0x3B)
        strokeWidth = 6f
    }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0x21, 0x21, 0x21)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(120, 0x61, 0x61, 0x61)
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.028f
        cell = (size - 2 * frame) / BoardGeometry.GRID_SIZE
        badgeText.textSize = cell * 0.46f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawFrame(canvas)
        drawHomeYards(canvas)
        drawTrack(canvas)
        drawHomeStretches(canvas)
        drawCenterArrows(canvas)
        drawTokens(canvas)
    }

    /** Wooden outer frame + white playfield. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.05f
        fill.color = Color.rgb(0xD2, 0x8C, 0x45)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, fill)
        fill.color = Color.rgb(0xE8, 0xA8, 0x64)
        canvas.drawRoundRect(RectF(frame * 0.35f, frame * 0.35f, size - frame * 0.35f, size - frame * 0.35f), r, r, fill)
        fill.color = Color.WHITE
        canvas.drawRect(RectF(px(0f), py(0f), px(15f), py(15f)), fill)
    }

    /** The four colored corner yards, each with a white circle holding the 4 base slots. */
    private fun drawHomeYards(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0].toFloat(); val c0 = box[1].toFloat()
            val r1 = (box[2] + 1).toFloat(); val c1 = (box[3] + 1).toFloat()

            fill.color = colorOf(color)
            canvas.drawRect(rect(r0, c0, r1, c1), fill)

            // white circle in the middle of the yard
            val cx = px((c0 + c1) / 2f)
            val cy = py((r0 + r1) / 2f)
            val radius = cell * 2.1f
            canvas.drawCircle(cx + cell * 0.06f, cy + cell * 0.09f, radius, shadow)
            fill.color = Color.WHITE
            canvas.drawCircle(cx, cy, radius, fill)
        }
    }

    /** The 52-cell outer ring: white cells, colored start cells, star safe cells, direction arrows. */
    private fun drawTrack(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val r = rc.first.toFloat(); val c = rc.second.toFloat()
            var startColor: PlayerColor? = null
            for (color in PlayerColor.entries) if (color.startOffset == idx) startColor = color

            fill.color = if (startColor != null) colorOf(startColor) else Color.WHITE
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), fill)
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), gridLine)

            if (startColor != null) drawTravelArrow(canvas, idx)
            if (arrowMode && LudoBoard.arrowJumpAt(idx) != null) drawShortcutArrow(canvas, idx)
            if (LudoBoard.isSafeCell(idx)) {
                val starColor = if (startColor != null) Color.WHITE else Color.rgb(0x9E, 0x9E, 0x9E)
                drawStar(canvas, px(c + 0.5f), py(r + 0.5f), cell * 0.3f, starColor)
            }
        }
    }

    /** A chevron on a start cell showing which way tokens travel from there. */
    private fun drawTravelArrow(canvas: Canvas, idx: Int) {
        val here = BoardGeometry.RING[idx]
        val next = BoardGeometry.RING[(idx + 1) % BoardGeometry.RING.size]
        val dr = next.first - here.first
        val dc = next.second - here.second
        val cx = px(here.second + 0.5f)
        val cy = py(here.first + 0.5f)
        val s = cell * 0.22f

        arrowPaint.color = Color.argb(200, 255, 255, 255)
        val path = Path()
        // chevron pointing along (dr, dc)
        val tipX = cx + dc * s; val tipY = cy + dr * s
        val backX = cx - dc * s * 0.4f; val backY = cy - dr * s * 0.4f
        // perpendicular
        val pxv = -dr.toFloat(); val pyv = dc.toFloat()
        path.moveTo(backX + pxv * s * 0.8f, backY + pyv * s * 0.8f)
        path.lineTo(tipX, tipY)
        path.lineTo(backX - pxv * s * 0.8f, backY - pyv * s * 0.8f)
        canvas.drawPath(path, arrowPaint)
    }

    /** ARROW-MODE shortcut marker: a bold curved-look arrow on the cell. */
    private fun drawShortcutArrow(canvas: Canvas, idx: Int) {
        val here = BoardGeometry.RING[idx]
        val next = BoardGeometry.RING[(idx + 1) % BoardGeometry.RING.size]
        val dr = (next.first - here.first).toFloat()
        val dc = (next.second - here.second).toFloat()
        val cx = px(here.second + 0.5f)
        val cy = py(here.first + 0.5f)

        // glowing disc behind the arrow
        fill.color = Color.rgb(0xFF, 0x8F, 0x00)
        canvas.drawCircle(cx, cy, cell * 0.44f, fill)
        fill.color = Color.rgb(0xFF, 0xB3, 0x00)
        canvas.drawCircle(cx, cy, cell * 0.36f, fill)

        // perpendicular unit for the shaft width
        val pr = -dc
        val pc = dr
        val headLen = cell * 0.30f
        val headHalf = cell * 0.26f
        val shaftHalf = cell * 0.10f
        val tailBack = cell * 0.28f

        val path = Path()
        // tail corners
        path.moveTo(cx - dc * tailBack + pc * shaftHalf, cy - dr * tailBack + pr * shaftHalf)
        path.lineTo(cx - dc * tailBack - pc * shaftHalf, cy - dr * tailBack - pr * shaftHalf)
        // up to the head base
        path.lineTo(cx + dc * (headLen * 0.1f) - pc * shaftHalf, cy + dr * (headLen * 0.1f) - pr * shaftHalf)
        path.lineTo(cx + dc * (headLen * 0.1f) - pc * headHalf, cy + dr * (headLen * 0.1f) - pr * headHalf)
        // tip
        path.lineTo(cx + dc * (headLen + cell * 0.08f), cy + dr * (headLen + cell * 0.08f))
        path.lineTo(cx + dc * (headLen * 0.1f) + pc * headHalf, cy + dr * (headLen * 0.1f) + pr * headHalf)
        path.lineTo(cx + dc * (headLen * 0.1f) + pc * shaftHalf, cy + dr * (headLen * 0.1f) + pr * shaftHalf)
        path.close()

        fill.color = Color.WHITE
        canvas.drawPath(path, fill)
    }

    /** Star path using whatever colour/alpha is already set on [fill]. */
    private fun drawStarPath(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            path.let { p ->
                val x = cx + (rr * Math.cos(angle)).toFloat()
                val y = cy + (rr * Math.sin(angle)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            val x = cx + (rr * Math.cos(angle)).toFloat()
            val y = cy + (rr * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    /** Each color's private path to home, drawn as one solid colored lane. */
    private fun drawHomeStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            fill.color = colorOf(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), fill)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), gridLine)
            }
        }
    }

    /** The four big arrowheads meeting at the center — the "win" zone. */
    private fun drawCenterArrows(canvas: Canvas) {
        val cx = px(7.5f); val cy = py(7.5f)
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(px(p1c), py(p1r))
            path.lineTo(px(p2c), py(p2r))
            path.lineTo(cx, cy)
            path.close()
            fill.color = colorOf(color)
            canvas.drawPath(path, fill)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    /**
     * Tokens, grouped so stacked pieces are obvious: one styled piece per
     * (cell, color) with a numbered badge when more than one sits there,
     * and a slight offset when two different colors share a safe cell.
     */
    /**
     * Tokens, drawn so a pile is unmistakable: each extra piece on a square is
     * drawn stepped up-and-left behind the front one, and a numbered badge
     * shows the exact count. Two colours sharing a safe cell sit side by side.
     */
    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return

        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val byColor = tokens.groupBy { it.color }
            val sideStep = if (byColor.size > 1) cell * 0.17f else 0f
            var slot = 0
            for ((color, group) in byColor) {
                val baseX = px(col) + when {
                    byColor.size <= 1 -> 0f
                    slot % 2 == 0 -> -sideStep
                    else -> sideStep
                }
                val baseY = py(row) + if (byColor.size > 2 && slot >= 2) sideStep else 0f
                val tappable = group.any { it.id in tappableTokenIds }
                val faded = group.any { it.id == fadingTokenId }
                val alpha = if (faded) fadeAlpha else 1f

                // pile: draw the back pieces first, stepped up-left
                val pile = minOf(group.size, 3)
                for (depth in pile - 1 downTo 1) {
                    val off = cell * 0.09f * depth
                    drawToken(canvas, baseX - off, baseY - off, color, alpha * 0.9f, false)
                }
                drawToken(canvas, baseX, baseY, color, alpha, tappable)
                if (group.size > 1) drawCountBadge(canvas, baseX, baseY, color, group.size, alpha)
                slot++
            }
        }
    }

    private fun drawToken(canvas: Canvas, cx: Float, cy: Float, color: PlayerColor, alpha: Float, tappable: Boolean) {
        if (alpha <= 0.02f) return
        val radius = cell * 0.36f
        val a = (alpha * 255).toInt().coerceIn(0, 255)

        shadow.alpha = (60 * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx + radius * 0.14f, cy + radius * 0.22f, radius, shadow)
        shadow.alpha = 60

        fill.color = colorOf(color)
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius, fill)

        fill.color = Color.WHITE
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 0.66f, fill)

        fill.color = colorOf(color)
        fill.alpha = a
        drawStarPath(canvas, cx, cy, radius * 0.56f)

        fill.alpha = 255

        if (tappable) canvas.drawCircle(cx, cy, radius + 4f, highlight)
    }

    private fun drawCountBadge(canvas: Canvas, cx: Float, cy: Float, color: PlayerColor, count: Int, alpha: Float) {
        val radius = cell * 0.36f
        val a = (alpha * 255).toInt().coerceIn(0, 255)
        val br = radius * 0.54f
        val bx = cx + radius * 0.78f
        val by = cy - radius * 0.78f

        fill.color = Color.WHITE
        fill.alpha = a
        canvas.drawCircle(bx, by, br, fill)
        fill.color = colorOf(color)
        fill.alpha = a
        canvas.drawCircle(bx, by, br * 0.82f, fill)
        fill.alpha = 255

        badgeText.color = Color.WHITE
        badgeText.alpha = a
        canvas.drawText(count.toString(), bx, by + badgeText.textSize * 0.36f, badgeText)
        badgeText.alpha = 255
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell <= 0f) return true

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for (player in s.players) {
            for (token in player.tokens) {
                if (token.id !in tappableTokenIds) continue
                val pos = displayedCenters[token.id] ?: continue
                val dx = event.x - px(pos.second)
                val dy = event.y - py(pos.first)
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }
        val touchRadius = cell * 0.85f
        if (best != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(best)
        }
        return true
    }
}
