package com.example.ludoroyale

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.example.ludoroyale.cosmetics.Cosmetics
import kotlin.math.min

/**
 * A player's picture, the frame around it, and their turn clock.
 *
 * THE FACE AND THE FRAME ARE BOTH PICTURES NOW
 *
 * They used to be drawn in code. The supplied artwork replaced both: fifteen
 * painted portraits, and six gold frames that grow a crown, then wings, then a
 * laurel as the player climbs.
 *
 * WHY EVERY FRAME SHOWS THE FACE AT THE SAME SIZE
 *
 * The six frames do not have the same opening — the plain band's window is
 * wider than the winged ones'. If each face were fitted to its own frame's
 * window, earning a better frame would SHRINK your face, which is the opposite
 * of a reward. So one window is used for all six: the largest square that fits
 * inside every one of them, measured off the files. A better frame is showier
 * and never smaller.
 *
 * THE CLOCK RUNS ROUND THE FACE, NOT ROUND THE FRAME
 *
 * The frames have wings and crowns sticking out at different places, so a line
 * round their outside would be a different shape on every one and would cross
 * the artwork. It runs round the opening instead: the same shape on all six,
 * always against the portrait, never fighting the gold.
 */
class AvatarFrameView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var avatarId: String = Cosmetics.AV_KING
        set(value) { field = value; portrait = null; invalidate() }

    var frameId: String = Cosmetics.FR_STEP1
        set(value) { field = value; frameArt = null; invalidate() }

    /**
     * The player's own picture, already cropped square. Null falls back to the
     * chosen portrait, so a player who has not set one still has a face.
     */
    var photo: Bitmap? = null
        set(value) { field = value; invalidate() }

    /** Drawn as a computer opponent instead of a person. */
    var isBot: Boolean = false
        set(value) { field = value; invalidate() }

    /** The seat colour, used behind the portrait so seats stay tellable apart. */
    var accent: Int = Color.rgb(0x2B, 0x3A, 0x63)
        set(value) { field = value; invalidate() }

    /** Hides the frame, for places that want the portrait on its own. */
    var showFrame: Boolean = true
        set(value) { field = value; invalidate() }

    // --------------------------------------------------------- the turn clock

    /** Seconds still on the clock, or null when this seat is not on the clock. */
    var secondsLeft: Float? = null
        set(value) {
            field = value
            if (value != null) startPulse() else stopPulse()
            invalidate()
        }

    var totalSeconds: Float = 15f

    private var pulse = 0f
    private val pulseTicker = object : Runnable {
        override fun run() {
            if (secondsLeft == null) return
            pulse += 0.28f
            invalidate()
            postDelayed(this, 45)
        }
    }

    private fun startPulse() {
        removeCallbacks(pulseTicker)
        post(pulseTicker)
    }

    private fun stopPulse() {
        removeCallbacks(pulseTicker)
        pulse = 0f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(pulseTicker)
        portrait = null
        frameArt = null
    }

    // ------------------------------------------------------------------ paint

    private var portrait: Bitmap? = null
    private var frameArt: Bitmap? = null

    private val picturePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clockTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(150, 0, 0, 0)
    }
    private val clockLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val clockGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val clockText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD
        )
    }

    private val clockPath = Path()
    private val clockSegment = Path()
    private val measure = PathMeasure()
    private val textBounds = Rect()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val s = min(w, h)
        val left = (w - s) / 2f
        val top = (h - s) / 2f

        // WITH a frame, the portrait sits in the frame's opening. WITHOUT one
        // there is nothing to fit inside, so it fills its box instead — which
        // is why an opponent's face, who wears no frame, is the bigger of the
        // two rather than a small picture floating in an empty square.
        val framed = showFrame && frameId != Cosmetics.FRAME_NONE
        val window = if (framed) {
            RectF(
                left + s * WINDOW_LEFT, top + s * WINDOW_TOP,
                left + s * WINDOW_RIGHT, top + s * WINDOW_BOTTOM
            )
        } else {
            val pad = s * 0.06f
            RectF(left + pad, top + pad, left + s - pad, top + s - pad)
        }
        val corner = window.width() * 0.16f

        drawPortrait(canvas, window, corner)
        if (framed) drawFrame(canvas, RectF(left, top, left + s, top + s))
        drawClock(canvas, window, corner)
    }

    // ------------------------------------------------------------- portrait

    private fun drawPortrait(canvas: Canvas, r: RectF, corner: Float) {
        val size = min(r.width(), r.height())

        // a backing in the seat colour, so an empty or transparent portrait
        // still reads as somebody's seat rather than as a hole
        shade.shader = RadialGradient(
            r.centerX() - size * 0.3f, r.centerY() - size * 0.4f, size * 1.4f,
            intArrayOf(lighten(accent, 0.35f), accent, darken(accent, 0.35f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, corner, corner, shade)
        shade.shader = null

        canvas.save()
        val clip = Path()
        clip.addRoundRect(r, corner, corner, Path.Direction.CW)
        canvas.clipPath(clip)

        val own = photo
        if (own != null && !own.isRecycled && avatarId == Cosmetics.AVATAR_PHOTO) {
            drawCovering(canvas, r, own)
        } else {
            val face = portraitBitmap()
            if (face != null) drawCovering(canvas, r, face) else drawFallbackFace(canvas, r)
        }

        canvas.restore()
    }

    /** Fills the window with [bitmap], cropping rather than squashing it. */
    private fun drawCovering(canvas: Canvas, r: RectF, bitmap: Bitmap) {
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        if (bw <= 0f || bh <= 0f) return
        val scale = maxOf(r.width() / bw, r.height() / bh)
        val dw = bw * scale
        val dh = bh * scale
        canvas.drawBitmap(
            bitmap, null,
            RectF(r.centerX() - dw / 2f, r.centerY() - dh / 2f,
                  r.centerX() + dw / 2f, r.centerY() + dh / 2f),
            picturePaint
        )
    }

    private fun portraitBitmap(): Bitmap? {
        portrait?.let { return it }
        val res = PictureArt.avatar(avatarId)
        if (res == 0) return null
        portrait = try {
            BitmapFactory.decodeResource(resources, res)
        } catch (e: Throwable) {
            null
        }
        return portrait
    }

    /**
     * The face drawn when there is no picture: a plain head and shoulders.
     *
     * It exists so a missing or undecodable file costs a bit of polish rather
     * than leaving a coloured hole where a player should be.
     */
    private fun drawFallbackFace(canvas: Canvas, r: RectF) {
        val cx = r.centerX()
        val cy = r.centerY()
        val u = min(r.width(), r.height()) * 0.5f
        fill.color = darken(accent, 0.45f)
        canvas.drawCircle(cx, cy + u * 1.02f, u * 0.86f, fill)
        fill.color = if (isBot) Color.rgb(0xCF, 0xDC, 0xEE) else Color.rgb(0xF2, 0xC6, 0xA0)
        canvas.drawCircle(cx, cy - u * 0.08f, u * 0.46f, fill)
        fill.color = Color.rgb(0x22, 0x1A, 0x14)
        canvas.drawCircle(cx - u * 0.16f, cy - u * 0.09f, u * 0.055f, fill)
        canvas.drawCircle(cx + u * 0.16f, cy - u * 0.09f, u * 0.055f, fill)
    }

    // ---------------------------------------------------------------- frame

    private fun drawFrame(canvas: Canvas, box: RectF) {
        if (frameId == Cosmetics.FRAME_NONE) return
        var art = frameArt
        if (art == null) {
            val res = PictureArt.frame(frameId)
            if (res == 0) return
            art = try {
                BitmapFactory.decodeResource(resources, res)
            } catch (e: Throwable) {
                null
            } ?: return
            frameArt = art
        }
        canvas.drawBitmap(art, null, box, picturePaint)
    }

    // ------------------------------------------------------------ turn clock

    /**
     * The seconds left, running clockwise round the portrait and shrinking.
     *
     * The colour used to start gold, which is the colour of the frames — so a
     * clock with plenty of time left was invisible against them. Cool
     * white-blue reads against gold, and leaves amber and red to mean "hurry"
     * and "now".
     */
    private fun drawClock(canvas: Canvas, r: RectF, corner: Float) {
        val left = secondsLeft ?: return
        val total = if (totalSeconds > 0f) totalSeconds else 15f
        val w = min(r.width(), r.height()) * 0.14f

        clockPath.reset()
        clockPath.addRoundRect(r, corner, corner, Path.Direction.CW)

        clockTrack.strokeWidth = w
        canvas.drawPath(clockPath, clockTrack)

        measure.setPath(clockPath, false)
        val length = measure.length
        if (length <= 0f) return

        val fraction = (left / total).coerceIn(0f, 1f)
        clockSegment.reset()
        measure.getSegment(0f, length * fraction, clockSegment, true)

        val color = when {
            left > total * 0.4f -> Color.rgb(0x9A, 0xE8, 0xFF)
            left > total * 0.15f -> Color.rgb(0xFF, 0x98, 0x1F)
            else -> Color.rgb(0xF2, 0x3B, 0x3B)
        }

        if (left <= total * 0.15f) {
            val p = 0.5f + 0.5f * kotlin.math.sin(pulse)
            clockGlow.strokeWidth = w * (1.4f + 0.9f * p)
            clockGlow.color = Color.argb((70 + 70 * p).toInt().coerceIn(0, 255), 0xF2, 0x3B, 0x3B)
            canvas.drawPath(clockSegment, clockGlow)
        }

        clockLine.color = color
        clockLine.strokeWidth = w * 0.72f
        canvas.drawPath(clockSegment, clockLine)

        // the number itself for the last few seconds, where it cannot be missed
        if (left <= 5f) {
            val text = kotlin.math.ceil(left.toDouble()).toInt().coerceAtLeast(0).toString()
            val plate = w * 2.2f
            val box = RectF(
                r.centerX() - plate / 2f, r.bottom - plate * 0.62f,
                r.centerX() + plate / 2f, r.bottom + plate * 0.38f
            )
            fill.color = Color.argb(225, 0x10, 0x0C, 0x06)
            canvas.drawRoundRect(box, plate * 0.28f, plate * 0.28f, fill)
            clockText.textSize = plate * 0.70f
            clockText.color = color
            clockText.getTextBounds(text, 0, text.length, textBounds)
            canvas.drawText(text, box.centerX(), box.centerY() + textBounds.height() / 2f, clockText)
        }
    }

    // ---------------------------------------------------------------- colour

    private fun lighten(c: Int, f: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
    )

    private fun darken(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.green(c) * (1 - f)).toInt().coerceIn(0, 255),
        (Color.blue(c) * (1 - f)).toInt().coerceIn(0, 255)
    )

    companion object {
        /**
         * The opening every frame shows its face through.
         *
         * MEASURED OFF THE SIX FILES, not chosen: it is the largest rectangle
         * that fits inside all six of their windows. Because it is the same for
         * every frame, a player's face is exactly as big with the plain gold
         * band as it is with the laurel crown.
         */
        const val WINDOW_LEFT = 0.278f
        const val WINDOW_TOP = 0.303f
        const val WINDOW_RIGHT = 0.722f
        const val WINDOW_BOTTOM = 0.750f
    }
}
