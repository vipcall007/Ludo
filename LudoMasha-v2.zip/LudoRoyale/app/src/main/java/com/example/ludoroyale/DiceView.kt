package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * Premium dice face: soft drop shadow, gradient ivory body, glossy top
 * highlight, gold rim, and recessed pips with a subtle inner shadow.
 * Tintable per player via [accent]. [dimmed] greys it out off-turn.
 * All drawn in code — no image assets.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) { field = v.coerceIn(1, 6); invalidate() }

    var dimmed: Boolean = false
        set(v) { field = v; invalidate() }

    /** Rim colour — normally the owning player's colour. */
    var accent: Int = Color.rgb(0xF2, 0xC1, 0x4E)
        set(v) { field = v; invalidate() }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 0, 0, 0) }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipInner = Paint(Paint.ANTI_ALIAS_FLAG)

    private val layouts: Map<Int, List<Pair<Float, Float>>> = mapOf(
        1 to listOf(0.5f to 0.5f),
        2 to listOf(0.3f to 0.3f, 0.7f to 0.7f),
        3 to listOf(0.27f to 0.27f, 0.5f to 0.5f, 0.73f to 0.73f),
        4 to listOf(0.3f to 0.3f, 0.7f to 0.3f, 0.3f to 0.7f, 0.7f to 0.7f),
        5 to listOf(0.27f to 0.27f, 0.73f to 0.27f, 0.5f to 0.5f, 0.27f to 0.73f, 0.73f to 0.73f),
        6 to listOf(
            0.3f to 0.23f, 0.7f to 0.23f,
            0.3f to 0.5f, 0.7f to 0.5f,
            0.3f to 0.77f, 0.7f to 0.77f
        )
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val inset = w * 0.08f
        val corner = w * 0.24f
        val face = RectF(inset, inset, w - inset, h - inset)

        // drop shadow
        canvas.drawRoundRect(
            RectF(face.left + w * 0.03f, face.top + h * 0.07f, face.right + w * 0.03f, face.bottom + h * 0.07f),
            corner, corner, shadowPaint
        )

        // body: soft vertical gradient (ivory -> light grey), or flat grey when dimmed
        bodyPaint.shader = if (dimmed) null else LinearGradient(
            face.left, face.top, face.left, face.bottom,
            Color.rgb(0xFF, 0xFF, 0xFF), Color.rgb(0xDE, 0xE4, 0xEA),
            Shader.TileMode.CLAMP
        )
        bodyPaint.color = if (dimmed) Color.rgb(0x9E, 0xAC, 0xB8) else Color.WHITE
        canvas.drawRoundRect(face, corner, corner, bodyPaint)
        bodyPaint.shader = null

        // glossy highlight on the upper half
        if (!dimmed) {
            glossPaint.shader = RadialGradient(
                face.centerX(), face.top + face.height() * 0.22f, face.width() * 0.62f,
                Color.argb(150, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(face, corner, corner, glossPaint)
            glossPaint.shader = null
        }

        // rim
        rimPaint.strokeWidth = w * 0.045f
        rimPaint.color = if (dimmed) Color.rgb(0x6B, 0x7A, 0x88) else accent
        canvas.drawRoundRect(face, corner, corner, rimPaint)

        // pips (with a soft inner shadow so they look recessed)
        val pipR = w * 0.075f
        pipPaint.color = if (dimmed) Color.rgb(0x4A, 0x55, 0x60) else Color.rgb(0x1E, 0x28, 0x32)
        pipInner.color = Color.argb(70, 255, 255, 255)
        for ((fx, fy) in layouts.getValue(value)) {
            val cx = face.left + fx * face.width()
            val cy = face.top + fy * face.height()
            canvas.drawCircle(cx, cy, pipR, pipPaint)
            canvas.drawCircle(cx - pipR * 0.25f, cy - pipR * 0.28f, pipR * 0.42f, pipInner)
        }
    }
}
