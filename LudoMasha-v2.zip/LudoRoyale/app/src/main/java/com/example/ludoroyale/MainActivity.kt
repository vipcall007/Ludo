package com.example.ludoroyale

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 * Classic and Arrow modes, optional 2v2 teams, per-player names and dice.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val dice: DiceView,
        val arrow: View
    )

    private lateinit var boardView: LudoBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var btnMenu: View

    private lateinit var modeGroup: RadioGroup
    private lateinit var countGroup: RadioGroup
    private lateinit var modeHint: TextView
    private lateinit var optTeams: CheckBox
    private lateinit var optLucky: CheckBox
    private lateinit var nameFields: List<EditText>

    private var engine: LudoEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()
    private var pendingMoves: List<Move> = emptyList()
    private var rolling = false

    /** Seat order so colours sit opposite correctly, and teams pair across. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.YELLOW, PlayerColor.GREEN)
        else -> listOf(PlayerColor.RED, PlayerColor.YELLOW, PlayerColor.GREEN, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        btnMenu = findViewById(R.id.btnMenu)

        modeGroup = findViewById(R.id.modeGroup)
        countGroup = findViewById(R.id.countGroup)
        modeHint = findViewById(R.id.modeHint)
        optTeams = findViewById(R.id.optTeams)
        optLucky = findViewById(R.id.optLucky)
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        countGroup.setOnCheckedChangeListener { _, _ -> syncNameFields() }
        modeGroup.setOnCheckedChangeListener { _, _ -> syncModeHint() }
        findViewById<View>(R.id.btnStart).setOnClickListener { startGame() }
        btnMenu.setOnClickListener { showMenu() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }

        syncNameFields()
        syncModeHint()
    }

    private fun selectedCount(): Int = when (countGroup.checkedRadioButtonId) {
        R.id.count3 -> 3
        R.id.count4 -> 4
        else -> 2
    }

    private fun arrowSelected(): Boolean = modeGroup.checkedRadioButtonId == R.id.modeArrow

    private fun syncNameFields() {
        val count = selectedCount()
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
        }
        // teams only make sense with exactly 4 players
        optTeams.isEnabled = count == 4
        if (count != 4) optTeams.isChecked = false
    }

    private fun syncModeHint() {
        modeHint.text = if (arrowSelected()) {
            "Arrow: land on an arrow and it carries your piece forward — then you roll again."
        } else {
            "Classic: normal Ludo rules."
        }
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun startGame() {
        val count = selectedCount()
        val colors = seatColors(count)
        val teamsOn = optTeams.isChecked && count == 4

        val players = colors.mapIndexed { i, color ->
            val typed = nameFields[i].text.toString().trim()
            val name = if (typed.isNotEmpty()) typed else "Player ${i + 1}"
            // teams pair the players sitting opposite each other
            val team = if (!teamsOn) 0 else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            Player.create("p${i + 1}", name, color, PlayerKind.HUMAN, team)
        }.toMutableList()

        val rules = RuleConfig(
            arrowMode = arrowSelected(),
            teamMode = teamsOn,
            luckyDice = optLucky.isChecked
        )

        val newEngine = LudoEngine(GameState(gameId = "pass-n-play", players = players), rules)
        engine = newEngine
        boardView.arrowMode = rules.arrowMode
        boardView.snapToState(newEngine.state)
        pendingMoves = emptyList()
        rolling = false

        for ((color, slot) in slots) {
            val player = players.firstOrNull { it.color == color }
            if (player == null) {
                slot.root.visibility = View.INVISIBLE
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teamsOn) "${player.displayName} (${if (player.team == 1) "A" else "B"})"
                                 else player.displayName
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.value = 1
            }
        }

        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        render()
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_new),
                    getString(R.string.menu_close),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> startGame()          // same settings, fresh board
                    1 -> backToSetup()
                    2 -> finish()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun backToSetup() {
        engine = null
        pendingMoves = emptyList()
        rolling = false
        for ((_, slot) in slots) {
            slot.arrow.clearAnimation()
            slot.arrow.animate().cancel()
        }
        gamePanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        setupPanel.visibility = View.VISIBLE
    }

    private fun handleRoll() {
        val e = engine ?: return
        val s = e.state
        if (rolling || s.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[s.currentPlayer.color] ?: return

        rolling = true
        val finalRoll = e.rollDice() // real result decided now; the shake only reveals it
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 10, finalValue = finalRoll)
    }

    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.2f).scaleY(1.2f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int) {
        if (remaining <= 0) {
            dice.value = finalValue
            SoundFx.diceRoll()
            rolling = false
            onDiceRevealed(finalValue)
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue) }, 50)
    }

    private fun onDiceRevealed(roll: Int) {
        val e = engine ?: return
        pendingMoves = e.legalMoves(roll)
        when {
            pendingMoves.isEmpty() -> {
                e.passTurn()
                pendingMoves = emptyList()
                render()
            }
            // only one piece can move: play it automatically, no pointless tap
            pendingMoves.size == 1 -> {
                val only = pendingMoves.first()
                render()
                boardView.postDelayed({ playMove(only) }, 220)
            }
            else -> render()
        }
    }

    private fun handleTokenTap(token: Token) {
        val move = pendingMoves.firstOrNull { it.token.id == token.id } ?: return
        playMove(move)
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        pendingMoves = emptyList()
        boardView.tappableTokenIds = emptySet() // lock input while the piece walks

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            val result = e.applyMove(move)

            val finish = {
                boardView.snapToState(e.state)
                when {
                    result.gameWon -> SoundFx.win()
                    result.capturedTokens.isNotEmpty() -> SoundFx.capture()
                    else -> SoundFx.tokenMove()
                }
                render()
            }

            val landed = result.arrowLandedSteps
            if (landed != null) {
                // arrow mode: carry the piece on to where the arrow ends
                SoundFx.arrow()
                boardView.hopToken(move.token.id, move.token.color, move.toSteps, landed) { finish() }
            } else {
                finish()
            }
        }
    }

    private fun render() {
        val e = engine ?: return
        val s = e.state
        boardView.tappableTokenIds = pendingMoves.map { it.token.id }.toSet()

        val gameOver = s.phase == TurnPhase.GAME_OVER
        val activeColor = if (gameOver) null else s.currentPlayer.color

        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == activeColor
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable = isActive && pendingMoves.isEmpty() && !rolling

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }
        }

        val roll = s.lastDiceRoll
        if (roll != null && activeColor != null) slots[activeColor]?.dice?.value = roll

        if (gameOver) announceWinner(s)
    }

    /** Pulsing arrow so whose turn it is is unmissable. */
    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    private fun announceWinner(s: GameState) {
        val winner = s.players.firstOrNull { it.id == s.rankings.firstOrNull() } ?: return
        val title = if (winner.team != 0) {
            "Team ${if (winner.team == 1) "A" else "B"} wins!"
        } else {
            "${winner.displayName} wins!"
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Play again?")
            .setPositiveButton(R.string.menu_restart) { _, _ -> startGame() }
            .setNegativeButton(R.string.menu_new) { _, _ -> backToSetup() }
            .setCancelable(true)
            .show()
    }

    private companion object {
        const val BLINKING = "blinking"
    }
}
