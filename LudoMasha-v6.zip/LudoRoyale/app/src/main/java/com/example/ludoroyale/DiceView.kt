package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

/**
 * Shows a real golden dice face (artwork supplied by the user, one image per
 * value). [dimmed] desaturates it for players whose turn it isn't; [accent]
 * draws a thin ring in the owning player's colour so you can tell the dice apart.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) {
            field = v.coerceIn(1, 6)
            face = faceFor(field)
            invalidate()
        }

    var dimmed: Boolean = false
        set(v) { field = v; invalidate() }

    /** Rim colour — normally the owning player's colour. 0 = no rim. */
    var accent: Int = 0
        set(v) { field = v; invalidate() }

    private var face: Drawable? = null

    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val grey = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.15f) })

    init {
        face = faceFor(value)
    }

    private fun faceFor(v: Int): Drawable? {
        val id = when (v) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        return ContextCompat.getDrawable(context, id)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return

        val d = face ?: return
        val pad = (w * 0.04f).toInt()
        d.bounds = Rect(pad, pad, w - pad, h - pad)
        d.colorFilter = if (dimmed) grey else null
        d.alpha = if (dimmed) 150 else 255
        d.draw(canvas)

        if (accent != 0) {
            rimPaint.color = accent
            rimPaint.alpha = if (dimmed) 90 else 255
            rimPaint.strokeWidth = w * 0.045f
            val r = w * 0.16f
            val inset = w * 0.02f
            canvas.drawRoundRect(
                RectF(inset, inset, w - inset, h - inset), r, r, rimPaint
            )
            rimPaint.alpha = 255
        }
    }
}
