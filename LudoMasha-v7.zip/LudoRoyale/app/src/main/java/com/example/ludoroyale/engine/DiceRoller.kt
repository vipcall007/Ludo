package com.example.ludoroyale.engine

import java.security.SecureRandom

/**
 * Dice source. Unbiased by default (SecureRandom, uniform 1-6).
 * When [lucky] is on, it rolls twice and keeps the higher face — an
 * openly-chosen setting that applies to every player equally, never a
 * hidden tilt toward or against anyone.
 */
class DiceRoller(
    private val random: SecureRandom = SecureRandom(),
    private val lucky: Boolean = false
) {
    fun roll(): Int {
        val first = 1 + random.nextInt(6)
        if (!lucky) return first
        val second = 1 + random.nextInt(6)
        return maxOf(first, second)
    }
}
