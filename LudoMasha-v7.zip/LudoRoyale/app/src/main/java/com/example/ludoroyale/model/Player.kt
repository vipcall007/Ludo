package com.example.ludoroyale.model

enum class PlayerKind { HUMAN, AI_EASY, AI_MEDIUM, AI_HARD, REMOTE }

data class Player(
    val id: String,
    val displayName: String,
    val color: PlayerColor,
    val kind: PlayerKind,
    /** 0 = no team. In team mode: 1 = Team A, 2 = Team B. */
    var team: Int = 0,
    val tokens: MutableList<Token> = mutableListOf(),
    var finishedCount: Int = 0,
    var hasWon: Boolean = false
) {
    companion object {
        const val TOKENS_PER_PLAYER = 4

        fun create(id: String, name: String, color: PlayerColor, kind: PlayerKind, team: Int = 0): Player {
            val tokens = (0 until TOKENS_PER_PLAYER).map { i ->
                Token(id = "${color.name}_$i", color = color)
            }.toMutableList()
            return Player(id, name, color, kind, team, tokens)
        }
    }
}
