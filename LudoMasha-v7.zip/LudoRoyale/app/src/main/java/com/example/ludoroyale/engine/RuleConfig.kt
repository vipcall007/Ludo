package com.example.ludoroyale.engine

data class RuleConfig(
    val extraTurnOnSix: Boolean = true,
    val threeSixCancelsTurn: Boolean = true,
    val captureGrantsExtraTurn: Boolean = true,
    /** Sending one of your pieces home also earns another roll. */
    val finishGrantsExtraTurn: Boolean = true,
    val exactRollToFinish: Boolean = true,
    val safeCellsBlockCapture: Boolean = true,
    val sixRequiredToLeaveBase: Boolean = true,

    /** ARROW MODE: landing exactly on an arrow's start cell carries the piece
     *  to where that arrow ends, and the same player rolls again. */
    val arrowMode: Boolean = false,

    /** TEAM MODE (2v2): partners sit opposite each other and cannot capture
     *  their own team's pieces. */
    val teamMode: Boolean = false,

    /** Openly-labelled "lucky dice": rolls the die twice and keeps the higher
     *  face, so sixes and captures happen more often. Applied identically to
     *  EVERY player — it speeds the game up, it does not favour anyone. */
    val luckyDice: Boolean = false
)
