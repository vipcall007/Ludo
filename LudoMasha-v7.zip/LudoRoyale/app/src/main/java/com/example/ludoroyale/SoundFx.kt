package com.example.ludoroyale

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Original sound effects synthesised on the fly (sine tones rendered into an
 * AudioTrack) — no audio files bundled, nothing copied, and far more reliable
 * than ToneGenerator, which was silent on some phones.
 */
object SoundFx {

    private const val RATE = 22050
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    /** [freq] start pitch; [endFreq] slides to it when set (comic slides, whoops). */
    private data class Note(val freq: Double, val ms: Int, val vol: Double = 0.55, val endFreq: Double = -1.0)

    var enabled: Boolean = true

    // ---- public effects ----

    fun gameStart() = play(
        listOf(
            Note(523.0, 120), Note(659.0, 120), Note(784.0, 120), Note(1047.0, 300, 0.6)
        )
    )

    fun diceRoll() = play(
        listOf(Note(440.0, 45, 0.4), Note(520.0, 45, 0.4), Note(610.0, 70, 0.45))
    )

    fun step() = play(listOf(Note(880.0, 28, 0.25)))

    fun tokenMove() = play(listOf(Note(700.0, 70, 0.4)))

    /** Comic "wah-wah-wahhh" slide when a piece gets cut. */
    fun capture() = play(
        listOf(
            Note(700.0, 150, 0.55, endFreq = 520.0),
            Note(560.0, 150, 0.55, endFreq = 410.0),
            Note(430.0, 420, 0.60, endFreq = 190.0)
        )
    )

    /** Sparkle for the arrow-mode magic jump. */
    fun magic() = play(
        listOf(
            Note(900.0, 45, 0.4), Note(1200.0, 45, 0.4), Note(1500.0, 45, 0.45),
            Note(1800.0, 60, 0.5), Note(2200.0, 120, 0.45)
        )
    )

    /** Full celebration fanfare on a win. */
    fun win() = play(
        listOf(
            Note(523.0, 130), Note(659.0, 130), Note(784.0, 130), Note(1047.0, 240, 0.62),
            Note(0.0, 70),
            Note(784.0, 110), Note(1047.0, 110), Note(1319.0, 520, 0.65, endFreq = 1568.0)
        )
    )

    /** Buzzer when three sixes burn the turn. */
    fun turnLost() = play(
        listOf(Note(200.0, 200, 0.55), Note(0.0, 50), Note(165.0, 280, 0.55))
    )

    fun arrow() = magic()

    // ---- synthesis ----

    private fun play(notes: List<Note>) {
        if (!enabled) return
        exec.execute {
            try {
                val totalMs = notes.sumOf { it.ms }
                val totalSamples = RATE * totalMs / 1000
                if (totalSamples <= 0) return@execute
                val buffer = ShortArray(totalSamples)

                var idx = 0
                for (note in notes) {
                    val count = min(RATE * note.ms / 1000, totalSamples - idx)
                    for (i in 0 until count) {
                        val t = i.toDouble() / RATE
                        val f = if (note.endFreq > 0.0)
                                    note.freq + (note.endFreq - note.freq) * (i.toDouble() / count)
                                else note.freq
                        val sample = if (f <= 0.0) 0.0
                                     else sin(2.0 * PI * f * t) * envelope(i, count) * note.vol
                        buffer[idx++] = (sample * Short.MAX_VALUE).toInt().toShort()
                    }
                    if (idx >= totalSamples) break
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                handler.postDelayed({
                    try { track.stop(); track.release() } catch (_: Exception) { }
                }, (totalMs + 250).toLong())
            } catch (_: Exception) {
                // never let a sound problem break the game
            }
        }
    }

    /** Short fade in/out so notes don't click. */
    private fun envelope(i: Int, count: Int): Double {
        if (count <= 1) return 0.0
        val fade = max(1, count / 12)
        val rise = min(1.0, i.toDouble() / fade)
        val fall = min(1.0, (count - 1 - i).toDouble() / fade)
        return min(rise, fall)
    }
}
