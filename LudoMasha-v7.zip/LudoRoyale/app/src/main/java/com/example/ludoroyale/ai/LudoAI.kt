package com.example.ludoroyale.ai

import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import kotlin.random.Random

/**
 * Picks a move from the same [Move] list the human UI would show — the AI
 * never sees hidden information and never gets moves a human couldn't make
 * (spec section 30: "AI must follow exactly the same legal move rules").
 */
object LudoAI {

    fun chooseMove(kind: PlayerKind, legalMoves: List<Move>, random: Random = Random.Default): Move {
        require(legalMoves.isNotEmpty())
        return when (kind) {
            PlayerKind.AI_EASY -> legalMoves[random.nextInt(legalMoves.size)]
            PlayerKind.AI_MEDIUM -> legalMoves.maxByOrNull { score(it, aggressive = false) } ?: legalMoves.first()
            PlayerKind.AI_HARD -> legalMoves.maxByOrNull { score(it, aggressive = true) } ?: legalMoves.first()
            else -> legalMoves.first()
        }
    }

    /** Higher = more desirable. Captures > finishing > reaching safety > leaving base > plain advance. */
    private fun score(move: Move, aggressive: Boolean): Int {
        var s = 0
        if (move.capturesTokenIds.isNotEmpty()) s += if (aggressive) 100 else 70
        if (move.finishesToken) s += 90
        if (move.entersHomeStretch) s += 40
        if (move.leavesBase) s += 20

        if (aggressive && move.token.state != TokenState.BASE) {
            val landsOnSafe = LudoBoard.isSafeCell(
                LudoBoard.toGlobalIndex(move.token.color, move.toSteps - 1)
            )
            if (landsOnSafe) s += 25
            // Mild preference for advancing tokens that are furthest along already.
            s += move.token.steps / 4
        }
        return s
    }
}
