package com.example.ludoroyale

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Animated startup screen: the logo spins/scales in, the title and tagline
 * fade up, then the game opens. Pure view animation — no video file needed,
 * so it costs nothing in APK size and runs on low-end phones.
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<ImageView>(R.id.splashLogo)
        val title = findViewById<TextView>(R.id.splashTitle)
        val tag = findViewById<TextView>(R.id.splashTag)

        // start states
        logo.alpha = 0f
        logo.scaleX = 0.4f
        logo.scaleY = 0.4f
        logo.rotation = -35f
        for (v: View in listOf(title, tag)) {
            v.alpha = 0f
            v.translationY = 40f
        }

        logo.animate()
            .alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
            .setDuration(650)
            .withEndAction {
                // gentle pulse so it feels alive, like a short looping clip
                logo.animate().scaleX(1.08f).scaleY(1.08f).setDuration(420)
                    .withEndAction {
                        logo.animate().scaleX(1f).scaleY(1f).setDuration(420).start()
                    }.start()
            }
            .start()

        title.animate().alpha(1f).translationY(0f).setStartDelay(420).setDuration(520).start()
        tag.animate().alpha(1f).translationY(0f).setStartDelay(620).setDuration(520).start()

        logo.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2100)
    }
}
