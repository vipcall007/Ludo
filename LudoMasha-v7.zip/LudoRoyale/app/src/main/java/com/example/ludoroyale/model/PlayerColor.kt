package com.example.ludoroyale.model

/**
 * The four Ludo colors. [startOffset] is this color's entry index on the
 * shared 52-cell outer track (0..51). [homeEntryOffset] is the index (0..51)
 * of the cell just before this color turns into its own private home stretch.
 */
enum class PlayerColor(val startOffset: Int, val homeEntryOffset: Int) {
    GREEN(0, 50),
    YELLOW(13, 11),
    BLUE(26, 24),
    RED(39, 37);

    companion object {
        fun forPlayerCount(count: Int): List<PlayerColor> =
            when (count) {
                2 -> listOf(RED, YELLOW)          // opposite corners
                3 -> listOf(RED, GREEN, YELLOW)
                else -> listOf(RED, GREEN, YELLOW, BLUE)
            }
    }
}
