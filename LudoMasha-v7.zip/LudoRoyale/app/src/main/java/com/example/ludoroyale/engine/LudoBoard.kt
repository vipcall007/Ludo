package com.example.ludoroyale.engine

import com.example.ludoroyale.model.PlayerColor

/**
 * Pure geometry of a classic Ludo board — no rendering, no Android
 * dependencies. UI layers map these indices onto screen coordinates.
 */
object LudoBoard {
    const val TRACK_LENGTH = 52          // shared outer ring, indices 0..51
    const val HOME_STRETCH_LENGTH = 6    // private final path per color, 0..5
    const val FINAL_INDEX = HOME_STRETCH_LENGTH - 1

    /** Global (0..51) cells that are safe — no captures allowed there. */
    val SAFE_CELLS: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    fun isSafeCell(globalIndex: Int): Boolean = globalIndex in SAFE_CELLS

    /** Converts a token's own relative track position to the shared global index. */
    fun toGlobalIndex(color: PlayerColor, relativeIndex: Int): Int =
        (color.startOffset + relativeIndex) % TRACK_LENGTH

    /** Steps remaining on the shared track before this color enters its home stretch. */
    fun stepsToHomeEntry(color: PlayerColor, relativeIndex: Int): Int {
        val entryRelative = ((color.homeEntryOffset - color.startOffset) + TRACK_LENGTH) % TRACK_LENGTH
        return entryRelative - relativeIndex
    }

    /**
     * ARROW MODE shortcuts: global ring index -> cells carried forward.
     *
     * These four indices are deliberately chosen because the 3 cells after
     * them run in a STRAIGHT line along one side of the board. Earlier the
     * arrows sat on corners, so the drawn arrow cut diagonally across the
     * board instead of following the track. Each landing cell also avoids the
     * safe stars and the colour start cells.
     */
    val ARROWS: Map<Int, Int> = mapOf(
        1 to 3,    // lands on 4
        12 to 3,   // lands on 15
        20 to 3,   // lands on 23
        32 to 3    // lands on 35
    )

    fun arrowJumpAt(globalIndex: Int): Int? = ARROWS[globalIndex]
}
