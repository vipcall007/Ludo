package com.example.ludoroyale

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 *
 * Turn flow: tap your dice; a six banks and makes you roll again; three sixes
 * burn the turn. Once you stop rolling, your banked values appear in the tray
 * and YOU choose which value to spend and on which piece.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val dice: DiceView,
        val arrow: View,
        val rolls: LinearLayout
    )

    private lateinit var boardView: LudoBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var btnMenu: View

    private lateinit var cardClassic: View
    private lateinit var cardArrow: View
    private lateinit var labelClassic: TextView
    private lateinit var labelArrow: TextView
    private lateinit var modeHint: TextView
    private lateinit var pills: List<TextView>
    private lateinit var optTeams: CheckBox
    private lateinit var optLucky: CheckBox
    private lateinit var nameFields: List<EditText>

    private var engine: LudoEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()
    private var arrowSelected = false
    private var playerCount = 2
    private var rolling = false
    private var choiceTokenId: String? = null
    private var busy = false

    /** Classic clockwise seating order — team mode keeps exactly this order. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
        else -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        btnMenu = findViewById(R.id.btnMenu)

        cardClassic = findViewById(R.id.cardClassic)
        cardArrow = findViewById(R.id.cardArrow)
        labelClassic = findViewById(R.id.labelClassic)
        labelArrow = findViewById(R.id.labelArrow)
        modeHint = findViewById(R.id.modeHint)
        optTeams = findViewById(R.id.optTeams)
        optLucky = findViewById(R.id.optLucky)
        pills = listOf(findViewById(R.id.pill2), findViewById(R.id.pill3), findViewById(R.id.pill4))
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft), findViewById(R.id.rollsTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight), findViewById(R.id.rollsTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft), findViewById(R.id.rollsBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight), findViewById(R.id.rollsBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        cardClassic.setOnClickListener { selectMode(false) }
        cardArrow.setOnClickListener { selectMode(true) }
        pills.forEachIndexed { i, pill -> pill.setOnClickListener { selectCount(i + 2) } }
        findViewById<View>(R.id.btnStart).setOnClickListener { startGame() }
        btnMenu.setOnClickListener { showMenu() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        boardView.onChoicePicked = { value -> handleChoicePicked(value) }

        selectMode(false)
        selectCount(2)
    }

    // ---------- setup screen ----------

    private fun selectMode(arrow: Boolean) {
        arrowSelected = arrow
        cardClassic.setBackgroundResource(if (arrow) R.drawable.card_normal else R.drawable.card_selected)
        cardArrow.setBackgroundResource(if (arrow) R.drawable.card_selected else R.drawable.card_normal)
        labelClassic.setTextColor(if (arrow) Color.WHITE else Color.rgb(0x1B, 0x25, 0x51))
        labelArrow.setTextColor(if (arrow) Color.rgb(0x1B, 0x25, 0x51) else Color.WHITE)
        modeHint.text = if (arrow) {
            "Arrow: land on an arrow and your piece magically jumps to where it ends — then you roll again."
        } else {
            "Classic: normal Ludo rules."
        }
    }

    private fun selectCount(count: Int) {
        playerCount = count
        pills.forEachIndexed { i, pill ->
            val on = i + 2 == count
            pill.setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
            pill.setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
        }
        val seats = seatColors(count)
        val hints = listOf("Red", "Green", "Yellow", "Blue")
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
            if (i < count) {
                val colorName = hints[PlayerColor.entries.indexOf(seats[i]).coerceIn(0, 3)]
                field.hint = "Player ${i + 1} ($colorName)"
            }
        }
        optTeams.isEnabled = count == 4
        if (count != 4) optTeams.isChecked = false
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    // ---------- game ----------

    private fun startGame() {
        val colors = seatColors(playerCount)
        val teamsOn = optTeams.isChecked && playerCount == 4

        val players = colors.mapIndexed { i, color ->
            val typed = nameFields[i].text.toString().trim()
            val name = if (typed.isNotEmpty()) typed else "Player ${i + 1}"
            // partners sit opposite: Red+Yellow vs Green+Blue
            val team = if (!teamsOn) 0
                       else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            Player.create("p${i + 1}", name, color, PlayerKind.HUMAN, team)
        }.toMutableList()

        val rules = RuleConfig(
            arrowMode = arrowSelected,
            teamMode = teamsOn,
            luckyDice = optLucky.isChecked
        )

        val newEngine = LudoEngine(GameState(gameId = "pass-n-play", players = players), rules)
        engine = newEngine
        boardView.arrowMode = rules.arrowMode
        boardView.snapToState(newEngine.state)
        rolling = false
        busy = false

        for ((color, slot) in slots) {
            val player = players.firstOrNull { it.color == color }
            if (player == null) {
                slot.root.visibility = View.INVISIBLE
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teamsOn) {
                    "${player.displayName}  •  Team ${if (player.team == 1) "A" else "B"}"
                } else player.displayName
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.value = 1
            }
        }

        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        SoundFx.gameStart()
        render()
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_new),
                    getString(R.string.menu_close),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> startGame()
                    1 -> backToSetup()
                    2 -> finish()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun backToSetup() {
        engine = null
        rolling = false
        busy = false
        for ((_, slot) in slots) stopBlink(slot.arrow)
        gamePanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        setupPanel.visibility = View.VISIBLE
    }

    private fun handleRoll() {
        val e = engine ?: return
        if (rolling || busy || e.state.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[e.state.currentPlayer.color] ?: return

        rolling = true
        clearChoice()
        val outcome = e.rollDice()
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 10, finalValue = outcome.value) {
            rolling = false
            when {
                outcome.turnLostToThreeSixes -> {
                    SoundFx.turnLost()
                                toast("Three sixes — turn lost, all rolls wasted!")
                    render()
                }
                outcome.mustRollAgain -> {
                    // six banked; the same player must roll again
                    render()
                }
                else -> onRollingFinished()
            }
        }
    }

    /** Shake + spin so rolling actually feels like rolling. */
    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.22f).scaleY(1.22f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    /**
     * Flickers random faces, then settles on the value the engine already
     * decided. The animation only reveals the result — it never changes it.
     */
    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int, onDone: () -> Unit) {
        if (remaining <= 0) {
            dice.value = finalValue
            SoundFx.diceRoll()
            onDone()
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue, onDone) }, 48)
    }

    private fun onRollingFinished() {
        val e = engine ?: return
        val moves = e.legalMoves()
        if (moves.isEmpty()) {
            e.passTurn()
            render()
            return
        }
        render()
        maybeAutoPlay()
    }

    /**
     * Plays by itself only when there is genuinely nothing to decide: one
     * piece, one value. The moment there is a real choice (a six banked next
     * to another number, or several pieces out) it hands control back.
     */
    private fun maybeAutoPlay() {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return
        val moves = e.legalMoves()
        val distinctValues = e.state.pendingRolls.distinct()
        val distinctTokens = moves.map { it.token.id }.distinct()
        if (moves.size == 1 || (distinctTokens.size == 1 && distinctValues.size == 1)) {
            val only = moves.first()
            boardView.postDelayed({ playMove(only) }, 260)
        }
    }

    private fun handleTokenTap(token: Token) {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return

        // which banked values can move THIS piece?
        val options = e.state.pendingRolls.distinct()
            .mapNotNull { value -> e.legalMovesFor(value).firstOrNull { it.token.id == token.id } }

        when {
            options.isEmpty() -> return
            options.size == 1 -> {
                clearChoice()
                playMove(options.first())
            }
            else -> {
                // little number chips float over the piece itself
                choiceTokenId = token.id
                boardView.showChoices(token.id, options.map { it.usedRoll })
            }
        }
    }

    /** Player tapped one of the number chips over a piece. */
    private fun handleChoicePicked(value: Int) {
        val e = engine ?: return
        val tokenId = choiceTokenId ?: return
        val move = e.legalMovesFor(value).firstOrNull { it.token.id == tokenId } ?: return
        clearChoice()
        playMove(move)
    }

    private fun clearChoice() {
        choiceTokenId = null
        boardView.clearChoices()
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        if (busy) return
        clearChoice()
        busy = true
        boardView.tappableTokenIds = emptySet()

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            val result = e.applyMove(move)

            val finish = {
                boardView.snapToState(e.state)
                when {
                    result.gameWon -> SoundFx.win()
                    result.capturedTokens.isNotEmpty() -> SoundFx.capture()
                    else -> SoundFx.tokenMove()
                }
                busy = false
                render()
                maybeAutoPlay()
            }

            val landed = result.arrowLandedSteps
            if (landed != null) {
                SoundFx.magic()
                boardView.magicTeleport(move.token.id, move.token.color, landed) { finish() }
            } else {
                finish()
            }
        }
    }

    // ---------- rendering ----------

    private fun render() {
        val e = engine ?: return
        val s = e.state
        val gameOver = s.phase == TurnPhase.GAME_OVER
        val activeColor = if (gameOver) null else s.currentPlayer.color

        // every piece any banked value can move is tappable (and pulses)
        boardView.tappableTokenIds =
            if (!busy && !rolling && s.phase == TurnPhase.AWAITING_MOVE)
                e.legalMoves().map { it.token.id }.toSet()
            else emptySet()

        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == activeColor
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable =
                isActive && !busy && !rolling && s.phase == TurnPhase.AWAITING_ROLL

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }

            renderRollsFor(color, slot, isActive)
        }

        val last = s.lastDiceRoll
        if (last != null && activeColor != null) slots[activeColor]?.dice?.value = last

        if (gameOver) announceWinner(s)
    }

    /** Banked values shown as small dice right under that player's own avatar. */
    private fun renderRollsFor(color: PlayerColor, slot: Slot, isActive: Boolean) {
        slot.rolls.removeAllViews()
        val e = engine ?: return
        if (!isActive) return
        val rolls = e.state.pendingRolls
        if (rolls.isEmpty()) return

        val size = (30 * resources.displayMetrics.density).toInt()
        val gap = (3 * resources.displayMetrics.density).toInt()
        rolls.forEach { value ->
            val chip = DiceView(this)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginStart = gap
            lp.marginEnd = gap
            chip.layoutParams = lp
            chip.value = value
            chip.accent = uiColor(color)
            chip.isClickable = false
            slot.rolls.addView(chip)
        }
    }

    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun announceWinner(s: GameState) {
        val winner = s.players.firstOrNull { it.id == s.rankings.firstOrNull() } ?: return
        val title = if (winner.team != 0) {
            "Team ${if (winner.team == 1) "A" else "B"} wins!"
        } else {
            "${winner.displayName} wins!"
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Play again?")
            .setPositiveButton(R.string.menu_restart) { _, _ -> startGame() }
            .setNegativeButton(R.string.menu_new) { _, _ -> backToSetup() }
            .setCancelable(true)
            .show()
    }

    private companion object {
        const val BLINKING = "blinking"
    }
}
