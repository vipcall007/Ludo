package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * A golden dice face drawn entirely in code: warm gold gradient body, bevelled
 * bright edge, glossy top sheen, deep gold border and glossy black pips with a
 * specular dot. Crisp at any size (no cropped bitmap), and [dimmed] turns it
 * to dull metal for players whose turn it isn't.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) { field = v.coerceIn(1, 6); invalidate() }

    var dimmed: Boolean = false
        set(v) { field = v; invalidate() }

    /** Thin ring in the owning player's colour. 0 = no ring. */
    var accent: Int = 0
        set(v) { field = v; invalidate() }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 0, 0, 0) }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bevelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipShinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val layouts: Map<Int, List<Pair<Float, Float>>> = mapOf(
        1 to listOf(0.5f to 0.5f),
        2 to listOf(0.30f to 0.30f, 0.70f to 0.70f),
        3 to listOf(0.27f to 0.27f, 0.5f to 0.5f, 0.73f to 0.73f),
        4 to listOf(0.30f to 0.30f, 0.70f to 0.30f, 0.30f to 0.70f, 0.70f to 0.70f),
        5 to listOf(0.27f to 0.27f, 0.73f to 0.27f, 0.5f to 0.5f, 0.27f to 0.73f, 0.73f to 0.73f),
        6 to listOf(
            0.30f to 0.24f, 0.70f to 0.24f,
            0.30f to 0.50f, 0.70f to 0.50f,
            0.30f to 0.76f, 0.70f to 0.76f
        )
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val inset = w * 0.07f
        val corner = w * 0.22f
        val face = RectF(inset, inset, w - inset, h - inset)

        // drop shadow
        canvas.drawRoundRect(
            RectF(face.left + w * 0.03f, face.top + h * 0.06f, face.right + w * 0.03f, face.bottom + h * 0.06f),
            corner, corner, shadowPaint
        )

        // gold body (or dull metal when it isn't your turn)
        bodyPaint.shader = LinearGradient(
            face.left, face.top, face.right, face.bottom,
            if (dimmed) Color.rgb(0x8E, 0x8E, 0x8E) else Color.rgb(0xFF, 0xE3, 0x8A),
            if (dimmed) Color.rgb(0x5A, 0x5A, 0x5A) else Color.rgb(0xC8, 0x8B, 0x12),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(face, corner, corner, bodyPaint)
        bodyPaint.shader = null

        // glossy sheen across the top half
        glossPaint.shader = RadialGradient(
            face.centerX(), face.top + face.height() * 0.18f, face.width() * 0.75f,
            Color.argb(if (dimmed) 40 else 130, 255, 255, 255),
            Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(face, corner, corner, glossPaint)
        glossPaint.shader = null

        // bright inner bevel then deep gold border
        bevelPaint.strokeWidth = w * 0.035f
        bevelPaint.color = if (dimmed) Color.rgb(0xA8, 0xA8, 0xA8) else Color.rgb(0xFF, 0xF2, 0xBE)
        val bevel = RectF(face.left + w * 0.05f, face.top + w * 0.05f, face.right - w * 0.05f, face.bottom - w * 0.05f)
        canvas.drawRoundRect(bevel, corner * 0.8f, corner * 0.8f, bevelPaint)

        borderPaint.strokeWidth = w * 0.05f
        borderPaint.color = if (dimmed) Color.rgb(0x4A, 0x4A, 0x4A) else Color.rgb(0x8A, 0x5B, 0x00)
        canvas.drawRoundRect(face, corner, corner, borderPaint)

        // glossy black pips with a specular dot
        val pipR = w * 0.082f
        pipPaint.color = if (dimmed) Color.rgb(0x33, 0x33, 0x33) else Color.rgb(0x14, 0x11, 0x08)
        pipShinePaint.color = Color.argb(if (dimmed) 60 else 150, 255, 255, 255)
        for ((fx, fy) in layouts.getValue(value)) {
            val cx = face.left + fx * face.width()
            val cy = face.top + fy * face.height()
            canvas.drawCircle(cx, cy, pipR, pipPaint)
            canvas.drawCircle(cx - pipR * 0.28f, cy - pipR * 0.30f, pipR * 0.38f, pipShinePaint)
        }

        // owner ring
        if (accent != 0) {
            ringPaint.color = accent
            ringPaint.alpha = if (dimmed) 90 else 255
            ringPaint.strokeWidth = w * 0.045f
            val r = w * 0.20f
            canvas.drawRoundRect(RectF(w * 0.02f, h * 0.02f, w - w * 0.02f, h - h * 0.02f), r, r, ringPaint)
            ringPaint.alpha = 255
        }
    }
}
