package com.example.ludoroyale.model

enum class TokenState { BASE, ACTIVE, HOME_STRETCH, FINISHED }

/**
 * A single playable piece. [steps] = total pips travelled since leaving
 * base (1-based). Meaning depends on [state]:
 *  - BASE: unused (0)
 *  - ACTIVE: steps in 1..51 -> shared-track global index via LudoBoard.toGlobalIndex(color, steps-1)
 *  - HOME_STRETCH: steps in 52..57 -> home-column index = steps-52 (0..5)
 *  - FINISHED: steps == 57
 */
data class Token(
    val id: String,
    val color: PlayerColor,
    var state: TokenState = TokenState.BASE,
    var steps: Int = 0
) {
    val isMovable: Boolean get() = state != TokenState.FINISHED

    fun resetToBase() {
        state = TokenState.BASE
        steps = 0
    }
}
