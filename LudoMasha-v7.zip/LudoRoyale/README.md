## Round 7 — thin arrows, smooth glide, bonus rolls, drawn golden dice

ARROWS: redrawn as a thin pencil-line stroke with a small open arrowhead and
a tail tick, instead of the heavy orange band.

BONUS ROLLS (the real fix): cutting a piece, riding an arrow, or getting a
piece home now all earn ANOTHER roll — but the bonus is STORED, not taken
immediately. Any values already banked are spent first; only when nothing is
left to play does the same player roll again. GameState gained `bonusRolls`
and the engine a `takeBonusOrAdvance()` step. Previously the extra turn was
only granted when the bank happened to be empty, so banked values could be
silently thrown away.

MOVEMENT: pieces now glide continuously along the real path (turning corners
correctly) instead of teleporting square to square. `glide()` interpolates
between cell centres at ~110ms per square, with a soft tick as each square is
crossed.

DICE: reverted to a drawn face — the cropped photo parts looked wrong at
small sizes. Same clean shape as before, but golden: warm gold gradient body,
bright inner bevel, deep gold border, glossy sheen, and black pips with a
specular dot. Crisp at any size, no bitmaps.

BACKGROUND: the XML layer-list wasn't rendering, so the backdrop is now a
custom `GameBackgroundView` drawn in code — blue-violet gradient, a warm pool
of light behind the board, faint scattered pips, corner vignette. Added to
both the game and splash screens.

SOUND: notes can now slide in pitch. A cut plays a comic falling
"wah-wah-wahhh"; a win plays a longer rising celebration fanfare.

## Round 6 — golden dice, fixed arrows, on-board number chips, game background

1. DICE: replaced the drawn dice with the golden artwork the user supplied.
   Sliced the 3x2 sheet into six faces (dice_1..dice_6 at 192px), and DiceView
   now renders the matching image, desaturating it off-turn and drawing a thin
   ring in the owner's colour.
2. ARROWS FIXED: the real bug was WHERE they sat, not how they were drawn.
   The old indices (4, 17, 30, 43) fall on corners of the track, so a straight
   shaft from start to landing cell cut diagonally across the board. Checked
   every ring index for a straight 3-cell run and moved the arrows to
   1, 12, 20, 32 (landing on 4, 15, 23, 35) — all straight, and none landing
   on a safe star or a colour's start cell.
3/5. BACKGROUND: game and splash now use layered gradients (night-blue base,
   warm radial glow behind the board, corner vignette) instead of a flat
   colour. Board frame reworked too: drop shadow, two-tone wood, thin gold
   inner edge, softer off-white playfield.
4. "Give how many?" dialog is gone. Tapping a piece now floats small gold
   number chips directly over that piece; tapping a chip plays that value.
   Chips flip below the piece when it sits near the top edge, and clear
   themselves whenever the turn moves on.

## Round 5 — build fix + real artwork icon

BUILD FIX: `LudoBoardView.onTouchEvent` failed to compile —
"Smart cast to 'Token' is impossible, because 'best' is a local variable
captured by a changing closure". The `var best` was written inside a
`forEachIndexed` lambda and then dereferenced afterwards, which Kotlin will
not smart-cast. Copied it into a local `val chosen` before use.

ICON: replaced the hand-drawn vector logo with the artwork the user supplied.
Generated proper launcher PNGs at every density (mdpi 48 -> xxxhdpi 192,
plus round variants) and a 512px copy used on the splash and setup screens.
Deleted the old adaptive-icon XML and vector foreground/background, which
would otherwise have overridden the PNG on Android 8+.

## Round 4 — arrows, sound, per-player rolls, pick-your-points

1. Arrow markers redrawn as a real arrow that spans the cells it covers:
   shaft starts on the arrow's own cell, head sits on the exact cell the piece
   lands on. No more guessing where it goes.
8. Arrow jump shortened from 6 cells to 3 — the piece stops on the arrow's
   TIP instead of skipping a whole side of the board.
2. Sound rewritten from scratch: ToneGenerator was silent on some phones, so
   SoundFx now synthesises sine tones into an AudioTrack (still no audio files
   bundled, nothing copied). Game-start flourish now actually plays, along
   with dice, step, cut, magic, three-six buzzer and win fanfare.
3. Banked rolls now appear UNDER each player's own avatar, not in a shared
   tray in the middle.
4. Tapping a piece asks "Give how many?" and lists the banked values that can
   move it, each labelled with what it would do (cuts / comes out / goes home).
5. It auto-plays only when there is genuinely nothing to decide (one piece and
   one value). As soon as a six is banked next to another number, or several
   pieces are out, the choice comes back to the player.
6. The current player's movable pieces gently pulse (grow/shrink) so it is
   obvious which pieces are theirs and which can actually move.
7. Stacked pieces are fanned out and shrunk to fit instead of being replaced
   by a number badge — you can literally count the pieces on the square.

## Round 3 — banked rolls, magic arrows, team turn order

1. Setup screen restyled to match the reference: selectable Classic / Arrow
   mode cards with icons, player-count pills, name fields, teams + lucky
   toggles, big gold START.
2. ARROW MODE redesigned: bolder orange arrow markers, and landing on one now
   makes the piece VANISH and REAPPEAR at the arrow's end (fade out / fade in)
   with a sparkle sound, instead of walking the gap. Same player rolls again.
3. Game-start flourish sound added. Logo and launcher icon redrawn (crown +
   gold ring + four-quadrant board + big dice).
4. Team mode now uses the SAME clockwise turn order as classic
   (Red -> Green -> Yellow -> Blue), which naturally alternates A, B, A, B.
   Team is shown as a separate label, not jammed into the name.
5+6. Rolls are now BANKED, not spent immediately:
   - a six banks the value and forces another roll (the six is not used yet)
   - three sixes in a row burn the turn and every banked value
   - when rolling stops, banked values appear in a tray under the board; the
     player taps WHICH value to spend, then which piece to spend it on, and
     repeats until all values are used. Works with a single piece too.
7. Home pieces sit closer together (tight 2x2 in each yard circle).
8. Piles are now unmistakable: stacked pieces are drawn stepped behind the
   front one AND carry a numbered badge; two colours on one safe cell sit
   side by side.

Engine note: GameState now carries `pendingRolls`, and Move carries the
`usedRoll` it spends, so the same rules drive UI, future AI and any future
server without special-casing.

## Round 2 — "Ludo Masha" rebrand + modes (14 of the 20 requests)
Done this round:
1. Animated splash: logo scales/spins in, title + tagline fade up, then the
   game opens (view animation, not a video file — costs no APK size).
2. New premium app icon + logo (gold badge, four ludo quadrants, dice, crown).
3. Home pieces now sit as a neat centred 2x2 in each yard (the old slots were
   off-centre, which is why they looked scattered).
4. Player name entry for each seat on the setup screen.
6. Board vertically centred in the game screen.
7. Premium dice: gradient body, gloss highlight, player-coloured rim,
   recessed pips.
8/19. ARROW MODE as a separate mode — landing on an arrow carries the piece
   to where the arrow ends and the same player rolls again. Arrows are drawn
   on the board only in that mode.
9. TEAM MODE (2v2): Red+Yellow vs Green+Blue, partners sit opposite, you
   cannot cut your own partner, and a team wins only when both partners are
   home.
10. Active player's arrow pulses (blinks) so the turn is unmissable.
12. Removed the "tap your dice" hint line.
13. Capture now plays a comic descending slide.
14. Win plays a rising celebration fanfare + a winner dialog.
15. Menu button (top-right): Restart / New game / Close.
17. "Lucky Dice" is an explicit, labelled setting (rolls twice, keeps the
    higher face) applied identically to every player — deliberately NOT a
    hidden tilt toward anyone, so the game stays fair.

Also: single-legal-move turns now auto-play instead of forcing a pointless tap.

Deferred to the next round (told the user, not silently dropped):
- 5/11: accumulating rolls after a six and letting the player choose which
  value to use.
- 16: removing a player mid-game (and clearing their pieces).
- 18: Easy/Medium/Hard — these only mean something against AI opponents, and
  pass-n-play is all humans; needs a decision on adding AI players first.

# Ludo Royale — Phase 1 (Offline Rule Engine)

## What's actually working right now
A complete, UI-independent Ludo **rules engine** in Kotlin — the piece every other
phase (AI, local multiplayer, online sync) depends on:

- `model/` — `PlayerColor`, `Token`, `Player` (pure data, no Android deps)
- `engine/` — `LudoBoard` (52-cell track + safe cells + home stretch geometry),
  `RuleConfig` (toggleable rules: extra turn on six, 3-six forfeit, capture
  extra turn, exact-roll-to-finish, safe-cell capture blocking...),
  `DiceRoller` (SecureRandom, unbiased, never favors anyone),
  `LudoEngine` (roll → legalMoves → applyMove → turn advance / win detection)
- `ai/LudoAI.kt` — Easy (random legal move), Medium/Hard (heuristic scoring:
  captures > finishing > home-stretch entry > leaving base). The AI is only
  ever given the same `List<Move>` a human would see — it cannot cheat.
- `MainActivity.kt` — a bare, text-only screen that plays a full human-vs-AI
  game end to end through the real engine (roll, move, capture, win). This is
  **not** the premium UI from the spec — it exists to prove the engine is
  actually wired to something runnable, per "don't stop at a mockup."
- `LudoEngineTest.kt` — 6 JUnit tests covering: can't leave base without a six,
  leaving base on six, capture + extra turn, exact-roll-to-finish (overshoot
  rejected), three-consecutive-sixes forfeit, normal turn advancement.

## Getting an actual APK on your phone (no coding needed)
A `.github/workflows/build-apk.yml` file is included — it builds the APK
automatically in the cloud when you upload this project to GitHub. Steps are
in the chat reply.

## Phase 1b update — real visible board
Added: `BoardGeometry.kt` (classic 15x15 cross-board coordinate mapping),
`LudoBoardView.kt` (Canvas-drawn board: 4 colored home squares, 52-cell ring,
safe-cell markers, colored home stretches, center pinwheel, circular tokens,
tap-to-move with yellow highlight on legal tokens). `MainActivity.kt` now
wires taps on the real board to the engine instead of auto-picking moves.
Still original artwork — nothing copied from any reference app.
Not yet done: dice-roll animation, token-slide animation, sound.

## Phase 1c update — local pass-and-play (2-4 players, one phone)
Added a setup screen: pick 2, 3, or 4 players, then everyone takes turns
passing the same phone. No AI needed for this mode — Ludo has no hidden
information, so this is fair and simple. `MainActivity.kt` now creates
that many `PlayerKind.HUMAN` players and the real board drives it.
Not yet done: dice-roll animation, token-slide animation, sound,
"pass to next player" confirmation screen (optional nicety, not required).

## Phase 1d update — animation + sound
Tokens now slide (animated, ~260ms) between positions instead of jumping.
Dice shows a quick random-cycling animation before landing on the real
(already-decided) result. Added `SoundFx.kt` — short original beep tones
via Android's built-in ToneGenerator for dice/move/capture/win (no external
audio files needed, nothing copied).

## Phase 1e update — closer to a "real board" look
Added `DiceView.kt` — dice now shows real pip dots (like a physical die),
not a plain digit. Safe cells now draw as a yellow star instead of a plain
gray dot. Compared against reference screenshots the person shared —
matched the dice-face and star-cell look; didn't copy any art files
(everything above is drawn in code).

## Bugfix — MainActivity out of sync with new box-by-box board API
LudoBoardView was upgraded to move tokens box-by-box (snapToState / hopToken)
but MainActivity.kt still tried the old direct `boardView.state = ...`
assignment, which no longer compiles (state's setter is now private by
design). Rewrote MainActivity to use snapToState (initial/instant sync) and
hopToken (animated box-by-box move, then snap to the true post-move state —
this is also what naturally resets a captured token back to its base).

## Visual overhaul — matching the reference screenshots more closely
Compared my build's screenshot against the reference game's screenshots the
person shared, and closed the gaps that were actually closable in code:
- Board: wooden/orange rounded frame, white playfield, circular home yards
  (were plain white squares), gray star safe cells, white travel-direction
  chevrons on each color's entry cell.
- Tokens: styled piece (colored disc + white ring + colored star + drop
  shadow) instead of a flat circle. Stacked pieces now show a numbered
  badge, and two colors sharing a safe cell are drawn offset — so you can
  always tell how many pieces are on a square.
- Players: each player now sits at their own corner of the board with an
  avatar (color-tinted ring) + name + their OWN dice, top players rotated
  180° so they face the board — replaces the single status-text line.
- Rolling: tap your own dice to roll (no separate button); the dice shakes
  and spins through random faces before landing on the real result, with a
  green arrow marking whose turn it is and inactive dice dimmed.
- Movement: a soft step tick on each box as the piece walks.
All drawn in code; no artwork, sound, or code copied from the reference app.
Still not matched (would need an artist / real asset pipeline): painted
3D artwork, gradient backgrounds, character illustrations, animated
victory sequences, and the reference's globe/decorative path icons.

## Honest caveats
- **This was not compiled.** The sandbox that wrote this code has no network
  access, so it can't download the Android Gradle Plugin, Kotlin compiler, or
  Gradle wrapper jar to actually build/run it. Open it in Android Studio and
  hit Sync — that's the first real build/test pass. I re-read every file by
  hand for syntax/logic errors, but treat that as "should compile," not "did compile."
- **No launcher icon** — `AndroidManifest.xml` points at `@mipmap/ic_launcher`,
  which doesn't exist yet. Use Android Studio's Image Asset tool (right-click
  `res` → New → Image Asset) before your first build or it'll fail on that.
- **No gradlew wrapper jar** — Android Studio will offer to generate one on
  first open; let it.
- 4-player and 3-player games, team mode pairing, and the online-sync layer
  (server, matchmaking, reconnect) aren't built yet — the engine's `GameState`
  is already the exact object a server would serialize/broadcast, so that
  layer plugs in without changing engine logic.

## Suggested next slices (small, testable, in order)
1. Real board rendering (Canvas/Compose) + tap-to-select tokens, replacing
   the text placeholder screen — sections 7-9 of the spec.
2. Local multiplayer (3-4 players, same device, pass-and-play).
3. Coins/XP/profile persistence (Room database) + daily reward + missions.
4. Server-authoritative online play: this is the point where I'd need you to
   provide a backend target (Firebase project, or a server you control) —
   see spec section 45/46. I won't pretend one is already configured.

## Scope note on the original master prompt
The uploaded spec asks for a full commercial-grade game (online multiplayer,
matchmaking, private rooms, chat, monetization architecture, Play Store
release) — that's realistically weeks of work, not one response. I built the
foundation everything else stacks on and I'm stopping here to check in before
going further, per the spec's own "build in phases, don't dump everything
at once" instruction (section 40/45).
