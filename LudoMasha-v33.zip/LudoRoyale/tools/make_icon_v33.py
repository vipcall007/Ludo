#!/usr/bin/env python3
"""
Cut the owner's LUDO MASHA picture into every icon Android asks for.

THREE DIFFERENT THINGS ARE NEEDED, AND THEY ARE NOT INTERCHANGEABLE.

  ic_launcher.png           the flat icon, for Android 7 and older. The picture
                            as supplied, rounded corners and all — old
                            launchers draw it exactly as given.

  ic_launcher_round.png     the same, for launchers that ask for a round one.
                            The picture is shrunk onto a gold disc rather than
                            punched out of a circle, because punching a circle
                            through it would cut off the PREMIUM banner and the
                            four corners of its own gold frame.

  foreground / background   the two layers of the adaptive icon, Android 8 and
                            newer. The LAUNCHER chooses the outline here — a
                            circle on one phone, a squircle on the next — and
                            cuts both layers to it. Only the middle 72 of the
                            108-unit canvas is guaranteed to survive any of
                            those shapes, so the whole picture is placed inside
                            that middle square and the background carries gold
                            out to the edges. Nothing of the artwork is ever
                            cut, whatever shape the phone picks.
"""
import os
from PIL import Image, ImageDraw

SRC = os.path.join(os.path.dirname(__file__), 'source_art', 'app_icon.png')
RES = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res')

# mipmap folder -> the flat icon size Android wants there
DENSITIES = {
    'mipmap-mdpi': 48, 'mipmap-hdpi': 72, 'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144, 'mipmap-xxxhdpi': 192,
}
# the adaptive layers are always 108/48 times the flat size
ADAPTIVE = 108.0 / 48.0
# and only the middle 72 of those 108 is safe from every mask
SAFE = 72.0 / 108.0

GOLD_OUT = (198, 132, 20)
GOLD_IN = (255, 226, 130)


def gold_disc(size):
    """A gold field, brighter in the middle, filling the whole square."""
    img = Image.new('RGBA', (size, size), GOLD_OUT + (255,))
    d = ImageDraw.Draw(img)
    steps = max(24, size // 4)
    for i in range(steps):
        t = i / float(steps)
        r = int(size * 0.72 * (1 - t))
        if r <= 0:
            continue
        c = tuple(int(GOLD_OUT[k] + (GOLD_IN[k] - GOLD_OUT[k]) * (1 - t)) for k in range(3))
        d.ellipse([size / 2 - r, size / 2 - r, size / 2 + r, size / 2 + r], fill=c + (255,))
    return img


def main():
    art = Image.open(SRC).convert('RGBA')

    for folder, flat in DENSITIES.items():
        out = os.path.join(RES, folder)
        os.makedirs(out, exist_ok=True)

        # 1. the flat icon: the picture, untouched apart from its size
        art.resize((flat, flat), Image.LANCZOS).save(os.path.join(out, 'ic_launcher.png'))

        # 2. the round one: the picture standing on a gold disc
        disc = gold_disc(flat)
        mask = Image.new('L', (flat * 4, flat * 4), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, flat * 4 - 1, flat * 4 - 1], fill=255)
        disc.putalpha(mask.resize((flat, flat), Image.LANCZOS))
        inner = int(flat * 0.80)
        disc.alpha_composite(art.resize((inner, inner), Image.LANCZOS),
                             ((flat - inner) // 2, (flat - inner) // 2))
        disc.save(os.path.join(out, 'ic_launcher_round.png'))

        # 3. the adaptive layers
        full = int(round(flat * ADAPTIVE))
        gold_disc(full).save(os.path.join(out, 'ic_launcher_background.png'))

        fg = Image.new('RGBA', (full, full), (0, 0, 0, 0))
        safe = int(full * SAFE)
        fg.alpha_composite(art.resize((safe, safe), Image.LANCZOS),
                           ((full - safe) // 2, (full - safe) // 2))
        fg.save(os.path.join(out, 'ic_launcher_foreground.png'))
        print(f'{folder}: flat {flat}, adaptive {full}, artwork {safe}')


if __name__ == '__main__':
    main()
