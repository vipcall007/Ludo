package com.example.ludoroyale

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * THE TABLE MUST COVER EVERY BADGE, FOREVER.
 *
 * The fault this guards against has already happened once: a single window
 * rectangle was used for all twenty-one rank badges, and the portrait only
 * fitted the badge it had been measured from. The fix was a table with one
 * entry per badge — which is only a fix for as long as the table stays
 * complete. Add a twenty-second badge and forget the entry, and that badge
 * silently falls back to an average and looks wrong, on somebody's phone,
 * with nothing to say so.
 *
 * So the test is not "do the numbers look right". It is "is there an entry for
 * every frame the game can actually put on screen".
 */
class FrameWindowsTest {

    @Test
    fun `every frame the game can show has its own measured window`() {
        val drawn = PictureArt.frameIds()
        val measured = FrameWindows.ids()
        val missing = drawn - measured
        assertTrue(
            "these frames have artwork but no measured window, so they would " +
                "fall back to an average and fit badly: $missing",
            missing.isEmpty()
        )
    }

    @Test
    fun `the table has nothing in it that is not a real frame`() {
        val stale = FrameWindows.ids() - PictureArt.frameIds()
        assertTrue("windows measured for frames that no longer exist: $stale", stale.isEmpty())
    }

    @Test
    fun `every window is inside its picture and big enough to be a face`() {
        for (id in FrameWindows.ids()) {
            val w = FrameWindows.of(id)
            assertTrue("$id: window runs off the left/top", w.cx - w.w / 2f >= 0f && w.cy - w.h / 2f >= 0f)
            assertTrue("$id: window runs off the right/bottom", w.cx + w.w / 2f <= 1f && w.cy + w.h / 2f <= 1f)
            // A badge whose opening is under a third of the picture would mean
            // a face too small to recognise; one over three-quarters would mean
            // the measurement caught the outside of the badge, not the hole.
            assertTrue("$id: opening is suspiciously small (${w.w} x ${w.h})", w.w > 0.33f && w.h > 0.33f)
            assertTrue("$id: opening is suspiciously large (${w.w} x ${w.h})", w.w < 0.75f && w.h < 0.75f)
        }
    }

    @Test
    fun `an unknown frame still gets a usable window instead of nothing`() {
        val fallback = FrameWindows.of("rk_not_a_real_frame")
        assertEquals(0.499f, fallback.cx, 0.001f)
        assertTrue(fallback.w > 0.33f && fallback.h > 0.33f)
    }
}
