package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * A slim bar showing how far into the current level a player stands.
 *
 * It can hold two values at once — where the bar WAS and where it is now — so
 * the match summary can slide it forward and the player sees what the match
 * was worth rather than just a number that changed while they weren't looking.
 */
class XpBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** 0f..1f, where the bar stands right now. */
    var progress: Float = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    /** 0f..1f, where it stood before the last change. Drawn as a ghost behind. */
    var previous: Float = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    /** The gold of the filled part. Changed for the league bar. */
    var fillFrom: Int = Color.rgb(0xFF, 0xE3, 0x8A)
        set(value) { field = value; invalidate() }

    var fillTo: Int = Color.rgb(0xF2, 0xC1, 0x4E)
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Slides from [previous] to [progress] so the gain is visible. */
    fun animateTo(from: Float, to: Float) {
        previous = from
        progress = from
        val start = System.currentTimeMillis()
        val tick = object : Runnable {
            override fun run() {
                val t = ((System.currentTimeMillis() - start) / 700f).coerceIn(0f, 1f)
                // ease out, so it arrives gently instead of stopping dead
                val eased = 1f - (1f - t) * (1f - t)
                progress = from + (to - from) * eased
                if (t < 1f) postDelayed(this, 16)
            }
        }
        post(tick)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f

        paint.shader = null
        paint.color = Color.argb(120, 0x14, 0x0A, 0x30)   // violet ink, not navy: the panels behind it are violet now
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, paint)

        if (previous > progress) {
            // the bar rolled over into a new level: show the old part faintly
            paint.color = Color.argb(70, 0xFF, 0xE9, 0xA8)
            canvas.drawRoundRect(RectF(0f, 0f, w * previous, h), r, r, paint)
        }

        if (progress > 0f) {
            paint.shader = LinearGradient(
                0f, 0f, w, 0f, fillFrom, fillTo, Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(RectF(0f, 0f, (w * progress).coerceAtLeast(h), h), r, r, paint)
            paint.shader = null
        }

        paint.color = Color.argb(90, 255, 255, 255)
        canvas.drawRoundRect(RectF(0.5f, 0.5f, w - 0.5f, h * 0.45f), r, r, paint)
    }
}
