package com.example.ludoroyale

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable

/**
 * ONE LOOK FOR EVERY PANEL, SHEET AND POPUP IN THE GAME.
 *
 * WHAT WAS WRONG
 *
 * The panels were navy blue boxes with a lighter blue outline — perfectly
 * readable, and belonging to a different game. The board is red, green, yellow
 * and blue on white; the top bar, the lobby cards, the dice and the rank
 * badges are all violet and gold. The sheets were the one part of the app that
 * had never been brought over, so opening any of them felt like leaving.
 *
 * WHAT IT IS NOW
 *
 * Deep royal violet with a gold edge, the same violet and the same gold as the
 * top bar and the badges, and the four player colours used as ACCENTS — a
 * coloured stripe down the side of a card, a coloured rule under a heading.
 *
 * WHY THE FOUR COLOURS ARE USED THAT WAY AND NOT MORE
 *
 * "Red, green, blue and yellow mixed" can be read two ways. Colouring whole
 * panels in it gives four differently-coloured boxes on one screen, and a
 * screen with four loud backgrounds has no order to it — the eye cannot tell
 * what is a heading and what is a number. Used as a thin accent on a violet
 * card, the four colours are unmistakably there, they tell one block from the
 * next at a glance, and the words on top stay easy to read, which is what the
 * panel is for. The colours are also taken IN BOARD ORDER, so the third block
 * on a screen is always the same colour as the third block on any other.
 *
 * WHY IT IS BUILT HERE INSTEAD OF IN XML
 *
 * Because the accent is the whole point, and an XML drawable is fixed at build
 * time. A card that wants a red edge and a card that wants a green one would
 * be two files, and nine screens' worth of them would be dozens. Built here,
 * a caller asks for `card(Royal.GREEN)` and gets it.
 */
object Royal {

    // The violets and the gold: the same numbers the top bar and the rank
    // badges use, so nothing on screen is "nearly" the same colour as
    // something else.
    val VIOLET_TOP = Color.parseColor("#2C1A66")
    val VIOLET_BOTTOM = Color.parseColor("#150C36")
    val VIOLET_DEEP = Color.parseColor("#1C1046")
    val GOLD = Color.parseColor("#F2C14E")
    val GOLD_PALE = Color.parseColor("#FFE9A8")
    val INK = Color.parseColor("#2A1A00")

    /** Text on violet. Warm rather than blue-grey, so it sits on the violet. */
    val TEXT = Color.parseColor("#F3ECFF")
    val TEXT_DIM = Color.parseColor("#B9A6E0")

    // The four seats, in board order. These are the board's own colours, not
    // approximations of them.
    val RED = Color.parseColor("#E0344B")
    val GREEN = Color.parseColor("#1DB954")
    val YELLOW = Color.parseColor("#FFC107")
    val BLUE = Color.parseColor("#2E7DFF")

    /** The accents, in the order a screen should use them. */
    val ACCENTS = intArrayOf(RED, GREEN, YELLOW, BLUE)

    /** The nth accent, wrapping round, so a screen never runs out. */
    fun accent(index: Int): Int = ACCENTS[((index % ACCENTS.size) + ACCENTS.size) % ACCENTS.size]

    /** The whole sheet: violet, falling darker, inside a gold edge. */
    fun sheet(density: Float): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(VIOLET_TOP, VIOLET_BOTTOM)
    ).apply {
        cornerRadius = 22f * density
        setStroke((2f * density).toInt(), GOLD)
    }

    /**
     * One block inside a sheet, with its accent down the leading edge.
     *
     * The stripe is a second layer rather than a border, because a border in
     * a seat colour all the way round a card competes with the gold edge of
     * the sheet holding it. Down one side it reads as a tab on a file.
     */
    fun card(density: Float, accent: Int): LayerDrawable {
        val body = GradientDrawable().apply {
            cornerRadius = 13f * density
            setColor(VIOLET_DEEP)
            setStroke((1f * density).toInt(), withAlpha(accent, 0x55))
        }
        val stripe = GradientDrawable().apply {
            cornerRadius = 13f * density
            setColor(accent)
        }
        val layers = LayerDrawable(arrayOf(stripe, body))
        // the body is pulled in from the left by the stripe's width, so all
        // that shows of the stripe is a band down that one side
        layers.setLayerInset(1, (4f * density).toInt(), 0, 0, 0)
        return layers
    }

    /** A title ribbon in gold, for the top of a sheet or a popup. */
    fun ribbon(density: Float): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(GOLD_PALE, GOLD)
    ).apply {
        cornerRadius = 14f * density
        setStroke((1.5f * density).toInt(), Color.parseColor("#8A5A00"))
    }

    /** A pill in one of the seat colours, for a small tag or chip. */
    fun chip(density: Float, accent: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 999f
        setColor(withAlpha(accent, 0x33))
        setStroke((1f * density).toInt(), withAlpha(accent, 0xAA))
    }

    private fun withAlpha(colour: Int, alpha: Int): Int =
        (alpha shl 24) or (colour and 0xFFFFFF)
}
