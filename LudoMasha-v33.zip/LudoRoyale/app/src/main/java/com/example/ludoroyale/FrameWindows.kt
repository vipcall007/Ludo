package com.example.ludoroyale

import com.example.ludoroyale.cosmetics.Cosmetics

/**
 * WHERE THE HOLE IS IN EACH RANK BADGE.
 *
 * THE BUG THIS EXISTS TO FIX
 *
 * There used to be three numbers — one centre, one diameter — used for all
 * twenty-one badges. They were measured off ONE badge, and the owner spotted
 * it straight away: the portrait only fitted the last one. Measuring the other
 * twenty shows why. The badges were never drawn to a single template: a bronze
 * badge's opening is 0.600 of the picture across, a Grand Master III's is
 * 0.456. Using the Grand Master number everywhere left a bronze portrait a
 * quarter too small, floating in the middle of its own frame with a thick ring
 * of empty gold round it, and sitting a little high as well.
 *
 * HOW THESE NUMBERS WERE FOUND
 *
 * Not by eye. Each badge is a picture with a see-through middle, so the middle
 * is found by asking which transparent region is completely enclosed by the
 * artwork — the one that does not touch any edge of the image. Its bounding box
 * is the window. That is a machine reading the picture rather than somebody
 * estimating it, which is the only way twenty-one of anything stay right.
 *
 * WIDTH AND HEIGHT ARE SEPARATE, AND THAT MATTERS
 *
 * Every one of these openings is wider than it is tall — a bronze badge's is
 * 0.600 by 0.578. Fitting a circle to it would mean using the smaller number
 * and leaving a sliver of gold showing down each side. The portrait is drawn
 * into the full oval instead, so it fills the opening exactly, which is what
 * "the avatar should match the frame fully" asks for.
 */
object FrameWindows {

    /** Centre and size of one badge's opening, as fractions of the picture. */
    data class Window(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val TABLE: Map<String, Window> = mapOf(
        Cosmetics.RK_BRONZE1 to Window(0.498f, 0.516f, 0.600f, 0.578f),
        Cosmetics.RK_BRONZE2 to Window(0.502f, 0.509f, 0.600f, 0.566f),
        Cosmetics.RK_BRONZE3 to Window(0.500f, 0.516f, 0.591f, 0.553f),
        Cosmetics.RK_SILVER1 to Window(0.502f, 0.511f, 0.588f, 0.556f),
        Cosmetics.RK_SILVER2 to Window(0.500f, 0.511f, 0.578f, 0.537f),
        Cosmetics.RK_SILVER3 to Window(0.498f, 0.514f, 0.544f, 0.494f),
        Cosmetics.RK_GOLD1 to Window(0.497f, 0.519f, 0.566f, 0.541f),
        Cosmetics.RK_GOLD2 to Window(0.506f, 0.512f, 0.534f, 0.497f),
        Cosmetics.RK_GOLD3 to Window(0.505f, 0.517f, 0.512f, 0.475f),
        Cosmetics.RK_PLAT1 to Window(0.492f, 0.512f, 0.525f, 0.491f),
        Cosmetics.RK_PLAT2 to Window(0.498f, 0.514f, 0.519f, 0.481f),
        Cosmetics.RK_PLAT3 to Window(0.497f, 0.512f, 0.497f, 0.459f),
        Cosmetics.RK_DIAMOND1 to Window(0.497f, 0.519f, 0.503f, 0.466f),
        Cosmetics.RK_DIAMOND2 to Window(0.502f, 0.523f, 0.512f, 0.469f),
        Cosmetics.RK_DIAMOND3 to Window(0.497f, 0.522f, 0.503f, 0.453f),
        Cosmetics.RK_MASTER1 to Window(0.498f, 0.508f, 0.525f, 0.494f),
        Cosmetics.RK_MASTER2 to Window(0.503f, 0.505f, 0.516f, 0.475f),
        Cosmetics.RK_MASTER3 to Window(0.497f, 0.508f, 0.503f, 0.456f),
        Cosmetics.RK_GRAND1 to Window(0.503f, 0.470f, 0.484f, 0.444f),
        Cosmetics.RK_GRAND2 to Window(0.503f, 0.472f, 0.484f, 0.447f),
        Cosmetics.RK_GRAND3 to Window(0.495f, 0.467f, 0.456f, 0.412f)
    )

    /**
     * The opening in [frameId].
     *
     * The fallback is the average of the twenty-one, so a frame that somehow
     * has no entry looks slightly wrong rather than catastrophically wrong.
     * The test in FrameWindowsTest is what makes sure that never happens.
     */
    fun of(frameId: String): Window =
        TABLE[frameId] ?: Window(0.499f, 0.510f, 0.535f, 0.497f)

    /** Every frame this table covers. Used by the test. */
    fun ids(): Set<String> = TABLE.keys
}
