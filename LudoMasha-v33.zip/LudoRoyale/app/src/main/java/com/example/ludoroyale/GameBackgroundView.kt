package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * The seven skies, one per game mode.
 *
 * WHY THE MODE'S COLOUR LIVES HERE AND NOT ON THE BOARD
 *
 * The first attempt laid each mode's colour over the BOARD. It worked, and it
 * was the wrong place: the board is the one thing on screen a player has to
 * read exactly, and seven differently-lit boards means learning a green square
 * seven times over. The owner's instruction was plain — one board, always the
 * board in the picture, and let the BACKGROUND carry the difference.
 *
 * So the board is untouched in every mode and the sky behind it changes
 * completely: its gradient, its two clouds, the tint of its stars, the lip of
 * gold round the edge, and one large soft shape unique to that mode. Nothing
 * here is subtle, because it is not competing with the board for attention —
 * it is a long way behind it.
 */
enum class Backdrop(
    val skyTop: Int, val skyMid: Int, val skyBottom: Int,
    val cloudA: Int, val cloudB: Int,
    val starWarm: Int, val edge: Int,
    val motif: Motif
) {
    /** The lobby, and a plain two-player game: the royal night as it was. */
    ROYAL(0x2A145C, 0x160D3A, 0x09061C, 0x9A5CFF, 0x2E8AFF, 0xFFECB8, 0xF2C14E, Motif.NONE),

    /** Four players — deep ocean blue, with diamonds scattered through it. */
    FOUR(0x102A6B, 0x0A1A46, 0x04091E, 0x3F7BFF, 0x00C6D8, 0xCFE6FF, 0x7FC4FF, Motif.DIAMONDS),

    /** Quick — embers and heat, with the streaks of something moving fast. */
    QUICK(0x5C1A0A, 0x3A1207, 0x1A0703, 0xFF7A2E, 0xFFC444, 0xFFD9A8, 0xFF9A3C, Motif.STREAKS),

    /** Snakes and Ladders — a jungle night, with coils drifting through it. */
    SNAKE(0x0B4A2A, 0x07301C, 0x03130B, 0x2ED47A, 0xC9E65B, 0xD8F5C0, 0x67D98A, Motif.COILS),

    /** Team Up — imperial purple, with two rings locked together. */
    TEAM(0x45115C, 0x2C0B3C, 0x120418, 0xD44BFF, 0xFF5CA8, 0xF3D0FF, 0xE08CFF, Motif.RINGS),

    /** Against the computer — a cold machine blue, on a faint grid. */
    COMPUTER(0x06333F, 0x04222C, 0x010C11, 0x00D7E8, 0x3FA8FF, 0xC4F4FF, 0x36D6E8, Motif.GRID),

    /** A custom game — warm amber, on rings like a target. */
    CUSTOM(0x5A3D04, 0x3A2703, 0x170F01, 0xFFC107, 0xFF8A3D, 0xFFE9B0, 0xFFC94A, Motif.TARGET);

    /** The one big shape that makes a sky recognisable at a glance. */
    enum class Motif { NONE, DIAMONDS, STREAKS, COILS, RINGS, GRID, TARGET }
}

/**
 * The backdrop behind every screen: a royal night sky.
 *
 * WHAT IT REPLACED, AND WHY
 *
 * This used to be deep blue water with bubbles drifting through it. Against a
 * gold-and-purple game it read as a fish tank, and the owner asked for royal
 * and galaxy instead. So: a deep violet-to-midnight sky, one purple nebula
 * bloom and one blue one, a field of stars with a handful of bright ones, and
 * a soft gold vignette round the edge to hold the whole screen together.
 *
 * There were dust lanes across the middle for a while. Thin, they read as
 * scratches on the screen; wide, they read as soft grey bars. Neither looked
 * like a galaxy, and the two nebulae already do that job, so they are gone —
 * this is a case where the honest fix was to draw less, not to draw it better.
 *
 * WHY IT IS DRAWN AND NOT A PICTURE
 *
 * A background is the one thing on screen at every size and every aspect ratio
 * a phone can have. A picture would have to be cropped or stretched on most of
 * them, and it would be the largest file in the app for something nobody looks
 * at directly. Drawn from these numbers it fits any screen exactly, costs
 * nothing to ship, and the star field is laid out from a fixed seed so it is
 * the same sky every time rather than shuffling on each redraw.
 */
class GameBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Which sky this is. Changing it repaints the screen. */
    var backdrop: Backdrop = Backdrop.ROYAL
        set(value) { if (field != value) { field = value; invalidate() } }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** x, y, radius, brightness — fractions of the view, so it scales anywhere. */
    private val stars = mutableListOf<FloatArray>()

    /** The bright ones, which get a cross of light: x, y, size, tilt. */
    private val brightStars = mutableListOf<FloatArray>()

    init {
        // One fixed seed, so it is the same sky on every redraw rather than a
        // field that reshuffles itself whenever the view is invalidated.
        val rnd = Random(20260921)
        repeat(150) {
            stars += floatArrayOf(
                rnd.nextFloat(), rnd.nextFloat(),
                0.0012f + rnd.nextFloat() * 0.0030f,
                0.25f + rnd.nextFloat() * 0.75f
            )
        }
        repeat(9) {
            brightStars += floatArrayOf(
                rnd.nextFloat(), rnd.nextFloat(),
                0.005f + rnd.nextFloat() * 0.008f,
                rnd.nextFloat() * 90f
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        drawSky(canvas, w, h)
        drawNebula(canvas, w * 0.22f, h * 0.20f, w * 0.85f, opaque(backdrop.cloudA))
        drawNebula(canvas, w * 0.86f, h * 0.68f, w * 0.75f, opaque(backdrop.cloudB))
        drawMotif(canvas, w, h)
        drawStars(canvas, w, h)
        drawBrightStars(canvas, w, h)
        drawVignette(canvas, w, h)
    }

    /** Deep violet at the top falling to midnight at the bottom. */
    private fun drawSky(canvas: Canvas, w: Float, h: Float) {
        paint.shader = LinearGradient(
            0f, 0f, w * 0.35f, h,
            intArrayOf(
                opaque(backdrop.skyTop),
                opaque(backdrop.skyMid),
                opaque(backdrop.skyBottom)
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    /** One soft bloom of colour, the thing that makes it a galaxy and not a wall. */
    private fun drawNebula(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int) {
        paint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(
                Color.argb(96, Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb(34, Color.red(color), Color.green(color), Color.blue(color)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        for (star in stars) {
            val a = (star[3] * 210).toInt().coerceIn(0, 255)
            // a touch of gold in the brighter ones, so the sky belongs with the
            // gold everything else in this game is trimmed with
            paint.color =
                if (star[3] > 0.72f) (a shl 24) or (backdrop.starWarm and 0xFFFFFF)
                else Color.argb(a, 0xE8, 0xE4, 0xFF)
            canvas.drawCircle(star[0] * w, star[1] * h, star[2] * w, paint)
        }
    }

    /** A few stars get a cross of light, which is what sells a night sky. */
    private fun drawBrightStars(canvas: Canvas, w: Float, h: Float) {
        for (star in brightStars) {
            val cx = star[0] * w
            val cy = star[1] * h
            val r = star[2] * w

            paint.shader = RadialGradient(
                cx, cy, r * 2.4f,
                intArrayOf(Color.argb(150, 0xFF, 0xF4, 0xD0), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 2.4f, paint)
            paint.shader = null

            paint.color = Color.argb(235, 0xFF, 0xFF, 0xFF)
            val spike = Path()
            for (i in 0 until 4) {
                val angle = Math.toRadians((star[3] + i * 90f).toDouble())
                val tip = if (i % 2 == 0) r * 2.3f else r * 1.3f
                val side = r * 0.20f
                val ax = cos(angle).toFloat()
                val ay = sin(angle).toFloat()
                spike.moveTo(cx, cy)
                spike.lineTo(cx + ax * tip - ay * side, cy + ay * tip + ax * side)
                spike.lineTo(cx + ax * tip + ay * side, cy + ay * tip - ax * side)
                spike.close()
            }
            canvas.drawPath(spike, paint)
            canvas.drawCircle(cx, cy, r * 0.45f, paint)
        }
    }

    /**
     * A dark edge with a warm gold lip.
     *
     * It does two jobs: it stops the sky competing with the board in the middle
     * of the screen, and the gold ties the backdrop to the frames, the dice and
     * the counters, which are all gold.
     */
    private fun drawVignette(canvas: Canvas, w: Float, h: Float) {
        val r = kotlin.math.max(w, h)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, r * 0.78f,
            intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        stroke.color = (60 shl 24) or (backdrop.edge and 0xFFFFFF)
        stroke.strokeWidth = w * 0.010f
        val inset = w * 0.012f
        canvas.drawRoundRect(
            RectF(inset, inset, w - inset, h - inset), w * 0.06f, w * 0.06f, stroke
        )
    }

    /**
     * The one large shape that tells a mode's sky apart across the room.
     *
     * Everything here is drawn FAINT — alpha in the twenties and thirties —
     * and it is drawn under the stars rather than over them. The point is that
     * a player glancing at the screen knows which game they are in before
     * reading a word, not that they should look at it.
     */
    private fun drawMotif(canvas: Canvas, w: Float, h: Float) {
        val tint = backdrop.cloudB and 0xFFFFFF
        when (backdrop.motif) {
            Backdrop.Motif.NONE -> Unit

            // four players, four suits of light scattered down the screen
            Backdrop.Motif.DIAMONDS -> {
                paint.color = (30 shl 24) or tint
                val rnd = Random(4404)
                repeat(14) {
                    val cx = rnd.nextFloat() * w
                    val cy = rnd.nextFloat() * h
                    val r = w * (0.03f + rnd.nextFloat() * 0.06f)
                    val p = Path()
                    p.moveTo(cx, cy - r); p.lineTo(cx + r * 0.62f, cy)
                    p.lineTo(cx, cy + r); p.lineTo(cx - r * 0.62f, cy)
                    p.close()
                    canvas.drawPath(p, paint)
                }
            }

            // quick: the lines something leaves behind when it is going fast
            Backdrop.Motif.STREAKS -> {
                stroke.strokeWidth = w * 0.012f
                val rnd = Random(7707)
                repeat(16) {
                    val y = rnd.nextFloat() * h
                    val x = rnd.nextFloat() * w
                    val len = w * (0.14f + rnd.nextFloat() * 0.34f)
                    stroke.color = ((16 + rnd.nextInt(20)) shl 24) or tint
                    canvas.drawLine(x, y, x + len, y - len * 0.22f, stroke)
                }
            }

            // snakes: long coils winding down the screen
            Backdrop.Motif.COILS -> {
                stroke.strokeWidth = w * 0.030f
                stroke.color = (26 shl 24) or tint
                for (k in 0 until 3) {
                    val p = Path()
                    val x0 = w * (0.18f + 0.32f * k)
                    p.moveTo(x0, -h * 0.05f)
                    var y = -h * 0.05f
                    var dir = 1f
                    while (y < h * 1.05f) {
                        p.rQuadTo(w * 0.22f * dir, h * 0.09f, 0f, h * 0.18f)
                        y += h * 0.18f
                        dir = -dir
                    }
                    canvas.drawPath(p, stroke)
                }
            }

            // team: two rings locked together, which is the whole idea
            //
            // They are drawn BIG and pushed apart on purpose. At a sensible
            // size and sitting either side of the middle they were a perfect
            // fit for the one part of the screen the board covers completely,
            // so the mode with the clearest idea behind it had the sky you
            // could not tell from any other. This way their arcs come out
            // above and below the board where they can be seen.
            Backdrop.Motif.RINGS -> {
                stroke.strokeWidth = w * 0.024f
                stroke.color = (34 shl 24) or tint
                val r = w * 0.46f
                canvas.drawCircle(w * 0.40f, h * 0.24f, r, stroke)
                canvas.drawCircle(w * 0.60f, h * 0.76f, r, stroke)
            }

            // the computer: a circuit board's grid, seen from far away
            Backdrop.Motif.GRID -> {
                stroke.strokeWidth = w * 0.004f
                stroke.color = (24 shl 24) or tint
                val step = w / 9f
                var x = step
                while (x < w) { canvas.drawLine(x, 0f, x, h, stroke); x += step }
                var y = step
                while (y < h) { canvas.drawLine(0f, y, w, y, stroke); y += step }
            }

            // custom: rings spreading out, for the game you set up yourself
            Backdrop.Motif.TARGET -> {
                stroke.strokeWidth = w * 0.016f
                stroke.color = (28 shl 24) or tint
                for (k in 1..5) {
                    canvas.drawCircle(w * 0.5f, h * 0.46f, w * 0.13f * k, stroke)
                }
            }
        }
        paint.shader = null
        stroke.shader = null
    }

    /** 0xRRGGBB from the table above, made into a solid colour. */
    private fun opaque(rgb: Int): Int = (0xFF shl 24) or (rgb and 0xFFFFFF)
}
