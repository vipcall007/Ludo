package com.example.ludoroyale

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * A full-screen panel, built in code.
 *
 * There are nine of these screens now — profile, customize, missions, daily,
 * leaderboard, friends, rooms, settings, rules — and writing each one out in
 * XML would mean nine copies of the same title bar, scroll view and close
 * button, drifting apart as they were edited. One builder means a change to
 * the look reaches all of them, and a new screen costs a function instead of
 * two hundred lines of layout.
 *
 * The panel puts itself into the host [FrameLayout] and takes itself out again
 * when it is closed, so nothing is left behind holding on to a view.
 */
class SheetPanel private constructor(
    context: Context,
    private val host: FrameLayout,
    title: String,
    subtitle: String?,
    private val onClose: (() -> Unit)?
) {
    private val d = context.resources.displayMetrics.density

    private fun dp(v: Float) = (v * d).toInt()

    /** Everything a caller adds goes in here. */
    val content: LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val root: FrameLayout = FrameLayout(context).apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        // royal violet rather than near-black navy, so a sheet belongs to
        // the same game as the board behind it. See Royal.
        setBackgroundColor(Color.parseColor("#F21A0D42"))
        // swallow taps so the board underneath is never touched by accident
        isClickable = true
        isFocusable = true
    }

    private val ctx = context

    init {
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(10f), dp(14f), dp(14f))
        }

        column.addView(TextView(context).apply {
            text = title
            setTextColor(Royal.GOLD)
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.10f
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6f)
            layoutParams = lp
        })

        if (!subtitle.isNullOrBlank()) {
            column.addView(TextView(context).apply {
                text = subtitle
                setTextColor(Royal.TEXT_DIM)
                textSize = 12f
                gravity = Gravity.CENTER
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(4f)
                lp.bottomMargin = dp(4f)
                layoutParams = lp
            })
        }

        val scroll = ScrollView(context).apply {
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            addView(content)
        }
        column.addView(scroll)
        root.addView(column)

        root.addView(TextView(context).apply {
            text = context.getString(R.string.glyph_close)
            setBackgroundResource(R.drawable.btn_close_red)
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            val lp = FrameLayout.LayoutParams(dp(40f), dp(40f), Gravity.TOP or Gravity.END)
            lp.setMargins(dp(12f), dp(12f), dp(12f), dp(12f))
            layoutParams = lp
            setOnClickListener { close() }
        })

        host.removeAllViews()
        host.addView(root)
        host.visibility = View.VISIBLE
    }

    fun close() {
        host.removeAllViews()
        host.visibility = View.GONE
        onClose?.invoke()
    }

    // ------------------------------------------------------ building blocks

    /**
     * A heading with a rule under it, to break a long panel into parts.
     *
     * Deliberately just a heading: everything that follows is added to the
     * panel's own column, so a caller writes `section(...)` then `row(...)`
     * and gets what it reads like. An earlier version returned a box to add
     * rows into, and every caller quietly ignored it and left an empty frame
     * on the screen.
     *
     * EACH SECTION TAKES THE NEXT SEAT COLOUR. The heading and the rule under
     * it go red, green, yellow, blue and round again, in board order. Every
     * screen in the game therefore carries the board's four colours without
     * anybody choosing them per screen, and the parts of a long panel can be
     * told apart at a glance instead of by reading every heading. See Royal.
     */
    fun section(title: String) {
        val accent = Royal.accent(sectionCount++)
        content.addView(TextView(ctx).apply {
            text = title
            setTextColor(accent)
            textSize = 11f
            letterSpacing = 0.10f
            setTypeface(typeface, Typeface.BOLD)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(16f)
            lp.bottomMargin = dp(4f)
            layoutParams = lp
        })
        content.addView(View(ctx).apply {
            // the rule is the same colour at a third strength, so it reads as
            // belonging to the heading rather than as a second thing
            setBackgroundColor((0x55 shl 24) or (accent and 0xFFFFFF))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(2f)
            ).apply { bottomMargin = dp(4f) }
        })
    }

    /** How many sections this panel has, which is what picks the next accent. */
    private var sectionCount = 0

    fun body(text: String, color: String = "#DCD0F6", size: Float = 13f): TextView {
        val view = TextView(ctx).apply {
            this.text = text
            setTextColor(Color.parseColor(color))
            textSize = size
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4f)
            layoutParams = lp
        }
        content.addView(view)
        return view
    }

    /** A gold call-to-action across the width of the panel. */
    fun primaryButton(label: String, onClick: () -> Unit): TextView {
        val view = TextView(ctx).apply {
            text = label
            setBackgroundResource(R.drawable.bg_button_gold)
            setTextColor(Color.parseColor("#2A1A00"))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.06f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(10f), dp(15f), dp(10f), dp(15f))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14f)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        content.addView(view)
        return view
    }

    /** A quieter button, for a second choice. */
    fun secondaryButton(label: String, onClick: () -> Unit): TextView {
        val view = TextView(ctx).apply {
            text = label
            setBackgroundResource(R.drawable.pill_normal)
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(10f), dp(13f), dp(10f), dp(13f))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8f)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        content.addView(view)
        return view
    }

    /** A label on the left, a value on the right. */
    fun row(label: String, value: String, valueColor: String = "#FFFFFF"): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5f), 0, dp(5f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        row.addView(TextView(ctx).apply {
            text = label
            setTextColor(Royal.TEXT_DIM)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(ctx).apply {
            text = value
            setTextColor(Color.parseColor(valueColor))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        })
        content.addView(row)
        return row
    }

    /** A blank stretch, for breathing room. */
    fun gap(height: Float = 10f) {
        content.addView(View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(height)
            )
        })
    }

    fun add(view: View) {
        content.addView(view)
    }

    companion object {
        /** Opens a panel in [host], replacing whatever was there. */
        fun open(
            context: Context,
            host: FrameLayout,
            title: String,
            subtitle: String? = null,
            onClose: (() -> Unit)? = null,
            build: SheetPanel.() -> Unit
        ): SheetPanel {
            val panel = SheetPanel(context, host, title, subtitle, onClose)
            panel.build()
            return panel
        }
    }
}
