#!/usr/bin/env python3
"""
Cuts the supplied frame, avatar, token and board artwork into game sprites.

Everything here follows the same shape as the dice extractor: find the grid on
the sheet itself rather than typing coordinates in, cut each cell, key the
background out, tighten to what is actually drawn, and write one file per item.
Keeping it as a script means the whole set can be regenerated from the sources
in tools/source_art, which is the difference between artwork that can be
adjusted and artwork that can only be replaced.

THE FOUR SHEETS

frames_steps.jpg  six gold frames in a three-by-two grid, each with a "STEP N"
                  caption underneath. The captions are grey where the frames
                  are gold, so they are dropped by colour rather than by
                  guessing where the text starts.

avatars.png       fifteen round portraits, three across and five down.

tokens.png        four crown counters, one per player colour.

board.png         the Ludo board, used whole as the board's backdrop.
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'source_art')
RES = os.path.join(HERE, '..', 'app', 'src', 'main', 'res')
NODPI = os.path.join(RES, 'drawable-nodpi')

FRAME_PX = 320
AVATAR_PX = 256
TOKEN_PX = 192
BOARD_PX = 1024

# The order the frames appear on the sheet, plainest first. They are handed out
# by level, so the order on the sheet is the order of the ladder.
FRAME_IDS = ['fn_step1', 'fn_step2', 'fn_step3', 'fn_step4', 'fn_step5', 'fn_step6']

# Read left to right, top to bottom off the avatar sheet.
AVATAR_IDS = [
    'an_king', 'an_trooper', 'an_thief',
    'an_samurai', 'an_panda', 'an_prince',
    'an_queen', 'an_skull', 'an_gamer',
    'an_lion', 'an_ninja', 'an_alien',
    'an_cat', 'an_wizard', 'an_angel',
]

TOKEN_IDS = ['tn_red', 'tn_blue', 'tn_green', 'tn_yellow']


def runs(on, min_len):
    out, start = [], None
    for i, v in enumerate(on):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(on)))
    return [r for r in out if r[1] - r[0] >= min_len]


def grid(mask, across, down):
    """Split a sheet into cells by projecting the drawn pixels onto each axis."""
    h, w = mask.shape
    cols = runs(mask.sum(0) > h * 0.008, int(w / (across * 4)))
    rows = runs(mask.sum(1) > w * 0.008, int(h / (down * 4)))
    return cols, rows


def keyed(cell_rgb, tolerance=40):
    """Transparent where the black backdrop reaches in from the cell's border."""
    from collections import deque
    a = np.array(cell_rgb).astype(int)
    h, w, _ = a.shape
    border = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    bg = np.median(border, axis=0)
    close = np.abs(a - bg).sum(2) < tolerance

    seen = np.zeros((h, w), bool)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if close[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if close[y, x] and not seen[y, x]:
                seen[y, x] = True
                q.append((y, x))
    while q:
        y, x = q.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and not seen[ny, nx] and close[ny, nx]:
                seen[ny, nx] = True
                q.append((ny, nx))

    out = cell_rgb.convert('RGBA')
    alpha = Image.fromarray(np.where(seen, 0, 255).astype(np.uint8), 'L')
    out.putalpha(alpha.filter(ImageFilter.GaussianBlur(0.6)))
    return out


def squared(im, pad=0.02):
    box = im.getchannel('A').point(lambda v: 255 if v > 18 else 0).getbbox()
    if box:
        im = im.crop(box)
    side = int(max(im.size) * (1 + pad * 2))
    out = Image.new('RGBA', (side, side), (0, 0, 0, 0))
    out.alpha_composite(im, ((side - im.width) // 2, (side - im.height) // 2))
    return out


# --------------------------------------------------------------------- frames

def drop_caption(cell):
    """Remove the grey "STEP N" caption, keeping the gold frame above it.

    The caption is neutral grey and the frame is gold, so the rows that hold
    only near-grey pixels are the caption's. Cutting by colour rather than by a
    fixed fraction means a sheet laid out slightly differently still works.
    """
    a = np.array(cell.convert('RGB')).astype(int)
    warm = (a[:, :, 0] - a[:, :, 2]) > 28          # gold: red well above blue
    lit = a.sum(2) > 120
    grey = lit & ~warm
    per_row_warm = warm.sum(1)
    per_row_grey = grey.sum(1)
    # walk up from the bottom while the row is mostly caption
    cut = a.shape[0]
    for y in range(a.shape[0] - 1, 0, -1):
        if per_row_warm[y] > per_row_grey[y] and per_row_warm[y] > a.shape[1] * 0.01:
            break
        cut = y
    return cell.crop((0, 0, cell.width, max(cut, int(cell.height * 0.5))))


def punch_window(rgba):
    """Make the frame's centre see-through.

    The centre of each frame is where the player's face goes, and on the sheet
    it is filled with the same black as the backdrop. Keying from the border
    cannot reach it — it is walled in by the gold — so it survives as an opaque
    black square, and a frame with a black square in the middle hides the very
    thing it is supposed to surround.

    The frame itself is gold and white, so nothing else in the picture is
    anywhere near black; clearing the near-black pixels takes the window out and
    leaves the metal alone.
    """
    a = np.array(rgba)
    dark = (a[:, :, :3].sum(2) < 110) & (a[:, :, 3] > 0)
    a[:, :, 3] = np.where(dark, 0, a[:, :, 3])
    out = Image.fromarray(a, 'RGBA')
    # soften the cut edge so the gold does not end in a hard staircase
    alpha = out.getchannel('A').filter(ImageFilter.GaussianBlur(0.7))
    out.putalpha(alpha)
    return out


def do_frames():
    sheet = Image.open(os.path.join(SRC, 'frames_steps.jpg')).convert('RGB')
    mask = np.array(sheet).astype(int).sum(2) > 90
    cols, rows = grid(mask, 3, 2)
    assert len(cols) == 3 and len(rows) == 2, f'frames grid was {len(cols)}x{len(rows)}'

    i = 0
    for (y0, y1) in rows:
        for (x0, x1) in cols:
            pad = int((x1 - x0) * 0.04)
            cell = sheet.crop((max(0, x0 - pad), max(0, y0 - pad),
                               min(sheet.width, x1 + pad), min(sheet.height, y1 + pad)))
            cell = drop_caption(cell)
            art = squared(punch_window(keyed(cell))).resize((FRAME_PX, FRAME_PX), Image.LANCZOS)
            art.save(os.path.join(NODPI, f'{FRAME_IDS[i]}.webp'), 'WEBP', quality=92, method=6)
            i += 1
    print(f'{i} frames')


# -------------------------------------------------------------------- avatars

def do_avatars():
    sheet = Image.open(os.path.join(SRC, 'avatars.png')).convert('RGB')
    mask = np.array(sheet).astype(int).sum(2) > 70
    cols, rows = grid(mask, 3, 5)
    assert len(cols) == 3 and len(rows) == 5, f'avatar grid was {len(cols)}x{len(rows)}'

    i = 0
    for (y0, y1) in rows:
        for (x0, x1) in cols:
            cell = sheet.crop((x0, y0, x1, y1))
            art = squared(keyed(cell)).resize((AVATAR_PX, AVATAR_PX), Image.LANCZOS)
            # these are round portraits; a clean circular edge beats whatever
            # the keying left behind at the rim
            m = Image.new('L', art.size, 0)
            ImageDraw.Draw(m).ellipse([0, 0, art.width - 1, art.height - 1], fill=255)
            m = m.filter(ImageFilter.GaussianBlur(1.0))
            art.putalpha(Image.fromarray(
                np.minimum(np.array(art.getchannel('A')), np.array(m)).astype(np.uint8), 'L'))
            art.save(os.path.join(NODPI, f'{AVATAR_IDS[i]}.webp'), 'WEBP', quality=92, method=6)
            i += 1
    print(f'{i} avatars')


# --------------------------------------------------------------------- tokens

def do_tokens():
    sheet = Image.open(os.path.join(SRC, 'tokens.png')).convert('RGB')
    mask = np.array(sheet).astype(int).sum(2) > 70
    cols, rows = grid(mask, 2, 2)
    assert len(cols) == 2 and len(rows) == 2, f'token grid was {len(cols)}x{len(rows)}'

    i = 0
    for (y0, y1) in rows:
        for (x0, x1) in cols:
            cell = sheet.crop((x0, y0, x1, y1))
            art = squared(keyed(cell)).resize((TOKEN_PX, TOKEN_PX), Image.LANCZOS)
            art.save(os.path.join(NODPI, f'{TOKEN_IDS[i]}.webp'), 'WEBP', quality=92, method=6)
            i += 1
    print(f'{i} tokens')


# ---------------------------------------------------------------------- board

def do_board():
    """The board goes in whole, as the backdrop the cells are drawn over."""
    board = Image.open(os.path.join(SRC, 'board.png')).convert('RGB')
    side = min(board.size)
    left = (board.width - side) // 2
    top = (board.height - side) // 2
    board = board.crop((left, top, left + side, top + side))
    board.resize((BOARD_PX, BOARD_PX), Image.LANCZOS).save(
        os.path.join(NODPI, 'board_royal.webp'), 'WEBP', quality=90, method=6)
    print('board written')


if __name__ == '__main__':
    os.makedirs(NODPI, exist_ok=True)
    do_frames()
    do_avatars()
    do_tokens()
    do_board()
