package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * TWO RULES THE OWNER ASKED FOR, AND WHY THEY NEED PINNING DOWN
 *
 * THE LOCKED LAP. In Quick mode, a piece that goes all the way round without
 * its player having cut anybody used to simply stop being offered a finishing
 * move — it sat at the door doing nothing. Now it is turned back out to run the
 * circuit again. That touches the most dangerous thing in the engine: a piece
 * moving backwards. If it lands in the wrong place, or the turn does not pass,
 * a Quick match can lock up completely.
 *
 * THE TEAM HAND-OVER. A player who is home keeps rolling for their partner. The
 * whole engine was written assuming the piece being moved belongs to the player
 * whose turn it is, so this is exactly the sort of change that quietly sends
 * somebody's piece to the wrong home.
 */
class LapAndTeamTest {

    // ------------------------------------------------------------ the lap

    private fun quickState(): GameState = GameState(
        gameId = "lap",
        players = mutableListOf(
            Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN),
            Player.create("p2", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN)
        )
    )

    private fun bank(s: GameState, vararg values: Int) {
        s.pendingRolls.clear()
        s.pendingRolls.addAll(values.toList())
        s.phase = TurnPhase.AWAITING_MOVE
        s.lastDiceRoll = values.lastOrNull()
    }

    /** A red piece three steps short of finishing, with the rest already home. */
    private fun atTheDoor(s: GameState): com.example.ludoroyale.model.Token {
        val token = s.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = LudoEngine.FINISH_STEPS - 3
        for (i in 1..3) {
            s.players[0].tokens[i].state = TokenState.FINISHED
            s.players[0].tokens[i].steps = LudoEngine.FINISH_STEPS
        }
        return token
    }

    @Test
    fun `without a kill the piece is turned back out for another lap`() {
        val s = quickState()
        val engine = LudoEngine(s, RuleConfig(quickMode = true))
        val token = atTheDoor(s)
        bank(s, 3)

        val move = engine.legalMovesFor(3).single { it.token.id == token.id }
        assertTrue("the piece was allowed home while locked", move.restartsLap)
        assertFalse(move.finishesToken)

        val result = engine.applyMove(move)
        assertTrue(result.restartedLap)
        assertEquals("it should be back on its own starting square",
                     LudoEngine.LAP_RESTART_STEPS, token.steps)
        assertEquals(TokenState.ACTIVE, token.state)
    }

    @Test
    fun `a turned-back piece is on the board, not in base`() {
        // This is the whole point of the rule. Sending it to base would mean
        // waiting for another six, which makes a locked match drag exactly
        // where it is supposed to get sharper.
        val s = quickState()
        val engine = LudoEngine(s, RuleConfig(quickMode = true))
        val token = atTheDoor(s)
        bank(s, 3)
        engine.applyMove(engine.legalMovesFor(3).single { it.token.id == token.id })

        assertNotEquals(TokenState.BASE, token.state)
        assertTrue("it should be able to move again without a six",
                   token.steps >= 1)
    }

    @Test
    fun `the piece keeps going round rather than getting stuck`() {
        // Play a locked Quick match out far enough that the piece must lap more
        // than once. Nothing should throw, and the turn must always move on.
        val s = quickState()
        val engine = LudoEngine(s, RuleConfig(quickMode = true))
        val token = atTheDoor(s)
        var laps = 0
        repeat(200) {
            s.currentPlayerIndex = 0
            token.state = TokenState.HOME_STRETCH
            token.steps = LudoEngine.FINISH_STEPS - 1
            bank(s, 1)
            val move = engine.legalMovesFor(1).single { it.token.id == token.id }
            engine.applyMove(move)
            if (move.restartsLap) laps++
        }
        assertEquals("every one of those should have been a lap restart", 200, laps)
    }

    @Test
    fun `once the lock is open the piece goes home instead`() {
        val s = quickState()
        val engine = LudoEngine(s, RuleConfig(quickMode = true))
        val token = atTheDoor(s)
        s.players[0].hasCapturedOpponent = true
        bank(s, 3)

        val move = engine.legalMovesFor(3).single { it.token.id == token.id }
        assertFalse("it was turned back even though the lock was open", move.restartsLap)
        assertTrue(move.finishesToken)
    }

    @Test
    fun `classic mode never turns a piece back`() {
        val s = quickState()
        val engine = LudoEngine(s)          // not quick mode
        val token = atTheDoor(s)
        bank(s, 3)
        assertFalse(engine.legalMovesFor(3).single { it.token.id == token.id }.restartsLap)
    }

    @Test
    fun `a piece turned back can cut somebody on the way in`() {
        // It lands on its own starting square, and somebody may be standing
        // there. That is a real capture, and it opens the lock.
        val s = quickState()
        val engine = LudoEngine(s, RuleConfig(quickMode = true, safeCellsBlockCapture = false))
        val token = atTheDoor(s)

        val victim = s.players[1].tokens[0]
        victim.state = TokenState.ACTIVE
        val target = LudoBoard.toGlobalIndex(PlayerColor.RED, LudoEngine.LAP_RESTART_STEPS - 1)
        victim.steps = ((target - PlayerColor.YELLOW.startOffset + LudoBoard.TRACK_LENGTH)
            % LudoBoard.TRACK_LENGTH) + 1

        bank(s, 3)
        val result = engine.applyMove(engine.legalMovesFor(3).single { it.token.id == token.id })

        assertTrue("the piece landed on an opponent and cut nothing",
                   result.capturedTokens.any { it.id == victim.id })
        assertTrue("that cut should have opened the lock", s.players[0].hasCapturedOpponent)
        assertTrue(result.unlockedHome)
    }

    // ----------------------------------------------------------- the team

    private fun teamState(): GameState {
        val red = Player.create("p1", "Red", PlayerColor.RED, PlayerKind.HUMAN, team = 1)
        val green = Player.create("p2", "Green", PlayerColor.GREEN, PlayerKind.HUMAN, team = 2)
        val yellow = Player.create("p3", "Yellow", PlayerColor.YELLOW, PlayerKind.HUMAN, team = 1)
        val blue = Player.create("p4", "Blue", PlayerColor.BLUE, PlayerKind.HUMAN, team = 2)
        return GameState(gameId = "team", players = mutableListOf(red, green, yellow, blue))
    }

    private fun sendHome(player: Player) {
        for (t in player.tokens) {
            t.state = TokenState.FINISHED
            t.steps = LudoEngine.FINISH_STEPS
        }
        player.finishedCount = Player.TOKENS_PER_PLAYER
        player.hasWon = true
    }

    @Test
    fun `a finished player still gets a turn in team mode`() {
        val s = teamState()
        val engine = LudoEngine(s, RuleConfig(teamMode = true))
        sendHome(s.players[0])                 // Red is home
        s.currentPlayerIndex = 3               // Blue to play
        s.phase = TurnPhase.AWAITING_MOVE
        engine.passTurn()
        assertEquals("the finished player was skipped", 0, s.currentPlayerIndex)
    }

    @Test
    fun `a finished player moves the partner's pieces, not nobody's`() {
        val s = teamState()
        val engine = LudoEngine(s, RuleConfig(teamMode = true))
        sendHome(s.players[0])
        val partner = s.players[2]             // Yellow, same team
        partner.tokens[0].state = TokenState.ACTIVE
        partner.tokens[0].steps = 10

        s.currentPlayerIndex = 0               // the finished player's turn
        bank(s, 3)

        val moves = engine.legalMovesFor(3)
        assertTrue("a finished player was offered nothing to do", moves.isNotEmpty())
        assertTrue("those are not the partner's pieces",
                   moves.all { m -> partner.tokens.any { it.id == m.token.id } })

        val result = engine.applyMove(moves.first { it.token.id == partner.tokens[0].id })
        assertTrue(result.playedForPartner)
        assertEquals(13, partner.tokens[0].steps)
    }

    @Test
    fun `outside team mode a finished player is skipped as before`() {
        val s = teamState()
        val engine = LudoEngine(s)             // no team mode
        sendHome(s.players[0])
        s.currentPlayerIndex = 3
        s.phase = TurnPhase.AWAITING_MOVE
        engine.passTurn()
        assertNotEquals("a finished player took a turn in a normal match",
                        0, s.currentPlayerIndex)
    }

    @Test
    fun `when the partner is home too the finished player stops`() {
        val s = teamState()
        val engine = LudoEngine(s, RuleConfig(teamMode = true))
        sendHome(s.players[0])
        sendHome(s.players[2])                 // both of team 1 are home
        s.currentPlayerIndex = 1
        s.phase = TurnPhase.AWAITING_MOVE
        engine.passTurn()
        assertEquals("a team with nothing left to move kept taking turns",
                     3, s.currentPlayerIndex)
    }

    // ------------------------------------------------- winning ends the turn

    @Test
    fun `winning throws away whatever was still banked`() {
        val s = quickState()
        val engine = LudoEngine(s)
        val player = s.players[0]
        for (i in 0..2) {
            player.tokens[i].state = TokenState.FINISHED
            player.tokens[i].steps = LudoEngine.FINISH_STEPS
        }
        player.finishedCount = 3
        val last = player.tokens[3]
        last.state = TokenState.HOME_STRETCH
        last.steps = LudoEngine.FINISH_STEPS - 2

        bank(s, 2, 4)
        val result = engine.applyMove(engine.legalMovesFor(2).single { it.token.id == last.id })

        assertTrue(result.gameWon)
        assertTrue("the match was won with numbers still in hand",
                   s.pendingRolls.isEmpty())
        assertTrue("the winning move should report nothing left",
                   result.rollsLeft.isEmpty())
        assertEquals(TurnPhase.GAME_OVER, s.phase)
    }
}
