package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * One dice, in either of the two ways this game has them.
 *
 * Most are drawn here in code: body gradient, bevelled bright edge, glossy
 * sheen, deep border and glossy pips with a specular dot, all taken from
 * [skin] — the same code with different paint, crisp at any size and nothing
 * to ship. The rest are rendered pictures listed in [DiceFaceArt], and for
 * those this view simply draws the right face.
 *
 * Which path is taken is decided by the id alone, so nothing else in the game
 * has to know or care which kind of dice is in play.
 *
 * [dimmed] turns it to dull metal for players whose turn it isn't.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) { field = v.coerceIn(1, 6); invalidate() }

    var dimmed: Boolean = false
        set(v) { field = v; invalidate() }

    /** Thin ring in the owning player's colour. 0 = no ring. */
    var accent: Int = 0
        set(v) { field = v; invalidate() }

    /** Which design this face wears. */
    var skin: DiceSkin = DiceSkins.resolve(DiceSkins.DEFAULT_ID)
        set(v) { field = v; invalidate() }

    fun setSkinId(id: String) {
        skin = DiceSkins.resolve(id)
    }

    /**
     * Whether the rolled number is stamped on the picture dice.
     *
     * On the board this is on, because the number has to be countable at a
     * glance. In the collection screen it is turned off, so the artwork can be
     * admired as it was drawn.
     */
    var showValueBadge: Boolean = true
        set(v) { field = v; invalidate() }

    private val picture = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    private val badgePlate = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val badgeEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD
        )
    }

    /**
     * The face currently loaded, and which drawable it came from.
     *
     * Kept so that flicking through faces during a roll does not decode a
     * bitmap sixteen times a second — only a change of face touches the disk.
     */
    private var faceBitmap: android.graphics.Bitmap? = null
    private var faceResId: Int = 0

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 0, 0, 0) }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bevelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipShinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val layouts: Map<Int, List<Pair<Float, Float>>> = mapOf(
        1 to listOf(0.5f to 0.5f),
        2 to listOf(0.30f to 0.30f, 0.70f to 0.70f),
        3 to listOf(0.27f to 0.27f, 0.5f to 0.5f, 0.73f to 0.73f),
        4 to listOf(0.30f to 0.30f, 0.70f to 0.30f, 0.30f to 0.70f, 0.70f to 0.70f),
        5 to listOf(0.27f to 0.27f, 0.73f to 0.27f, 0.5f to 0.5f, 0.27f to 0.73f, 0.73f to 0.73f),
        6 to listOf(
            0.30f to 0.24f, 0.70f to 0.24f,
            0.30f to 0.50f, 0.70f to 0.50f,
            0.30f to 0.76f, 0.70f to 0.76f
        )
    )

    private fun grey(level: Int) = Color.rgb(level, level, level)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (DiceFaceArt.isPicture(skin.id)) {
            drawPicture(canvas, w, h)
            return
        }

        val inset = w * 0.07f
        val corner = w * 0.22f
        val face = RectF(inset, inset, w - inset, h - inset)

        // drop shadow
        canvas.drawRoundRect(
            RectF(face.left + w * 0.03f, face.top + h * 0.06f, face.right + w * 0.03f, face.bottom + h * 0.06f),
            corner, corner, shadowPaint
        )

        // body (or dull metal when it isn't your turn)
        bodyPaint.shader = LinearGradient(
            face.left, face.top, face.right, face.bottom,
            if (dimmed) grey(0x8E) else skin.top,
            if (dimmed) grey(0x5A) else skin.bottom,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(face, corner, corner, bodyPaint)
        bodyPaint.shader = null

        // glossy sheen across the top half
        glossPaint.shader = RadialGradient(
            face.centerX(), face.top + face.height() * 0.18f, face.width() * 0.75f,
            Color.argb(if (dimmed) 40 else 130, 255, 255, 255),
            Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(face, corner, corner, glossPaint)
        glossPaint.shader = null

        // bright inner bevel then the deeper border
        bevelPaint.strokeWidth = w * 0.035f
        bevelPaint.color = if (dimmed) grey(0xA8) else skin.bevel
        val bevel = RectF(face.left + w * 0.05f, face.top + w * 0.05f, face.right - w * 0.05f, face.bottom - w * 0.05f)
        canvas.drawRoundRect(bevel, corner * 0.8f, corner * 0.8f, bevelPaint)

        borderPaint.strokeWidth = w * 0.05f
        borderPaint.color = if (dimmed) grey(0x4A) else skin.border
        canvas.drawRoundRect(face, corner, corner, borderPaint)

        // pips, in whichever shape this design uses
        val pipR = w * 0.082f
        pipPaint.color = if (dimmed) grey(0x33) else skin.pip
        pipShinePaint.color = Color.argb(if (dimmed) 60 else 150, 255, 255, 255)
        for ((fx, fy) in layouts.getValue(value)) {
            val cx = face.left + fx * face.width()
            val cy = face.top + fy * face.height()
            when (skin.pipStyle) {
                1 -> canvas.drawRoundRect(
                    RectF(cx - pipR, cy - pipR, cx + pipR, cy + pipR),
                    pipR * 0.45f, pipR * 0.45f, pipPaint
                )
                2 -> canvas.drawPath(starPip(cx, cy, pipR * 1.15f), pipPaint)
                else -> canvas.drawCircle(cx, cy, pipR, pipPaint)
            }
            canvas.drawCircle(cx - pipR * 0.28f, cy - pipR * 0.30f, pipR * 0.34f, pipShinePaint)
        }

        // owner ring
        if (accent != 0) {
            ringPaint.color = accent
            ringPaint.alpha = if (dimmed) 90 else 255
            ringPaint.strokeWidth = w * 0.045f
            val r = w * 0.20f
            canvas.drawRoundRect(RectF(w * 0.02f, h * 0.02f, w - w * 0.02f, h - h * 0.02f), r, r, ringPaint)
            ringPaint.alpha = 255
        }
    }

    /**
     * A picture dice: the whole cube, fitted to the view.
     *
     * The artwork already carries its own edges, lighting and glow, so nothing
     * is drawn over it — a bevel or a sheen on top would only fight what the
     * picture is already doing. The owner ring still goes round it, because
     * that is the game speaking rather than the dice, and [dimmed] fades it
     * the same way the drawn dice fade.
     */
    private fun drawPicture(canvas: Canvas, w: Float, h: Float) {
        val wanted = DiceFaceArt.face(skin.id, value)
        if (wanted == 0) return
        if (wanted != faceResId || faceBitmap == null) {
            faceBitmap = try {
                android.graphics.BitmapFactory.decodeResource(resources, wanted)
            } catch (e: Throwable) {
                // an unreadable face must never take the game down with it
                null
            }
            faceResId = wanted
        }
        val bitmap = faceBitmap ?: return

        val side = min(w, h)
        val left = (w - side) / 2f
        val top = (h - side) / 2f
        picture.alpha = if (dimmed) 110 else 255
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + side, top + side), picture)

        if (accent != 0) {
            ringPaint.color = accent
            ringPaint.alpha = if (dimmed) 90 else 210
            ringPaint.strokeWidth = w * 0.045f
            val r = w * 0.20f
            canvas.drawRoundRect(
                RectF(w * 0.02f, h * 0.02f, w - w * 0.02f, h - h * 0.02f), r, r, ringPaint
            )
            ringPaint.alpha = 255
        }

        if (showValueBadge) drawValueBadge(canvas, w, h)
    }

    /**
     * The rolled number, stamped flat on the front.
     *
     * The picture dice are photographed as cubes standing at an angle, so the
     * face carrying the number is tilted away from the viewer: on a small
     * dice at the edge of the board, five pips seen at that angle are genuinely
     * hard to count. The artwork cannot be turned to face the screen — it would
     * have to be drawn again from the front to do that — so the number itself
     * is written here instead, square to the screen, in the one place on the
     * dice that is always in shadow.
     *
     * It is drawn rather than photographed, so it is sharp at any size, and it
     * reads the same on every one of the twelve dice.
     */
    private fun drawValueBadge(canvas: Canvas, w: Float, h: Float) {
        val side = min(w, h)
        val plate = side * 0.36f
        val pad = side * 0.05f
        val box = RectF(w - pad - plate, h - pad - plate, w - pad, h - pad)
        val corner = plate * 0.30f

        badgePlate.color = Color.argb(if (dimmed) 120 else 225, 0x10, 0x0C, 0x06)
        canvas.drawRoundRect(box, corner, corner, badgePlate)

        badgeEdge.strokeWidth = plate * 0.09f
        badgeEdge.color = Color.argb(if (dimmed) 120 else 255, 0xF2, 0xC8, 0x5A)
        canvas.drawRoundRect(box, corner, corner, badgeEdge)

        badgeText.textSize = plate * 0.74f
        badgeText.color = Color.argb(if (dimmed) 140 else 255, 0xFF, 0xEC, 0xB8)
        // centre the digit on the plate by its own height, not the font's
        val bounds = android.graphics.Rect()
        val text = value.toString()
        badgeText.getTextBounds(text, 0, text.length, bounds)
        canvas.drawText(text, box.centerX(), box.centerY() + bounds.height() / 2f, badgeText)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        faceBitmap = null
        faceResId = 0
    }

    private fun starPip(cx: Float, cy: Float, outer: Float): Path {
        val p = Path()
        val inner = outer * 0.46f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -Math.PI / 2 + i * Math.PI / 5
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }
}
