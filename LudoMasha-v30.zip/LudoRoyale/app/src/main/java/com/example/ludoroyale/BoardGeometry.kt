package com.example.ludoroyale

import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState

/**
 * Classic 15x15 Ludo board geometry. All positions are expressed as
 * (row, col) FLOAT centers in "cell units" — multiply by the on-screen
 * cell size (px) to get a pixel coordinate. Board is 15x15 cells total.
 * Corner layout: GREEN top-left, YELLOW top-right, RED bottom-left,
 * BLUE bottom-right (matches the common reference layout).
 */
object BoardGeometry {
    const val GRID_SIZE = 15

    // The 52-cell outer ring, in track order (index 0 = GREEN's start cell).
    val RING: List<Pair<Int, Int>> = listOf(
        6 to 1, 6 to 2, 6 to 3, 6 to 4, 6 to 5,
        5 to 6, 4 to 6, 3 to 6, 2 to 6, 1 to 6, 0 to 6,
        0 to 7,
        0 to 8,
        1 to 8, 2 to 8, 3 to 8, 4 to 8, 5 to 8,
        6 to 9, 6 to 10, 6 to 11, 6 to 12, 6 to 13, 6 to 14,
        7 to 14,
        8 to 14,
        8 to 13, 8 to 12, 8 to 11, 8 to 10, 8 to 9,
        9 to 8, 10 to 8, 11 to 8, 12 to 8, 13 to 8, 14 to 8,
        14 to 7,
        14 to 6,
        13 to 6, 12 to 6, 11 to 6, 10 to 6, 9 to 6,
        8 to 5, 8 to 4, 8 to 3, 8 to 2, 8 to 1, 8 to 0,
        7 to 0,
        6 to 0
    )

    // Each color's private 6-cell path from the ring into the center.
    val STRETCH: Map<PlayerColor, List<Pair<Int, Int>>> = mapOf(
        PlayerColor.GREEN to listOf(7 to 1, 7 to 2, 7 to 3, 7 to 4, 7 to 5, 7 to 6),
        PlayerColor.YELLOW to listOf(1 to 7, 2 to 7, 3 to 7, 4 to 7, 5 to 7, 6 to 7),
        PlayerColor.BLUE to listOf(7 to 13, 7 to 12, 7 to 11, 7 to 10, 7 to 9, 7 to 8),
        PlayerColor.RED to listOf(13 to 7, 12 to 7, 11 to 7, 10 to 7, 9 to 7, 8 to 7)
    )

    /**
     * Where the four waiting pieces sit inside each yard.
     *
     * MEASURED OFF THE BOARD PICTURE, one yard at a time, rather than worked
     * out from the geometry. The picture draws a white circle in each yard with
     * four grey resting places inside it, and those circles are NOT centred on
     * the yard — a painted dice in one corner pushes each of them slightly, and
     * by a different amount in each yard. Four tidy symmetrical numbers looked
     * right on paper and put every waiting piece a little up and to the left of
     * the place the board had drawn for it.
     */
    val BASE_SLOTS: Map<PlayerColor, List<Pair<Float, Float>>> = mapOf(
        PlayerColor.GREEN to listOf(
            2.64f to 2.49f, 2.64f to 3.92f, 3.95f to 2.49f, 3.95f to 3.92f
        ),
        PlayerColor.YELLOW to listOf(
            2.63f to 11.09f, 2.63f to 12.51f, 3.94f to 11.09f, 3.94f to 12.51f
        ),
        PlayerColor.BLUE to listOf(
            11.05f to 11.10f, 11.05f to 12.52f, 12.39f to 11.10f, 12.39f to 12.52f
        ),
        PlayerColor.RED to listOf(
            11.04f to 2.46f, 11.04f to 3.88f, 12.38f to 2.46f, 12.38f to 3.88f
        )
    )

    // Home-square bounding boxes: (rowStart, colStart, rowEnd, colEnd) inclusive, each 6x6.
    val HOME_SQUARES: Map<PlayerColor, IntArray> = mapOf(
        PlayerColor.GREEN to intArrayOf(0, 0, 5, 5),
        PlayerColor.YELLOW to intArrayOf(0, 9, 5, 14),
        PlayerColor.BLUE to intArrayOf(9, 9, 14, 14),
        PlayerColor.RED to intArrayOf(9, 0, 14, 5)
    )

    /** Center (row, col in cell units) for a color at a given pip count (1..57), ignoring base/finished edge cases. */
    fun centerForSteps(color: PlayerColor, steps: Int): Pair<Float, Float> {
        return if (steps <= 51) {
            val globalIdx = (color.startOffset + steps - 1).mod(52)
            val (r, c) = RING[globalIdx]
            (r + 0.5f) to (c + 0.5f)
        } else {
            val (r, c) = STRETCH.getValue(color)[(steps - 52).coerceIn(0, 5)]
            (r + 0.5f) to (c + 0.5f)
        }
    }

    /** Screen-space center (row, col in cell units) for a token given its current state. */
    fun centerOf(token: Token, tokenIndexWithinColor: Int): Pair<Float, Float> {
        return when (token.state) {
            TokenState.BASE -> BASE_SLOTS.getValue(token.color)[tokenIndexWithinColor.coerceIn(0, 3)]
            TokenState.ACTIVE, TokenState.HOME_STRETCH -> centerForSteps(token.color, token.steps)
            TokenState.FINISHED -> centerForSteps(token.color, 57)
        }
    }
}
