package com.example.ludoroyale.cosmetics

/**
 * What kind of thing a cosmetic is.
 *
 * Every one of these changes how something LOOKS and nothing else. There is no
 * cosmetic type for dice odds, movement or board rules, because no such thing
 * is allowed to exist in this game.
 */
enum class CosmeticType(val display: String) {
    TOKEN_SKIN("TOKEN"),
    DICE_SKIN("DICE"),
    AVATAR("AVATAR"),
    AVATAR_FRAME("FRAME"),
    VICTORY_EFFECT("VICTORY")
}

enum class Rarity(val display: String) {
    COMMON("COMMON"),
    RARE("RARE"),
    EPIC("EPIC"),
    LEGENDARY("LEGENDARY")
}

/** How an item is come by. */
enum class UnlockMethod {
    /** Owned from the first launch. */
    FREE,
    /** Bought with coins earned by playing. */
    COINS,
    /** Given on reaching a player level. */
    LEVEL,
    /** Given by the daily login cycle. */
    DAILY,
    /** Given for finishing missions. */
    MISSION,
    /** Found in a chest earned by playing. */
    CHEST
}

/**
 * One collectable.
 *
 * This is the single source of truth for what exists, what it costs and how it
 * is come by. The drawing code keys off [id] for its colours, so a cosmetic can
 * be re-priced or re-classified without touching a line of rendering, and no
 * Activity has to carry its own copy of the list.
 */
data class CosmeticItem(
    val id: String,
    val name: String,
    val type: CosmeticType,
    val rarity: Rarity,
    val unlock: UnlockMethod,
    /** Coins, when [unlock] is COINS. Otherwise 0. */
    val price: Int = 0,
    /** Player level required, when [unlock] is LEVEL. Otherwise 0. */
    val requiredLevel: Int = 0
) {
    /** What a duplicate is worth when a chest turns one up again. */
    val dustValue: Int
        get() = when (rarity) {
            Rarity.COMMON -> 40
            Rarity.RARE -> 90
            Rarity.EPIC -> 180
            Rarity.LEGENDARY -> 350
        }
}

/**
 * The whole collection.
 *
 * FAIRNESS: nothing in this catalog is consulted by the rules engine, the dice
 * or the computer players. A Legendary dragon token moves exactly as far as the
 * free one, and a Legendary dice rolls exactly the same numbers.
 */
object Cosmetics {

    // ---------------------------------------------------------- token skins

    /**
     * THE ONE TOKEN DESIGN.
     *
     * The counters on the board are the supplied crown pieces, one per player
     * colour, and they belong to the board picture they sit on. The nine token
     * skins that used to be here changed a rim and an ornament on a piece the
     * game no longer draws, so keeping them would have meant a shop full of
     * items that change nothing. They are gone.
     */
    const val TOKEN_CROWN = "tok_crown"

    // ----------------------------------------------------------- dice skins
    //
    // THE EIGHT PICTURE DICE ARE THE WHOLE COLLECTION.
    //
    // Everything before these is gone. The dice they replaced were drawn as
    // cubes standing at an angle, so the number was tilted away from the player
    // and hard to count on a small screen; these are drawn flat, facing out.
    //
    // Their artwork lives in DiceFaceArt, six real pictures each, and the "dn_"
    // prefix keeps them apart from anything that came before.

    const val DN_HEART = "dn_heart"
    const val DN_ROYAL = "dn_royal"
    const val DN_DRAGON = "dn_dragon"
    const val DN_ALIEN = "dn_alien"
    const val DN_DIAMOND = "dn_diamond"
    const val DN_GHOST = "dn_ghost"
    const val DN_ROBOT = "dn_robot"
    const val DN_GIFT = "dn_gift"

    // ------------------------------------------------------------- avatars
    //
    // Fifteen painted portraits, handed out as the player climbs the levels.
    // The drawn faces that used to be here are gone with the drawn dice.

    const val AV_KING = "av_king"
    const val AV_TROOPER = "av_trooper"
    const val AV_THIEF = "av_thief"
    const val AV_SAMURAI = "av_samurai"
    const val AV_PANDA = "av_panda"
    const val AV_PRINCE = "av_prince"
    const val AV_QUEEN = "av_queen"
    const val AV_SKULL = "av_skull"
    const val AV_GAMER = "av_gamer"
    const val AV_LION = "av_lion"
    const val AV_NINJA = "av_ninja"
    const val AV_ALIEN = "av_alien"
    const val AV_CAT = "av_cat"
    const val AV_WIZARD = "av_wizard"
    const val AV_ANGEL = "av_angel"

    /**
     * The player's own photograph.
     *
     * Not a drawing: choosing it opens the phone's picture chooser, and what
     * the player crops is kept on this phone and shown here. Always owned,
     * because it is their own face.
     */
    const val AVATAR_PHOTO = "av_photo"

    // -------------------------------------------------------------- frames
    //
    // Six gold frames that grow as the player climbs: a plain band, then a
    // crown, then wings, then a full laurel. The step number IS the rank, so
    // the order here is the order they are earned in.

    const val FRAME_NONE = "fr_none"
    const val FR_STEP1 = "fr_step1"
    const val FR_STEP2 = "fr_step2"
    const val FR_STEP3 = "fr_step3"
    const val FR_STEP4 = "fr_step4"
    const val FR_STEP5 = "fr_step5"
    const val FR_STEP6 = "fr_step6"

    // ----------------------------------------------------- victory effects

    const val FX_CONFETTI = "fx_confetti"
    const val FX_GOLD_RAIN = "fx_gold_rain"
    const val FX_FIREWORKS = "fx_fireworks"
    const val FX_ROYAL_CROWN = "fx_royal_crown"

    val ALL: List<CosmeticItem> = listOf(
        // ---- the counters on the board
        item(TOKEN_CROWN, "Royal Crown", CosmeticType.TOKEN_SKIN, Rarity.COMMON, UnlockMethod.FREE),

        // ---- the eight picture dice: the whole dice collection.
        // One is free so a new player is never without a dice; the other seven
        // are the reward for the HARD missions and cannot be bought at all.
        item(DN_GIFT, "Gift Box", CosmeticType.DICE_SKIN, Rarity.COMMON, UnlockMethod.FREE),
        item(DN_HEART, "Ruby Heart", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(DN_ROBOT, "Robo", CosmeticType.DICE_SKIN, Rarity.RARE, UnlockMethod.MISSION),
        item(DN_GHOST, "Ghost Charm", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DN_ALIEN, "Alien", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DN_ROYAL, "Royal Crown", CosmeticType.DICE_SKIN, Rarity.EPIC, UnlockMethod.MISSION),
        item(DN_DIAMOND, "Diamond", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),
        item(DN_DRAGON, "Dragon Fire", CosmeticType.DICE_SKIN, Rarity.LEGENDARY, UnlockMethod.MISSION),

        // ---- avatars, climbing with the player's level
        item(AVATAR_PHOTO, "My Photo", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AV_KING, "The King", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.FREE),
        item(AV_PANDA, "Panda", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.LEVEL, requiredLevel = 2),
        item(AV_CAT, "Cool Cat", CosmeticType.AVATAR, Rarity.COMMON, UnlockMethod.LEVEL, requiredLevel = 4),
        item(AV_PRINCE, "Prince", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 6),
        item(AV_GAMER, "Gamer Girl", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 9),
        item(AV_THIEF, "Shadow", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 12),
        item(AV_NINJA, "Ninja", CosmeticType.AVATAR, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 16),
        item(AV_TROOPER, "Trooper", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 20),
        item(AV_ALIEN, "Alien", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 25),
        item(AV_QUEEN, "The Queen", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 30),
        item(AV_SAMURAI, "Samurai", CosmeticType.AVATAR, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 38),
        item(AV_LION, "War Lion", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 46),
        item(AV_WIZARD, "Wizard", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 55),
        item(AV_SKULL, "Ghost Rider", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 70),
        item(AV_ANGEL, "Angel", CosmeticType.AVATAR, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 90),

        // ---- frames. The step number IS the rank, so they are earned in order
        // and spread right across the hundred levels.
        item(FRAME_NONE, "No Frame", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FR_STEP1, "Gold Band", CosmeticType.AVATAR_FRAME, Rarity.COMMON, UnlockMethod.FREE),
        item(FR_STEP2, "Crowned", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 5),
        item(FR_STEP3, "Winged", CosmeticType.AVATAR_FRAME, Rarity.RARE, UnlockMethod.LEVEL, requiredLevel = 15),
        item(FR_STEP4, "Royal Wings", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 30),
        item(FR_STEP5, "Grand Wings", CosmeticType.AVATAR_FRAME, Rarity.EPIC, UnlockMethod.LEVEL, requiredLevel = 50),
        item(FR_STEP6, "Laurel Crown", CosmeticType.AVATAR_FRAME, Rarity.LEGENDARY, UnlockMethod.LEVEL, requiredLevel = 75),

        // ---- victory effects
        item(FX_CONFETTI, "Confetti", CosmeticType.VICTORY_EFFECT, Rarity.COMMON, UnlockMethod.FREE),
        item(FX_GOLD_RAIN, "Gold Rain", CosmeticType.VICTORY_EFFECT, Rarity.RARE, UnlockMethod.DAILY),
        item(FX_FIREWORKS, "Fireworks", CosmeticType.VICTORY_EFFECT, Rarity.EPIC, UnlockMethod.DAILY),
        item(FX_ROYAL_CROWN, "Royal Crown", CosmeticType.VICTORY_EFFECT, Rarity.LEGENDARY, UnlockMethod.CHEST)
    )

    private fun item(
        id: String, name: String, type: CosmeticType, rarity: Rarity,
        unlock: UnlockMethod, price: Int = 0, requiredLevel: Int = 0
    ) = CosmeticItem(id, name, type, rarity, unlock, price, requiredLevel)

    fun byId(id: String): CosmeticItem? = ALL.firstOrNull { it.id == id }

    fun byType(type: CosmeticType): List<CosmeticItem> = ALL.filter { it.type == type }

    /** Owned from the first launch, whatever else happens. */
    fun free(): List<String> = ALL.filter { it.unlock == UnlockMethod.FREE }.map { it.id }

    /** What a brand-new player has selected. */
    fun defaultFor(type: CosmeticType): String = when (type) {
        CosmeticType.TOKEN_SKIN -> TOKEN_CROWN
        CosmeticType.DICE_SKIN -> DN_GIFT
        CosmeticType.AVATAR -> AV_KING
        CosmeticType.AVATAR_FRAME -> FR_STEP1
        CosmeticType.VICTORY_EFFECT -> FX_CONFETTI
    }

    /** Everything a player is owed for standing at [level]. */
    fun unlockedAtLevel(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel in 1..level }

    /** Everything handed out exactly on reaching [level]. */
    fun unlockedOnReaching(level: Int): List<CosmeticItem> =
        ALL.filter { it.unlock == UnlockMethod.LEVEL && it.requiredLevel == level }

    /** Every id must be unique, or ownership would be ambiguous. */
    fun isSane(): Boolean {
        val ids = ALL.map { it.id }
        if (ids.size != ids.toSet().size) return false
        if (ALL.any { it.unlock == UnlockMethod.COINS && it.price <= 0 }) return false
        if (ALL.any { it.unlock == UnlockMethod.LEVEL && it.requiredLevel <= 0 }) return false
        if (ALL.any { it.unlock != UnlockMethod.COINS && it.price != 0 }) return false
        // every type must have something a new player already owns
        return CosmeticType.entries.all { type ->
            byType(type).any { it.unlock == UnlockMethod.FREE }
        }
    }
}
