package com.example.ludoroyale

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Toast
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.RuleConfig
import com.example.ludoroyale.engine.SnakeDifficulty
import com.example.ludoroyale.engine.SpecialType
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState

/**
 * Ludo Masha — offline pass-n-play for 2-4 friends on one phone.
 *
 * Turn flow: tap your dice; a six banks and makes you roll again; three sixes
 * burn the turn. Once you stop rolling, your banked values appear in the tray
 * and YOU choose which value to spend and on which piece.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val avatar: ImageView,
        val dice: DiceView,
        val arrow: View,
        val rolls: LinearLayout
    )

    private lateinit var boardView: LudoBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var btnMenu: View
    private lateinit var btnSound: TextView
    private lateinit var winOverlay: View
    private lateinit var winTitle: TextView
    private lateinit var quickStatus: TextView
    private lateinit var confetti: ConfettiView

    private lateinit var cardClassic: View
    private lateinit var cardQuick: View
    private lateinit var cardSnakes: View
    private lateinit var labelClassic: TextView
    private lateinit var labelQuick: TextView
    private lateinit var labelSnakes: TextView
    private lateinit var btnMusic: TextView
    private lateinit var snakeDiffRow: View
    private lateinit var snakeDiffGroup: RadioGroup
    private lateinit var modeHint: TextView
    private lateinit var pills: List<TextView>
    private lateinit var optTeams: CheckBox
    private lateinit var optLucky: CheckBox
    private lateinit var optBots: CheckBox
    private lateinit var botLevelGroup: RadioGroup
    private lateinit var nameFields: List<EditText>

    private var engine: LudoEngine? = null
    private val slots = mutableMapOf<PlayerColor, Slot>()
    private enum class Mode { CLASSIC, QUICK, SNAKES }
    private var mode = Mode.CLASSIC
    private var playerCount = 2
    private var rolling = false
    private var choiceTokenId: String? = null
    private var busy = false

    /** Classic clockwise seating order — team mode keeps exactly this order. */
    private fun seatColors(count: Int): List<PlayerColor> = when (count) {
        2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
        3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
        else -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        btnMenu = findViewById(R.id.btnMenu)
        btnSound = findViewById(R.id.btnSound)
        winOverlay = findViewById(R.id.winOverlay)
        winTitle = findViewById(R.id.winTitle)
        quickStatus = findViewById(R.id.quickStatus)
        confetti = findViewById(R.id.confetti)

        cardClassic = findViewById(R.id.cardClassic)
        cardQuick = findViewById(R.id.cardQuick)
        cardSnakes = findViewById(R.id.cardSnakes)
        labelClassic = findViewById(R.id.labelClassic)
        labelQuick = findViewById(R.id.labelQuick)
        labelSnakes = findViewById(R.id.labelSnakes)
        btnMusic = findViewById(R.id.btnMusic)
        snakeDiffRow = findViewById(R.id.snakeDiffRow)
        snakeDiffGroup = findViewById(R.id.snakeDiffGroup)
        modeHint = findViewById(R.id.modeHint)
        optTeams = findViewById(R.id.optTeams)
        optLucky = findViewById(R.id.optLucky)
        optBots = findViewById(R.id.optBots)
        botLevelGroup = findViewById(R.id.botLevelGroup)
        pills = listOf(findViewById(R.id.pill2), findViewById(R.id.pill3), findViewById(R.id.pill4))
        nameFields = listOf(
            findViewById(R.id.name1), findViewById(R.id.name2),
            findViewById(R.id.name3), findViewById(R.id.name4)
        )

        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.avatarTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft), findViewById(R.id.rollsTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.avatarTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight), findViewById(R.id.rollsTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.avatarBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft), findViewById(R.id.rollsBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.avatarBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight), findViewById(R.id.rollsBottomRight)
        )
        for ((_, slot) in slots) slot.dice.setOnClickListener { handleRoll() }

        cardClassic.setOnClickListener { selectMode(Mode.CLASSIC) }
        cardQuick.setOnClickListener { selectMode(Mode.QUICK) }
        cardSnakes.setOnClickListener { selectMode(Mode.SNAKES) }
        pills.forEachIndexed { i, pill -> pill.setOnClickListener { selectCount(i + 2) } }
        findViewById<View>(R.id.btnStart).setOnClickListener { onStartPressed() }
        btnMenu.setOnClickListener { showMenu() }
        btnSound.setOnClickListener { toggleSound() }
        findViewById<View>(R.id.btnPlayAgain).setOnClickListener { hideWin(); startGame() }
        findViewById<View>(R.id.btnGoHome).setOnClickListener { hideWin(); backToSetup() }
        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        boardView.onChoicePicked = { value -> handleChoicePicked(value) }

        selectMode(Mode.CLASSIC)
        selectCount(2)
    }

    // ---------- setup screen ----------

    private fun selectMode(picked: Mode) {
        mode = picked
        fun style(card: View, label: TextView, on: Boolean) {
            card.setBackgroundResource(if (on) R.drawable.card_selected else R.drawable.card_normal)
            label.setTextColor(if (on) Color.rgb(0x1B, 0x25, 0x51) else Color.WHITE)
        }
        style(cardClassic, labelClassic, picked == Mode.CLASSIC)
        style(cardQuick, labelQuick, picked == Mode.QUICK)
        style(cardSnakes, labelSnakes, picked == Mode.SNAKES)

        modeHint.text = when (picked) {
            Mode.CLASSIC -> "Classic: normal Ludo rules."
            Mode.QUICK -> "Quick: two pieces start out. Cut one opponent to unlock HOME, then get one piece home to win."
            Mode.SNAKES -> "Classic Ludo with special Snakes & Ladders shortcuts on the route!"
        }

        // teams only make sense in the Ludo modes
        snakeDiffRow.visibility = if (picked == Mode.SNAKES) View.VISIBLE else View.GONE
        optTeams.isEnabled = picked != Mode.SNAKES && playerCount == 4
        if (picked == Mode.SNAKES) optTeams.isChecked = false
    }

    private fun selectCount(count: Int) {
        playerCount = count
        pills.forEachIndexed { i, pill ->
            val on = i + 2 == count
            pill.setBackgroundResource(if (on) R.drawable.pill_selected else R.drawable.pill_normal)
            pill.setTextColor(if (on) Color.rgb(0x1B, 0x10, 0x00) else Color.WHITE)
        }
        val seats = seatColors(count)
        val hints = listOf("Red", "Green", "Yellow", "Blue")
        nameFields.forEachIndexed { i, field ->
            field.visibility = if (i < count) View.VISIBLE else View.GONE
            if (i < count) {
                val colorName = hints[PlayerColor.entries.indexOf(seats[i]).coerceIn(0, 3)]
                field.hint = "Player ${i + 1} ($colorName)"
            }
        }
        optTeams.isEnabled = mode != Mode.SNAKES && count == 4
        if (count != 4) optTeams.isChecked = false
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    // ---------- game ----------

    private fun onStartPressed() {
        startGame()
    }

    private fun startGame() {
        val colors = seatColors(playerCount)
        val teamsOn = optTeams.isChecked && playerCount == 4

        val botsOn = optBots.isChecked
        val botKind = when (botLevelGroup.checkedRadioButtonId) {
            R.id.botEasy -> PlayerKind.AI_EASY
            R.id.botHard -> PlayerKind.AI_HARD
            else -> PlayerKind.AI_MEDIUM
        }

        val players = colors.mapIndexed { i, color ->
            val typed = nameFields[i].text.toString().trim()
            val name = if (typed.isNotEmpty()) typed
                       else if (botsOn && i > 0) "Computer $i"
                       else "Player ${i + 1}"
            // partners sit opposite: Red+Yellow vs Green+Blue
            val team = if (!teamsOn) 0
                       else if (color == PlayerColor.RED || color == PlayerColor.YELLOW) 1 else 2
            val kind = if (botsOn && i > 0) botKind else PlayerKind.HUMAN
            Player.create("p${i + 1}", name, color, kind, team)
        }.toMutableList()

        val rules = RuleConfig(
            quickMode = mode == Mode.QUICK,
            snakeMode = mode == Mode.SNAKES,
            snakeDifficulty = when (snakeDiffGroup.checkedRadioButtonId) {
                R.id.snakeEasy -> SnakeDifficulty.EASY
                R.id.snakeHard -> SnakeDifficulty.HARD
                else -> SnakeDifficulty.MEDIUM
            },
            teamMode = teamsOn,
            luckyDice = optLucky.isChecked
        )

        if (rules.quickMode) {
            // Spec: exactly ONE token starts on the board, no six needed for it.
            // The other three wait in base and come out on a six as normal.
            for (p in players) {
                p.tokens[0].state = TokenState.ACTIVE
                p.tokens[0].steps = 1
            }
        }

        val newEngine = LudoEngine(GameState(gameId = "pass-n-play", players = players), rules)
        engine = newEngine
        boardView.snakeDifficulty = if (rules.snakeMode) rules.snakeDifficulty else null
        boardView.snapToState(newEngine.state)
        rolling = false
        busy = false

        for ((color, slot) in slots) {
            val player = players.firstOrNull { it.color == color }
            if (player == null) {
                slot.root.visibility = View.INVISIBLE
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = if (teamsOn) {
                    "${player.displayName}  •  Team ${if (player.team == 1) "A" else "B"}"
                } else player.displayName
                slot.avatar.setImageResource(
                    if (player.kind != PlayerKind.HUMAN) R.drawable.ic_avatar_bot
                    else when (players.indexOf(player)) {
                        0 -> R.drawable.ic_avatar_p1
                        1 -> R.drawable.ic_avatar_p2
                        2 -> R.drawable.ic_avatar_p3
                        else -> R.drawable.ic_avatar_p4
                    }
                )
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.accent = uiColor(color)
                slot.dice.value = 1
            }
        }

        quickStatus.visibility = if (rules.quickMode) View.VISIBLE else View.GONE
        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        btnMenu.visibility = View.VISIBLE
        btnSound.visibility = View.VISIBLE
        btnMusic.visibility = View.VISIBLE
        hideWin()
        SoundFx.gameStart()
        SoundFx.startMusic()
        render()
    }

    private fun toggleSound() {
        SoundFx.enabled = !SoundFx.enabled
        btnSound.text = getString(if (SoundFx.enabled) R.string.sound_on else R.string.sound_off)
        btnSound.alpha = if (SoundFx.enabled) 1f else 0.5f
    }

    override fun onResume() {
        super.onResume()
        SoundFx.resumeMusic()
    }

    override fun onPause() {
        super.onPause()
        SoundFx.pauseMusic()
    }

    private var musicOn = true

    private fun toggleMusic() {
        musicOn = !musicOn
        if (musicOn) SoundFx.startMusic() else SoundFx.stopMusic()
        btnMusic.text = getString(if (musicOn) R.string.music_on else R.string.music_off)
        btnMusic.alpha = if (musicOn) 1f else 0.5f
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_title)
            .setItems(
                arrayOf(
                    getString(R.string.menu_restart),
                    getString(R.string.menu_new),
                    getString(R.string.menu_close),
                    getString(R.string.menu_cancel)
                )
            ) { dialog, which ->
                when (which) {
                    0 -> startGame()
                    1 -> backToSetup()
                    2 -> finish()
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun backToSetup() {
        engine = null
        rolling = false
        busy = false
        for ((_, slot) in slots) stopBlink(slot.arrow)
        gamePanel.visibility = View.GONE
        btnMenu.visibility = View.GONE
        btnSound.visibility = View.GONE
        btnMusic.visibility = View.GONE
        hideWin()
        setupPanel.visibility = View.VISIBLE
    }

    private fun handleRoll() {
        val e = engine ?: return
        if (rolling || busy || e.state.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[e.state.currentPlayer.color] ?: return

        rolling = true
        clearChoice()
        val outcome = e.rollDice()
        SoundFx.diceRoll()          // starts WITH the roll, runs under the animation
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 14, finalValue = outcome.value) {
            rolling = false
            when {
                outcome.turnLostToThreeSixes -> {
                    SoundFx.turnLost()
                                toast("Three sixes — turn lost, all rolls wasted!")
                    render()
                }
                outcome.mustRollAgain -> {
                    // six banked; the same player must roll again
                    render()
                }
                else -> onRollingFinished()
            }
        }
    }

    /** Shake + spin so rolling actually feels like rolling. */
    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f).scaleX(1.22f).scaleY(1.22f)
            .setDuration(330)
            .withEndAction { dice.animate().scaleX(1f).scaleY(1f).setDuration(170).start() }
            .start()
    }

    /**
     * Flickers random faces, then settles on the value the engine already
     * decided. The animation only reveals the result — it never changes it.
     */
    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int, onDone: () -> Unit) {
        if (remaining <= 0) {
            dice.value = finalValue
            onDone()
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue, onDone) }, 50)
    }

    private fun onRollingFinished() {
        val e = engine ?: return
        val moves = e.legalMoves()
        if (moves.isEmpty()) {
            e.passTurn()
            render()
            return
        }
        render()
        maybeAutoPlay()
    }

    /**
     * Plays by itself only when there is genuinely nothing to decide: one
     * piece, one value. The moment there is a real choice (a six banked next
     * to another number, or several pieces out) it hands control back.
     */
    private fun maybeAutoPlay() {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return
        if (isBotTurn()) { maybeRunBot(); return }   // the computer decides for itself
        val moves = e.legalMoves()
        val distinctValues = e.state.pendingRolls.distinct()
        val distinctTokens = moves.map { it.token.id }.distinct()
        if (moves.size == 1 || (distinctTokens.size == 1 && distinctValues.size == 1)) {
            val only = moves.first()
            boardView.postDelayed({ playMove(only) }, 260)
        }
    }

    private fun handleTokenTap(token: Token) {
        val e = engine ?: return
        if (busy || rolling || e.state.phase != TurnPhase.AWAITING_MOVE) return

        // which banked values can move THIS piece?
        val options = e.state.pendingRolls.distinct()
            .mapNotNull { value -> e.legalMovesFor(value).firstOrNull { it.token.id == token.id } }

        when {
            options.isEmpty() -> return
            options.size == 1 -> {
                clearChoice()
                playMove(options.first())
            }
            else -> {
                // little number chips float over the piece itself
                choiceTokenId = token.id
                boardView.showChoices(token.id, options.map { it.usedRoll })
            }
        }
    }

    /** Player tapped one of the number chips over a piece. */
    private fun handleChoicePicked(value: Int) {
        val e = engine ?: return
        val tokenId = choiceTokenId ?: return
        val move = e.legalMovesFor(value).firstOrNull { it.token.id == tokenId } ?: return
        clearChoice()
        playMove(move)
    }

    private fun clearChoice() {
        choiceTokenId = null
        boardView.clearChoices()
    }

    private fun playMove(move: Move) {
        val e = engine ?: return
        if (busy) return
        clearChoice()
        busy = true
        boardView.tappableTokenIds = emptySet()

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            // remember where the victims were standing — applyMove resets them
            val victimsBefore = move.capturesTokenIds.mapNotNull { id ->
                e.state.players.flatMap { p -> p.tokens.map { p to it } }
                    .firstOrNull { it.second.id == id }
                    ?.let { (owner, tok) -> Triple(tok.id, tok.color, tok.steps to owner.tokens.indexOf(tok)) }
            }

            val result = e.applyMove(move)

            val settle = {
                boardView.snapToState(e.state)
                when {
                    result.gameWon -> SoundFx.win()
                    else -> SoundFx.tokenMove()
                }
                busy = false
                render()
                maybeAutoPlay()
            }

            val afterCaptures = {
                if (victimsBefore.isNotEmpty()) {
                    SoundFx.capture()
                    var pending = victimsBefore.size
                    for ((id, color, info) in victimsBefore) {
                        val (steps, slot) = info
                        boardView.flyHome(id, color, steps, slot) {
                            pending--
                            if (pending == 0) settle()
                        }
                    }
                } else settle()
            }

            if (result.unlockedHome) {
                SoundFx.magic()
                showUnlockBanner()
            }

            // LUDO SNAKE MODE: land on trigger -> pause -> glow -> ride -> continue.
            // The engine has already decided everything; this only plays it out.
            val sp = result.special
            val fromSteps = result.specialFromSteps
            val toSteps = result.specialToSteps
            if (sp != null && fromSteps != null && toSteps != null) {
                val isLadder = sp.type == SpecialType.LADDER
                boardView.setSpecialGlow(sp.entryCell)
                boardView.postDelayed({
                    if (isLadder) SoundFx.ladderClimb() else SoundFx.snakeSlide()
                    boardView.rideSpecial(move.token.id, move.token.color, fromSteps, toSteps, isLadder) {
                        boardView.setSpecialGlow(null)
                        afterCaptures()
                    }
                }, SPECIAL_PAUSE_MS)
            } else {
                afterCaptures()
            }
        }
    }

    /** "HOME UNLOCKED!" — brief, doesn't hold the game up (spec: 1-1.5s). */
    private fun showUnlockBanner() {
        quickStatus.text = getString(R.string.quick_unlock_toast)
        quickStatus.scaleX = 0.8f
        quickStatus.scaleY = 0.8f
        quickStatus.animate().scaleX(1.12f).scaleY(1.12f).setDuration(220)
            .withEndAction { quickStatus.animate().scaleX(1f).scaleY(1f).setDuration(200).start() }
            .start()
        quickStatus.postDelayed({ refreshQuickStatus() }, 1300)
    }

    /** Lock/unlock line for the player whose turn it is. */
    private fun refreshQuickStatus() {
        val e = engine ?: return
        if (quickStatus.visibility != View.VISIBLE) return
        val p = if (e.state.phase == TurnPhase.GAME_OVER) e.state.players.firstOrNull()
                else e.state.currentPlayer
        quickStatus.text = getString(
            if (p?.hasCapturedOpponent == true) R.string.quick_unlocked else R.string.quick_locked
        )
    }

    // ---------- rendering ----------


    // ---------- computer players ----------

    private fun isBotTurn(): Boolean {
        val e = engine ?: return false
        if (e.state.phase == TurnPhase.GAME_OVER) return false
        return e.state.currentPlayer.kind != PlayerKind.HUMAN
    }

    /** Let the computer take its turn, with a short pause so it reads naturally. */
    private fun maybeRunBot() {
        if (!isBotTurn() || busy || rolling) return
        val e = engine ?: return

        when (e.state.phase) {
            TurnPhase.AWAITING_ROLL -> boardView.postDelayed({
                if (isBotTurn() && !busy && !rolling) handleRoll()
            }, 650)

            TurnPhase.AWAITING_MOVE -> boardView.postDelayed({
                if (!isBotTurn() || busy || rolling) return@postDelayed
                val moves = e.legalMoves()
                if (moves.isEmpty()) {
                    e.passTurn()
                    render()
                } else {
                    playMove(
                        LudoAI.chooseMove(
                            e.state.currentPlayer.kind, moves, e.state,
                            needsKill = e.rules.quickMode && !e.state.currentPlayer.hasCapturedOpponent
                        )
                    )
                }
            }, 600)

            TurnPhase.GAME_OVER -> Unit
        }
    }

    private fun render() {
        val e = engine ?: return
        val s = e.state
        val gameOver = s.phase == TurnPhase.GAME_OVER
        val activeColor = if (gameOver) null else s.currentPlayer.color

        // every piece any banked value can move is tappable (and pulses)
        boardView.tappableTokenIds =
            if (!busy && !rolling && s.phase == TurnPhase.AWAITING_MOVE)
                e.legalMoves().map { it.token.id }.toSet()
            else emptySet()

        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == activeColor
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.5f
            slot.dice.isClickable =
                isActive && !busy && !rolling && s.phase == TurnPhase.AWAITING_ROLL

            if (isActive) {
                slot.arrow.visibility = View.VISIBLE
                startBlink(slot.arrow)
            } else {
                stopBlink(slot.arrow)
                slot.arrow.visibility = View.INVISIBLE
            }

            renderRollsFor(color, slot, isActive)
        }

        val last = s.lastDiceRoll
        if (last != null && activeColor != null) slots[activeColor]?.dice?.value = last

        refreshQuickStatus()
        if (gameOver) announceWinner(s) else maybeRunBot()
    }

    /** Banked values shown as small dice right under that player's own avatar. */
    private fun renderRollsFor(color: PlayerColor, slot: Slot, isActive: Boolean) {
        slot.rolls.removeAllViews()
        val e = engine ?: return
        if (!isActive) return
        val rolls = e.state.pendingRolls
        if (rolls.isEmpty()) return

        val size = (30 * resources.displayMetrics.density).toInt()
        val gap = (3 * resources.displayMetrics.density).toInt()
        rolls.forEach { value ->
            val chip = DiceView(this)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginStart = gap
            lp.marginEnd = gap
            chip.layoutParams = lp
            chip.value = value
            chip.accent = uiColor(color)
            chip.isClickable = false
            slot.rolls.addView(chip)
        }
    }

    private fun startBlink(view: View) {
        if (view.tag == BLINKING) return
        view.tag = BLINKING
        blinkStep(view)
    }

    private fun blinkStep(view: View) {
        if (view.tag != BLINKING) return
        view.animate().alpha(0.25f).scaleY(0.82f).setDuration(420)
            .withEndAction {
                if (view.tag != BLINKING) return@withEndAction
                view.animate().alpha(1f).scaleY(1f).setDuration(420)
                    .withEndAction { blinkStep(view) }.start()
            }.start()
    }

    private fun stopBlink(view: View) {
        view.tag = null
        view.animate().cancel()
        view.alpha = 1f
        view.scaleY = 1f
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun announceWinner(s: GameState) {
        if (winOverlay.visibility == View.VISIBLE) return
        val winner = s.players.firstOrNull { it.id == s.rankings.firstOrNull() } ?: return
        winTitle.text = if (winner.team != 0) {
            "Team ${if (winner.team == 1) "A" else "B"} wins!"
        } else {
            "${winner.displayName} wins!"
        }
        if (quickStatus.visibility == View.VISIBLE) {
            winTitle.text = "${winTitle.text}\n${getString(R.string.quick_victory)}"
        }
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.animate().alpha(1f).setDuration(320).start()
        confetti.start()
    }

    private fun hideWin() {
        confetti.stop()
        winOverlay.visibility = View.GONE
    }

    private companion object {
        /** Beat before a snake or ladder fires, so the landing reads first. */
        const val SPECIAL_PAUSE_MS = 220L
        const val BLINKING = "blinking"
    }
}
