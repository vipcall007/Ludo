package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import kotlin.math.min

/**
 * Draws the classic 15x15 Ludo cross board + all tokens, animates token
 * movement between positions, and reports taps on movable tokens back to
 * the caller. Original design — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    /** Token IDs the current player may legally tap right now. */
    var tappableTokenIds: Set<String> = emptySet()
        set(value) { field = value; invalidate() }

    var onTokenTapped: ((Token) -> Unit)? = null

    // Current on-screen center of each token, in cell units.
    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Immediately syncs the board to [newState] — no animation (used for game start / after a hop finishes). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /**
     * Moves one token cell-by-cell (box by box) from [fromSteps] to [toSteps],
     * matching real Ludo — the token visibly hops across each square instead
     * of sliding straight through. Calls [onComplete] once it lands.
     */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val hops: List<Int> = if (fromSteps <= 0) listOf(toSteps) else (fromSteps + 1..toSteps).toList()
        hopSequence(tokenId, color, hops, 0, onComplete)
    }

    private fun hopSequence(tokenId: String, color: PlayerColor, hops: List<Int>, index: Int, onComplete: () -> Unit) {
        if (index >= hops.size) { onComplete(); return }
        displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, hops[index])
        invalidate()
        postDelayed({ hopSequence(tokenId, color, hops, index + 1, onComplete) }, 140)
    }

    private var cell = 0f
    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.DKGRAY
        strokeWidth = 2f
    }
    private val tokenBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.BLACK
        strokeWidth = 4f
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.YELLOW
        strokeWidth = 7f
    }

    private fun androidColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xD3, 0x2F, 0x2F)
        PlayerColor.GREEN -> Color.rgb(0x38, 0x8E, 0x3C)
        PlayerColor.YELLOW -> Color.rgb(0xFB, 0xC0, 0x2D)
        PlayerColor.BLUE -> Color.rgb(0x19, 0x76, 0xD2)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cell = min(w, h) / BoardGeometry.GRID_SIZE.toFloat()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBaseGrid(canvas)
        drawHomeSquares(canvas)
        drawRingCells(canvas)
        drawStretches(canvas)
        drawCenter(canvas)
        drawTokens(canvas)
    }

    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(c0 * cell, r0 * cell, c1 * cell, r1 * cell)

    private fun drawBaseGrid(canvas: Canvas) {
        boardPaint.style = Paint.Style.FILL
        boardPaint.color = Color.WHITE
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), boardPaint)
    }

    private fun drawHomeSquares(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0]; val c0 = box[1]; val r1 = box[2]; val c1 = box[3]
            boardPaint.color = androidColor(color)
            canvas.drawRect(rect(r0.toFloat(), c0.toFloat(), (r1 + 1).toFloat(), (c1 + 1).toFloat()), boardPaint)

            // inner white panel with the 4 base slot circles
            val pad = 0.9f
            boardPaint.color = Color.WHITE
            canvas.drawRect(rect(r0 + pad, c0 + pad, (r1 + 1) - pad, (c1 + 1) - pad), boardPaint)

            boardPaint.color = androidColor(color)
            for ((sr, sc) in BoardGeometry.BASE_SLOTS.getValue(color)) {
                canvas.drawCircle(sc * cell, sr * cell, cell * 0.32f, boardPaint)
            }
        }
    }

    private fun drawRingCells(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val (r, c) = rc
            boardPaint.color = Color.rgb(0xF5, 0xF5, 0xF0)
            // tint each color's own starting cell
            for (color in PlayerColor.entries) {
                if (color.startOffset == idx) boardPaint.color = androidColor(color)
            }
            canvas.drawRect(rect(r.toFloat(), c.toFloat(), (r + 1).toFloat(), (c + 1).toFloat()), boardPaint)
            canvas.drawRect(rect(r.toFloat(), c.toFloat(), (r + 1).toFloat(), (c + 1).toFloat()), borderPaint)

            if (LudoBoard.isSafeCell(idx)) {
                drawStar(canvas, (c + 0.5f) * cell, (r + 0.5f) * cell, cell * 0.28f, Color.rgb(0xFF, 0xC1, 0x07))
            }
        }
    }

    /** A simple 5-point star, used to mark safe cells — like a real board's star squares. */
    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val r = if (i % 2 == 0) outerR else innerR
            val x = cx + (r * Math.cos(angle)).toFloat()
            val y = cy + (r * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        boardPaint.color = color
        canvas.drawPath(path, boardPaint)
    }

    private fun drawStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            boardPaint.color = androidColor(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), (r + 1).toFloat(), (c + 1).toFloat()), boardPaint)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), (r + 1).toFloat(), (c + 1).toFloat()), borderPaint)
            }
        }
    }

    private fun drawCenter(canvas: Canvas) {
        val cx = 7.5f * cell
        val cy = 7.5f * cell
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(p1c * cell, p1r * cell)
            path.lineTo(p2c * cell, p2r * cell)
            path.lineTo(cx, cy)
            path.close()
            boardPaint.color = androidColor(color)
            canvas.drawPath(path, boardPaint)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return
        for (player in s.players) {
            for (token in player.tokens) {
                val (r, c) = displayedCenters[token.id] ?: continue
                val cx = c * cell
                val cy = r * cell
                val radius = cell * 0.34f
                boardPaint.color = androidColor(token.color)
                canvas.drawCircle(cx, cy, radius, boardPaint)
                canvas.drawCircle(cx, cy, radius, tokenBorder)
                if (token.id in tappableTokenIds) {
                    canvas.drawCircle(cx, cy, radius + 6f, highlightPaint)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell == 0f) return true

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for (player in s.players) {
            for (token in player.tokens) {
                if (token.id !in tappableTokenIds) continue
                val (r, c) = displayedCenters[token.id] ?: continue
                val dx = event.x - c * cell
                val dy = event.y - r * cell
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }
        val touchRadius = cell * 0.7f
        if (best != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(best)
        }
        return true
    }
}
