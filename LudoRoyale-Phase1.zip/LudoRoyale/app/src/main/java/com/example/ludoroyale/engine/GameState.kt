package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player

enum class TurnPhase { AWAITING_ROLL, AWAITING_MOVE, GAME_OVER }

/**
 * The full authoritative state of one match. This is the object the
 * server is the single source of truth for online games (spec section 18) —
 * clients only ever *request* moves, never mutate this directly.
 */
data class GameState(
    val gameId: String,
    val players: MutableList<Player>,
    var currentPlayerIndex: Int = 0,
    var lastDiceRoll: Int? = null,
    var consecutiveSixes: Int = 0,
    var phase: TurnPhase = TurnPhase.AWAITING_ROLL,
    var rankings: MutableList<String> = mutableListOf() // player IDs, finish order
) {
    val currentPlayer: Player get() = players[currentPlayerIndex]

    fun findTokenOwner(tokenId: String): Player? =
        players.firstOrNull { p -> p.tokens.any { it.id == tokenId } }
}
