package com.example.ludoroyale.engine

import java.security.SecureRandom

/**
 * Transparent, unbiased dice source (spec section 6).
 * SecureRandom avoids any predictable seed/pattern. Swap the RNG for a
 * unit-test seed via [DiceRoller(random = Random(seed))]-style constructor
 * overload if deterministic tests are needed — never manipulate results
 * based on player identity or payment status.
 */
class DiceRoller(private val random: SecureRandom = SecureRandom()) {
    fun roll(): Int = 1 + random.nextInt(6)
}
