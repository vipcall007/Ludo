package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Token

/** One legal choice offered to whoever's turn it is. */
data class Move(
    val token: Token,
    val fromSteps: Int,
    val toSteps: Int,
    val capturesTokenIds: List<String> = emptyList(),
    val leavesBase: Boolean = false,
    val entersHomeStretch: Boolean = false,
    val finishesToken: Boolean = false
)

/** Outcome returned to callers (UI / network layer / AI) after applying a move. */
data class MoveResult(
    val move: Move,
    val capturedTokens: List<Token>,
    val extraTurn: Boolean,
    val gameWon: Boolean,
    val winnerPlayerId: String?
)
