package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Draws a physical-looking dice face: rounded square with a soft drop
 * shadow and real pips (dots), 1-6. [dimmed] greys it out for players
 * whose turn it isn't. All drawn in code — no copied art.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) { field = v.coerceIn(1, 6); invalidate() }

    var dimmed: Boolean = false
        set(v) { field = v; invalidate() }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Pip layout as fractional (x, y) positions within the face, per value.
    private val layouts: Map<Int, List<Pair<Float, Float>>> = mapOf(
        1 to listOf(0.5f to 0.5f),
        2 to listOf(0.3f to 0.3f, 0.7f to 0.7f),
        3 to listOf(0.28f to 0.28f, 0.5f to 0.5f, 0.72f to 0.72f),
        4 to listOf(0.3f to 0.3f, 0.7f to 0.3f, 0.3f to 0.7f, 0.7f to 0.7f),
        5 to listOf(0.28f to 0.28f, 0.72f to 0.28f, 0.5f to 0.5f, 0.28f to 0.72f, 0.72f to 0.72f),
        6 to listOf(
            0.3f to 0.24f, 0.7f to 0.24f,
            0.3f to 0.5f, 0.7f to 0.5f,
            0.3f to 0.76f, 0.7f to 0.76f
        )
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val inset = w * 0.07f
        val corner = w * 0.2f

        facePaint.color = if (dimmed) Color.rgb(0xB0, 0xBE, 0xC5) else Color.WHITE
        edgePaint.color = if (dimmed) Color.rgb(0x78, 0x90, 0x9C) else Color.rgb(0xCF, 0xD8, 0xDC)
        pipPaint.color = if (dimmed) Color.rgb(0x55, 0x60, 0x6B) else Color.rgb(0x26, 0x32, 0x38)

        // soft drop shadow
        canvas.drawRoundRect(
            RectF(inset + w * 0.03f, inset + h * 0.05f, w - inset + w * 0.03f, h - inset + h * 0.05f),
            corner, corner, shadowPaint
        )

        val face = RectF(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(face, corner, corner, facePaint)
        canvas.drawRoundRect(face, corner, corner, edgePaint)

        val pipRadius = w * 0.075f
        val faceW = face.width()
        val faceH = face.height()
        for ((fx, fy) in layouts.getValue(value)) {
            canvas.drawCircle(face.left + fx * faceW, face.top + fy * faceH, pipRadius, pipPaint)
        }
    }
}
