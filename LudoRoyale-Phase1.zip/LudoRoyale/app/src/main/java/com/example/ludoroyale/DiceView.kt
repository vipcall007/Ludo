package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Draws a physical-looking dice face (rounded white square + black pips)
 * for the given value 1-6 — matches how a real die reads, instead of a
 * plain digit. Original drawing code, no copied art.
 */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var value: Int = 1
        set(v) { field = v.coerceIn(1, 6); invalidate() }

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.rgb(0x37, 0x47, 0x4F)
    }
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x21, 0x21, 0x21) }

    // Pip layout as fractional (x, y) positions within the face, per value.
    private val layouts: Map<Int, List<Pair<Float, Float>>> = mapOf(
        1 to listOf(0.5f to 0.5f),
        2 to listOf(0.28f to 0.28f, 0.72f to 0.72f),
        3 to listOf(0.28f to 0.28f, 0.5f to 0.5f, 0.72f to 0.72f),
        4 to listOf(0.28f to 0.28f, 0.72f to 0.28f, 0.28f to 0.72f, 0.72f to 0.72f),
        5 to listOf(0.28f to 0.28f, 0.72f to 0.28f, 0.5f to 0.5f, 0.28f to 0.72f, 0.72f to 0.72f),
        6 to listOf(
            0.28f to 0.22f, 0.72f to 0.22f,
            0.28f to 0.5f, 0.72f to 0.5f,
            0.28f to 0.78f, 0.72f to 0.78f
        )
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val corner = w * 0.18f

        val rect = RectF(4f, 4f, w - 4f, h - 4f)
        canvas.drawRoundRect(rect, corner, corner, facePaint)
        canvas.drawRoundRect(rect, corner, corner, borderPaint)

        val pipRadius = w * 0.08f
        for ((fx, fy) in layouts.getValue(value)) {
            canvas.drawCircle(fx * w, fy * h, pipRadius, pipPaint)
        }
    }
}
