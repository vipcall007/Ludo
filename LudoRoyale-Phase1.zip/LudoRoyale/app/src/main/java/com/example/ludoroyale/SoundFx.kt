package com.example.ludoroyale

import android.media.AudioManager
import android.media.ToneGenerator

/**
 * Short original sound feedback using Android's built-in ToneGenerator —
 * no bundled or copied audio files. Swappable for real sound assets later
 * without touching call sites.
 */
object SoundFx {
    private val generator by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 75) }

    fun diceRoll() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP, 60) }
    fun step() = safe { generator.startTone(ToneGenerator.TONE_DTMF_1, 35) }
    fun tokenMove() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP2, 60) }
    fun capture() = safe { generator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 150) }
    fun win() = safe { generator.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 400) }

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (_: Exception) { /* never crash the game over a beep */ }
    }
}
