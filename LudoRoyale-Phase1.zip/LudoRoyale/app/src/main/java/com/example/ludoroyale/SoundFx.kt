package com.example.ludoroyale

import android.media.AudioManager
import android.media.ToneGenerator

/**
 * Simple, original sound feedback using Android's built-in ToneGenerator
 * (electronic beeps) — no copied/licensed audio files, nothing to bundle.
 * Good enough for "the game responds when something happens"; can be
 * swapped for real sound-effect files later without touching call sites.
 */
object SoundFx {
    private val generator by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }

    fun diceRoll() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP, 70) }
    fun tokenMove() = safe { generator.startTone(ToneGenerator.TONE_PROP_BEEP2, 60) }
    fun capture() = safe { generator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 150) }
    fun win() = safe { generator.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 400) }

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (_: Exception) { /* never crash the game over a beep */ }
    }
}
