package com.example.ludoroyale.engine

/**
 * Toggleable rules (spec section 5). Defaults match the most common
 * classic Ludo ruleset. The engine is fully driven by this config so
 * offline / AI / online modes all share identical logic.
 */
data class RuleConfig(
    val extraTurnOnSix: Boolean = true,
    val threeSixCancelsTurn: Boolean = true,   // 3 consecutive sixes -> forfeit move
    val captureGrantsExtraTurn: Boolean = true,
    val exactRollToFinish: Boolean = true,
    val safeCellsBlockCapture: Boolean = true,
    val allowStackingOwnTokens: Boolean = true, // own tokens can share a cell
    val sixRequiredToLeaveBase: Boolean = true,
    val undoAllowed: Boolean = false
)
