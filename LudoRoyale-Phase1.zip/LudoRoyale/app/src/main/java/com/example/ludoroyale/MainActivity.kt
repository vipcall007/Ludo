package com.example.ludoroyale

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token

/**
 * PHASE 1b — a real, visible, tappable Ludo board (see LudoBoardView /
 * BoardGeometry), driven by the same rule engine as before. Offline,
 * human vs AI. Original board design — nothing copied from any
 * reference app's artwork or code.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var engine: LudoEngine
    private lateinit var statusText: TextView
    private lateinit var diceText: TextView
    private lateinit var boardView: LudoBoardView

    private var pendingMoves: List<Move> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        diceText = findViewById(R.id.diceText)
        boardView = findViewById(R.id.boardView)
        val rollButton = findViewById<Button>(R.id.rollButton)

        val human = Player.create("p1", "You", PlayerColor.RED, PlayerKind.HUMAN)
        val ai = Player.create("p2", "AI", PlayerColor.YELLOW, PlayerKind.AI_MEDIUM)
        engine = LudoEngine(GameState(gameId = "local-vs-ai", players = mutableListOf(human, ai)))
        boardView.state = engine.state

        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        rollButton.setOnClickListener { handleRoll() }

        render()
    }

    private fun handleRoll() {
        val s = engine.state
        if (s.phase != TurnPhase.AWAITING_ROLL || s.currentPlayer.kind != PlayerKind.HUMAN) return

        val roll = engine.rollDice()
        diceText.text = roll.toString()
        pendingMoves = engine.legalMoves(roll)

        if (pendingMoves.isEmpty()) {
            engine.passTurn()
            pendingMoves = emptyList()
            render()
            runAiTurnsIfNeeded()
        } else {
            render() // highlights tappable tokens; waits for a tap
        }
    }

    private fun handleTokenTap(token: Token) {
        val move = pendingMoves.firstOrNull { it.token.id == token.id } ?: return
        engine.applyMove(move)
        pendingMoves = emptyList()
        render()
        runAiTurnsIfNeeded()
    }

    private fun runAiTurnsIfNeeded() {
        val s = engine.state
        while (s.phase != TurnPhase.GAME_OVER && s.currentPlayer.kind != PlayerKind.HUMAN) {
            val roll = engine.rollDice()
            val moves = engine.legalMoves(roll)
            if (moves.isEmpty()) {
                engine.passTurn()
            } else {
                engine.applyMove(LudoAI.chooseMove(s.currentPlayer.kind, moves))
            }
        }
        render()
    }

    private fun render() {
        val s = engine.state
        boardView.state = s
        boardView.tappableTokenIds = pendingMoves.map { it.token.id }.toSet()
        diceText.text = (s.lastDiceRoll ?: "-").toString()

        statusText.text = when {
            s.phase == TurnPhase.GAME_OVER ->
                "Game over! Winner: ${s.rankings.firstOrNull()}"
            s.currentPlayer.kind == PlayerKind.HUMAN && pendingMoves.isNotEmpty() ->
                "Your turn — tap a highlighted token"
            s.currentPlayer.kind == PlayerKind.HUMAN ->
                "Your turn — roll the dice"
            else ->
                "${s.currentPlayer.displayName}'s turn..."
        }
    }
}
