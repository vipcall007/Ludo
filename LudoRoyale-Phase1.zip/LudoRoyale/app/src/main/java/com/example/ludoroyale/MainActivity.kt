package com.example.ludoroyale

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token

/**
 * Local "pass n play" Ludo: 2-4 players on ONE phone, each sitting at
 * their own corner with their own dice (tap your dice to roll), tokens
 * hopping box-by-box. Fully offline.
 */
class MainActivity : AppCompatActivity() {

    private class Slot(
        val root: View,
        val name: TextView,
        val ring: FrameLayout,
        val dice: DiceView,
        val arrow: View
    )

    private lateinit var engine: LudoEngine
    private lateinit var boardView: LudoBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var hintText: TextView

    private val slots = mutableMapOf<PlayerColor, Slot>()
    private var pendingMoves: List<Move> = emptyList()
    private var rolling = false

    private val playerNames = listOf("Player 1", "Player 2", "Player 3", "Player 4")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        boardView = findViewById(R.id.boardView)
        hintText = findViewById(R.id.hintText)

        // Each color sits at its own corner of the board, like a real table.
        slots[PlayerColor.GREEN] = Slot(
            findViewById(R.id.panelTopLeft), findViewById(R.id.nameTopLeft),
            findViewById(R.id.ringTopLeft), findViewById(R.id.diceTopLeft),
            findViewById(R.id.arrowTopLeft)
        )
        slots[PlayerColor.YELLOW] = Slot(
            findViewById(R.id.panelTopRight), findViewById(R.id.nameTopRight),
            findViewById(R.id.ringTopRight), findViewById(R.id.diceTopRight),
            findViewById(R.id.arrowTopRight)
        )
        slots[PlayerColor.RED] = Slot(
            findViewById(R.id.panelBottomLeft), findViewById(R.id.nameBottomLeft),
            findViewById(R.id.ringBottomLeft), findViewById(R.id.diceBottomLeft),
            findViewById(R.id.arrowBottomLeft)
        )
        slots[PlayerColor.BLUE] = Slot(
            findViewById(R.id.panelBottomRight), findViewById(R.id.nameBottomRight),
            findViewById(R.id.ringBottomRight), findViewById(R.id.diceBottomRight),
            findViewById(R.id.arrowBottomRight)
        )

        for ((_, slot) in slots) {
            slot.dice.setOnClickListener { handleRoll() }
        }

        findViewById<Button>(R.id.btn2Players).setOnClickListener { startGame(2) }
        findViewById<Button>(R.id.btn3Players).setOnClickListener { startGame(3) }
        findViewById<Button>(R.id.btn4Players).setOnClickListener { startGame(4) }

        boardView.onTokenTapped = { token -> handleTokenTap(token) }
    }

    private fun uiColor(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    private fun startGame(playerCount: Int) {
        val colors = PlayerColor.forPlayerCount(playerCount)
        val players = colors.mapIndexed { i, color ->
            Player.create("p${i + 1}", playerNames[i], color, PlayerKind.HUMAN)
        }.toMutableList()

        engine = LudoEngine(GameState(gameId = "pass-n-play", players = players))
        boardView.snapToState(engine.state)
        pendingMoves = emptyList()
        rolling = false

        // show only the corners that are in play, tinted to that player's color
        for ((color, slot) in slots) {
            val player = players.firstOrNull { it.color == color }
            if (player == null) {
                slot.root.visibility = View.INVISIBLE
            } else {
                slot.root.visibility = View.VISIBLE
                slot.name.text = player.displayName
                slot.ring.backgroundTintList = ColorStateList.valueOf(uiColor(color))
                slot.dice.value = 1
            }
        }

        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        render()
    }

    private fun handleRoll() {
        if (!::engine.isInitialized) return
        val s = engine.state
        if (rolling || s.phase != TurnPhase.AWAITING_ROLL) return
        val slot = slots[s.currentPlayer.color] ?: return

        rolling = true
        val finalRoll = engine.rollDice() // real result decided now; the shake is only a reveal
        shakeDice(slot.dice)
        animateDiceReveal(slot.dice, remaining = 10, finalValue = finalRoll)
    }

    /** Shake + spin the dice so rolling actually feels like rolling. */
    private fun shakeDice(dice: DiceView) {
        dice.animate().cancel()
        dice.rotation = 0f
        dice.animate()
            .rotationBy(360f)
            .scaleX(1.18f).scaleY(1.18f)
            .setDuration(320)
            .withEndAction {
                dice.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            .start()
    }

    private fun animateDiceReveal(dice: DiceView, remaining: Int, finalValue: Int) {
        if (remaining <= 0) {
            dice.value = finalValue
            SoundFx.diceRoll()
            rolling = false
            onDiceRevealed(finalValue)
            return
        }
        dice.value = (1..6).random()
        dice.postDelayed({ animateDiceReveal(dice, remaining - 1, finalValue) }, 50)
    }

    private fun onDiceRevealed(roll: Int) {
        pendingMoves = engine.legalMoves(roll)
        if (pendingMoves.isEmpty()) {
            engine.passTurn()
            pendingMoves = emptyList()
        }
        render()
    }

    private fun handleTokenTap(token: Token) {
        val move = pendingMoves.firstOrNull { it.token.id == token.id } ?: return
        pendingMoves = emptyList()
        boardView.tappableTokenIds = emptySet() // lock input while the piece walks

        boardView.hopToken(move.token.id, move.token.color, move.fromSteps, move.toSteps) {
            val result = engine.applyMove(move)
            boardView.snapToState(engine.state)

            when {
                result.gameWon -> SoundFx.win()
                result.capturedTokens.isNotEmpty() -> SoundFx.capture()
                else -> SoundFx.tokenMove()
            }
            render()
        }
    }

    private fun render() {
        val s = engine.state
        boardView.tappableTokenIds = pendingMoves.map { it.token.id }.toSet()

        val gameOver = s.phase == TurnPhase.GAME_OVER
        val activeColor = if (gameOver) null else s.currentPlayer.color

        for ((color, slot) in slots) {
            if (slot.root.visibility != View.VISIBLE) continue
            val isActive = color == activeColor
            slot.arrow.visibility = if (isActive) View.VISIBLE else View.INVISIBLE
            slot.dice.dimmed = !isActive
            slot.root.alpha = if (isActive) 1f else 0.55f
            slot.dice.isClickable = isActive && pendingMoves.isEmpty() && !rolling
        }

        if (s.lastDiceRoll != null && activeColor != null) {
            slots[activeColor]?.dice?.value = s.lastDiceRoll!!
        }

        hintText.text = when {
            gameOver -> {
                val winner = s.players.firstOrNull { it.id == s.rankings.firstOrNull() }
                "\uD83C\uDFC6 ${winner?.displayName ?: "-"} jeet gaya!"
            }
            pendingMoves.isNotEmpty() -> "Apni goti par tap karein"
            else -> "Apna dice tap karke roll karein"
        }
    }
}
