package com.example.ludoroyale

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.Move
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.Token

/**
 * PHASE 1e — local "pass and play" multiplayer (2-4 human players on ONE
 * phone) on the real animated board, with a rolling-dice animation shown
 * on a real pip-dice face (DiceView), and simple sound feedback. Offline.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var engine: LudoEngine
    private lateinit var statusText: TextView
    private lateinit var diceView: DiceView
    private lateinit var boardView: LudoBoardView
    private lateinit var setupPanel: View
    private lateinit var gamePanel: View
    private lateinit var rollButton: Button

    private var pendingMoves: List<Move> = emptyList()
    private val playerNames = listOf("Player 1", "Player 2", "Player 3", "Player 4")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        gamePanel = findViewById(R.id.gamePanel)
        statusText = findViewById(R.id.statusText)
        diceView = findViewById(R.id.diceView)
        boardView = findViewById(R.id.boardView)
        rollButton = findViewById(R.id.rollButton)

        findViewById<Button>(R.id.btn2Players).setOnClickListener { startGame(2) }
        findViewById<Button>(R.id.btn3Players).setOnClickListener { startGame(3) }
        findViewById<Button>(R.id.btn4Players).setOnClickListener { startGame(4) }

        boardView.onTokenTapped = { token -> handleTokenTap(token) }
        rollButton.setOnClickListener { handleRoll() }
    }

    private fun startGame(playerCount: Int) {
        val colors = PlayerColor.forPlayerCount(playerCount)
        val players = colors.mapIndexed { i, color ->
            Player.create("p${i + 1}", playerNames[i], color, PlayerKind.HUMAN)
        }.toMutableList()

        engine = LudoEngine(GameState(gameId = "local-multiplayer", players = players))
        boardView.state = engine.state
        pendingMoves = emptyList()

        setupPanel.visibility = View.GONE
        gamePanel.visibility = View.VISIBLE
        render()
    }

    private fun handleRoll() {
        val s = engine.state
        if (s.phase != TurnPhase.AWAITING_ROLL) return

        rollButton.isEnabled = false
        val finalRoll = engine.rollDice() // authoritative result decided now; only the reveal is animated
        animateDiceReveal(remaining = 8, finalValue = finalRoll)
    }

    /** Cycles random faces briefly before landing on the real (already-decided) roll — just visual flavor. */
    private fun animateDiceReveal(remaining: Int, finalValue: Int) {
        if (remaining <= 0) {
            diceView.value = finalValue
            SoundFx.diceRoll()
            onDiceRevealed(finalValue)
            return
        }
        diceView.value = (1..6).random()
        diceView.postDelayed({ animateDiceReveal(remaining - 1, finalValue) }, 55)
    }

    private fun onDiceRevealed(roll: Int) {
        pendingMoves = engine.legalMoves(roll)
        if (pendingMoves.isEmpty()) {
            engine.passTurn()
            pendingMoves = emptyList()
        }
        rollButton.isEnabled = true
        render()
    }

    private fun handleTokenTap(token: Token) {
        val move = pendingMoves.firstOrNull { it.token.id == token.id } ?: return
        val result = engine.applyMove(move)
        pendingMoves = emptyList()

        when {
            result.gameWon -> SoundFx.win()
            result.capturedTokens.isNotEmpty() -> SoundFx.capture()
            else -> SoundFx.tokenMove()
        }

        render()
    }

    private fun render() {
        val s = engine.state
        boardView.state = s
        boardView.tappableTokenIds = pendingMoves.map { it.token.id }.toSet()
        diceView.value = s.lastDiceRoll ?: diceView.value

        statusText.text = when {
            s.phase == TurnPhase.GAME_OVER -> {
                val winner = s.players.firstOrNull { it.id == s.rankings.firstOrNull() }
                "Game over! Winner: ${winner?.displayName ?: "-"} (${winner?.color})"
            }
            pendingMoves.isNotEmpty() ->
                "${s.currentPlayer.displayName}'s turn (${s.currentPlayer.color}) — tap a highlighted token"
            else ->
                "${s.currentPlayer.displayName}'s turn (${s.currentPlayer.color}) — roll the dice"
        }
    }
}
