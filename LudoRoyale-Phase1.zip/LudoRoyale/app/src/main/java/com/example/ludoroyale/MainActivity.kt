package com.example.ludoroyale

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ludoroyale.ai.LudoAI
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoEngine
import com.example.ludoroyale.engine.TurnPhase
import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind

/**
 * PHASE 1 PLACEHOLDER SCREEN.
 * This is intentionally NOT the premium home/board UI from the spec
 * (sections 7-11) — it exists only to prove the rule engine drives a
 * real, playable game end-to-end (human vs 1 AI, text-only).
 * Board rendering, animations, sounds, and the real home screen are
 * the next slice of Phase 1 work.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var engine: LudoEngine
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val rollButton = findViewById<Button>(R.id.rollButton)

        val human = Player.create("p1", "You", PlayerColor.RED, PlayerKind.HUMAN)
        val ai = Player.create("p2", "AI", PlayerColor.YELLOW, PlayerKind.AI_MEDIUM)
        engine = LudoEngine(GameState(gameId = "local-vs-ai", players = mutableListOf(human, ai)))

        rollButton.setOnClickListener { takeTurn() }
        render()
    }

    private fun takeTurn() {
        val roll = engine.rollDice()
        val moves = engine.legalMoves(roll)
        if (moves.isEmpty()) {
            engine.passTurn()
        } else {
            val player = engine.state.currentPlayer
            val chosen = if (player.kind == PlayerKind.HUMAN) moves.first() // TODO: real tap-to-select UI
                         else LudoAI.chooseMove(player.kind, moves)
            engine.applyMove(chosen)
        }
        render()

        // Auto-play the AI's turn(s) so the loop is demonstrably playable end to end.
        while (engine.state.phase != TurnPhase.GAME_OVER && engine.state.currentPlayer.kind != PlayerKind.HUMAN) {
            val aiRoll = engine.rollDice()
            val aiMoves = engine.legalMoves(aiRoll)
            if (aiMoves.isEmpty()) engine.passTurn()
            else engine.applyMove(LudoAI.chooseMove(engine.state.currentPlayer.kind, aiMoves))
            render()
        }
    }

    private fun render() {
        val s = engine.state
        statusText.text = if (s.phase == TurnPhase.GAME_OVER) {
            "Game over! Winner: ${s.rankings.firstOrNull()}"
        } else {
            "Turn: ${s.currentPlayer.displayName} (${s.currentPlayer.color})  " +
                "Last roll: ${s.lastDiceRoll ?: "-"}"
        }
    }
}
