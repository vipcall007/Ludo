package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.Token
import com.example.ludoroyale.model.TokenState

/**
 * Deterministic, UI-independent Ludo rules engine (spec section 5).
 * The identical instance/logic is meant to back offline play, AI play,
 * and — on a server — authoritative online play. Nothing here touches
 * Android APIs, so it is trivially unit-testable (spec section 39).
 *
 * Usage:
 *   val engine = LudoEngine(state, RuleConfig())
 *   val roll = engine.rollDice()
 *   val moves = engine.legalMoves(roll)
 *   val result = engine.applyMove(moves.first())
 */
class LudoEngine(
    val state: GameState,
    val rules: RuleConfig = RuleConfig(),
    private val dice: DiceRoller = DiceRoller()
) {

    /** Rolls the dice for the current player. Server-authoritative — never trust a client-supplied roll. */
    fun rollDice(): Int {
        check(state.phase == TurnPhase.AWAITING_ROLL) { "Not awaiting a roll." }
        val value = dice.roll()
        state.lastDiceRoll = value
        state.consecutiveSixes = if (value == 6) state.consecutiveSixes + 1 else 0
        state.phase = TurnPhase.AWAITING_MOVE
        return value
    }

    /** All legal moves for the current player given the last dice roll. Empty list = forced pass. */
    fun legalMoves(roll: Int = state.lastDiceRoll ?: error("No dice roll recorded")): List<Move> {
        val player = state.currentPlayer
        if (rules.threeSixCancelsTurn && state.consecutiveSixes >= 3) return emptyList()

        val moves = mutableListOf<Move>()
        for (token in player.tokens) {
            when (token.state) {
                TokenState.BASE -> {
                    val canLeave = !rules.sixRequiredToLeaveBase || roll == 6
                    if (canLeave) {
                        moves += Move(token, fromSteps = 0, toSteps = 1, leavesBase = true)
                    }
                }
                TokenState.ACTIVE, TokenState.HOME_STRETCH -> {
                    val target = token.steps + roll
                    if (target > FINISH_STEPS) continue // overshoot, illegal
                    if (target == FINISH_STEPS) {
                        moves += Move(token, token.steps, target, finishesToken = true)
                        continue
                    }
                    if (!rules.exactRollToFinish && target > FINISH_STEPS) continue

                    val entersHome = token.steps <= LudoBoard.TRACK_LENGTH - 1 && target > LudoBoard.TRACK_LENGTH - 1
                    val captured = if (target <= LudoBoard.TRACK_LENGTH - 1) capturablesAt(player, target) else emptyList()
                    moves += Move(
                        token = token,
                        fromSteps = token.steps,
                        toSteps = target,
                        capturesTokenIds = captured.map { it.id },
                        entersHomeStretch = entersHome
                    )
                }
                TokenState.FINISHED -> Unit
            }
        }
        return moves
    }

    /** Applies a chosen move, mutates state, advances/keeps turn per the rules, and reports the outcome. */
    fun applyMove(move: Move): MoveResult {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        val player = state.currentPlayer

        val capturedTokens = mutableListOf<Token>()
        if (move.capturesTokenIds.isNotEmpty()) {
            for (id in move.capturesTokenIds) {
                val ownerAndToken = state.players
                    .flatMap { p -> p.tokens.map { p to it } }
                    .firstOrNull { it.second.id == id }
                ownerAndToken?.second?.let { victim ->
                    victim.resetToBase()
                    capturedTokens += victim
                }
            }
        }

        move.token.steps = move.toSteps
        move.token.state = when {
            move.finishesToken -> TokenState.FINISHED
            move.toSteps > LudoBoard.TRACK_LENGTH - 1 -> TokenState.HOME_STRETCH
            else -> TokenState.ACTIVE
        }

        var gameWon = false
        if (move.finishesToken) {
            player.finishedCount++
            if (player.finishedCount >= Player.TOKENS_PER_PLAYER) {
                player.hasWon = true
                state.rankings += player.id
                gameWon = state.rankings.size >= state.players.size - 1 // last player auto-ranked
            }
        }

        val earnsExtraTurn =
            (rules.extraTurnOnSix && state.lastDiceRoll == 6 && !(rules.threeSixCancelsTurn && state.consecutiveSixes >= 3)) ||
            (rules.captureGrantsExtraTurn && capturedTokens.isNotEmpty())

        if (gameWon) {
            state.phase = TurnPhase.GAME_OVER
        } else {
            advanceTurn(keepSamePlayer = earnsExtraTurn)
        }

        return MoveResult(
            move = move,
            capturedTokens = capturedTokens,
            extraTurn = earnsExtraTurn && !gameWon,
            gameWon = gameWon,
            winnerPlayerId = if (gameWon) player.id else null
        )
    }

    /** Call when [legalMoves] is empty — forfeits the turn without a move. */
    fun passTurn() {
        check(state.phase == TurnPhase.AWAITING_MOVE) { "Not awaiting a move." }
        advanceTurn(keepSamePlayer = false)
    }

    private fun advanceTurn(keepSamePlayer: Boolean) {
        if (!keepSamePlayer) {
            var next = (state.currentPlayerIndex + 1) % state.players.size
            var guard = 0
            while (state.players[next].hasWon && guard < state.players.size) {
                next = (next + 1) % state.players.size
                guard++
            }
            state.currentPlayerIndex = next
            state.consecutiveSixes = 0
        }
        state.lastDiceRoll = null
        state.phase = TurnPhase.AWAITING_ROLL
    }

    /** Opponent (non-safe-cell) tokens standing on the shared-track cell the mover would land on. */
    private fun capturablesAt(mover: Player, targetSteps: Int): List<Token> {
        val globalIndex = LudoBoard.toGlobalIndex(mover.color, targetSteps - 1)
        if (rules.safeCellsBlockCapture && LudoBoard.isSafeCell(globalIndex)) return emptyList()
        return state.players
            .filter { it.id != mover.id }
            .flatMap { it.tokens }
            .filter { it.state == TokenState.ACTIVE }
            .filter { LudoBoard.toGlobalIndex(it.color, it.steps - 1) == globalIndex }
    }

    companion object {
        /** Total pips from just-left-base to finished: 51 shared-track steps + 6 home-column steps. */
        const val FINISH_STEPS = 57
    }
}
