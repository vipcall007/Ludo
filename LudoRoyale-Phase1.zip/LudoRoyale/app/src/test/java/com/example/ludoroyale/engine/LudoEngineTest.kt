package com.example.ludoroyale.engine

import com.example.ludoroyale.model.Player
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.PlayerKind
import com.example.ludoroyale.model.TokenState
import org.junit.Assert.*
import org.junit.Test

class LudoEngineTest {

    private fun twoPlayerState(): GameState {
        val red = Player.create("p1", "Red Player", PlayerColor.RED, PlayerKind.HUMAN)
        val yellow = Player.create("p2", "Yellow Player", PlayerColor.YELLOW, PlayerKind.AI_EASY)
        return GameState(gameId = "test", players = mutableListOf(red, yellow))
    }

    @Test
    fun `token cannot leave base without a six`() {
        val state = twoPlayerState()
        val engine = LudoEngine(state, RuleConfig(sixRequiredToLeaveBase = true))
        val moves = engine.legalMoves(roll = 4)
        assertTrue("No token should be able to leave base on a non-six", moves.isEmpty())
    }

    @Test
    fun `token leaves base on a six`() {
        val state = twoPlayerState()
        val engine = LudoEngine(state, RuleConfig())
        val moves = engine.legalMoves(roll = 6)
        assertEquals(4, moves.size) // all 4 base tokens can leave
        val result = engine.applyMove(moves[0])
        assertEquals(TokenState.ACTIVE, moves[0].token.state)
        assertEquals(1, moves[0].token.steps)
        assertTrue("Rolling a six grants an extra turn", result.extraTurn)
    }

    @Test
    fun `capture sends opponent token back to base and grants extra turn`() {
        val state = twoPlayerState()
        val engine = LudoEngine(state, RuleConfig())

        val redToken = state.players[0].tokens[0]
        redToken.state = TokenState.ACTIVE
        redToken.steps = 5 // global index 4 (RED start offset 0)

        val yellowToken = state.players[1].tokens[0]
        yellowToken.state = TokenState.ACTIVE
        // Put yellow token on the same global cell (index 4) as red.
        // Yellow startOffset=26, so steps s => global (26+s-1)%52 == 4  =>  s = 4-26+1+52 = 31
        yellowToken.steps = 31

        state.currentPlayerIndex = 0
        state.lastDiceRoll = 2
        state.phase = TurnPhase.AWAITING_MOVE

        val moves = engine.legalMoves(roll = 2)
        val captureMove = moves.first { it.token.id == redToken.id }
        assertTrue(captureMove.capturesTokenIds.contains(yellowToken.id))

        val result = engine.applyMove(captureMove)
        assertEquals(TokenState.BASE, yellowToken.state)
        assertEquals(0, yellowToken.steps)
        assertTrue(result.extraTurn)
    }

    @Test
    fun `exact roll required to finish, overshoot is illegal`() {
        val state = twoPlayerState()
        val engine = LudoEngine(state, RuleConfig())
        val token = state.players[0].tokens[0]
        token.state = TokenState.HOME_STRETCH
        token.steps = 55 // needs exactly 2 to finish (57)

        val overshoot = engine.legalMoves(roll = 4)
        assertTrue(overshoot.none { it.token.id == token.id })

        val exact = engine.legalMoves(roll = 2)
        val finishMove = exact.first { it.token.id == token.id }
        assertTrue(finishMove.finishesToken)
        engine.applyMove(finishMove)
        assertEquals(TokenState.FINISHED, token.state)
        assertEquals(1, state.players[0].finishedCount)
    }

    @Test
    fun `three consecutive sixes forfeits the turn`() {
        val state = twoPlayerState()
        state.consecutiveSixes = 3
        val engine = LudoEngine(state, RuleConfig(threeSixCancelsTurn = true))
        val moves = engine.legalMoves(roll = 6)
        assertTrue(moves.isEmpty())
    }

    @Test
    fun `turn advances to next non-winning player when no extra turn earned`() {
        val state = twoPlayerState()
        val engine = LudoEngine(state, RuleConfig())
        state.lastDiceRoll = 3
        state.phase = TurnPhase.AWAITING_MOVE
        val token = state.players[0].tokens[0]
        token.state = TokenState.ACTIVE
        token.steps = 10
        val move = Move(token, fromSteps = 10, toSteps = 13)
        engine.applyMove(move)
        assertEquals(1, state.currentPlayerIndex)
        assertEquals(TurnPhase.AWAITING_ROLL, state.phase)
    }
}
