# Ludo Royale — Phase 1 (Offline Rule Engine)

## What's actually working right now
A complete, UI-independent Ludo **rules engine** in Kotlin — the piece every other
phase (AI, local multiplayer, online sync) depends on:

- `model/` — `PlayerColor`, `Token`, `Player` (pure data, no Android deps)
- `engine/` — `LudoBoard` (52-cell track + safe cells + home stretch geometry),
  `RuleConfig` (toggleable rules: extra turn on six, 3-six forfeit, capture
  extra turn, exact-roll-to-finish, safe-cell capture blocking...),
  `DiceRoller` (SecureRandom, unbiased, never favors anyone),
  `LudoEngine` (roll → legalMoves → applyMove → turn advance / win detection)
- `ai/LudoAI.kt` — Easy (random legal move), Medium/Hard (heuristic scoring:
  captures > finishing > home-stretch entry > leaving base). The AI is only
  ever given the same `List<Move>` a human would see — it cannot cheat.
- `MainActivity.kt` — a bare, text-only screen that plays a full human-vs-AI
  game end to end through the real engine (roll, move, capture, win). This is
  **not** the premium UI from the spec — it exists to prove the engine is
  actually wired to something runnable, per "don't stop at a mockup."
- `LudoEngineTest.kt` — 6 JUnit tests covering: can't leave base without a six,
  leaving base on six, capture + extra turn, exact-roll-to-finish (overshoot
  rejected), three-consecutive-sixes forfeit, normal turn advancement.

## Getting an actual APK on your phone (no coding needed)
A `.github/workflows/build-apk.yml` file is included — it builds the APK
automatically in the cloud when you upload this project to GitHub. Steps are
in the chat reply.

## Phase 1b update — real visible board
Added: `BoardGeometry.kt` (classic 15x15 cross-board coordinate mapping),
`LudoBoardView.kt` (Canvas-drawn board: 4 colored home squares, 52-cell ring,
safe-cell markers, colored home stretches, center pinwheel, circular tokens,
tap-to-move with yellow highlight on legal tokens). `MainActivity.kt` now
wires taps on the real board to the engine instead of auto-picking moves.
Still original artwork — nothing copied from any reference app.
Not yet done: dice-roll animation, token-slide animation, sound.

## Phase 1c update — local pass-and-play (2-4 players, one phone)
Added a setup screen: pick 2, 3, or 4 players, then everyone takes turns
passing the same phone. No AI needed for this mode — Ludo has no hidden
information, so this is fair and simple. `MainActivity.kt` now creates
that many `PlayerKind.HUMAN` players and the real board drives it.
Not yet done: dice-roll animation, token-slide animation, sound,
"pass to next player" confirmation screen (optional nicety, not required).

## Phase 1d update — animation + sound
Tokens now slide (animated, ~260ms) between positions instead of jumping.
Dice shows a quick random-cycling animation before landing on the real
(already-decided) result. Added `SoundFx.kt` — short original beep tones
via Android's built-in ToneGenerator for dice/move/capture/win (no external
audio files needed, nothing copied).

## Phase 1e update — closer to a "real board" look
Added `DiceView.kt` — dice now shows real pip dots (like a physical die),
not a plain digit. Safe cells now draw as a yellow star instead of a plain
gray dot. Compared against reference screenshots the person shared —
matched the dice-face and star-cell look; didn't copy any art files
(everything above is drawn in code).

## Bugfix — MainActivity out of sync with new box-by-box board API
LudoBoardView was upgraded to move tokens box-by-box (snapToState / hopToken)
but MainActivity.kt still tried the old direct `boardView.state = ...`
assignment, which no longer compiles (state's setter is now private by
design). Rewrote MainActivity to use snapToState (initial/instant sync) and
hopToken (animated box-by-box move, then snap to the true post-move state —
this is also what naturally resets a captured token back to its base).

## Visual overhaul — matching the reference screenshots more closely
Compared my build's screenshot against the reference game's screenshots the
person shared, and closed the gaps that were actually closable in code:
- Board: wooden/orange rounded frame, white playfield, circular home yards
  (were plain white squares), gray star safe cells, white travel-direction
  chevrons on each color's entry cell.
- Tokens: styled piece (colored disc + white ring + colored star + drop
  shadow) instead of a flat circle. Stacked pieces now show a numbered
  badge, and two colors sharing a safe cell are drawn offset — so you can
  always tell how many pieces are on a square.
- Players: each player now sits at their own corner of the board with an
  avatar (color-tinted ring) + name + their OWN dice, top players rotated
  180° so they face the board — replaces the single status-text line.
- Rolling: tap your own dice to roll (no separate button); the dice shakes
  and spins through random faces before landing on the real result, with a
  green arrow marking whose turn it is and inactive dice dimmed.
- Movement: a soft step tick on each box as the piece walks.
All drawn in code; no artwork, sound, or code copied from the reference app.
Still not matched (would need an artist / real asset pipeline): painted
3D artwork, gradient backgrounds, character illustrations, animated
victory sequences, and the reference's globe/decorative path icons.

## Honest caveats
- **This was not compiled.** The sandbox that wrote this code has no network
  access, so it can't download the Android Gradle Plugin, Kotlin compiler, or
  Gradle wrapper jar to actually build/run it. Open it in Android Studio and
  hit Sync — that's the first real build/test pass. I re-read every file by
  hand for syntax/logic errors, but treat that as "should compile," not "did compile."
- **No launcher icon** — `AndroidManifest.xml` points at `@mipmap/ic_launcher`,
  which doesn't exist yet. Use Android Studio's Image Asset tool (right-click
  `res` → New → Image Asset) before your first build or it'll fail on that.
- **No gradlew wrapper jar** — Android Studio will offer to generate one on
  first open; let it.
- 4-player and 3-player games, team mode pairing, and the online-sync layer
  (server, matchmaking, reconnect) aren't built yet — the engine's `GameState`
  is already the exact object a server would serialize/broadcast, so that
  layer plugs in without changing engine logic.

## Suggested next slices (small, testable, in order)
1. Real board rendering (Canvas/Compose) + tap-to-select tokens, replacing
   the text placeholder screen — sections 7-9 of the spec.
2. Local multiplayer (3-4 players, same device, pass-and-play).
3. Coins/XP/profile persistence (Room database) + daily reward + missions.
4. Server-authoritative online play: this is the point where I'd need you to
   provide a backend target (Firebase project, or a server you control) —
   see spec section 45/46. I won't pretend one is already configured.

## Scope note on the original master prompt
The uploaded spec asks for a full commercial-grade game (online multiplayer,
matchmaking, private rooms, chat, monetization architecture, Play Store
release) — that's realistically weeks of work, not one response. I built the
foundation everything else stacks on and I'm stopping here to check in before
going further, per the spec's own "build in phases, don't dump everything
at once" instruction (section 40/45).
