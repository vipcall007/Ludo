# Ludo Royale — Phase 1 (Offline Rule Engine)

## What's actually working right now
A complete, UI-independent Ludo **rules engine** in Kotlin — the piece every other
phase (AI, local multiplayer, online sync) depends on:

- `model/` — `PlayerColor`, `Token`, `Player` (pure data, no Android deps)
- `engine/` — `LudoBoard` (52-cell track + safe cells + home stretch geometry),
  `RuleConfig` (toggleable rules: extra turn on six, 3-six forfeit, capture
  extra turn, exact-roll-to-finish, safe-cell capture blocking...),
  `DiceRoller` (SecureRandom, unbiased, never favors anyone),
  `LudoEngine` (roll → legalMoves → applyMove → turn advance / win detection)
- `ai/LudoAI.kt` — Easy (random legal move), Medium/Hard (heuristic scoring:
  captures > finishing > home-stretch entry > leaving base). The AI is only
  ever given the same `List<Move>` a human would see — it cannot cheat.
- `MainActivity.kt` — a bare, text-only screen that plays a full human-vs-AI
  game end to end through the real engine (roll, move, capture, win). This is
  **not** the premium UI from the spec — it exists to prove the engine is
  actually wired to something runnable, per "don't stop at a mockup."
- `LudoEngineTest.kt` — 6 JUnit tests covering: can't leave base without a six,
  leaving base on six, capture + extra turn, exact-roll-to-finish (overshoot
  rejected), three-consecutive-sixes forfeit, normal turn advancement.

## Getting an actual APK on your phone (no coding needed)
A `.github/workflows/build-apk.yml` file is included — it builds the APK
automatically in the cloud when you upload this project to GitHub. Steps are
in the chat reply.

## Honest caveats
- **This was not compiled.** The sandbox that wrote this code has no network
  access, so it can't download the Android Gradle Plugin, Kotlin compiler, or
  Gradle wrapper jar to actually build/run it. Open it in Android Studio and
  hit Sync — that's the first real build/test pass. I re-read every file by
  hand for syntax/logic errors, but treat that as "should compile," not "did compile."
- **No launcher icon** — `AndroidManifest.xml` points at `@mipmap/ic_launcher`,
  which doesn't exist yet. Use Android Studio's Image Asset tool (right-click
  `res` → New → Image Asset) before your first build or it'll fail on that.
- **No gradlew wrapper jar** — Android Studio will offer to generate one on
  first open; let it.
- 4-player and 3-player games, team mode pairing, and the online-sync layer
  (server, matchmaking, reconnect) aren't built yet — the engine's `GameState`
  is already the exact object a server would serialize/broadcast, so that
  layer plugs in without changing engine logic.

## Suggested next slices (small, testable, in order)
1. Real board rendering (Canvas/Compose) + tap-to-select tokens, replacing
   the text placeholder screen — sections 7-9 of the spec.
2. Local multiplayer (3-4 players, same device, pass-and-play).
3. Coins/XP/profile persistence (Room database) + daily reward + missions.
4. Server-authoritative online play: this is the point where I'd need you to
   provide a backend target (Firebase project, or a server you control) —
   see spec section 45/46. I won't pretend one is already configured.

## Scope note on the original master prompt
The uploaded spec asks for a full commercial-grade game (online multiplayer,
matchmaking, private rooms, chat, monetization architecture, Play Store
release) — that's realistically weeks of work, not one response. I built the
foundation everything else stacks on and I'm stopping here to check in before
going further, per the spec's own "build in phases, don't dump everything
at once" instruction (section 40/45).
