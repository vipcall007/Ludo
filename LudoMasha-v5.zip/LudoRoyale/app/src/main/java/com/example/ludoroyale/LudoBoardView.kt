package com.example.ludoroyale

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ludoroyale.engine.GameState
import com.example.ludoroyale.engine.LudoBoard
import com.example.ludoroyale.model.PlayerColor
import com.example.ludoroyale.model.Token
import kotlin.math.min

/**
 * Draws the classic Ludo cross board (wooden frame, circular home yards,
 * arrow-shaped home stretches, star safe cells, direction arrows) plus
 * styled tokens with stack counts, and moves tokens box-by-box.
 * Everything is drawn in code — no copied artwork.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: GameState? = null
        private set

    var tappableTokenIds: Set<String> = emptySet()
        set(value) {
            field = value
            if (value.isEmpty()) stopPulse() else startPulse()
            invalidate()
        }

    // Movable pieces breathe in and out so the player can spot them instantly.
    private var pulse = 1f
    private var pulseUp = true
    private var pulsing = false

    private val pulseTick = object : Runnable {
        override fun run() {
            if (!pulsing) return
            pulse += if (pulseUp) 0.022f else -0.022f
            if (pulse >= 1.18f) { pulse = 1.18f; pulseUp = false }
            if (pulse <= 1.0f) { pulse = 1.0f; pulseUp = true }
            invalidate()
            postDelayed(this, 32)
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        pulse = 1f
        pulseUp = true
        post(pulseTick)
    }

    private fun stopPulse() {
        pulsing = false
        pulse = 1f
        removeCallbacks(pulseTick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopPulse()   // don't keep ticking after the view is gone
    }

    var onTokenTapped: ((Token) -> Unit)? = null

    /** Draw ARROW-MODE shortcut arrows on the track. */
    var arrowMode: Boolean = false
        set(value) { field = value; invalidate() }

    private val displayedCenters = mutableMapOf<String, Pair<Float, Float>>()

    /** Token currently vanishing/reappearing for an ARROW-MODE magic jump. */
    private var fadingTokenId: String? = null
    private var fadeAlpha: Float = 1f

    /**
     * ARROW MODE magic move: the piece puffs out at the arrow's start and
     * reappears where the arrow ends, instead of walking the gap.
     */
    fun magicTeleport(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit) {
        fadingTokenId = tokenId
        fadeOut(tokenId, color, toSteps, onComplete, 1f)
    }

    private fun fadeOut(tokenId: String, color: PlayerColor, toSteps: Int, onComplete: () -> Unit, a: Float) {
        if (a <= 0.05f) {
            // reappear at the arrow's end
            displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, toSteps)
            fadeIn(tokenId, onComplete, 0f)
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeOut(tokenId, color, toSteps, onComplete, a - 0.16f) }, 34)
    }

    private fun fadeIn(tokenId: String, onComplete: () -> Unit, a: Float) {
        if (a >= 1f) {
            fadeAlpha = 1f
            fadingTokenId = null
            invalidate()
            onComplete()
            return
        }
        fadeAlpha = a
        invalidate()
        postDelayed({ fadeIn(tokenId, onComplete, a + 0.16f) }, 34)
    }

    /** Instantly syncs the board to [newState] (game start, or after a hop lands). */
    fun snapToState(newState: GameState) {
        state = newState
        displayedCenters.clear()
        for (player in newState.players) {
            for ((i, token) in player.tokens.withIndex()) {
                displayedCenters[token.id] = BoardGeometry.centerOf(token, i)
            }
        }
        invalidate()
    }

    /** Moves one token cell-by-cell from [fromSteps] to [toSteps], then calls [onComplete]. */
    fun hopToken(tokenId: String, color: PlayerColor, fromSteps: Int, toSteps: Int, onComplete: () -> Unit) {
        val hops: List<Int> = if (fromSteps <= 0) listOf(toSteps) else (fromSteps + 1..toSteps).toList()
        hopSequence(tokenId, color, hops, 0, onComplete)
    }

    private fun hopSequence(tokenId: String, color: PlayerColor, hops: List<Int>, index: Int, onComplete: () -> Unit) {
        if (index >= hops.size) { onComplete(); return }
        displayedCenters[tokenId] = BoardGeometry.centerForSteps(color, hops[index])
        invalidate()
        SoundFx.step()
        postDelayed({ hopSequence(tokenId, color, hops, index + 1, onComplete) }, 130)
    }

    // ---- geometry ----
    private var cell = 0f
    private var frame = 0f

    private fun px(col: Float) = frame + col * cell
    private fun py(row: Float) = frame + row * cell
    private fun rect(r0: Float, c0: Float, r1: Float, c1: Float) =
        RectF(px(c0), py(r0), px(c1), py(r1))

    // ---- paints ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xBD, 0xBD, 0xBD)
        strokeWidth = 1.5f
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(0xFF, 0xEB, 0x3B)
        strokeWidth = 6f
    }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0x21, 0x21, 0x21)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val arrowOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f
        strokeJoin = Paint.Join.ROUND
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(120, 0x61, 0x61, 0x61)
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private fun colorOf(c: PlayerColor): Int = when (c) {
        PlayerColor.RED -> Color.rgb(0xE5, 0x30, 0x35)
        PlayerColor.GREEN -> Color.rgb(0x22, 0xA6, 0x4B)
        PlayerColor.YELLOW -> Color.rgb(0xFA, 0xBF, 0x16)
        PlayerColor.BLUE -> Color.rgb(0x16, 0x8D, 0xE8)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val size = min(w, h).toFloat()
        frame = size * 0.028f
        cell = (size - 2 * frame) / BoardGeometry.GRID_SIZE
        badgeText.textSize = cell * 0.46f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        drawFrame(canvas)
        drawHomeYards(canvas)
        drawTrack(canvas)
        drawHomeStretches(canvas)
        drawCenterArrows(canvas)
        drawTokens(canvas)
    }

    /** Wooden outer frame + white playfield. */
    private fun drawFrame(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val r = size * 0.05f
        fill.color = Color.rgb(0xD2, 0x8C, 0x45)
        canvas.drawRoundRect(RectF(0f, 0f, size, size), r, r, fill)
        fill.color = Color.rgb(0xE8, 0xA8, 0x64)
        canvas.drawRoundRect(RectF(frame * 0.35f, frame * 0.35f, size - frame * 0.35f, size - frame * 0.35f), r, r, fill)
        fill.color = Color.WHITE
        canvas.drawRect(RectF(px(0f), py(0f), px(15f), py(15f)), fill)
    }

    /** The four colored corner yards, each with a white circle holding the 4 base slots. */
    private fun drawHomeYards(canvas: Canvas) {
        for ((color, box) in BoardGeometry.HOME_SQUARES) {
            val r0 = box[0].toFloat(); val c0 = box[1].toFloat()
            val r1 = (box[2] + 1).toFloat(); val c1 = (box[3] + 1).toFloat()

            fill.color = colorOf(color)
            canvas.drawRect(rect(r0, c0, r1, c1), fill)

            // white circle in the middle of the yard
            val cx = px((c0 + c1) / 2f)
            val cy = py((r0 + r1) / 2f)
            val radius = cell * 2.1f
            canvas.drawCircle(cx + cell * 0.06f, cy + cell * 0.09f, radius, shadow)
            fill.color = Color.WHITE
            canvas.drawCircle(cx, cy, radius, fill)
        }
    }

    /** The 52-cell outer ring: white cells, colored start cells, star safe cells, direction arrows. */
    private fun drawTrack(canvas: Canvas) {
        for ((idx, rc) in BoardGeometry.RING.withIndex()) {
            val r = rc.first.toFloat(); val c = rc.second.toFloat()
            var startColor: PlayerColor? = null
            for (color in PlayerColor.entries) if (color.startOffset == idx) startColor = color

            fill.color = if (startColor != null) colorOf(startColor) else Color.WHITE
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), fill)
            canvas.drawRect(rect(r, c, r + 1f, c + 1f), gridLine)

            if (startColor != null) drawTravelArrow(canvas, idx)
            if (arrowMode && LudoBoard.arrowJumpAt(idx) != null) drawShortcutArrow(canvas, idx)
            if (LudoBoard.isSafeCell(idx)) {
                val starColor = if (startColor != null) Color.WHITE else Color.rgb(0x9E, 0x9E, 0x9E)
                drawStar(canvas, px(c + 0.5f), py(r + 0.5f), cell * 0.3f, starColor)
            }
        }
    }

    /** A chevron on a start cell showing which way tokens travel from there. */
    private fun drawTravelArrow(canvas: Canvas, idx: Int) {
        val here = BoardGeometry.RING[idx]
        val next = BoardGeometry.RING[(idx + 1) % BoardGeometry.RING.size]
        val dr = next.first - here.first
        val dc = next.second - here.second
        val cx = px(here.second + 0.5f)
        val cy = py(here.first + 0.5f)
        val s = cell * 0.22f

        arrowPaint.color = Color.argb(200, 255, 255, 255)
        val path = Path()
        // chevron pointing along (dr, dc)
        val tipX = cx + dc * s; val tipY = cy + dr * s
        val backX = cx - dc * s * 0.4f; val backY = cy - dr * s * 0.4f
        // perpendicular
        val pxv = -dr.toFloat(); val pyv = dc.toFloat()
        path.moveTo(backX + pxv * s * 0.8f, backY + pyv * s * 0.8f)
        path.lineTo(tipX, tipY)
        path.lineTo(backX - pxv * s * 0.8f, backY - pyv * s * 0.8f)
        canvas.drawPath(path, arrowPaint)
    }

    /**
     * ARROW-MODE marker drawn across the cells it actually covers: the shaft
     * starts on the arrow's own cell and the head sits on the cell the piece
     * will land on, so where it ends is never a guess.
     */
    private fun drawShortcutArrow(canvas: Canvas, idx: Int) {
        val jump = LudoBoard.arrowJumpAt(idx) ?: return
        val from = BoardGeometry.RING[idx]
        val to = BoardGeometry.RING[(idx + jump) % BoardGeometry.RING.size]

        val x0 = px(from.second + 0.5f)
        val y0 = py(from.first + 0.5f)
        val x1 = px(to.second + 0.5f)
        val y1 = py(to.first + 0.5f)

        // unit direction along the (straight) run
        val dx = if (x1 == x0) 0f else if (x1 > x0) 1f else -1f
        val dy = if (y1 == y0) 0f else if (y1 > y0) 1f else -1f
        val perpX = -dy
        val perpY = dx

        val headLen = cell * 0.85f
        val headHalf = cell * 0.36f
        val shaftHalf = cell * 0.15f

        // shaft stops where the head begins
        val hx = x1 - dx * headLen
        val hy = y1 - dy * headLen

        val path = Path()
        path.moveTo(x0 + perpX * shaftHalf, y0 + perpY * shaftHalf)
        path.lineTo(hx + perpX * shaftHalf, hy + perpY * shaftHalf)
        path.lineTo(hx + perpX * headHalf, hy + perpY * headHalf)
        path.lineTo(x1, y1)                                  // tip = landing cell
        path.lineTo(hx - perpX * headHalf, hy - perpY * headHalf)
        path.lineTo(hx - perpX * shaftHalf, hy - perpY * shaftHalf)
        path.lineTo(x0 - perpX * shaftHalf, y0 - perpY * shaftHalf)
        path.close()

        // dark outline then bright body, so it reads on white cells
        arrowOutline.color = Color.rgb(0xC1, 0x54, 0x00)
        canvas.drawPath(path, arrowOutline)
        fill.color = Color.rgb(0xFF, 0x8F, 0x00)
        canvas.drawPath(path, fill)

        // tail dot marks where the arrow begins
        fill.color = Color.rgb(0xFF, 0xCC, 0x66)
        canvas.drawCircle(x0, y0, cell * 0.13f, fill)
    }

    /** Star path using whatever colour/alpha is already set on [fill]. */
    private fun drawStarPath(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            path.let { p ->
                val x = cx + (rr * Math.cos(angle)).toFloat()
                val y = cy + (rr * Math.sin(angle)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outerR: Float, color: Int) {
        val innerR = outerR * 0.45f
        val path = Path()
        val points = 5
        for (i in 0 until points * 2) {
            val angle = (Math.PI / points) * i - Math.PI / 2
            val rr = if (i % 2 == 0) outerR else innerR
            val x = cx + (rr * Math.cos(angle)).toFloat()
            val y = cy + (rr * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    /** Each color's private path to home, drawn as one solid colored lane. */
    private fun drawHomeStretches(canvas: Canvas) {
        for ((color, cells) in BoardGeometry.STRETCH) {
            fill.color = colorOf(color)
            for ((r, c) in cells) {
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), fill)
                canvas.drawRect(rect(r.toFloat(), c.toFloat(), r + 1f, c + 1f), gridLine)
            }
        }
    }

    /** The four big arrowheads meeting at the center — the "win" zone. */
    private fun drawCenterArrows(canvas: Canvas) {
        val cx = px(7.5f); val cy = py(7.5f)
        fun tri(color: PlayerColor, p1r: Float, p1c: Float, p2r: Float, p2c: Float) {
            val path = Path()
            path.moveTo(px(p1c), py(p1r))
            path.lineTo(px(p2c), py(p2r))
            path.lineTo(cx, cy)
            path.close()
            fill.color = colorOf(color)
            canvas.drawPath(path, fill)
        }
        tri(PlayerColor.YELLOW, 6f, 6f, 6f, 9f)
        tri(PlayerColor.BLUE, 6f, 9f, 9f, 9f)
        tri(PlayerColor.RED, 9f, 9f, 9f, 6f)
        tri(PlayerColor.GREEN, 9f, 6f, 6f, 6f)
    }

    /**
     * Tokens, grouped so stacked pieces are obvious: one styled piece per
     * (cell, color) with a numbered badge when more than one sits there,
     * and a slight offset when two different colors share a safe cell.
     */
    /**
     * Every piece is drawn as its own piece — a pile of three shows three
     * discs fanned out, not one disc with a number on it. Movable pieces
     * gently grow and shrink so the player can see what they can play.
     */
    private fun drawTokens(canvas: Canvas) {
        val s = state ?: return

        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            val shrink = when {
                tokens.size >= 4 -> 0.62f
                tokens.size == 3 -> 0.70f
                tokens.size == 2 -> 0.80f
                else -> 1f
            }
            tokens.forEachIndexed { i, token ->
                val (ox, oy) = offsets[i]
                val faded = token.id == fadingTokenId
                val alpha = if (faded) fadeAlpha else 1f
                val tappable = token.id in tappableTokenIds
                val scale = shrink * if (tappable) pulse else 1f
                drawToken(
                    canvas,
                    px(col) + ox * cell,
                    py(row) + oy * cell,
                    token.color, alpha, tappable, scale
                )
            }
        }
    }

    /** Where each piece sits when several share one square. */
    private fun fanOffsets(count: Int): List<Pair<Float, Float>> = when (count) {
        0, 1 -> listOf(0f to 0f)
        2 -> listOf(-0.16f to 0f, 0.16f to 0f)
        3 -> listOf(0f to -0.17f, -0.17f to 0.13f, 0.17f to 0.13f)
        4 -> listOf(-0.16f to -0.16f, 0.16f to -0.16f, -0.16f to 0.16f, 0.16f to 0.16f)
        else -> {
            // 5+ : ring them around the cell centre
            val list = mutableListOf<Pair<Float, Float>>()
            for (i in 0 until count) {
                val angle = 2.0 * Math.PI * i / count
                list += (0.19f * Math.cos(angle).toFloat()) to (0.19f * Math.sin(angle).toFloat())
            }
            list
        }
    }

    private fun drawToken(
        canvas: Canvas, cx: Float, cy: Float,
        color: PlayerColor, alpha: Float, tappable: Boolean, scale: Float
    ) {
        if (alpha <= 0.02f) return
        val radius = cell * 0.36f * scale
        val a = (alpha * 255).toInt().coerceIn(0, 255)

        shadow.alpha = (60 * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx + radius * 0.14f, cy + radius * 0.22f, radius, shadow)
        shadow.alpha = 60

        // dark rim so overlapping pieces stay separate to the eye
        fill.color = Color.rgb(0x1E, 0x28, 0x32)
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 1.06f, fill)

        fill.color = colorOf(color)
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius, fill)

        fill.color = Color.WHITE
        fill.alpha = a
        canvas.drawCircle(cx, cy, radius * 0.66f, fill)

        fill.color = colorOf(color)
        fill.alpha = a
        drawStarPath(canvas, cx, cy, radius * 0.56f)
        fill.alpha = 255

        if (tappable) canvas.drawCircle(cx, cy, radius + 5f, highlight)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val s = state ?: return true
        if (cell <= 0f) return true

        // rebuild the same layout used for drawing, so taps hit what you see
        val byCell = LinkedHashMap<Pair<Int, Int>, MutableList<Token>>()
        for (player in s.players) {
            for (token in player.tokens) {
                val pos = displayedCenters[token.id] ?: continue
                val key = Math.round(pos.first * 2) to Math.round(pos.second * 2)
                byCell.getOrPut(key) { mutableListOf() }.add(token)
            }
        }

        var best: Token? = null
        var bestDist = Float.MAX_VALUE
        for ((key, tokens) in byCell) {
            val row = key.first / 2f
            val col = key.second / 2f
            val offsets = fanOffsets(tokens.size)
            tokens.forEachIndexed { i, token ->
                if (token.id !in tappableTokenIds) return@forEachIndexed
                val (ox, oy) = offsets[i]
                val dx = event.x - (px(col) + ox * cell)
                val dy = event.y - (py(row) + oy * cell)
                val dist = dx * dx + dy * dy
                if (dist < bestDist) { bestDist = dist; best = token }
            }
        }

        // copy to a local val: Kotlin cannot smart-cast a var written inside a lambda
        val chosen = best
        val touchRadius = cell * 0.8f
        if (chosen != null && bestDist <= touchRadius * touchRadius) {
            onTokenTapped?.invoke(chosen)
        }
        return true
    }
}
